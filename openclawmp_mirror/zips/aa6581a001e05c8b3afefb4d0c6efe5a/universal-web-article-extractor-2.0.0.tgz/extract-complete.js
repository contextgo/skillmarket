const fs = require('fs');
const path = require('path');
const os = require('os');
const { chromium } = require('playwright');

/**
 * 微信公众号文章完整提取器
 * 合并wechat-article-extractor + playwright-browser-automation功能
 */
class WeChatArticleExtractor {
  constructor(options = {}) {
    // 跨平台默认输出目录
    const getDefaultOutputDir = () => {
      const platform = os.platform();
      const homeDir = os.homedir();
      
      switch (platform) {
        case 'win32':
          return path.join(homeDir, 'Documents', 'Articles');
        case 'darwin':
          return path.join(homeDir, 'Documents', '文稿');
        case 'linux':
          return path.join(homeDir, 'Documents', 'Articles');
        default:
          return path.join(homeDir, 'Documents', 'Articles');
      }
    };
    
    this.options = {
      outputDir: options.outputDir || getDefaultOutputDir(),
      formats: options.formats || ['md', 'pdf'],
      pdfOptions: {
        format: 'A4',
        printBackground: true,
        margin: { top: '20mm', right: '15mm', bottom: '20mm', left: '15mm' },
        displayHeaderFooter: false,
        scale: 1.0,
        preferCSSPageSize: true,
        ...options.pdfOptions
      },
      extractOptions: {
        shouldReturnContent: true,
        shouldReturnRawMeta: false,
        shouldFollowTransferLink: true,
        shouldExtractMpLinks: false,
        shouldExtractTags: false,
        shouldExtractRepostMeta: false,
        ...options.extractOptions
      }
    };
    
    // 确保输出目录存在
    if (!fs.existsSync(this.options.outputDir)) {
      fs.mkdirSync(this.options.outputDir, { recursive: true });
    }
  }

  /**
   * 主要处理函数 - 完整流程
   */
  async processArticle(url, options = {}) {
    console.log('🚀 开始处理微信公众号文章...');
    console.log('📄 URL:', url);
    
    try {
      // 第1步：提取文章内容
      console.log('🔍 正在提取文章内容...');
      const extractResult = await this.extract(url, options.extractOptions || this.options.extractOptions);
      
      if (!extractResult.done) {
        throw new Error(`提取失败: ${extractResult.msg || '未知错误'}`);
      }
      
      const articleData = extractResult.data;
      console.log('✅ 文章提取成功');
      console.log('📋 标题:', articleData.msg_title);
      console.log('👤 作者:', articleData.msg_author || articleData.account_name);
      
      // 生成文件名 - 优化：直接使用文章原名，不加前缀和后缀
      const safeTitle = this.sanitizeFilename(articleData.msg_title);
      const baseFilename = safeTitle; // 直接使用文章原名
      const result = {
        data: articleData,
        files: [],
        title: articleData.msg_title,
        author: articleData.msg_author || articleData.account_name,
        publishTime: articleData.msg_publish_time_str
      };
      
      // 第2步：生成指定格式
      for (const format of this.options.formats) {
        console.log(`📝 正在生成${format.toUpperCase()}格式...`);
        
        switch (format) {
          case 'md':
            const mdPath = await this.generateMarkdown(articleData, baseFilename);
            result.files.push(mdPath);
            console.log(`✅ Markdown生成完成: ${mdPath}`);
            break;
            
          case 'pdf':
            const pdfPath = await this.generatePDF(articleData, baseFilename);
            result.files.push(pdfPath);
            console.log(`✅ PDF生成完成: ${pdfPath}`);
            break;
            
          case 'html':
            const htmlPath = await this.generateHTML(articleData, baseFilename);
            result.files.push(htmlPath);
            console.log(`✅ HTML生成完成: ${htmlPath}`);
            break;
        }
      }
      
      console.log('🎉 所有格式生成完成！');
      console.log('📁 生成文件:', result.files.join(', '));
      
      return result;
      
    } catch (error) {
      console.error('❌ 处理失败:', error.message);
      throw error;
    }
  }

  /**
   * 提取文章内容（复用wechat-article-extractor逻辑）
   */
  async extract(url, options = {}) {
    // 这里复用wechat-article-extractor的核心逻辑
    // 由于我们不能直接require那个模块，这里实现核心功能
    
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    try {
      console.log('🌐 正在访问文章页面...');
      // 根据URL类型选择不同的加载策略（基于实战经验）
      const loadingOptions = { timeout: 30000 };
      
      // 基于实战验证的慢加载网站列表
      const slowLoadingSites = [
        'runoob.com',      // 教程网站，内容较多
        'liumingye.cn',    // 工具网站，功能丰富
        'tool.liumingye.cn' // 工具箱网站，动态内容多
      ];
      
      const isSlowSite = slowLoadingSites.some(site => url.includes(site));
      
      if (isSlowSite) {
        // 对于加载较慢的网站，使用domcontentloaded策略
        loadingOptions.waitUntil = 'domcontentloaded';
        console.log('⚠️  检测到慢加载网站，使用宽松加载策略');
      } else if (url.includes('mp.weixin.qq.com')) {
        // 微信公众号使用网络空闲检测
        loadingOptions.waitUntil = 'networkidle';
        console.log('📱 微信公众号文章，使用网络空闲检测');
      } else {
        // 普通网站使用网络空闲检测
        loadingOptions.waitUntil = 'networkidle';
      }
      await page.goto(url, loadingOptions);
      
      // 等待内容加载
      await page.waitForSelector('#js_content', { timeout: 10000 }).catch(() => {
        console.log('⚠️ 主要内容区域加载超时，继续尝试...');
      });
      
      // 提取文章数据前，先处理页面动态内容
      console.log('🔍 正在处理页面动态内容...');
      
      // 等待并触发图片懒加载
      await page.evaluate(() => {
        // 滚动页面触发懒加载
        window.scrollTo(0, document.body.scrollHeight);
        window.scrollTo(0, 0);
      });
      
      // 等待图片加载
      await page.waitForTimeout(2000);
      
      // 处理图片懒加载
      await page.evaluate(() => {
        const contentElement = document.querySelector('#js_content');
        if (contentElement) {
          const images = contentElement.querySelectorAll('img');
          images.forEach(img => {
            // 处理data-src懒加载图片
            if (img.dataset.src) {
              img.src = img.dataset.src;
            }
            
            // 处理其他形式的懒加载
            if (img.dataset.original) {
              img.src = img.dataset.original;
            }
            
            // 移除占位符和懒加载相关class
            img.classList.remove('js_img_placeholder', 'wx_img_placeholder', 'rich_pages');
            
            // 清理data属性，避免混淆
            delete img.dataset.src;
            delete img.dataset.original;
            
            // 确保图片显示
            img.style.display = 'block';
            img.style.visibility = 'visible';
            img.style.opacity = '1';
          });
        }
      });
      
      // 再次等待图片加载完成
      await page.waitForTimeout(1000);
      
      // 提取文章数据
      console.log('🔍 正在提取文章数据...');
      
      // 判断是微信文章还是普通网页，选择对应的提取模式
      const isWeChat = url.includes('mp.weixin.qq.com');
      let articleData;
      
      if (isWeChat) {
        console.log('📱 使用微信公众号专用提取模式');
        articleData = await this.extractWeChatArticle(page, url);
      } else {
        console.log('🌐 使用通用网页提取模式');
        articleData = await this.extractGeneralWebPage(page, url);
      }
      
      await browser.close();
      
      if (!articleData.msg_title || !articleData.msg_content) {
        return { done: false, code: 1001, msg: '无法获取文章信息' };
      }
      
      return { done: true, code: 0, data: articleData };
      
    } catch (error) {
      await browser.close();
      return { done: false, code: 1002, msg: `请求失败: ${error.message}` };
    }
  }

  /**
   * 提取微信公众号文章（专用模式）
   */
  async extractWeChatArticle(page, url) {
    try {
      console.log('📱 检测到微信公众号文章，使用专用提取模式');
      
      // 等待微信内容加载
      await page.waitForSelector('#js_content', { timeout: 10000 }).catch(() => {
        console.log('⚠️ 主要内容区域加载超时，继续尝试...');
      });
      
      // 处理微信特有的图片懒加载
      await page.evaluate(() => {
        const contentElement = document.querySelector('#js_content');
        if (contentElement) {
          const images = contentElement.querySelectorAll('img');
          images.forEach(img => {
            // 处理微信特有的data-src懒加载
            if (img.dataset.src) {
              img.src = img.dataset.src;
            }
            if (img.dataset.original) {
              img.src = img.dataset.original;
            }
            img.classList.remove('js_img_placeholder', 'wx_img_placeholder', 'rich_pages');
            delete img.dataset.src;
            delete img.dataset.original;
            img.style.display = 'block';
            img.style.visibility = 'visible';
            img.style.opacity = '1';
          });
        }
      });
      
      await page.waitForTimeout(1000);
      
      return await page.evaluate((url) => {
        // 微信文章专用选择器
        const title = document.querySelector('.rich_media_title')?.textContent?.trim() || 
                     document.querySelector('h1')?.textContent?.trim() || 
                     document.querySelector('meta[property="og:title"]')?.content;
        
        const author = document.querySelector('#js_author_name')?.textContent?.trim() ||
                      document.querySelector('meta[name=author]')?.content ||
                      document.querySelector('.profile_nickname')?.textContent?.trim();
        
        const publishTime = document.querySelector('#post-date')?.textContent?.trim() ||
                           document.querySelector('#publish_time')?.textContent?.trim();
        
        const accountName = document.querySelector('.profile_nickname')?.textContent?.trim() ||
                           document.querySelector('.wx_follow_nickname')?.textContent?.trim();
        
        const contentElement = document.querySelector('#js_content');
        let content = '';
        if (contentElement) {
          content = contentElement.innerHTML;
        }
        
        const coverImg = document.querySelector('#js_cover')?.src ||
                        document.querySelector('meta[property="og:image"]')?.content;
        
        return {
          msg_title: title || '未知标题',
          msg_author: author || accountName || '未知作者',
          msg_publish_time_str: publishTime || new Date().toLocaleString('zh-CN'),
          account_name: accountName || '未知公众号',
          msg_content: content || '',
          msg_cover: coverImg || '',
          msg_link: url,
          msg_type: 'post'
        };
      }, url);
      
    } catch (error) {
      throw new Error(`微信文章提取失败: ${error.message}`);
    }
  }

  /**
   * 提取普通网页（通用模式）
   */
  async extractGeneralWebPage(page, url) {
    try {
      console.log('🔍 正在提取普通网页内容...');
      
      // 等待主要内容加载
      await page.waitForSelector('body', { timeout: 10000 });
      
      // 处理普通网页的图片懒加载
      await page.evaluate(() => {
        // 通用图片懒加载处理
        const images = document.querySelectorAll('img');
        images.forEach(img => {
          // 处理常见的懒加载属性
          if (img.dataset.src) {
            img.src = img.dataset.src;
          }
          if (img.dataset.original) {
            img.src = img.dataset.original;
          }
          if (img.dataset.lazy) {
            img.src = img.dataset.lazy;
          }
          
          // 确保图片可见
          img.style.display = img.style.display || 'block';
          img.style.visibility = 'visible';
          img.style.opacity = '1';
        });
        
        // 移除常见的广告和无关元素
        const unwantedSelectors = [
          '.advertisement', '.ads', '.ad-banner', '.ad-container',
          '.sidebar', '.widget', '.comments', '.comment-section',
          '.footer', '.header-nav', '.navigation', '.menu',
          '.social-share', '.share-buttons', '.social-media'
        ];
        
        unwantedSelectors.forEach(selector => {
          const elements = document.querySelectorAll(selector);
          elements.forEach(el => el.remove());
        });
      });
      
      await page.waitForTimeout(1000);
      
      return await page.evaluate((url) => {
        // 通用网页提取逻辑
        const title = document.querySelector('h1')?.textContent?.trim() || 
                     document.querySelector('title')?.textContent?.trim() ||
                     document.querySelector('meta[property="og:title"]')?.content ||
                     document.querySelector('meta[name="title"]')?.content ||
                     '未知标题';
        
        const author = document.querySelector('meta[name="author"]')?.content ||
                      document.querySelector('.author')?.textContent?.trim() ||
                      document.querySelector('[rel="author"]')?.textContent?.trim() ||
                      '未知作者';
        
        // 尝试多种发布时间格式
        let publishTime = '';
        const timeSelectors = [
          'time[datetime]', '.publish-time', '.post-time', '.date',
          'meta[property="article:published_time"]',
          'meta[name="publishdate"]',
          'meta[name="publish_time"]'
        ];
        
        for (const selector of timeSelectors) {
          const element = document.querySelector(selector);
          if (element) {
            publishTime = element.getAttribute('datetime') || element.textContent || element.content;
            if (publishTime) break;
          }
        }
        
        // 查找主要内容区域
        let contentElement = null;
        const contentSelectors = [
          'article', '.article', '.post-content', '.content', '.main-content',
          '.entry-content', '.post-body', '.text-content', '#content', '#main-content'
        ];
        
        for (const selector of contentSelectors) {
          contentElement = document.querySelector(selector);
          if (contentElement) break;
        }
        
        // 如果没有找到特定内容区域，使用body但排除导航和侧边栏
        if (!contentElement) {
          contentElement = document.body;
          // 移除导航和侧边栏
          const navSidebars = contentElement.querySelectorAll('nav, .nav, .navigation, .sidebar, .side-bar, .widget-area');
          navSidebars.forEach(el => el.remove());
        }
        
        let content = '';
        if (contentElement) {
          content = contentElement.innerHTML;
        }
        
        // 提取封面图
        const coverImg = document.querySelector('meta[property="og:image"]')?.content ||
                        document.querySelector('meta[name="twitter:image"]')?.content ||
                        document.querySelector('img[alt*="封面"]')?.src ||
                        document.querySelector('img[src*="logo"]')?.src ||
                        document.querySelector('img')?.src || '';
        
        // 尝试提取网站名称作为账号名
        const siteName = document.querySelector('meta[property="og:site_name"]')?.content ||
                        document.querySelector('meta[name="author"]')?.content ||
                        window.location.hostname || '未知网站';
        
        return {
          msg_title: title,
          msg_author: author,
          msg_publish_time_str: publishTime || new Date().toLocaleString('zh-CN'),
          account_name: siteName,
          msg_content: content || '',
          msg_cover: coverImg || '',
          msg_link: url,
          msg_type: 'webpage'
        };
      }, url);
      
    } catch (error) {
      throw new Error(`普通网页提取失败: ${error.message}`);
    }
  }

  /**
   * 生成Markdown格式
   */
  async generateMarkdown(data, baseFilename) {
    const mdPath = path.join(this.options.outputDir, `${baseFilename}.md`);
    
    const markdown = `# ${data.msg_title}

## 文章信息
- **标题**: ${data.msg_title}
- **作者**: ${data.msg_author || data.account_name}
- **公众号**: ${data.account_name}
- **发布时间**: ${data.msg_publish_time_str}
- **原文链接**: ${data.msg_link}

## 正文内容

${this.htmlToMarkdown(data.msg_content)}

---
*爬取时间: ${new Date().toLocaleString('zh-CN')}*
*使用技能: wechat-article-complete-extractor*
`;
    
    fs.writeFileSync(mdPath, markdown, 'utf8');
    return mdPath;
  }

  /**
   * 生成PDF格式（原生浏览器打印 - 保持原网站格式）
   */
  async generatePDF(data, baseFilename) {
    const pdfPath = path.join(this.options.outputDir, `${baseFilename}.pdf`);
    
    console.log('🖨️ 正在生成PDF文件（原生浏览器打印）...');
    
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    try {
      console.log('🌐 正在访问原网页，保持原生格式...');
      
      // 直接访问原网页，保持原生格式和样式
      const loadingOptions = { timeout: 60000 };
      
      // 根据URL类型选择加载策略
      if (data.msg_link.includes('runoob.com') || data.msg_link.includes('liumingye.cn')) {
        loadingOptions.waitUntil = 'domcontentloaded';
        console.log('⚠️  检测到慢加载网站，使用宽松加载策略');
      } else {
        loadingOptions.waitUntil = 'networkidle';
      }
      
      await page.goto(data.msg_link, loadingOptions);
      
      console.log('🔍 正在处理页面内容...');
      
      // 处理图片懒加载（保持原网站逻辑）
      await page.evaluate(() => {
        // 通用图片懒加载处理
        const images = document.querySelectorAll('img');
        images.forEach(img => {
          // 处理常见的懒加载属性
          if (img.dataset.src) {
            img.src = img.dataset.src;
          }
          if (img.dataset.original) {
            img.src = img.dataset.original;
          }
          if (img.dataset.lazy) {
            img.src = img.dataset.lazy;
          }
          
          // 确保图片可见
          img.style.display = img.style.display || 'block';
          img.style.visibility = 'visible';
          img.style.opacity = '1';
        });
        
        // 移除常见的广告和无关元素（保持原网站清洁）
        const unwantedSelectors = [
          '.advertisement', '.ads', '.ad-banner', '.ad-container',
          '.sidebar', '.widget', '.comments', '.comment-section',
          '.social-share', '.share-buttons', '.social-media'
        ];
        
        unwantedSelectors.forEach(selector => {
          const elements = document.querySelectorAll(selector);
          elements.forEach(el => el.remove());
        });
      });
      
      await page.waitForTimeout(3000); // 等待图片和内容完全加载
      
      console.log('📄 正在使用原生浏览器打印功能生成PDF...');
      
      // 使用原生浏览器打印功能，保持原网站格式
      await page.pdf({
        path: pdfPath,
        ...this.options.pdfOptions,
        printBackground: true, // 打印背景颜色和图像
        margin: { 
          top: '20mm', 
          right: '15mm', 
          bottom: '20mm', 
          left: '15mm' 
        },
        displayHeaderFooter: false,
        preferCSSPageSize: true,
        scale: 1.0
      });
      
      await browser.close();
      console.log('✅ PDF生成完成（原生格式）');
      return pdfPath;
      
    } catch (error) {
      await browser.close();
      throw new Error(`PDF生成失败: ${error.message}`);
    }
  }

  /**
   * 生成HTML格式（保留原网站格式和样式）
   */
  async generateHTML(data, baseFilename) {
    const htmlPath = path.join(this.options.outputDir, `${baseFilename}.html`);
    
    console.log('🌐 正在生成HTML格式（保留原网站格式）...');
    
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    try {
      console.log('🌐 正在访问原网页，保留原生格式...');
      
      // 直接访问原网页，保持原生格式和样式
      const loadingOptions = { timeout: 60000 };
      
      // 根据URL类型选择加载策略
      if (data.msg_link.includes('runoob.com') || data.msg_link.includes('liumingye.cn')) {
        loadingOptions.waitUntil = 'domcontentloaded';
        console.log('⚠️  检测到慢加载网站，使用宽松加载策略');
      } else {
        loadingOptions.waitUntil = 'networkidle';
      }
      
      await page.goto(data.msg_link, loadingOptions);
      
      console.log('🔍 正在优化页面内容...');
      
      // 处理图片懒加载（保持原网站逻辑）
      await page.evaluate(() => {
        // 通用图片懒加载处理
        const images = document.querySelectorAll('img');
        images.forEach(img => {
          // 处理常见的懒加载属性
          if (img.dataset.src) {
            img.src = img.dataset.src;
          }
          if (img.dataset.original) {
            img.src = img.dataset.original;
          }
          if (img.dataset.lazy) {
            img.src = img.dataset.lazy;
          }
          
          // 确保图片可见
          img.style.display = img.style.display || 'block';
          img.style.visibility = 'visible';
          img.style.opacity = '1';
        });
        
        // 移除广告和无关元素（更智能的清理）
        const unwantedSelectors = [
          // 广告相关
          '.advertisement', '.ads', '.ad-banner', '.ad-container', '.google-anno',
          '[data-google-vignette]', '[aria-label*="广告"]', '[aria-label*="Advertisement"]',
          // 侧边栏和无关内容
          '.sidebar', '.widget', '.comments', '.comment-section',
          // 导航和社交
          '.footer', '.header-nav', '.navigation', '.menu',
          '.social-share', '.share-buttons', '.social-media',
          // 脚本和样式注入
          'script', 'ins.adsbygoogle', 'ins[data-ad-client]'
        ];
        
        unwantedSelectors.forEach(selector => {
          const elements = document.querySelectorAll(selector);
          elements.forEach(el => el.remove());
        });
        
        // 清理内联样式污染（移除过长的内联样式）
        const allElements = document.querySelectorAll('*');
        allElements.forEach(el => {
          if (el.style && el.style.cssText && el.style.cssText.length > 500) {
            // 如果内联样式过长，可能是动态注入的广告样式，移除它
            el.removeAttribute('style');
          }
          
          // 移除特定的属性污染
          el.removeAttribute('data-google-vignette');
          el.removeAttribute('data-google-interstitial');
          el.removeAttribute('aria-label');
        });
      });
      
      await page.waitForTimeout(2000); // 等待优化完成
      
      console.log('📄 正在获取优化后的HTML内容...');
      
      // 获取优化后的完整HTML（保留原格式和样式）
      const optimizedHTML = await page.evaluate(() => {
        // 添加一些优化但保留原格式
        const style = document.createElement('style');
        style.textContent = `
          @media print {
            body { font-size: 12pt; line-height: 1.6; margin: 1cm; }
            .page-break { page-break-before: always; }
          }
          /* 确保图片不会超出页面 */
          img { max-width: 100%; height: auto; }
          /* 优化打印时的表格 */
          table { page-break-inside: avoid; }
          /* 确保长单词不会溢出 */
          body { word-wrap: break-word; overflow-wrap: break-word; }
        `;
        document.head.appendChild(style);
        
        return document.documentElement.outerHTML;
      });
      
      // 保存优化后的HTML（保留原网站格式和样式）
      fs.writeFileSync(htmlPath, optimizedHTML, 'utf8');
      
      await browser.close();
      console.log('✅ HTML生成完成（保留原网站格式）');
      return htmlPath;
      
    } catch (error) {
      await browser.close();
      throw new Error(`HTML生成失败: ${error.message}`);
    }
  }

  /**
   * 生成HTML内容
   */
  generateHTMLContent(data) {
    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.msg_title}</title>
    <style>
        @media print {
            body { font-size: 12pt; line-height: 1.6; margin: 1cm; }
            .page-break { page-break-before: always; }
        }
        body {
            font-family: 
                'PingFang SC',        /* macOS系统字体 */
                'Microsoft YaHei',    /* Windows系统字体 */
                '思源黑体',           /* 通用中文 */
                'Source Han Sans',    /* 通用中文 */
                -apple-system,        /* macOS系统字体 */
                BlinkMacSystemFont,   /* Chrome macOS */
                'Segoe UI',           /* Windows系统字体 */
                Roboto,               /* Android/Web */
                'Helvetica Neue',     /* 通用无衬线 */
                Arial,                /* 通用无衬线 */
                sans-serif;           /* 兜底字体 */
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            color: #333;
            background-color: #fff;
        }
        .header {
            border-bottom: 2px solid #3498db;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
            line-height: 1.3;
        }
        .meta {
            color: #7f8c8d;
            font-size: 14px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .content {
            font-size: 16px;
            line-height: 1.8;
            text-align: justify;
        }
        .content h3 {
            color: #34495e;
            margin-top: 25px;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .content ul {
            padding-left: 20px;
            margin: 15px 0;
        }
        .content li {
            margin-bottom: 8px;
        }
        .content code {
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            border: 1px solid #e9ecef;
        }
        .content pre {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            border-left: 4px solid #3498db;
            margin: 15px 0;
        }
        .content blockquote {
            border-left: 4px solid #3498db;
            margin: 15px 0;
            padding-left: 20px;
            color: #555;
            font-style: italic;
            background-color: #f8f9fa;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ecf0f1;
            color: #7f8c8d;
            font-size: 12px;
        }
        .cover-image {
            width: 100%;
            max-width: 600px;
            height: auto;
            margin: 20px 0;
            border-radius: 8px;
        }
        p {
            margin: 12px 0;
            page-break-inside: avoid;
        }
        strong {
            color: #2c3e50;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="title">${data.msg_title}</div>
            <div class="meta">
                <span>📝 作者：${data.msg_author || data.account_name}</span>
                <span>📅 时间：${data.msg_publish_time_str}</span>
                <span>🏢 公众号：${data.account_name}</span>
            </div>
        </div>
        
        ${data.msg_cover ? `<img src="${data.msg_cover}" alt="封面图" class="cover-image">` : ''}
        
        <div class="content">
            ${data.msg_content}
        </div>
        
        <div class="footer">
            <p>原文链接：<a href="${data.msg_link}">${data.msg_link}</a></p>
            <p>爬取时间：${new Date().toLocaleString('zh-CN')}</p>
            <p>使用技能：wechat-article-complete-extractor</p>
        </div>
    </div>
</body>
</html>`;
  }

  /**
   * HTML转Markdown（优化版，支持图片）
   */
  htmlToMarkdown(html) {
    // 简单的HTML到Markdown转换
    let markdown = html;
    
    // 移除script和style标签
    markdown = markdown.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
    markdown = markdown.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
    
    // 处理图片 - 关键优化
    markdown = markdown.replace(/<img[^>]*src=["']([^"']*)["'][^>]*>/gi, (match, src) => {
      // 获取alt文本
      const altMatch = match.match(/alt=["']([^"']*)["']/);
      const alt = altMatch ? altMatch[1] : '图片';
      return `![${alt}](${src})`;
    });
    
    // 转换基本标签
    markdown = markdown.replace(/<h3[^>]*>/gi, '### ').replace(/<\/h3>/gi, '\n\n');
    markdown = markdown.replace(/<strong[^>]*>/gi, '**').replace(/<\/strong>/gi, '**');
    markdown = markdown.replace(/<em[^>]*>/gi, '*').replace(/<\/em>/gi, '*');
    markdown = markdown.replace(/<p[^>]*>/gi, '').replace(/<\/p>/gi, '\n\n');
    markdown = markdown.replace(/<ul[^>]*>/gi, '').replace(/<\/ul>/gi, '\n');
    markdown = markdown.replace(/<ol[^>]*>/gi, '').replace(/<\/ol>/gi, '\n');
    markdown = markdown.replace(/<li[^>]*>/gi, '- ').replace(/<\/li>/gi, '\n');
    markdown = markdown.replace(/<pre[^>]*>/gi, '```\n').replace(/<\/pre>/gi, '\n```\n\n');
    markdown = markdown.replace(/<code[^>]*>/gi, '`').replace(/<\/code>/gi, '`');
    markdown = markdown.replace(/<blockquote[^>]*>/gi, '> ').replace(/<\/blockquote>/gi, '\n');
    markdown = markdown.replace(/<br[^>]*>/gi, '\n');
    
    // 移除剩余HTML标签，但保留图片已经处理过了
    markdown = markdown.replace(/<[^>]+>/g, '');
    
    // 清理多余空行
    markdown = markdown.replace(/\n{3,}/g, '\n\n');
    
    return markdown.trim();
  }

  /**
   * 文件名安全处理
   */
  sanitizeFilename(filename) {
    return filename
      .replace(/[<>:"/\\|?*]/g, '_')
      .replace(/\s+/g, '_')
      .replace(/_{2,}/g, '_')
      .substring(0, 100) // 限制长度
      .replace(/^_+|_+$/g, '');
  }
}

// CLI支持
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log('使用方法:');
    console.log('  node extract-complete.js <文章URL> [选项]');
    console.log('');
    console.log('选项:');
    console.log('  --format=md,pdf,html    指定输出格式 (默认: md,pdf)');
    console.log('  --output=<路径>         指定输出目录');
    console.log('  --help                  显示帮助信息');
    console.log('');
    console.log('示例:');
    console.log('  node extract-complete.js https://mp.weixin.qq.com/s/xxxxx');
    console.log('  node extract-complete.js https://mp.weixin.qq.com/s/xxxxx --format=pdf --output=/Users/audrey/Documents/文稿/');
    process.exit(0);
  }
  
  const url = args[0];
  const options = {};
  
  // 解析命令行参数
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg.startsWith('--format=')) {
      options.formats = arg.split('=')[1].split(',');
    } else if (arg.startsWith('--output=')) {
      options.outputDir = arg.split('=')[1];
    } else if (arg === '--help') {
      console.log('使用方法见上方');
      process.exit(0);
    }
  }
  
  // 执行提取
  const extractor = new WeChatArticleExtractor(options);
  extractor.processArticle(url)
    .then(result => {
      console.log('\n🎉 处理完成！');
      console.log('📋 文章标题:', result.title);
      console.log('👤 作者:', result.author);
      console.log('📁 生成文件:', result.files.join(', '));
    })
    .catch(error => {
      console.error('❌ 处理失败:', error.message);
      process.exit(1);
    });
}

module.exports = { WeChatArticleExtractor };