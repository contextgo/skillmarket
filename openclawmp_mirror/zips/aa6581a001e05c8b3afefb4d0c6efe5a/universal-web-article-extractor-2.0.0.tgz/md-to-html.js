const fs = require('fs');
const path = require('path');

/**
 * Markdown转HTML转换器
 * 专为微信公众号文章优化的转换器
 */

function markdownToHTML(markdown, title = '文章', author = '', date = '', source = '') {
    // 基础Markdown转换
    let html = markdown;
    
    // 转换标题
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^#### (.+)$/gm, '<h4>$1</h4>');
    
    // 转换粗体和斜体
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    
    // 转换代码块
    html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    html = html.replace(/`(.+?)`/g, '<code>$1</code>');
    
    // 转换列表
    html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
    html = html.replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>');
    
    // 处理列表块
    const listBlocks = html.split(/\n(?=-|\d+\.)/);
    let processedHtml = '';
    let inList = false;
    
    for (const block of listBlocks) {
        if (block.match(/^- |^\d+\./)) {
            if (!inList) {
                processedHtml += '<ul>\n';
                inList = true;
            }
            processedHtml += block + '\n';
        } else {
            if (inList) {
                processedHtml += '</ul>\n';
                inList = false;
            }
            processedHtml += block + '\n';
        }
    }
    if (inList) {
        processedHtml += '</ul>\n';
    }
    html = processedHtml;
    
    // 转换段落
    const lines = html.split('\n');
    let result = '';
    let inParagraph = false;
    
    for (const line of lines) {
        if (line.trim() === '') {
            if (inParagraph) {
                result += '</p>\n';
                inParagraph = false;
            }
            continue;
        }
        
        if (line.match(/^<h[1-6]>/) || line.match(/^<ul>/) || line.match(/^<\/ul>/) || line.match(/^<li>/) || line.match(/^<pre>/) || line.match(/^<\/pre>/)) {
            if (inParagraph) {
                result += '</p>\n';
                inParagraph = false;
            }
            result += line + '\n';
        } else {
            if (!inParagraph) {
                result += '<p>';
                inParagraph = true;
            }
            result += line + ' ';
        }
    }
    if (inParagraph) {
        result += '</p>\n';
    }
    
    // 清理多余的空格
    result = result.replace(/<\/p>\s*<p>/g, '</p><p>');
    result = result.replace(/\s+<\/p>/g, '</p>');
    result = result.replace(/<p>\s+/g, '<p>');
    
    return result;
}

function createHTMLDocument(title, author, date, source, content) {
    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        @media print {
            body { font-size: 12pt; line-height: 1.6; margin: 1cm; }
            .page-break { page-break-before: always; }
        }
        body {
            font-family: 'PingFang SC', 'Microsoft YaHei', 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            color: #333;
            background-color: #fff;
        }
        .header {
            border-bottom: 2px solid #3498db;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
            line-height: 1.3;
        }
        .meta {
            color: #7f8c8d;
            font-size: 14px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .content {
            font-size: 16px;
            line-height: 1.8;
            text-align: justify;
        }
        .content h1 {
            color: #2c3e50;
            margin-top: 30px;
            margin-bottom: 20px;
            font-size: 28px;
        }
        .content h2 {
            color: #34495e;
            margin-top: 25px;
            margin-bottom: 15px;
            font-size: 22px;
        }
        .content h3 {
            color: #34495e;
            margin-top: 25px;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .content h4 {
            color: #7f8c8d;
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .content ul {
            padding-left: 20px;
            margin: 15px 0;
        }
        .content li {
            margin-bottom: 8px;
        }
        .content code {
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            border: 1px solid #e9ecef;
        }
        .content pre {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            border-left: 4px solid #3498db;
            margin: 15px 0;
        }
        .content blockquote {
            border-left: 4px solid #3498db;
            margin: 15px 0;
            padding-left: 20px;
            color: #555;
            font-style: italic;
            background-color: #f8f9fa;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ecf0f1;
            color: #7f8c8d;
            font-size: 12px;
        }
        .cover-image {
            width: 100%;
            max-width: 600px;
            height: auto;
            margin: 20px 0;
            border-radius: 8px;
        }
        p {
            margin: 12px 0;
            page-break-inside: avoid;
        }
        strong {
            color: #2c3e50;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="title">${title}</div>
            <div class="meta">
                <span>📝 作者：${author}</span>
                <span>📅 时间：${date}</span>
                <span>🏢 来源：${source}</span>
            </div>
        </div>
        
        <div class="content">
            ${content}
        </div>
        
        <div class="footer">
            <p>爬取时间：${new Date().toLocaleString('zh-CN')}</p>
            <p>使用技能：wechat-article-complete-extractor</p>
        </div>
    </div>
</body>
</html>`;
}

/**
 * 处理单个Markdown文件
 */
function processMarkdownFile(mdPath) {
    console.log(`正在处理: ${path.basename(mdPath)}`);
    
    const content = fs.readFileSync(mdPath, 'utf8');
    
    // 提取元信息
    let title = path.basename(mdPath, '.md');
    let author = '';
    let date = '';
    let source = '';
    let mainContent = content;
    
    // 尝试提取文章信息（如果MD文件有标准格式）
    const titleMatch = content.match(/^#\s+(.+)$/m);
    if (titleMatch) {
        title = titleMatch[1];
    }
    
    const authorMatch = content.match(/作者[：:]\s*(.+)$/m);
    if (authorMatch) {
        author = authorMatch[1].trim();
    }
    
    const dateMatch = content.match(/时间[：:]\s*(.+)$/m);
    if (dateMatch) {
        date = dateMatch[1].trim();
    }
    
    const sourceMatch = content.match(/来源[：:]\s*(.+)$/m);
    if (sourceMatch) {
        source = sourceMatch[1].trim();
    }
    
    // 提取主要内容（跳过元信息部分）
    const contentStart = content.indexOf('## 正文内容');
    if (contentStart !== -1) {
        mainContent = content.substring(contentStart + 12).trim();
    } else {
        mainContent = content.replace(/^#\s+.+$/m, '').trim();
    }
    
    // 转换Markdown到HTML
    const htmlContent = markdownToHTML(mainContent, title, author, date, source);
    
    // 生成HTML文件
    const htmlPath = mdPath.replace('.md', '.html');
    const htmlDocument = createHTMLDocument(title, author, date, source, htmlContent);
    
    fs.writeFileSync(htmlPath, htmlDocument, 'utf8');
    console.log(`✅ 生成HTML: ${path.basename(htmlPath)}`);
    
    return htmlPath;
}

/**
 * 主函数 - 处理所有Markdown文件
 */
function main() {
    const docsDir = '/Users/audrey/Documents/文稿/';
    const mdFiles = fs.readdirSync(docsDir)
        .filter(file => file.endsWith('.md') && !file.includes('如何让OpenClaw半夜去学习提升自己'))
        .map(file => path.join(docsDir, file));
    
    console.log(`找到 ${mdFiles.length} 个Markdown文件需要转换:`);
    mdFiles.forEach(file => console.log(`  - ${path.basename(file)}`));
    
    const results = [];
    for (const mdFile of mdFiles) {
        try {
            const htmlPath = processMarkdownFile(mdFile);
            results.push({
                md: path.basename(mdFile),
                html: path.basename(htmlPath),
                size: fs.statSync(htmlPath).size
            });
        } catch (error) {
            console.error(`❌ 处理失败: ${path.basename(mdFile)} - ${error.message}`);
        }
    }
    
    console.log('\n🎉 转换完成！');
    console.log('结果汇总:');
    results.forEach(result => {
        console.log(`  ${result.md} → ${result.html} (${(result.size/1024).toFixed(1)}KB)`);
    });
}

// 执行
if (require.main === module) {
    main();
}

module.exports = { processMarkdownFile, markdownToHTML, createHTMLDocument };