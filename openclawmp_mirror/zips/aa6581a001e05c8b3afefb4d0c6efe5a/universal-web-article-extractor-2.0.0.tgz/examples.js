const { WeChatArticleExtractor } = require('./extract-complete');

/**
 * 使用示例 - 微信公众号文章完整提取
 */

async function main() {
  console.log('🎯 微信公众号文章完整提取器 - 使用示例');
  console.log('=' .repeat(50));
  
  // 示例1: 基本用法（默认双格式）
  console.log('\n📖 示例1: 基本用法 - 生成Markdown和PDF双格式');
  const extractor1 = new WeChatArticleExtractor();
  
  try {
    const result1 = await extractor1.processArticle('https://mp.weixin.qq.com/s/KYzh04ZUkohrlA3gxlSNdA');
    console.log('✅ 成功生成:', result1.files);
  } catch (error) {
    console.error('❌ 失败:', error.message);
  }
  
  // 示例2: 指定输出目录和格式
  console.log('\n📖 示例2: 指定输出目录和格式');
  const extractor2 = new WeChatArticleExtractor({
    outputDir: '/Users/audrey/Documents/文稿/',
    formats: ['pdf'], // 只生成PDF
    pdfOptions: {
      format: 'A4',
      margin: { top: '15mm', right: '10mm', bottom: '15mm', left: '10mm' },
      scale: 0.95
    }
  });
  
  try {
    const result2 = await extractor2.processArticle('https://mp.weixin.qq.com/s/KYzh04ZUkohrlA3gxlSNdA');
    console.log('✅ 成功生成:', result2.files);
  } catch (error) {
    console.error('❌ 失败:', error.message);
  }
  
  // 示例3: CLI命令行用法
  console.log('\n📖 示例3: 命令行用法');
  console.log('基本提取:');
  console.log('  node extract-complete.js https://mp.weixin.qq.com/s/文章ID');
  console.log('指定格式和目录:');
  console.log('  node extract-complete.js https://mp.weixin.qq.com/s/文章ID --format=pdf --output=/Users/audrey/Documents/文稿/');
  
  console.log('\n🎉 示例完成！');
  console.log('💡 提示: 生成的文件默认保存在 ~/Documents/文稿/ 目录下');
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = { main };