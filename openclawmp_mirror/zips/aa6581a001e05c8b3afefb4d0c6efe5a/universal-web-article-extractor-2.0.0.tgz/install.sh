#!/bin/bash

# 微信公众号文章完整提取器 - 安装脚本

echo "🚀 开始安装 wechat-article-complete-extractor..."
echo "=================================="

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js 未安装"
    echo "请先安装Node.js: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js 已安装: $(node --version)"

# 检查npm
if ! command -v npm &> /dev/null; then
    echo "❌ 错误: npm 未安装"
    exit 1
fi

echo "✅ npm 已安装: $(npm --version)"

# 安装playwright
echo "📦 正在安装Playwright..."
npm install -g playwright

if [ $? -eq 0 ]; then
    echo "✅ Playwright 安装成功"
else
    echo "❌ Playwright 安装失败"
    exit 1
fi

# 安装浏览器
echo "🌐 正在安装浏览器..."
npx playwright install chromium

if [ $? -eq 0 ]; then
    echo "✅ 浏览器安装成功"
else
    echo "⚠️ 浏览器安装可能失败，但不影响基本功能"
fi

# 创建全局命令
echo "🔗 创建全局命令..."
cat > /tmp/wechat-extract << 'EOF'
#!/bin/bash
node /Users/audrey/.openclaw/workspace/.agents/skills/wechat-article-complete-extractor/extract-complete.js "$@"
EOF

chmod +x /tmp/wechat-extract
sudo mv /tmp/wechat-extract /usr/local/bin/wechat-extract

echo "✅ 全局命令创建成功"
echo "   使用方法: wechat-extract <文章URL> [选项]"

# 创建桌面快捷方式（可选）
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "🍎 创建macOS快捷方式..."
    
    cat > ~/Desktop/微信公众号提取器.command << 'EOF'
#!/bin/bash
cd /Users/audrey/.openclaw/workspace/.agents/skills/wechat-article-complete-extractor/
echo "🚀 微信公众号文章完整提取器"
echo "请输入文章URL:"
read -r url
node extract-complete.js "$url" --output=/Users/audrey/Documents/文稿/
echo "✅ 提取完成！文件保存在 ~/Documents/文稿/"
echo "按任意键退出..."
read -n 1 -s
EOF
    
    chmod +x ~/Desktop/微信公众号提取器.command
    echo "✅ 桌面快捷方式创建成功"
fi

echo ""
echo "🎉 安装完成！"
echo "=================================="
echo "📖 使用方法:"
echo "  wechat-extract https://mp.weixin.qq.com/s/文章ID"
echo ""
echo "📁 默认输出目录: ~/Documents/文稿/"
echo "🎯 生成格式: Markdown + PDF"
echo ""
echo "💡 测试命令:"
echo "  wechat-extract https://mp.weixin.qq.com/s/KYzh04ZUkohrlA3gxlSNdA"
echo ""
echo "✨ 享受一键提取的便利吧！"