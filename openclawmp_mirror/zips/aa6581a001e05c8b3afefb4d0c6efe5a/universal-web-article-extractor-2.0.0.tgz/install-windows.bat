@echo off
setlocal enabledelayedexpansion

echo 🚀 通用网页文章提取器 - Windows安装程序
echo ==================================
echo.

:: 检测管理员权限
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 需要管理员权限运行
    echo 请右键点击此文件，选择"以管理员身份运行"
    pause
    exit /b 1
)

echo 📊 系统信息:
echo   操作系统: Windows
echo   用户名: %USERNAME%
echo   用户目录: %USERPROFILE%
echo.

:: 检查Node.js
echo 🔍 检查Node.js安装...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ 错误: Node.js 未安装
    echo.
    echo 📥 请从以下地址下载安装Node.js:
    echo   https://nodejs.org/zh-cn/download/
    echo.
    echo 💡 安装完成后重新运行此脚本
    pause
    exit /b 1
)

echo ✅ Node.js 已安装: 
node --version
echo.

:: 检查npm
echo 🔍 检查npm安装...
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ 错误: npm 未安装
    echo npm 应该随Node.js一起安装，请重新安装Node.js
    pause
    exit /b 1
)

echo ✅ npm 已安装: 
npm --version
echo.

:: 安装Playwright
echo 📦 正在安装Playwright...
call npm install -g playwright
if %errorlevel% neq 0 (
    echo ❌ Playwright 安装失败
    echo 请检查网络连接和npm配置
    pause
    exit /b 1
)

echo ✅ Playwright 安装成功
echo.

:: 安装浏览器
echo 🌐 正在安装浏览器...
call npx playwright install chromium
if %errorlevel% neq 0 (
    echo ⚠️ 浏览器安装可能失败，但不影响基本功能
    echo 您可以稍后手动运行: npx playwright install chromium
)

echo ✅ 浏览器安装完成
echo.

:: 创建输出目录
echo 📁 创建输出目录...
set "OUTPUT_DIR=%USERPROFILE%\Documents\Articles"
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
echo ✅ 输出目录: %OUTPUT_DIR%
echo.

:: 创建配置文件
echo ⚙️ 创建配置文件...
set "CONFIG_DIR=%USERPROFILE%\AppData\Roaming\ArticleExtractor"
if not exist "%CONFIG_DIR%" mkdir "%CONFIG_DIR%"

(
echo {
echo   "platform": "windows",
echo   "outputDir": "%OUTPUT_DIR%",
echo   "browser": "chromium",
echo   "fontFamily": "Microsoft YaHei, Segoe UI, sans-serif"
echo }
) > "%CONFIG_DIR%\config.json"

echo ✅ 配置文件创建成功
echo.

:: 创建桌面快捷方式
echo 🎯 创建桌面快捷方式...
set "SHORTCUT_PATH=%USERPROFILE%\Desktop\网页文章提取器.bat"

(
echo @echo off
echo title 通用网页文章提取器
echo color 0A
echo.
echo 🕷️ 通用网页文章提取器 v2.0.0
echo ==================================
echo.
echo 💡 支持: 微信公众号、普通网页、技术文档
echo 📄 输出: Markdown + HTML + PDF 三格式
echo 📁 保存: %OUTPUT_DIR%
echo.
echo 🔗 请输入要提取的文章网址:
echo   示例: https://mp.weixin.qq.com/s/xxxxx
echo   示例: https://example.com/article
echo.

echo ⌨️  请输入URL: 
set /p "url="

if "%%url%%"=="" (
    echo ❌ URL不能为空
    pause
    exit /b 1
)

echo.
echo ⏳ 正在提取文章，请稍候...
echo   URL: %%url%%
echo.

:: 调用提取器
cd /d "%~dp0"
call node extract-complete.js "%%url%%" --output="%OUTPUT_DIR%" --format=md,html,pdf

if %errorlevel% equ 0 (
    echo.
    echo ✅ 提取成功！
    echo 📁 文件保存在: %OUTPUT_DIR%
    echo 🎯 生成格式: Markdown + HTML + PDF
    echo.
    echo 💡 提示: 您可以在文件资源管理器中查看结果
) else (
    echo.
    echo ❌ 提取失败，请检查URL是否正确或网络连接
    echo 💡 提示: 支持微信公众号和普通网页
)

echo.
echo 按任意键退出...
pause >nul
) > "%SHORTCUT_PATH%"

echo ✅ 桌面快捷方式创建成功: %SHORTCUT_PATH%
echo.

:: 添加到PATH（可选）
echo 🔗 添加到系统PATH...
set "CURRENT_DIR=%~dp0"
set "NEW_PATH=%PATH%;%CURRENT_DIR%"

:: 更新PATH（需要重启生效）
setx PATH "%NEW_PATH%" >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ 已添加到系统PATH（需要重启生效）
    echo 💡 重启后可在任意目录运行: extract-complete
) else (
    echo ⚠️ 添加到PATH失败，但不影响使用
    echo 💡 您可以手动将以下目录添加到PATH:
    echo   %CURRENT_DIR%
)

echo.
echo 🎉 Windows安装完成！
echo ==================================
echo 📖 使用方法:
echo   方法1: 双击桌面的"网页文章提取器"快捷方式
echo   方法2: 在命令行运行: extract-complete ^<URL^>
echo   方法3: 将脚本目录添加到PATH后全局使用
echo.
echo 📁 默认输出目录: %OUTPUT_DIR%
echo 🎯 生成格式: Markdown + HTML + PDF
echo 💻 支持平台: Windows 10/11
echo.
echo 🌟 现在您可以:
echo   • 提取微信公众号文章
echo   • 提取普通网页内容
echo   • 生成高质量三格式文件
echo.
pause