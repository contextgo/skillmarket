
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  
  try {
    await page.goto('https://www.runoob.com/ai-agent/openclaw-feishu.html', { waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(2000);
    
    // 获取完整的HTML内容
    const htmlContent = await page.content();
    
    // 提取文章主要内容
    const articleData = await page.evaluate(() => {
      const title = document.querySelector('h1')?.textContent?.trim() || 'OpenClaw 接入飞书';
      const author = '菜鸟教程';
      const date = new Date().toLocaleString('zh-CN');
      const source = '菜鸟教程';
      
      // 获取主要内容区域
      const mainContent = document.querySelector('.article-intro, .article-body, main, .content')?.innerHTML || 
                         document.body.innerHTML;
      
      return {
        title: title,
        author: author,
        date: date,
        source: source,
        content: mainContent
      };
    });
    
    await browser.close();
    console.log(JSON.stringify(articleData));
  } catch (error) {
    console.error('错误:', error.message);
    await browser.close();
    process.exit(1);
  }
})();
