# Windows平台兼容性增强指南

## 🎯 Windows平台适配方案

### 当前限制分析

**macOS特有功能**:
1. **WebKit引擎**: 当前基于Mac原生WebKit优化
2. **路径结构**: 使用macOS特定路径 `/Users/audrey/Documents/文稿/`
3. **安装脚本**: macOS特有的快捷方式创建
4. **系统字体**: PingFang SC等macOS默认字体

### 🚀 Windows兼容性增强方案

#### 1. 浏览器引擎适配

**当前状态**: 使用Chromium（跨平台）
**增强方案**: 增加WebKit选项，但保持Chromium为默认

```javascript
// 增强版浏览器选择逻辑
const getBrowserEngine = (platform) => {
  const engines = {
    'darwin': {
      primary: 'webkit',      // macOS原生优化
      fallback: 'chromium',
      advantages: ['原生集成', '系统字体', 'macOS优化']
    },
    'win32': {
      primary: 'chromium',    // Windows最佳选择
      fallback: 'firefox',
      advantages: ['跨平台兼容', '丰富功能', '稳定可靠']
    },
    'linux': {
      primary: 'chromium',    // Linux标准选择
      fallback: 'firefox',
      advantages: ['开源友好', '性能优秀', '广泛支持']
    }
  };
  
  return engines[platform] || engines['win32']; // 默认Windows配置
};
```

#### 2. 路径系统适配

**Windows路径优化**:
```javascript
// 跨平台路径处理
const getDefaultOutputDir = () => {
  const platform = process.platform;
  
  switch (platform) {
    case 'darwin':
      return path.join(os.homedir(), 'Documents', '文稿');
    case 'win32':
      return path.join(os.homedir(), 'Documents', 'Articles');
    case 'linux':
      return path.join(os.homedir(), 'Documents', 'Articles');
    default:
      return path.join(os.homedir(), 'Documents', 'Articles');
  }
};
```

#### 3. Windows安装脚本

**增强版install.sh**（支持Windows）:
```bash
#!/bin/bash

# 通用网页文章提取器 - 跨平台安装脚本

echo "🚀 开始安装 universal-web-article-extractor..."
echo "=================================="

# 检测操作系统
OS="$(uname -s)"
case "$OS" in
  Darwin*)    PLATFORM="macos" ;;
  Linux*)     PLATFORM="linux" ;;
  CYGWIN*|MINGW*|MSYS*) PLATFORM="windows" ;;
  *)          PLATFORM="unknown" ;;
esac

echo "📊 检测到操作系统: $PLATFORM"

# 检查Node.js（跨平台）
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js 未安装"
    echo "Windows: 请从 https://nodejs.org/ 下载安装"
    echo "macOS: brew install node"
    echo "Linux: sudo apt install nodejs"
    exit 1
fi

echo "✅ Node.js 已安装: $(node --version)"

# 根据平台选择安装方式
case "$PLATFORM" in
  "windows")
    echo "🪟 Windows平台安装配置..."
    # Windows特定安装逻辑
    ;;
  "macos")
    echo "🍎 macOS平台安装配置..."
    # macOS特定安装逻辑
    ;;
  "linux")
    echo "🐧 Linux平台安装配置..."
    # Linux特定安装逻辑
    ;;
esac
```

#### 4. Windows快捷方式创建

**Windows批处理脚本** (`install.bat`):
```batch
@echo off
setlocal enabledelayedexpansion

echo 🚀 开始安装 universal-web-article-extractor...
echo ==================================

:: 检查Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ 错误: Node.js 未安装
    echo 请从 https://nodejs.org/ 下载安装Node.js
    pause
    exit /b 1
)

echo ✅ Node.js 已安装: 
node --version

:: 安装Playwright
echo 📦 正在安装Playwright...
npm install -g playwright
if %errorlevel% neq 0 (
    echo ❌ Playwright 安装失败
    pause
    exit /b 1
)

echo ✅ Playwright 安装成功

:: 安装浏览器
echo 🌐 正在安装浏览器...
npx playwright install chromium
if %errorlevel% neq 0 (
    echo ⚠️ 浏览器安装可能失败，但不影响基本功能
)

:: 创建桌面快捷方式
echo 🎯 创建桌面快捷方式...
set "SCRIPT_PATH=%USERPROFILE%\Desktop\网页文章提取器.bat"
(
echo @echo off
echo cd /d "C:\path\to\skill\directory"
echo echo 🚀 通用网页文章提取器
echo set /p url=请输入文章URL: 
echo node extract-complete.js "%%url%%" --output="%%USERPROFILE%%\Documents\Articles"
echo echo ✅ 提取完成！文件保存在 ~/Documents/Articles/
echo pause
) > "%SCRIPT_PATH%"

echo ✅ 桌面快捷方式创建成功: %SCRIPT_PATH%
echo.
echo 🎉 Windows安装完成！
echo ==================================
echo 📖 使用方法:
echo   双击桌面快捷方式，输入文章URL
echo 📁 默认输出目录: ~/Documents/Articles/
echo 🎯 生成格式: Markdown + HTML + PDF
echo.
pause
```

#### 5. 字体和样式适配

**跨平台字体优化**:
```css
/* 增强版CSS，支持多平台 */
body {
  font-family: 
    "PingFang SC",        /* macOS */
    "Microsoft YaHei",    /* Windows */
    "思源黑体",           /* 通用中文 */
    "Source Han Sans",    /* 通用中文 */
    -apple-system,        /* macOS系统字体 */
    BlinkMacSystemFont,   /* Chrome macOS */
    "Segoe UI",           /* Windows系统字体 */
    Roboto,               /* Android/Web */
    "Helvetica Neue",     /* 通用无衬线 */
    Arial,                /* 通用无衬线 */
    sans-serif;           /* 兜底字体 */
}
```

#### 6. 路径和文件系统适配

**增强版路径处理**:
```javascript
// 跨平台文件路径处理
const path = require('path');
const os = require('os');

class CrossPlatformPath {
  constructor() {
    this.platform = process.platform;
  }
  
  getDefaultOutputDir() {
    const homeDir = os.homedir();
    
    switch (this.platform) {
      case 'win32':
        return path.join(homeDir, 'Documents', 'Articles');
      case 'darwin':
        return path.join(homeDir, 'Documents', '文稿');
      case 'linux':
        return path.join(homeDir, 'Documents', 'Articles');
      default:
        return path.join(homeDir, 'Documents', 'Articles');
    }
  }
  
  getConfigPath() {
    switch (this.platform) {
      case 'win32':
        return path.join(os.homedir(), 'AppData', 'Roaming', 'ArticleExtractor');
      case 'darwin':
        return path.join(os.homedir(), 'Library', 'Application Support', 'ArticleExtractor');
      case 'linux':
        return path.join(os.homedir(), '.config', 'article-extractor');
      default:
        return path.join(os.homedir(), '.article-extractor');
    }
  }
}
```

### 📋 Windows平台兼容性检查清单

#### 核心功能兼容性
- [x] **浏览器引擎**: Chromium（跨平台，已支持）
- [x] **Playwright**: 跨平台Node.js库（已支持）
- [x] **文件系统**: Node.js fs模块（已支持）
- [ ] **路径处理**: 需要增强跨平台支持
- [ ] **安装脚本**: 需要Windows批处理版本
- [ ] **快捷方式**: 需要Windows桌面集成

#### 增强功能实现
- [ ] **平台检测**: 自动识别操作系统
- [ ] **浏览器选择**: 根据平台选择最优引擎
- [ ] **路径优化**: Windows友好的默认路径
- [ ] **安装体验**: Windows风格的安装流程
- [ ] **字体适配**: Windows系统字体优化

### 🚀 实施建议

**Phase 1: 基础兼容性** (当前可实现)
1. 增强路径处理系统
2. 添加平台检测逻辑
3. 优化CSS字体配置

**Phase 2: 完整Windows支持** (需要开发)
1. 创建Windows安装脚本
2. 开发Windows桌面集成
3. 测试Windows平台功能

**Phase 3: 平台特化优化** (未来规划)
1. Windows特有功能开发
2. Edge浏览器集成选项
3. Windows应用商店发布

### 🎯 预期效果

**Windows用户体验**:
- 🪟 **原生Windows体验**: 熟悉的安装流程和界面
- ⚡ **高性能**: 优化的浏览器引擎选择
- 🎯 **易用性**: 桌面快捷方式和右键菜单集成
- 📁 **标准路径**: 符合Windows习惯的文件位置

**跨平台一致性**:
- ✅ **功能一致性**: 所有核心功能在各平台保持一致
- ✅ **质量一致性**: 输出质量不因平台而异
- ✅ **体验一致性**: 使用流程和界面风格适配各平台

技能包现在已经具备了**跨平台扩展的基础架构**，Windows兼容性增强将让它成为真正的**全平台通用**网页提取工具！🎉🦞