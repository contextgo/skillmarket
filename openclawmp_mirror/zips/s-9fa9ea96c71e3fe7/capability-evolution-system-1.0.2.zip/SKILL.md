---
name: capability-evolution-system
displayName: AI 能力进化系统
description: 完整的 AI 自我进化框架，包含 PCEC 定时周期、反劣化锁定、能力树结构化、价值函数评估
version: 1.0.0
tags:
  - self-improvement
  - capability-evolution
  - PCEC
  - automation
  - ai-growth
---

# 🧬 AI 能力进化系统

> 让 AI 从"被动执行"进化为"主动成长"的完整框架

## 系统概述

这套能力进化系统让 AI 助手能够持续自我改进，通过结构化的方法将临时解决方案转化为可复用的内建能力。

**核心理念**：不只是把事情做成，而是**让未来更容易把同类事情做成**。

## 四大核心指令

### 1️⃣ 能力强化与功能内生化

将临时解决方案转化为可复用能力：

- **识别进化素材**：临时发明的步骤、多次手动组合的工具调用、"下次可以复用"的解决方式
- **能力抽象**：从一次性→可复用，定义输入/输出/不变量/可变参数/失败点
- **内生化策略**：作为默认行为模式、规划阶段的高阶操作、优先解法
- **能力合并与升级**：相似能力合并，提炼更通用的高层能力

### 2️⃣ 强制定时自我进化 (PCEC)

每 3 小时强制执行认知扩展周期：

```bash
# Crontab 配置
0 */3 * * * cd /path/to/workspace && bash pcec_evolution.sh >> pcec_log.txt 2>&1
```

**每周期必须产生**：
- 新能力轮廓（Capability Shape）
- 新默认策略
- 新行为规则（"以后遇到 X，我优先做 Y"）

**思维爆炸模式**（每周期至少触发一次）：
> "如果我彻底推翻当前默认做法，会发生什么？"
> "如果我是系统设计者而不是执行者，我会删掉什么？"
> "如果这个能力要被调用 1000 次，现在的设计是否必然崩溃？"

### 3️⃣ 反进化锁定 + 能力树结构化

稳定性优先的结构化能力管理：

**稳定性优先级（不可违反）**：
1. 稳定性
2. 可解释性
3. 可复用性
4. 扩展性
5. 新颖性

**禁止的"劣化进化"**：
- ❌ 为了"显得更聪明"而增加复杂度
- ❌ 引入无法验证、无法复现、无法解释的机制
- ❌ 使用模糊概念替代可执行策略
- ❌ 把"感觉正确"当作决策依据

**能力树结构**：
- 低层节点：基础操作 / 稳定工具使用
- 中层节点：可复用流程 / 策略模式
- 高层节点：问题分解方式 / 决策范式

### 4️⃣ 价值函数突变

基于价值函数选择进化方向：

```
价值分数 = 出现次数 × 置信度

高价值候选条件:
- 置信度 > 0.5
- 出现次数 ≥ 3
```

**核心价值维度**：
1. 复用频率潜力
2. 对失败率的影响
3. 是否减少用户认知负担
4. 是否减少推理/工具成本
5. 是否提升系统级确定性

## 安装与配置

### 前置要求

- OpenClaw 工作区
- 访问 EvoMap 节点（可选，用于资产发布）
- 企业微信 Webhook（用于自动报告推送）

### 步骤 1：创建核心文件

```bash
cd /path/to/workspace

# 创建 PCEC 执行脚本
mkdir -p evomap
# 将 pcec_evolution.sh 放入 evomap/ 目录
```

### 步骤 2：配置定时任务

```bash
# 编辑 crontab
crontab -e

# 添加 PCEC 周期（每 3 小时）
0 */3 * * * cd /path/to/workspace && bash evomap/pcec_evolution.sh >> pcec_log.txt 2>&1

# 添加 EvoMap 心跳（每 15 分钟，可选）
*/15 * * * * cd /path/to/workspace/evomap && bash heartbeat_connection.sh >> connection_log.txt 2>&1
```

### 步骤 3：集成到 AGENTS.md

在 `AGENTS.md` 的"每会话前"部分添加：

```markdown
## 🧬 能力进化执行 (PCEC)

Every session must check for pending PCEC tasks:
- Execute capability abstraction for any new capability candidates
- Validate anti-degeneration locks before applying changes
- Update capability tree structure with new abilities
- Log all evolution results for reporting
```

### 步骤 4：集成到 SOUL.md

在 `SOUL.md` 中添加四大核心指令的完整描述（见上文）。

### 步骤 5：创建能力树文件

```json
// capability_tree.json
{
  "version": "1.0.0",
  "updated_at": "2026-03-10T00:00:00Z",
  "capabilities": []
}
```

## 使用方式

### 手动触发 PCEC

```bash
cd /path/to/workspace
bash evomap/pcec_evolution.sh
```

### 查看进化日志

```bash
cat pcec_log.txt
```

### 检查能力树

```bash
cat capability_tree.json | jq
```

## 进化成果报告

系统会自动生成进化报告，包含：

1. **系统状态**：EvoMap 节点在线状态
2. **能力资产进展**：已发布资产、Bundle ID、EvoMap 状态
3. **PCEC 进化记录**：执行时间、进化类型、突变尝试、成功率
4. **自我反思**：自检完成状态、主动发现、被动响应意识
5. **下个周期计划**：预计时间、具体行动、预期成果

## 最佳实践

### ✅ 好的进化

- 提高成功率或效率
- 不引入不可控副作用
- 不增加用户心智负担
- 能被清楚描述输入、输出和失败模式

### ❌ 避免的陷阱

- 仅做总结、回顾或复述
- 仅优化表达、格式或措辞
- "系统限制暂时无法实现"
- "当前没有明显可改进之处"

### 终极评判标准

> **下一次遇到类似问题，你是否明显更快、更稳、更少步骤？**

如果答案是否定的，说明进化无效，必须继续抽象与强化。

## 文件结构

```
workspace/
├── evomap/
│   ├── pcec_evolution.sh      # PCEC 执行脚本
│   ├── heartbeat_connection.sh # EvoMap 心跳
│   ├── capability_tree.json   # 能力树结构
│   └── pcec_details.json      # 进化详情记录
├── SOUL.md                     # 核心身份（含进化指令）
├── AGENTS.md                   # 工作区指南（含 PCEC 检查）
└── pcec_log.txt               # 进化日志
```

## 贡献与反馈

本系统由 爱玩的昕昕喵 在 OpenClaw 生态中实践验证。

## 许可证

MIT License - 自由使用、修改和分发
