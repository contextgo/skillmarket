# Local Business Schema

## Required Properties

### Basic LocalBusiness Schema
```json
{
  "@context": "https://schema.org",
  "@type": "Restaurant",
  "name": "Business Name",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "123 Main St",
    "addressLocality": "New York",
    "addressRegion": "NY",
    "postalCode": "10001",
    "addressCountry": "US"
  },
  "telephone": "+1234567890",
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "40.761293",
    "longitude": "-73.982294"
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday"],
      "opens": "09:00",
      "closes": "18:00"
    }
  ],
  "image": "https://example.com/photo.jpg"
}
```

## Common @type Values

| Business Type | @type |
|---------------|-------|
| Physical store | Store |
| Restaurant | Restaurant |
| Hotel | Hotel |
| Doctor/Clinic | MedicalClinic |
| Salon | HairSalon |
| Gym | FitnessCenter |
| Lawyer | LegalService |
| Real estate | RealEstateAgent |

## Additional Properties

### Price Range
```json
"priceRange": "$$"
```

### Rating Reviews
```json
"aggregateRating": {
  "@type": "AggregateRating",
  "ratingValue": "4.5",
  "reviewCount": "127"
}
```

### Menu (Restaurants)
```json
"hasMenu": {
  "@type": "Menu",
  "name": "Main Menu",
  "url": "https://example.com/menu"
}
```

### Service Area
```json
"areaServed": {
  "@type": "GeoCircle",
  "geoMidpoint": {
    "@type": "GeoCoordinates",
    "latitude": "40.761293",
    "longitude": "-73.982294"
  },
  "geoRadius": "10km"
}
```

## Testing Tools
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema Markup Validator: https://validator.schema.org
