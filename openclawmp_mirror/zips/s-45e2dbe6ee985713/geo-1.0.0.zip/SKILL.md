---
name: geo
description: "Geo-targeting and local SEO optimization. Target specific geographic locations, manage multi-regional/multilingual websites, implement local business schema, and optimize for location-based searches."
---

## Quick Reference

| Topic | File |
|-------|------|
| Google Business Profile, NAP, local keywords | `local-business.md` |
| ccTLD, subdomains, subdirectories, hreflang | `multi-regional.md` |
| LocalBusiness schema, GeoCoordinates, OpeningHours | `schema.md` |
| Local content, location pages, geo-targeting signals | `content.md` |

## Critical Rules

### Google Business Profile (GBP)
- Claim and verify your listing — unverified profiles don't rank
- Complete ALL fields: hours, services, attributes, products
- Primary category: choose the most specific match (not generic "Business")
- Photos: businesses with photos get 42% more direction requests
- Posts: weekly updates show activity, appear in Knowledge Panel
- Q&A: seed with common questions, monitor for spam
- Respond to ALL reviews — especially negative, shows engagement

### NAP Consistency
- NAP = Name, Address, Phone — must be IDENTICAL everywhere
- Format matters: "Street" vs "St." is a mismatch to Google
- Check major directories: Yelp, Yellow Pages, Facebook, Apple Maps, Bing Places
- Use local phone number — toll-free looks non-local
- Update NAP when moving — inconsistency tanks rankings for months

### Multi-Regional URL Structures

| Type | Example | Pros | Cons |
|------|---------|------|------|
| ccTLD | example.de | Clear geo-target | Expensive, limits to one country |
| Subdomain | de.example.com | Easy to set up | Users may miss geo signal |
| Subdirectory | example.com/de/ | Low cost, same server | Weaker geo signal |
| URL param | site.com?loc=de | Not recommended | Hard to index, no geo signal |

### hreflang Implementation
- Tell Google which page version to show for which language/region
- Must be bidirectional: en→zh and zh→en
- Use x-default for fallback
- Implement in HTML head or HTTP headers
- Also add to sitemap

### Local Keywords
- "[Service] + [City]" pages for each location served
- "near me" queries: proximity + relevance + prominence
- Neighborhood/district names for dense metros
- Location in title tag: "Plumber in Austin, TX | Company Name"
- Service area pages: one per city, unique content each

### Geo-Targeting Signals Google Uses
1. ccTLD (.de, .cn, .co.uk) — strongest geo signal
2. hreflang annotations
3. Server location (IP address)
4. Local address and phone on page
5. Local language and currency
6. Links from local websites
7. Google Business Profile signals

### Local Content Requirements
- Location pages with unique content — not just NAP + map
- Local news/events coverage — shows community involvement
- Case studies with local clients — builds local relevance
- Embed Google Maps embed code
- Include neighborhood-specific details

### Reviews Strategy
- Quantity + recency + rating: all three matter for local pack
- Never buy fake reviews — Google detects patterns
- Review velocity: steady flow better than sudden burst
- Ask at point of transaction

### Structured Data Required
- LocalBusiness schema with:
  - @type (Restaurant, Store, etc.)
  - name, address, telephone
  - geo (latitude/longitude)
  - openingHoursSpecification
  - image
  - priceRange (if applicable)
- SameName and sameAs for social profiles

### Penalties to Avoid
- Doorway pages: thin location pages just for SEO
- Keyword stuffing in city names
- Duplicate content across location pages
- Incorrect hreflang (missing return tags)
- Using URL parameters for geo-targeting
