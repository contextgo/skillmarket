# Local Content Strategy

## Location Page Requirements

Each location page must have unique content:

### Minimum Requirements
- Unique introduction (not copied from other locations)
- Location-specific address and map embed
- Local phone number (not toll-free)
- Service list specific to that location
- Operating hours for that branch
- Directions or parking information
- Staff photos (location-specific team)
- Local customer testimonials/reviews

### Content Structure
```
1. H1: Brand + Location + Service
2. Intro paragraph: Local relevance
3. Services offered locally
4. About the local team
5. Directions/parking
6. Embedded Google Map
7. Contact information
8. Related local content links
```

## Geo-Targeting Content Signals

### What Google Looks For
1. Local address and phone number in content
2. Local landmarks and neighborhood references
3. Service area mentions
4. Local news/event coverage
5. Community involvement content
6. Local customer case studies
7. Region-specific keywords naturally integrated

### Content That Doesn't Help
- Generic content reused across locations
- Only NAP + map (too thin)
- Keyword-stuffed city names
- Duplicate content with just city name changed

## Multi-Location Business Strategy

### URL Structure
```
example.com/locations/new-york/
example.com/locations/los-angeles/
example.com/locations/chicago/
```

### Internal Linking
- Link from homepage to all location pages
- Location pages link to each other contextually
- Service pages link to relevant location pages

## Local Link Building

### Earn Local Links
- Local chamber of commerce membership
- Sponsoring local events
- Local charity partnerships
- Guest posts on local blogs
- Local news coverage
- Business associations (BBB, etc.)
