# Multi-Regional & Multi-Language SEO

## URL Structure Options

### 1. Country-Code TLD (ccTLD)
```
example.de     → Germany
example.co.uk  → United Kingdom
example.cn     → China
```
- **Pros:** Clear geo-target, strongest signal
- **Cons:** Expensive, limits to one country, may have registration restrictions

### 2. Subdomains with gTLD
```
de.example.com   → German site
fr.example.com   → French site
```
- **Pros:** Easy setup, different server locations possible
- **Cons:** Users may not recognize geo signal in URL

### 3. Subdirectories (Recommended for Small Sites)
```
example.com/de/   → German
example.com/fr/   → French
```
- **Pros:** Low cost, same server, domain authority consolidated
- **Cons:** Weaker geo signal than ccTLD

### 4. URL Parameters
```
example.com?loc=de
```
- **NOT recommended** — Google struggles to index properly

## hreflang Implementation

### Basic Syntax
```html
<link rel="alternate" hreflang="en" href="https://example.com/" />
<link rel="alternate" hreflang="zh-CN" href="https://example.com/zh/" />
<link rel="alternate" hreflang="x-default" href="https://example.com/" />
```

### Key Rules
1. **Bidirectional:** If en→zh exists, zh→en must also exist
2. **x-default:** Specify fallback for unhandled regions
3. **Self-reference:** Each page must link to itself
4. **Consistent:** Use same format across all pages

### Implementation Methods
- HTML `<head>` section
- HTTP headers (for PDF, etc.)
- XML sitemap

## Googlebot Location
- Googlebot primarily crawls from US IP addresses
- Won't use Accept-Language header for content selection
- Use hreflang to explicitly signal geo-targeting

## Server Location
- Server location is a geo signal but not decisive
- CDN users: Geo-DNS routing helps but isn't required
- Page speed matters more than server location
