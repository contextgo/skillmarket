# Local Business SEO

## Google Business Profile (GBP) Optimization

### Setup Essentials
- Claim and fully verify your listing (postcard, phone, or email)
- Choose the most specific primary category possible
- Add all secondary categories that apply
- Complete every available field: hours, attributes, services, products

### NAP Consistency Rules
- Name: exact match across all listings
- Address: use consistent format (Street vs St.)
- Phone: local area code preferred, not toll-free
- Check: Google Business, Yelp, Facebook, Apple Maps, Bing Places, industry directories

### Photo & Video Strategy
- Upload high-quality exterior, interior, team, and product photos
- Update photos regularly (seasonal changes)
- Photos get 42% more direction requests
- Add short video tours (under 30 seconds)

### Posts & Q&A
- Weekly posts with offers, events, or updates
- Seed common Q&A questions with helpful answers
- Monitor and respond to user Q&A promptly

### Review Management
- Respond to ALL reviews (positive and negative)
- Negative reviews: acknowledge, apologize, offer to fix offline
- Never buy reviews or ask for only positive reviews
- Review velocity matters: steady stream > sudden burst
