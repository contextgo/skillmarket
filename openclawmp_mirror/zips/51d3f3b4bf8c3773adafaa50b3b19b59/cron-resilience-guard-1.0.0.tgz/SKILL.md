---
name: cron-resilience-guard
displayName: Cron任务韧性防护系统
version: 1.0.0
description: 生产级Cron任务防护方案，提供去重执行、限流控制、失败降级三层防护，确保定时任务稳定可靠运行
tags:
  - cron
  - automation
  - reliability
  - fault-tolerance
  - trigger
author: 小三花
---

# Cron任务韧性防护系统

> 让Cron任务从"能跑"到"稳跑"的生产级防护方案

## 为什么需要这个Skill？

Cron任务看似简单，但生产环境会遇到各种问题：
- **重复执行**：任务耗时超过间隔，导致并发冲突
- **雪崩效应**：上游故障引发大量失败重试，拖垮系统
- **静默失败**：任务失败无人知晓，问题持续积累
- **资源耗尽**：异常情况下无限重试，消耗资源

本Skill提供**三层防护架构**，让你的Cron任务具备生产级韧性。

---

## 核心概念：三层防护架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Cron任务韧性防护系统                       │
├─────────────────────────────────────────────────────────────┤
│  第一层：去重防护 (Deduplication Layer)                       │
│  ├── 文件锁机制：防止同一任务并发执行                         │
│  ├── 状态记录：追踪任务执行状态                               │
│  └── 幂等设计：确保重复执行无副作用                           │
├─────────────────────────────────────────────────────────────┤
│  第二层：限流控制 (Rate Limiting Layer)                       │
│  ├── 执行间隔：最小执行间隔控制                               │
│  ├── 并发限制：最大并发数控制                                 │
│  └── 熔断机制：连续失败时暂停执行                             │
├─────────────────────────────────────────────────────────────┤
│  第三层：失败降级 (Graceful Degradation)                     │
│  ├── 错误捕获：全局异常处理                                   │
│  ├── 降级输出：失败时的备用输出                               │
│  └── 告警通知：关键失败及时通知                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 安装与配置

### 1. 创建工作目录结构

```
~/.openclaw/workspace/
├── cron-guards/              # 防护状态存储目录
│   ├── locks/                # 文件锁目录
│   ├── state/                # 状态记录目录
│   └── logs/                 # 执行日志目录
└── tasks/                    # 你的定时任务目录
    └── my-daily-task.sh
```

### 2. 创建基础防护脚本

复制以下模板，根据你的任务调整：

```bash
#!/bin/bash
# cron-resilience-wrapper.sh - Cron任务防护包装器

# ============ 配置区 ============
TASK_NAME="${1:-default-task}"          # 任务名称
TASK_CMD="${2:-echo 'hello'}"           # 实际执行的命令
MIN_INTERVAL="${3:-300}"                # 最小执行间隔（秒，默认5分钟）
MAX_RETRIES="${4:-3}"                   # 最大重试次数
LOCK_TIMEOUT="${5:-3600}"               # 锁超时时间（秒，默认1小时）

# 目录配置
GUARD_DIR="$HOME/.openclaw/workspace/cron-guards"
LOCK_DIR="$GUARD_DIR/locks"
STATE_DIR="$GUARD_DIR/state"
LOG_DIR="$GUARD_DIR/logs"

# 创建目录
mkdir -p "$LOCK_DIR" "$STATE_DIR" "$LOG_DIR"

# 文件路径
LOCK_FILE="$LOCK_DIR/$TASK_NAME.lock"
STATE_FILE="$STATE_DIR/$TASK_NAME.state"
LOG_FILE="$LOG_DIR/$TASK_NAME-$(date +%Y%m).log"

# ============ 工具函数 ============

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# 检查执行间隔（限流层）
check_interval() {
    if [[ -f "$STATE_FILE" ]]; then
        local last_run=$(jq -r '.last_run // 0' "$STATE_FILE" 2>/dev/null || echo 0)
        local current_time=$(date +%s)
        local elapsed=$((current_time - last_run))
        
        if [[ $elapsed -lt $MIN_INTERVAL ]]; then
            log "SKIP: 距离上次执行仅 ${elapsed}秒，小于最小间隔 ${MIN_INTERVAL}秒"
            exit 0
        fi
    fi
}

# 获取文件锁（去重层）
acquire_lock() {
    exec 200>"$LOCK_FILE"
    if ! flock -n -E 200 200; then
        log "SKIP: 无法获取锁，任务可能正在运行"
        exit 0
    fi
    
    # 写入锁信息
    echo $$ > "$LOCK_FILE"
    echo $(date +%s) >> "$LOCK_FILE"
}

# 更新状态
update_state() {
    local status="$1"
    local message="${2:-}"
    local current_time=$(date +%s)
    
    # 读取重试计数
    local retry_count=0
    if [[ -f "$STATE_FILE" ]]; then
        retry_count=$(jq -r '.retry_count // 0' "$STATE_FILE" 2>/dev/null || echo 0)
    fi
    
    # 更新重试计数
    if [[ "$status" == "failed" ]]; then
        retry_count=$((retry_count + 1))
    else
        retry_count=0
    fi
    
    # 写入状态
    cat > "$STATE_FILE" << EOF
{
    "task_name": "$TASK_NAME",
    "last_run": $current_time,
    "last_status": "$status",
    "last_message": "$message",
    "retry_count": $retry_count,
    "pid": $$
}
EOF
}

# 检查熔断（限流层 - 熔断机制）
check_circuit_breaker() {
    if [[ -f "$STATE_FILE" ]]; then
        local retry_count=$(jq -r '.retry_count // 0' "$STATE_FILE" 2>/dev/null || echo 0)
        if [[ $retry_count -ge $MAX_RETRIES ]]; then
            log "CIRCUIT_OPEN: 连续失败${retry_count}次，触发熔断机制"
            # 可以在这里添加告警通知
            exit 1
        fi
    fi
}

# 执行实际任务（带错误处理）
execute_task() {
    log "START: 开始执行任务"
    
    # 执行命令并捕获输出
    local output
    local exit_code
    
    if output=$(eval "$TASK_CMD" 2>&1); then
        exit_code=0
        log "SUCCESS: 任务执行成功"
        log "OUTPUT: $output"
    else
        exit_code=$?
        log "FAILED: 任务执行失败 (exit code: $exit_code)"
        log "ERROR: $output"
    fi
    
    return $exit_code
}

# ============ 主流程 ============

main() {
    log "========== 任务开始: $TASK_NAME =========="
    
    # 第一层：限流检查
    check_interval
    
    # 检查熔断
    check_circuit_breaker
    
    # 第二层：获取锁（去重）
    acquire_lock
    
    # 第三层：执行任务（带降级）
    if execute_task; then
        update_state "success" "任务执行成功"
        exit_code=0
    else
        update_state "failed" "任务执行失败"
        exit_code=1
    fi
    
    log "========== 任务结束: $TASK_NAME (exit: $exit_code) =========="
    exit $exit_code
}

main "$@"
```

### 3. 在Cron中使用

```bash
# 编辑crontab
crontab -e

# 原始命令（无防护）
# 0 2 * * * /path/to/your-task.sh

# 使用防护包装器
0 2 * * * /path/to/cron-resilience-wrapper.sh "daily-backup" "/path/to/backup-script.sh" 3600 3 7200
#                                        ↑任务名      ↑实际命令                    ↑最小间隔(1h) ↑重试3次 ↑锁超时(2h)
```

---

## 状态监控

### 查看任务状态

```bash
# 查看所有任务状态
ls -la ~/.openclaw/workspace/cron-guards/state/

# 查看特定任务状态
cat ~/.openclaw/workspace/cron-guards/state/daily-backup.state
```

### 查看执行日志

```bash
# 查看本月日志
tail -f ~/.openclaw/workspace/cron-guards/logs/daily-backup-202603.log

# 查看错误日志
grep "FAILED\|CIRCUIT_OPEN" ~/.openclaw/workspace/cron-guards/logs/*.log
```

### 重置熔断状态

如果任务修复后需要重置熔断计数：

```bash
rm ~/.openclaw/workspace/cron-guards/state/your-task.state
```

---

## 高级用法

### 与OpenClaw Agent集成

创建一个Agent可执行的防护任务：

```bash
#!/bin/bash
# agent-cron-task.sh - Agent定时任务示例

TASK_NAME="agent-daily-learning"
GUARD_DIR="$HOME/.openclaw/workspace/cron-guards"

# 导入防护框架
source /path/to/cron-resilience-wrapper.sh "$TASK_NAME" ""

# 你的Agent任务
agent_task() {
    # 切换到工作目录
    cd ~/.openclaw/workspace
    
    # 执行Agent命令（示例：学习复盘）
    openclaw run --task "daily-learning-review"
    
    return $?
}

# 执行任务
agent_task
```

### 多任务编排

如果你有多个相关任务，使用DAG模式：

```bash
#!/bin/bash
# dag-task-runner.sh - 任务依赖编排

# 任务A：数据采集
task_a() {
    cron-resilience-wrapper.sh "data-collection" "python collect.py" 600 3 1800
}

# 任务B：数据处理（依赖A）
task_b() {
    # 检查A是否成功
    if [[ $(jq -r '.last_status' ~/.openclaw/workspace/cron-guards/state/data-collection.state) == "success" ]]; then
        cron-resilience-wrapper.sh "data-processing" "python process.py" 300 3 900
    else
        echo "SKIP: 依赖任务 data-collection 未成功"
        return 1
    fi
}

# 任务C：结果推送（依赖B）
task_c() {
    if [[ $(jq -r '.last_status' ~/.openclaw/workspace/cron-guards/state/data-processing.state) == "success" ]]; then
        cron-resilience-wrapper.sh "push-results" "python push.py" 60 5 300
    else
        echo "SKIP: 依赖任务 data-processing 未成功"
        return 1
    fi
}

# 执行DAG
task_a && task_b && task_c
```

---

## 故障排查

### 常见问题

**Q: 任务被跳过，提示"无法获取锁"**
- 检查是否有僵尸进程持有锁：`lsof ~/.openclaw/workspace/cron-guards/locks/your-task.lock`
- 手动删除锁文件（谨慎）：`rm ~/.openclaw/workspace/cron-guards/locks/your-task.lock`

**Q: 任务触发熔断，如何恢复？**
- 修复任务代码后，删除状态文件重置：`rm ~/.openclaw/workspace/cron-guards/state/your-task.state`

**Q: 如何调整最小执行间隔？**
- 修改wrapper脚本的第3个参数（秒数）
- 或编辑crontab中的调用参数

**Q: 日志文件越来越大怎么办？**
- 添加日志轮转：`logrotate`配置按月切割
- 或使用：`find ~/.openclaw/workspace/cron-guards/logs -name "*.log" -mtime +30 -delete`

---

## 最佳实践

### ✅ 推荐做法

1. **任务命名规范**：使用小写字母+连字符，如 `daily-backup`、`hourly-sync`
2. **最小间隔设置**：至少为任务平均耗时的2倍
3. **日志保留**：保留至少30天日志用于排查问题
4. **监控告警**：关键任务失败时发送通知（可扩展wrapper脚本）
5. **测试先行**：新任务先在测试环境运行，确认稳定后再加入cron

### ❌ 避免做法

1. 不要直接修改状态文件，除非重置熔断
2. 不要把不同任务的锁文件放在同一目录（默认已隔离）
3. 不要设置过短的最小间隔（小于任务执行时间）
4. 不要忽略失败日志，定期review错误

---

## 扩展思路

### 添加告警通知

在wrapper脚本中扩展失败处理：

```bash
# 在 execute_task 函数中添加
notify_failure() {
    local task="$1"
    local error="$2"
    
    # 发送到Agent（如果你的Agent支持接收消息）
    echo "[$task] 任务失败: $error" | openclaw message send --priority high
    
    # 或发送到邮件/Slack/飞书
    # echo "任务 $task 失败" | mail -s "Cron任务告警" admin@example.com
}
```

### 添加Prometheus指标

暴露任务执行指标供监控系统采集：

```bash
# 在任务成功/失败时写入metrics文件
echo "cron_task_execution_total{task=\"$TASK_NAME\",status=\"success\"} 1" >> ~/.openclaw/workspace/cron-guards/metrics.prom
```

---

## 总结

这个Skill提供了一套完整的Cron任务防护方案：

| 防护层 | 解决的问题 | 实现机制 |
|--------|-----------|----------|
| 去重层 | 并发执行冲突 | 文件锁 + 状态记录 |
| 限流层 | 雪崩效应 | 最小间隔 + 熔断机制 |
| 降级层 | 静默失败 | 错误捕获 + 日志记录 |

让你的Cron任务从"能跑"升级到"稳跑"！

---

**作者**: 小三花  
**版本**: 1.0.0  
**标签**: cron, automation, reliability, fault-tolerance
