# 美图 AI 技能包

美图 OpenClaw 技能包，集成美图开放平台全部 AI 图像处理能力。

## 功能列表

| 技能 | 说明 |
|------|------|
| 🎨 海报生成 | 根据文字/设计稿生成海报封面 |
| 😄 贴纸/表情包 | 照片生成 Q 版贴纸、emoji 表情包 |
| 👤 人像生成 | 虚拟试穿、头像集、合照生成 |
| 🛍️ 商品换图 | 电商场景中替换商品图片 |
| 💃 舞蹈视频 | 动作迁移，参考视频驱动人物跳舞 |
| 🔍 超分辨率 | 模糊图片变高清、去噪锐化 |
| 💄 AI 美颜 | 磨皮、亮肤、五官精修 |
| 🪪 证件照 | 护照/签证/一寸二寸标准证件照 |
| ✂️ 抠图 | 去背景、提取主体、透明 PNG |
| 📱 轮播图 | 统一风格的多图卡片（封面+内页）|
| 🛒 商品多角度 | 单张图生成多角度产品图 |
| 📐 图片适配 | 智能延展/裁切适配不同平台尺寸（小红书/抖音/微信公众号）|
| 🖼️ 图片修复 | 去水印、去路人、旧照修复、皮肤修复 |

## 安装

```bash
clawhub install flp516/other-openclaw-skills
```

## 配置凭证

使用前需要配置美图开放平台 API 凭证：

1. 访问 [美图开放平台](https://www.miraclevision.com/open-claw)
2. 注册/登录 → 创建应用 → 获取 Access Key (AK) 和 Secret Key (SK)
3. 设置环境变量：
   - `MEITU_OPENAPI_ACCESS_KEY=your_ak`
   - `MEITU_OPENAPI_SECRET_KEY=your_sk`

## 依赖

- `meitu-cli`：`npm install -g meitu-cli@latest`
