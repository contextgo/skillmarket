---
name: auto-redbook
description: "自动撰写小红书笔记、生成多主题卡片、可选自动发布的完整工作流"
version: 1.1.0
---

# Auto-Redbook 小红书自动创作

自动撰写小红书笔记、生成多主题卡片、可选自动发布的完整工作流。

## 能力

- **8 套主题皮肤**：默认简约灰、Playful Geometric、Neo-Brutalism、Botanical、Professional、Retro、Terminal、Sketch
- **4 种分页模式**：separator（手动分页）、auto-fit（自动缩放）、auto-split（自动拆分）、dynamic（动态高度）
- **一键发布**：配置 Cookie 后可直接发布到小红书平台

## 使用方式

### 渲染图片

```bash
# Python 渲染（推荐）
python scripts/render_xhs.py content.md -t terminal -m auto-split

# Node.js 渲染
node scripts/render_xhs.js content.md -t retro -m auto-fit
```

### 发布到小红书

```bash
# 先配置 Cookie（从浏览器 F12 获取）
python scripts/publish_xhs.py --title "标题" --desc "描述" --images cover.png card_1.png card_2.png
```

## 参数说明

| 参数 | 说明 |
|------|------|
| `-t/--theme` | 主题：default/playful-geometric/neo-brutalism/botanical/professional/retro/terminal/sketch |
| `-m/--mode` | 分页模式：separator/auto-fit/auto-split/dynamic |
| `-w/--width` | 图片宽度（默认 1080） |
| `--dpr` | 设备像素比（默认 2） |

## 注意事项

1. Cookie 不要提交到 Git，存放在 .env 文件中
2. 避免高频发布，触发平台风控
3. 默认尺寸 1080x1440px，符合小红书推荐比例
