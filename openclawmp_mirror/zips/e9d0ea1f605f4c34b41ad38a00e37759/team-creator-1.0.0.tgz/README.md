# 多 Agent 团队创建器

自动创建 OpenClaw Agent 团队，支持预设模板和自定义配置。

## 核心能力

| 能力 | 说明 |
|------|------|
| 创建团队 | 按模板一键创建多个专业 agent |
| 初始化文件 | 自动生成 IDENTITY.md、SOUL.md、AGENTS.md、USER.md |
| 团队共享目录 | 创建 `buffer/` 共享工作区供协作 |
| 飞书绑定 | 可选绑定飞书机器人 |
| 预览模式 | dry-run 模式先预览不实际创建 |
| 校验 | 创建后自动验证 agent 是否就绪 |

## 触发场景

- "我想创建个项目团队"
- "我们需要 pm、ui、coding 三个角色"
- "帮我搭建一个 AI 项目团队"
- "创建一个 full 模板的团队"
- "帮我创建一个专门做测试的 agent"

## 预设模板

| 模板 | Agent 组成 | 适用场景 |
|------|------------|----------|
| `default` | 📋pm 🎨ui 💻coding | 标准项目团队（最常用） |
| `full` | 📋pm 🎨ui 💻coding 🧪tester 🔧devops | 完整职能团队 |
| `minimal` | 📋pm 💻coding | 最小团队 |
| `ai` | 📋pm 💻coding 🔬researcher | AI/研究项目 |
| `web` | 📋pm 🎨ui 💻coding 🔧devops | Web 项目 |

## 使用方式

```javascript
// 创建默认团队
await skill.handle({
  params: {
    action: 'create',
    template: 'default',
    initFiles: true
  }
});

// 自定义团队
await skill.handle({
  params: {
    action: 'create',
    agents: 'pm,ui,coding,tester',
    bindFeishu: true,
    initFiles: true
  }
});

// 预览模式
await skill.handle({
  params: {
    action: 'create',
    template: 'default',
    dryRun: true
  }
});
```

## 模型配置

支持全局模型覆盖和按 agent 类型指定模型：

```yaml
agents:
  - name: pm
    model: minimax/MiniMax-M2.5
  - name: coding
    model: openai-codex/gpt-5.4
```

## 前置要求

使用 `sessions_send` 进行跨 agent 派单前，需先在 `openclaw.json` 中开启跨 agent 通信权限。

---

**【小遇AI实验室荣誉出品】**
