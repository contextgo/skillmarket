---
name: team-creator
description: 自动创建 OpenClaw Agent 团队。当用户需要搭建多 agent 工作流、创建项目团队、初始化团队分工（如 pm+ui+coding）、或需要快速创建新的专业 agent 时使用。支持预设模板（default/full/minimal/ai/web）和自定义配置。
keywords: [agent, 团队, team, 创建, pm, ui, coding, 多agent, 协作]
---

# Team Creator

自动创建 OpenClaw Agent 团队，agent 可直接调用，无需用户手动执行命令。

## 核心能力

| 能力 | 说明 |
|------|------|
| 创建团队 | 按模板一键创建多个专业 agent |
| 初始化文件 | 自动生成 IDENTITY.md、SOUL.md、AGENTS.md、USER.md |
| 团队共享目录 | 创建 `buffer/` 共享工作区供协作 |
| 飞书绑定 | 可选绑定飞书机器人 |
| 预览模式 | dry-run 模式先预览不实际创建 |
| 校验 | 创建后自动验证 agent 是否就绪 |

## 触发场景

当用户表达以下意图时，应调用此技能：

1. **新建项目需要团队**
   - "我想创建个项目团队"
   - "我们需要 pm、ui、coding 三个角色"
   - "帮我搭建一个 AI 项目团队"

2. **需要完整的团队配置**
   - "创建一个 full 模板的团队"
   - "我想创建一个完整的开发团队"

3. **需要创建新的专业 agent**
   - "帮我创建一个专门做测试的 agent"
   - "我想加一个 researcher agent"

4. **需要快速复制/克隆团队**
   - "基于现有团队创建个新团队"
   - "复制一套 pm+ui 的配置"

## 使用方式

### Agent 自动调用示例

agent 应通过 `handle()` 函数直接调用本技能：

```javascript
// 1. 智能推荐模板（输入需求，自动推荐最合适的模板）
await skill.handle({
  params: {
    action: 'analyze',
    query: '我想做一个AI研究项目团队'
  }
});

// 2. 查看可用模板
await skill.handle({ params: { action: 'list' } });

// 3. 查看模板详情
await skill.handle({ params: { action: 'describe', template: 'default' } });

// 4. 创建团队（最常用，含完整文件初始化）
await skill.handle({
  params: {
    action: 'create',
    template: 'default',  // default | full | minimal | ai | web
    bindFeishu: false,
    dryRun: false,
    initFiles: true  // 生成 SOUL.md + AGENTS.md + USER.md + team-config.json + 共享buffer
  }
});

// 5. 预览模式（不实际创建）
await skill.handle({
  params: {
    action: 'create',
    template: 'default',
    dryRun: true
  }
});

// 6. 自定义 agent 列表（含文件初始化）
await skill.handle({
  params: {
    action: 'create',
    agents: 'pm,ui,coding,tester',
    bindFeishu: true,
    initFiles: true
  }
});

// 7. 校验团队状态
await skill.handle({ params: { action: 'validate', template: 'default' } });

// 8. 指定模型创建团队【小遇AI实验室荣誉出品】
await skill.handle({
  params: {
    action: 'create',
    template: 'default',
    model: 'minimax/MiniMax-M2.7-highspeed'  // 全局模型，可被 agent 级别覆盖
  }
});

// 9. 按 agent 类型指定不同模型
// 在模板中配置（见下方模板配置示例）

// 10. 强制覆盖已存在的 workspace
await skill.handle({
  params: {
    action: 'create',
    template: 'default',
    force: true  // 强制覆盖已存在的 workspace
  }
});
```

### 模板模型配置示例

在模板中可按 agent 类型指定模型：

```yaml
# assets/templates/xykz-team.yaml
name: xykz-team
agents:
  - name: pm
    emoji: "📋"
    role: 产品
    model: minimax/MiniMax-M2.7-highspeed
  - name: ui
    emoji: "🎨"
    role: 设计
    model: minimax/MiniMax-M2.7-highspeed
  - name: coding
    emoji: "💻"
    role: 开发
    model: openai-codex/gpt-5.4  # coding 使用更强模型
```

### 飞书绑定前置要求

飞书绑定需要先在飞书开放平台创建自定义 bot：

1. 进入 [飞书开放平台](https://open.feishu.cn/) 创建应用
2. 添加「机器人」能力
3. 获取 App ID 和 App Secret
4. 在 OpenClaw 配置中设置飞书 bot 凭证
5. 然后才能使用 `bindFeishu: true` 绑定

未配置飞书时，绑定操作会提示需要配置，但不会阻止 agent 创建。

### 预设模板

| 模板 | Agent 组成 | 适用场景 |
|------|------------|----------|
| `default` | 📋pm 🎨ui 💻coding | 标准项目团队（最常用） |
| `full` | 📋pm 🎨ui 💻coding 🧪tester 🔧devops | 完整职能团队 |
| `minimal` | 📋pm 💻coding | 最小团队 |
| `ai` | 📋pm 💻coding 🔬researcher | AI/研究项目 |
| `web` | 📋pm 🎨ui 💻coding 🔧devops | Web 项目 |

## 响应格式

### list action
```json
{
  "success": true,
  "action": "list",
  "templates": [
    { "name": "default", "description": "标准项目团队", "agents": "📋pm 🎨ui 💻coding" },
    ...
  ]
}
```

### create action
```json
{
  "success": true,
  "action": "create",
  "template": "default",
  "results": [
    { "name": "pm", "status": "ok", "workspace": "/path/to/workspace-pm", "model": "minimax/MiniMax-M2.5" },
    { "name": "ui", "status": "ok", "workspace": "/path/to/workspace-ui", "model": "minimax/MiniMax-M2.5" },
    { "name": "coding", "status": "ok", "workspace": "/path/to/workspace-coding", "model": "openai-codex/gpt-5.4" },
    { "name": "tester", "status": "skipped", "workspace": "/path/to/workspace-tester", "reason": "workspace_exists" }
  ],
  "summary": {
    "created": 3,
    "skipped": 1,
    "dryRun": 0
  },
  "dryRun": false,
  "nextSteps": ["openclaw gateway restart", "openclaw agents list"]
}
```

## 前置要求

使用 `sessions_send` 进行跨 agent 派单前，需要先确保 `openclaw.json` 中已开启跨 agent 通信权限：

```json
{
  "tools": {
    "sessions": {
      "visibility": "all"
    }
  }
}
```

修改后需执行 `openclaw gateway restart` 使配置生效。

**注意**：`team-creator` 本身不会修改 `openclaw.json`，这一步需要手动完成后再使用本技能创建团队。

## 注意事项

1. **模型配置**：默认使用 `minimax/MiniMax-M2.5`，可通过 `model` 参数全局覆盖，也可在模板中按 agent 类型指定
2. **workspace 冲突**：如果 `workspace-{name}` 目录已存在，会**跳过创建**并显示警告⚠️，使用 `--force` 可强制覆盖
3. **配置生效**：创建 agent 后 OpenClaw 会自动识别，无需手动配置
4. **飞书绑定**：需要预先在飞书开放平台创建对应 bot 才能生效，未配置时会显示引导信息

## 下一步建议

创建团队后，可以：
- 执行 `openclaw agents list` 查看所有 agent
- 为新 agent 初始化 SOUL.md/AGENTS.md/USER.md（使用 `initFiles: true` 会自动生成）
- 使用 `sessions_send` 为 specialist agent 分配任务
- 提醒新 agent 阅读 `/home/ecs-user/.openclaw/workspace/AGENTS.md` 了解团队协作规范

## 快速参考

| 操作 | 调用方式 |
|------|----------|
| 智能推荐模板 | `handle({ params: { action: 'analyze', query: '需求描述' } })` |
| 查看模板 | `handle({ params: { action: 'list' } })` |
| 创建默认团队 | `handle({ params: { action: 'create', template: 'default', initFiles: true } })` |
| 创建完整团队 | `handle({ params: { action: 'create', template: 'full', initFiles: true } })` |
| 自定义团队 | `handle({ params: { action: 'create', agents: 'pm,ui,coding', initFiles: true } })` |
| 预览不创建 | `handle({ params: { action: 'create', template: 'default', dryRun: true } })` |
| 指定全局模型 | `handle({ params: { action: 'create', template: 'default', model: 'minimax/MiniMax-M2.7-highspeed' } })` |
| 强制覆盖已存在 | `handle({ params: { action: 'create', template: 'default', force: true } })` |

---

**【小遇AI实验室荣誉出品】**
