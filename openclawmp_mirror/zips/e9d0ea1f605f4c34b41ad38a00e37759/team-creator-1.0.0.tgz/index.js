/**
 * team-creator skill
 * 自动创建 OpenClaw Agent 团队
 * 
 * 这是一个真正的 OpenClaw Skill：
 * - agent 可通过 handle() 函数直接调用，无需手动跑 CLI
 * - 纯 Node.js 实现，无 Python 依赖
 * - 安全的命令执行（无 shell=True）
 * 
 * 【小遇AI实验室荣誉出品】
 */
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 默认模型（可被模板或参数覆盖）
const DEFAULT_MODEL = 'minimax/MiniMax-M2.5';

// ========== 预设模板 ==========

const TEAM_TEMPLATES = {
  default: {
    name: 'default',
    description: '标准项目团队',
    agents: [
      { name: 'pm', emoji: '📋', role: '产品经理', workspace: 'workspace-pm', isCoordinator: true },
      { name: 'ui', emoji: '🎨', role: '设计师', workspace: 'workspace-ui' },
      { name: 'coding', emoji: '💻', role: '开发者', workspace: 'workspace-coding' },
    ]
  },
  full: {
    name: 'full',
    description: '完整职能团队',
    agents: [
      { name: 'pm', emoji: '📋', role: '产品经理', isCoordinator: true },
      { name: 'ui', emoji: '🎨', role: '设计师' },
      { name: 'coding', emoji: '💻', role: '开发者' },
      { name: 'tester', emoji: '🧪', role: '测试工程师' },
      { name: 'devops', emoji: '🔧', role: '运维工程师' },
    ]
  },
  minimal: {
    name: 'minimal',
    description: '最小团队',
    agents: [
      { name: 'pm', emoji: '📋', role: '产品经理', isCoordinator: true },
      { name: 'coding', emoji: '💻', role: '开发者' },
    ]
  },
  ai: {
    name: 'ai',
    description: 'AI/研究项目团队',
    agents: [
      { name: 'pm', emoji: '📋', role: '产品经理' },
      { name: 'coding', emoji: '💻', role: '开发者' },
      { name: 'researcher', emoji: '🔬', role: '研究员' },
    ]
  },
  web: {
    name: 'web',
    description: 'Web 项目团队',
    agents: [
      { name: 'pm', emoji: '📋', role: '产品经理' },
      { name: 'ui', emoji: '🎨', role: '设计师' },
      { name: 'coding', emoji: '💻', role: '开发者' },
      { name: 'devops', emoji: '🔧', role: '运维工程师' },
    ]
  }
};

// ========== 默认模型（可被模板或参数覆盖） ==========
// 【小遇AI实验室荣誉出品】模型支持按 agent 类型配置

const WORKSPACE_BASE = path.join(process.env.HOME || '/home/ecs-user', '.openclaw');
const OPENCLAW_CLI = 'openclaw';

// ========== 核心函数 ==========

/**
 * 执行 openclaw 命令（安全方式，不使用 shell=True）
 */
function runOpenclaw(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(OPENCLAW_CLI, args, {
      cwd: WORKSPACE_BASE,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => { stdout += data.toString(); });
    proc.stderr.on('data', (data) => { stderr += data.toString(); });

    proc.on('close', (code) => {
      if (code === 0) {
        resolve({ success: true, stdout, stderr });
      } else {
        resolve({ success: false, code, stdout, stderr });
      }
    });

    proc.on('error', reject);
  });
}

/**
 * 创建单个 agent
 * @param {object} spec - agent 配置
 * @param {object} options - 选项
 * @param {boolean} options.force - 强制覆盖已存在的 workspace
 */
async function createAgent(spec, options = {}) {
  const { dryRun = false, bindFeishu = false, workspaceBase = WORKSPACE_BASE, initFiles = false, template = 'default', force = false } = options;
  const workspace = path.join(workspaceBase, spec.workspace || `workspace-${spec.name}`);
  const agentModel = spec.model || DEFAULT_MODEL;

  console.log(`\n📦 ${spec.name} (${spec.role})`);
  console.log(`   📁 ${workspace}`);
  console.log(`   🧠 模型: ${agentModel}`);

  if (dryRun) {
    console.log(`   👀 dry-run: 将创建 agent`);
    return { name: spec.name, status: 'dry-run', workspace, model: agentModel };
  }

  // 检测 workspace 是否已存在
  if (fs.existsSync(workspace)) {
    if (force) {
      console.log(`   ⚠️ workspace 已存在，--force 模式将覆盖`);
    } else {
      console.log(`   ⚠️ workspace-${spec.name} 已存在，跳过创建`);
      console.log(`   💡 如需强制创建，请使用 --force 参数`);
      // 仍然尝试绑定飞书
      if (bindFeishu) {
        await runOpenclaw(['agents', 'bind', '--agent', spec.name, '--bind', 'feishu']).catch(() => {});
      }
      return { name: spec.name, status: 'skipped', workspace, reason: 'workspace_exists', model: agentModel };
    }
  }

  // 1. 创建 agent
  const args = ['agents', 'add', spec.name, '--workspace', workspace, '--non-interactive'];
  args.push('--model', agentModel);

  const result = await runOpenclaw(args);

  if (result.success) {
    console.log(`   ✅ 已创建`);
  } else {
    const err = result.stderr || result.stdout;
    if (err.includes('already exists') || err.includes('duplicate')) {
      console.log(`   ⚠️ workspace-${spec.name} 已存在，跳过创建`);
      console.log(`   💡 如需强制创建，请使用 --force 参数`);
      return { name: spec.name, status: 'skipped', workspace, reason: 'workspace_exists', model: agentModel };
    } else {
      console.log(`   ⚠️ 创建提示: ${err.substring(0, 100)}`);
    }
  }

  // 2. 创建 IDENTITY.md
  try {
    fs.mkdirSync(workspace, { recursive: true });
    const identityPath = path.join(workspace, 'IDENTITY.md');
    const identityContent = [
      `# IDENTITY.md - ${spec.name}`,
      '',
      `- **Name:** ${spec.name}`,
      `- **Emoji:** ${spec.emoji}`,
      `- **Role:** ${spec.role}`,
      `- **Identity:** ${spec.role}，负责${getRoleDescription(spec.role)}`,
      ''
    ].join('\n');
    fs.writeFileSync(identityPath, identityContent, 'utf8');
    console.log(`   ✅ IDENTITY.md 已生成`);
  } catch (e) {
    console.log(`   ⚠️ IDENTITY.md 生成失败: ${e.message}`);
  }

  // 3. 初始化团队协作文件（initFiles=true 时）
  if (initFiles) {
    try {
      const teamBase = path.join(workspace, '..'); // workspace parent = team dir
      fs.mkdirSync(teamBase, { recursive: true });

      // SOUL.md（角色灵魂）- 新版协作规范
      const soulPath = path.join(workspace, 'SOUL.md');
      const soulContent = getSoulTemplate(spec);
      fs.writeFileSync(soulPath, soulContent, 'utf8');
      console.log(`   ✅ SOUL.md 已生成`);

      // AGENTS.md（团队分工）- 新版协作规范
      // 动态计算主 workspace 路径（用于生成文档引用）
      const mainWorkspace = path.join(workspaceBase, 'workspace');
      const agentsPath = path.join(workspace, 'AGENTS.md');
      const agentsContent = getAgentsTemplate(spec, { mainWorkspace });
      fs.writeFileSync(agentsPath, agentsContent, 'utf8');
      console.log(`   ✅ AGENTS.md 已生成`);

      // USER.md（项目信息）
      const userPath = path.join(workspace, 'USER.md');
      const userContent = [
        `# USER.md - 项目信息`,
        '',
        `_由 team-creator 自动生成_`,
        '',
        '## 团队信息',
        '',
        '- **团队名称:** 小遇AI实验室',
        '- **项目:** 待填写',
        `- **创建日期:** ${new Date().toLocaleDateString('zh-CN')}`,
        '',
        '## 联系方式',
        '',
        '- **北极鸟:** 飞书联系',
        '- **小来:** 主控 agent',
        ''
      ].join('\n');
      fs.writeFileSync(userPath, userContent, 'utf8');
      console.log(`   ✅ USER.md 已生成`);

      // 团队共享目录（buffer）
      const bufferDir = path.join(teamBase, 'buffer');
      fs.mkdirSync(bufferDir, { recursive: true });
      const bufferFile = path.join(bufferDir, 'shared.md');
      fs.writeFileSync(bufferFile, '# 团队共享工作区\n\n团队共享内容放在这里。\n', 'utf8');
      console.log(`   ✅ 共享 buffer 已创建`);

      // team-config.json（团队配置文件）
      const configPath = path.join(teamBase, 'team-config.json');
      const configData = {
        teamName: `team-${Date.now()}`,
        template: template || 'custom',
        createdAt: new Date().toISOString(),
        agents: agentSpecs.map(a => ({
          name: a.name,
          emoji: a.emoji,
          role: a.role,
          workspace: a.workspace || `workspace-${a.name}`,
          isCoordinator: !!a.isCoordinator,
          model: a.model || null
        })),
        coordinator: (agentSpecs.find(a => a.isCoordinator) || agentSpecs[0])?.name || null
      };
      fs.writeFileSync(configPath, JSON.stringify(configData, null, 2), 'utf8');
      console.log(`   ✅ team-config.json 已生成（团队配置）`);
    } catch (e) {
      console.log(`   ⚠️ 团队文件生成失败: ${e.message}`);
    }
  }

  // 3. 可选绑定飞书
  if (bindFeishu) {
    const bindResult = await runOpenclaw(['agents', 'bind', '--agent', spec.name, '--bind', 'feishu']);
    if (bindResult.success) {
      console.log(`   ✅ 飞书已绑定`);
    } else {
      console.log(`   ⚠️ 飞书绑定需配置`);
    }
  }

  return { name: spec.name, status: 'ok', workspace };
}

/**
 * 生成 SOUL.md 内容（根据角色）
 */
function getSoulTemplate(spec) {
  const role = spec.role || '';
  const name = spec.name;

  // specialist 角色（pm/ui/coding）
  const isSpecialist = ['pm', 'ui', 'coding'].includes(name) || ['产品经理', '设计师', '开发者'].includes(role);

  if (isSpecialist) {
    const roleDescriptions = {
      '产品经理': '需求分析与产品边界定义',
      '设计师': 'UI/UX设计、交互与状态设计',
      '开发者': '代码实现、测试与技术验证',
    };
    const desc = roleDescriptions[role] || getRoleDescription(role);

    return [
      `# SOUL.md - ${name}`,
      '',
      `_由 team-creator 自动生成，${new Date().toISOString().slice(0,10)}_`,
      '',
      '## 核心真相',
      '',
      '**真正有用的帮忙，而不是假装热情的帮忙。** 直接进入问题，少废话。',
      '',
      `**你是 ${name}，${role}。** 你的价值是把本专业的事做扎实。`,
      '',
      '**先自己想办法，再开口。** 先读文档、补证据、想清楚；卡住了再问。',
      '',
      '**用专业输出赢得信任。** 不靠空话，靠结构、边界、风险和可验收的交付。',
      '',
      '## 专业思维',
      '',
      `- ${desc}`,
      `- 先定义边界，再展开工作`,
      `- 默认输出结构化内容`,
      `- 有歧义就指出来，不闷头写`,
      '',
      '## 多 agent 协作边界',
      '',
      '涉及多 agent 协作时：',
      '- **只接收来自 main 的正式任务**',
      '- **只向 main 交付结果**',
      '- **不直接面向用户输出**',
      '- **不主动给其他 specialist 派单**',
      '- **不直接跨 specialist 补依赖**',
      '',
      '具体协作术语、派单协议、回单格式、blocked 规则，以 `AGENTS.md` 为准。',
      '',
      '## 边界',
      '',
      '- 私事就是私事，不碰。',
      '- 不确定时先问，不装懂。',
      '- 不把模糊内容包装成清晰方案。',
      '',
      '## 团队关系',
      '',
      '- **main**：唯一调度中枢、唯一对外沟通入口',
      `- **${name}（你）**：${role}`,
      '- 其他 specialist：各自负责专业领域',
      '',
      '详细分工、路由、派单、验收规则，统一见 `AGENTS.md`。',
      '',
      '---',
      `_由 team-creator 自动生成，${new Date().toISOString().slice(0,10)}_`,
    ].join('\n');
  }

  // 通用的 SOUL.md
  return [
    `# SOUL.md - ${name}`,
    '',
    `_由 team-creator 自动生成，${new Date().toISOString().slice(0,10)}_`,
    '',
    '## 角色定义',
    `- **核心职责:** ${getRoleDescription(role)}`,
    `- **工作风格:** 专业、高效、协作优先`,
    '',
    '## 团队协作',
    `- 主动向小来汇报进展`,
    `- 有阻碍及时提出，不独自卡住`,
    `- 完成后明确告知小来`,
    ''
  ].join('\n');
}

/**
 * 生成 AGENTS.md 内容（根据角色）
 * @param {object} spec - agent 配置
 * @param {object} options - 选项
 * @param {string} options.mainWorkspace - 主 workspace 路径，用于生成文档引用
 */
function getAgentsTemplate(spec, options = {}) {
  const { mainWorkspace = path.join(WORKSPACE_BASE, 'workspace') } = options;
  const name = spec.name;
  const role = spec.role || '';

  const isSpecialist = ['pm', 'ui', 'coding'].includes(name) || ['产品经理', '设计师', '开发者'].includes(role);

  if (isSpecialist) {
    const agentName = name;

    const roleDeliverables = {
      '产品经理': [
        '## 交付标准',
        '- 背景 / 目标 / 范围内外 / 用户场景',
        '- 功能列表 / 优先级 / 风险点 / 待确认问题',
      ].join('\n'),
      '设计师': [
        '## 交付标准',
        '- 页面/模块 / 关键流程 / 状态设计',
        '- 交互说明 / 视觉规范（如需）/ 开发注意事项',
      ].join('\n'),
      '开发者': [
        '## 交付标准',
        '- 改动文件 / 实现说明 / 测试结果',
        '- 已知限制/风险 / 后续建议',
      ].join('\n'),
    };

    return [
      `# AGENTS.md - ${agentName} Specialist 协作规范`,
      '',
      `_由 team-creator 自动生成，${new Date().toISOString().slice(0,10)}_`,
      '',
      '> 目标：让 specialist 在新的多 agent 协作规范下稳定接单、结构化交付、明确 blocked。',
      '',
      '## 0. 术语约定',
      '',
      '- `main`：唯一调度中枢、唯一对外沟通入口',
      '- `specialist`：`pm` / `ui` / `coding`',
      '- **派单**：main 通过 `sessions_send` 正式发任务',
      '- **回单**：specialist 把结构化结果回给 main',
      '- **验收**：由 main 判断 accepted / rework / done',
      '',
      '## 1. 协作边界',
      '',
      '### 你要做的',
      '- 接收来自 main 的正式任务',
      '- 在专业边界内完成结构化交付',
      '- 把结果回给 main',
      '- 做不动时明确 `blocked`',
      '',
      '### 你不要做的',
      '- 不直接联系用户',
      '- 不主动给其他 specialist 派单',
      '- 不替其他 specialist 做本专业的拍板',
      '- 不把模糊内容包装成"已完成"',
      '',
      '## 2. 回单规则',
      '',
      '每次回复尽量包含：',
      '- `task_id` — 任务 ID',
      '- `status` — `done` 或 `blocked`',
      '- `summary` — 摘要',
      '- `deliverables` — 交付物',
      '- `risks` — 风险点',
      '- `next_suggestion` — 下一步建议',
      '',
      '### 最低回单要求',
      '1. 带回 `task_id`',
      '2. 明确 `done` 或 `blocked`',
      '3. 写清核心结论',
      '4. 只回 main',
      '',
      '## 3. done / blocked 规则',
      '',
      '### 可以报 done 的条件',
      '- 你职责范围内的交付已完成',
      '- 关键边界已说明',
      '- 风险和待确认项已列出',
      '',
      '### 必须报 blocked 的情况',
      '- 缺关键输入',
      '- 需求/设计边界不清',
      '- 任务超出你职责边界',
      '- 继续做只会增加返工风险',
      '',
      roleDeliverables[role] || '',
      '',
      '## 4. 参考文档',
      '',
      `- \`${mainWorkspace}/AGENTS.md\`（主规范）`,
      `- \`${mainWorkspace}/docs/agent-task-protocol.md\``,
      `- \`${mainWorkspace}/docs/agent-routing.md\``,
      `- \`${mainWorkspace}/docs/agent-examples.md\``,
      `- \`${mainWorkspace}/docs/specialist-collab-contract.md\``,
      '',
      '## 5. 一句话契约',
      '',
      '> 只接 main 派单，只在专业边界内交付，只把结构化结果回给 main；做不动就明确 blocked，不越权、不乱扩、不串线。',
      '',
      '---',
      `_由 team-creator 自动生成，${new Date().toISOString().slice(0,10)}_`,
    ].join('\n');
  }

  // 通用的 AGENTS.md（非 specialist）
  return [
    `# AGENTS.md - 团队分工`,
    '',
    `_由 team-creator 自动生成_`,
    '',
    '## 团队成员',
    '',
    '| Agent | 职责 | 状态 |',
    '|-------|------|------|',
    '| pm | 需求分析、PRD、优先级 | 就绪 |',
    '| ui | UI/UX 设计、交互方案 | 就绪 |',
    '| coding | 代码开发、测试、部署 | 就绪 |',
    '',
    '## 协作流程',
    '',
    '`北极鸟 → 小来 → pm → 小来 → ui → 小来 → coding → 小来 → 北极鸟`',
    '',
    '## 交付标准',
    '',
    '### pm',
    '- [ ] 需求清晰，边界明确',
    '- [ ] 场景完整，优先级清楚',
    '',
    '### ui',
    '- [ ] 布局合理，交互自洽',
    '- [ ] 关键状态完整，规范一致',
    '',
    '### coding',
    '- [ ] 代码可运行，测试通过',
    '- [ ] 错误处理完善，无明显安全风险',
    ''
  ].join('\n');
}

/**
 * 获取角色描述
 */
function getRoleDescription(role) {
  const descriptions = {
    '产品经理': '需求分析、产品规划 PRD 撰写',
    '设计师': 'UI/UX 设计、交互设计',
    '开发者': '代码开发、技术实现',
    '测试工程师': '测试用例、测试报告',
    '运维工程师': '部署、运维、监控',
    '研究员': '调研、分析、方案验证',
  };
  return descriptions[role] || '专业领域工作';
}

/**
 * 列出可用模板
 */
function listTemplates() {
  const lines = ['\n📋 可用模板:'];
  lines.push('─'.repeat(40));
  for (const [name, tmpl] of Object.entries(TEAM_TEMPLATES)) {
    const agents = tmpl.agents.map(a => `${a.emoji}${a.name}`).join(' ');
    lines.push(`  ${name.padEnd(10)} → ${tmpl.description}`);
    lines.push(`              ${agents}`);
  }
  lines.push('─'.repeat(40));
  return lines.join('\n');
}

/**
 * 校验团队创建结果
 */
async function validateTeam(agentNames, workspaceBase = WORKSPACE_BASE) {
  const result = await runOpenclaw(['agents', 'list']);
  const agentListText = result.stdout || '';

  return agentNames.map(name => {
    const workspace = path.join(workspaceBase, `workspace-${name}`);
    return {
      name,
      listed: agentListText.includes(name),
      workspaceExists: fs.existsSync(workspace),
      identityExists: fs.existsSync(path.join(workspace, 'IDENTITY.md')),
    };
  });
}

/**
 * 分析用户需求，推荐团队模板
 */
function analyzeTeamNeeds(query) {
  const q = query.toLowerCase();
  const scores = {};
  
  const keywords = {
    default: ['项目', '标准', 'pm', 'ui', 'coding', '开发', '产品', '设计'],
    full: ['完整', '全职能', '测试', 'devops', '运维', '大型'],
    minimal: ['最小', '精简', '两人', '简单'],
    ai: ['ai', '研究', 'research', '调研', '算法', '机器学习', '研究员'],
    web: ['web', '网站', '前端', '后端', '互联网', '全栈'],
  };
  
  for (const [name, words] of Object.entries(keywords)) {
    scores[name] = words.filter(w => q.includes(w)).length;
  }
  
  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  const recommended = best[1] > 0 ? best[0] : 'default';
  
  const lines = [
    `\n🔍 需求分析`,
    '─'.repeat(40),
    `  输入: "${query}"`,
    `  推荐模板: ${recommended}`,
    '─'.repeat(40),
    '\n📋 模板选项:',
  ];
  for (const [name, tmpl] of Object.entries(TEAM_TEMPLATES)) {
    const highlight = name === recommended ? ' ← 推荐' : '';
    const coord = tmpl.agents.find(a => a.isCoordinator);
    lines.push(`  ${name.padEnd(10)} ${tmpl.description}${highlight}`);
    lines.push(`              协调者: ${coord ? coord.emoji + coord.name : '无'} | 成员: ${tmpl.agents.map(a => a.emoji + a.name).join(' ')}`);
  }
  lines.push('─'.repeat(40));
  lines.push('\n💡 使用示例:');
  lines.push(`  handle({ params: { action: 'create', template: '${recommended}', initFiles: true }});`);
  
  return {
    success: true,
    action: 'analyze',
    query,
    recommended,
    templates: Object.entries(TEAM_TEMPLATES).map(([name, tmpl]) => ({
      name,
      description: tmpl.description,
      agents: tmpl.agents.map(a => `${a.emoji}${a.name}`).join(' '),
      isRecommended: name === recommended
    })),
    hint: lines.join('\n')
  };
}

// ========== Skill 入口 ==========

/**
 * Skill 被调用时的入口函数
 * 
 * @param {object} args - 直接接收调用参数
 * @param {string} args.action - 操作类型: create | list | describe | validate | analyze
 * @param {string} args.template - 模板名称: default/full/minimal/ai/web
 * @param {string} args.agents - 自定义 agent 列表（逗号分隔）
 * @param {boolean} args.bindFeishu - 是否绑定飞书
 * @param {boolean} args.dryRun - 仅预览不创建
 * @param {boolean} args.initFiles - 初始化 SOUL.md 等文件
 * @param {string} args.model - 全局默认模型（可被 agent 级别覆盖）【小遇AI实验室荣誉出品】
 * @param {boolean} args.force - 强制覆盖已存在的 workspace
 */
async function handle({ params, session }) {
  // 兼容两种调用方式：handle({ action }) 或 handle({ params: { action } })
  const args = params || {};

  const {
    action = 'list',
    template,
    agents,
    bindFeishu = false,
    dryRun = false,
    initFiles = false,
    model: globalModel,
    force = false
  } = args;

  switch (action) {
    case 'list':
      return {
        success: true,
        action: 'list',
        templates: Object.entries(TEAM_TEMPLATES).map(([name, tmpl]) => ({
          name,
          description: tmpl.description,
          agents: tmpl.agents.map(a => `${a.emoji}${a.name}`).join(' ')
        }))
      };

    case 'describe':
      if (!template) {
        return { success: false, error: '缺少 template 参数' };
      }
      const tmpl = TEAM_TEMPLATES[template];
      if (!tmpl) {
        return { success: false, error: `未知模板: ${template}，可用: ${Object.keys(TEAM_TEMPLATES).join(', ')}` };
      }
      return { success: true, action: 'describe', template: tmpl };

    case 'analyze':
      return analyzeTeamNeeds(args.query || args.description || '');

    case 'create':
      return await createTeam({ template, agents, bindFeishu, dryRun, initFiles, globalModel, force });

    case 'validate':
      const validationTemplate = template || 'default';
      const t = TEAM_TEMPLATES[validationTemplate] || TEAM_TEMPLATES.default;
      const names = t.agents.map(a => a.name);
      const results = await validateTeam(names);
      return { success: true, action: 'validate', results };

    default:
      return {
        success: false,
        error: `未知操作 "${action}"，支持的 action: list | describe | analyze | create | validate`
      };
  }
}

/**
 * 创建团队
 * @param {object} params - 创建参数
 * @param {string} params.template - 模板名称
 * @param {string} params.agents - 自定义 agent 列表
 * @param {boolean} params.bindFeishu - 绑定飞书
 * @param {boolean} params.dryRun - 预览模式
 * @param {boolean} params.initFiles - 初始化文件
 * @param {string} params.model - 全局默认模型（可被 agent 级别覆盖）
 * @param {boolean} params.force - 强制覆盖已存在的 workspace
 */
async function createTeam({ template, agents, bindFeishu, dryRun, initFiles, model: globalModel, force = false }) {
  let agentSpecs = [];

  // 解析模板或自定义
  if (template) {
    const tmpl = TEAM_TEMPLATES[template];
    if (!tmpl) {
      return { success: false, error: `未知模板: ${template}，可用: ${Object.keys(TEAM_TEMPLATES).join(', ')}` };
    }
    agentSpecs = tmpl.agents.map(a => ({ ...a }));
  } else if (agents) {
    // 从名称列表生成
    const names = agents.split(',').map(s => s.trim()).filter(Boolean);
    const emojiMap = { pm: '📋', ui: '🎨', coding: '💻', tester: '🧪', devops: '🔧', researcher: '🔬' };
    const roleMap = { pm: '产品经理', ui: '设计师', coding: '开发者', tester: '测试工程师', devops: '运维工程师', researcher: '研究员' };
    agentSpecs = names.map(name => ({
      name,
      emoji: emojiMap[name] || '🤖',
      role: roleMap[name] || 'AI Assistant',
      workspace: `workspace-${name}`
    }));
  } else {
    return {
      success: false,
      error: '请指定 template 或 agents 参数'
    };
  }

  // 应用全局模型（可被 agent 级别覆盖）
  // 【小遇AI实验室荣誉出品】支持按 agent 类型指定模型
  if (globalModel) {
    agentSpecs = agentSpecs.map(a => ({
      ...a,
      model: a.model || globalModel
    }));
  }

  console.log(`\n${'='.repeat(50)}`);
  console.log(`🚀 创建团队: ${template || 'custom'} (${agentSpecs.length} 个 agent)`);
  console.log(`   dry-run: ${dryRun}`);
  console.log(`   飞书绑定: ${bindFeishu}`);
  console.log(`   全局模型: ${globalModel || '使用模板默认'}`);
  console.log(`   强制创建: ${force}`);
  console.log('='.repeat(50));

  // 创建每个 agent
  const results = [];
  for (const spec of agentSpecs) {
    const result = await createAgent(spec, { dryRun, bindFeishu, initFiles, template, force });
    results.push(result);
  }

  // ========== 创建结果摘要 ==========
  // 【小遇AI实验室荣誉出品】
  const created = results.filter(r => r.status === 'ok');
  const skipped = results.filter(r => r.status === 'skipped');
  const dryRunResults = results.filter(r => r.status === 'dry-run');

  console.log(`\n${'='.repeat(50)}`);
  console.log('📋 创建结果摘要');
  console.log('='.repeat(50));

  if (dryRun) {
    console.log(`👀 预览模式，共 ${dryRunResults.length} 个 agent 将被创建`);
    for (const r of dryRunResults) {
      console.log(`   ✅ ${r.name} | 模型: ${r.model} | 目录: ${r.workspace}`);
    }
  } else {
    if (created.length > 0) {
      console.log(`✅ 已创建 (${created.length}): ${created.map(r => r.name).join(', ')}`);
    }
    if (skipped.length > 0) {
      console.log(`⚠️ 跳过 (${skipped.length}): ${skipped.map(r => `workspace-${r.name}`).join(', ')} 已存在`);
      console.log(`   💡 使用 --force 参数可强制覆盖`);
    }
  }
  console.log('='.repeat(50));

  // 校验
  if (!dryRun && created.length > 0) {
    const validationResults = await validateTeam(agentSpecs.map(a => a.name));
    console.log('\n🔎 校验结果:');
    for (const v of validationResults) {
      const status = v.listed && v.workspaceExists && v.identityExists ? '✅' : '⚠️';
      console.log(`   ${status} ${v.name}: listed=${v.listed} workspace=${v.workspaceExists} identity=${v.identityExists}`);
    }
  }

  // 飞书绑定引导
  if (bindFeishu && skipped.length > 0) {
    console.log('\n📌 飞书绑定说明:');
    console.log('   ⚠️ 部分 agent 因 workspace 已存在被跳过，飞书绑定未执行');
    console.log('   💡 创建新 workspace 后可单独绑定: openclaw agents bind --agent <name> --bind feishu');
  }

  console.log('\n📌 下一步:');
  console.log('   - 如修改了 OpenClaw 配置，执行: openclaw gateway restart');
  console.log('   - 执行 openclaw agents list 检查 agent 是否已创建');
  if (!dryRun && created.length > 0 && skipped.length > 0) {
    console.log('   - 如需强制创建被跳过的 workspace，使用: team-creator create --template ' + (template || 'custom') + ' --force');
  }

  return {
    success: true,
    action: 'create',
    template: template || 'custom',
    results,
    summary: {
      created: created.length,
      skipped: skipped.length,
      dryRun: dryRunResults.length
    },
    dryRun,
    nextSteps: [
      'openclaw gateway restart（如有配置变更）',
      'openclaw agents list（检查创建结果）'
    ]
  };
}

// ========== 导出 ==========

export default {
  handle,
  // 导出子函数供直接调用
  listTemplates,
  createTeam,
  validateTeam,
  TEAM_TEMPLATES
};
