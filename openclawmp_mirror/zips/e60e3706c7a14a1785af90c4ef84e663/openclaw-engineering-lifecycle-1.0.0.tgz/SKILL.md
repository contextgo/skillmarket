---
name: openclaw-engineering-lifecycle
description: Guides OpenClaw agents through DEFINE→PLAN→BUILD→VERIFY→REVIEW→SHIP engineering lifecycle. Use when implementing features, fixing bugs, changing code, reviewing work, preparing launches, or coordinating zhi-* engineering agents. Use when a task needs spec, plan, incremental implementation, tests, code review, debugging, or shipping checks.
---

# OpenClaw Engineering Lifecycle

## Overview

This skill turns engineering work into a controlled lifecycle:

```text
DEFINE → PLAN → BUILD → VERIFY → REVIEW → SHIP
```

It is adapted from `addyosmani/agent-skills` and optimized for OpenClaw's `zhi-*` agent workflow.

Core rule: **no meaningful engineering change is complete without evidence.**

## When to Use

Use this skill when:

- implementing a feature
- fixing a bug
- changing code or configuration
- reviewing code
- preparing a release/deployment
- coordinating `zhi-pm`, `zhi-architect`, `zhi-coder`, `zhi-auditor`, `zhi-monitor`
- a task feels large, ambiguous, risky, or hard to verify

Do not use it for:

- simple Q&A with no artifact changes
- pure brainstorming with no execution requested
- non-engineering writing tasks

## Lifecycle

### 1. DEFINE — clarify before doing

Responsible agents: `zhi-pm`, `zhi-architect`

Before implementation, identify:

- objective
- scope
- non-goals
- constraints
- affected files/services
- acceptance criteria
- rollback/safety boundary if relevant

Minimum output:

```markdown
## Definition
- Goal:
- Scope:
- Non-goals:
- Constraints:
- Acceptance criteria:
```

If requirements are unclear, stop and ask the smallest blocking question.

### 2. PLAN — split into verifiable tasks

Responsible agents: `zhi-pm`, `zhi-architect`

Break work into small ordered tasks. Each task must have:

- action
- expected output
- verification method
- dependencies

Preferred task size: one logical slice that can be reviewed and reverted.

### 3. BUILD — implement incrementally

Responsible agent: `zhi-coder`

Rules:

1. One slice at a time.
2. Keep the system runnable after each slice.
3. Prefer boring/simple code.
4. Do not refactor unrelated areas.
5. Do not expand scope without approval.

For multi-file changes, use thin vertical slices:

```text
contract/schema → smallest implementation → tests → docs/update
```

### 4. VERIFY — prove it works

Responsible agent: `zhi-monitor`

Verification must produce evidence:

- test output
- lint/build output
- runtime log
- screenshot/browser evidence
- import/compile check
- command output

If something fails, switch to `debugging-and-error-recovery` style:

```text
reproduce → localize → reduce → fix root cause → guard recurrence → verify end-to-end
```

### 5. REVIEW — inspect quality before done

Responsible agent: `zhi-auditor`

Review across five axes:

1. correctness
2. readability/simplicity
3. architecture/scope fit
4. security/safety
5. performance/reliability

Review output must say one of:

- PASS
- PASS WITH NOTES
- NEEDS CHANGES
- BLOCKED

### 6. SHIP — package and hand off

Responsible agents: `zhi-monitor`, `zhi-architect`

Before shipping/reporting completion, confirm:

- acceptance criteria met
- tests/verification passed or blocker named
- docs/knowledge updated if needed
- rollback or recovery path known for risky changes
- final summary includes files changed and evidence

## OpenClaw Agent Mapping

| Stage | Primary Agent | Output |
|---|---|---|
| DEFINE | `zhi-pm` / `zhi-architect` | spec, scope, acceptance criteria |
| PLAN | `zhi-pm` / `zhi-architect` | ordered task list |
| BUILD | `zhi-coder` | implementation slices |
| VERIFY | `zhi-monitor` | test/build/runtime evidence |
| REVIEW | `zhi-auditor` | quality verdict |
| SHIP | `zhi-monitor` / `zhi-architect` | final handoff, docs, rollback notes |

## Anti-Rationalization Table

| Rationalization | Reality |
|---|---|
| This is small, skip the lifecycle | Small tasks still need acceptance criteria and evidence |
| I can test later | Later often means never; verify before completion |
| It looks right | Looking right is not evidence |
| I'll clean adjacent code while here | Unrequested refactors increase risk |
| The user wants speed | Controlled small slices are faster than rework |
| No need to document this | Decisions and workflows rot without documentation |
| We can ship and fix later | Ship requires rollback/recovery awareness |

## Red Flags

- implementation begins before scope is clear
- no acceptance criteria
- large multi-file change with no checkpoint
- no tests/build/lint/runtime evidence
- review only says “looks good” without axes
- unrelated cleanup mixed into functional changes
- final report lacks changed files or verification output

## Verification Checklist

Before declaring done:

- [ ] DEFINE completed or explicitly unnecessary
- [ ] PLAN completed for multi-step work
- [ ] BUILD done in minimal slices
- [ ] VERIFY evidence collected
- [ ] REVIEW completed for code/config changes
- [ ] SHIP/final summary includes files, evidence, risks/blockers

## References

For detailed patterns, read `references/lifecycle-details.md` when the task is complex or high-risk.
