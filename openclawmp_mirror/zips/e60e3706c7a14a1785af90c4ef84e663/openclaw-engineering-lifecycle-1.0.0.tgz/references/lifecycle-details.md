# Lifecycle Details

## Spec Template

```markdown
# Spec: <name>

## Objective
## Context
## Scope
## Non-goals
## Constraints
## Acceptance Criteria
## Verification Plan
## Rollback / Safety
```

## Task Template

```markdown
## Task N: <name>

- Goal:
- Files/areas:
- Steps:
- Acceptance criteria:
- Verification:
- Dependencies:
```

## Review Template

```markdown
Verdict: PASS / PASS WITH NOTES / NEEDS CHANGES / BLOCKED

## Correctness
## Readability & Simplicity
## Architecture / Scope
## Security / Safety
## Performance / Reliability
## Required Changes
## Evidence Reviewed
```

## Final Handoff Template

```markdown
## Done
- What changed:
- Files:
- Verification:
- Review result:
- Risks:
- Next steps:
```
