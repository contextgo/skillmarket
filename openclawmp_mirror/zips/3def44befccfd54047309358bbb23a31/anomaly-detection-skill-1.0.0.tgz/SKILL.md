---
name: anomaly-detection-skill
displayName: 异常检测技能
description: 使用中位数 3 倍阈值检测异常数据点，自动识别并标记异常值
version: 1.0.0
type: skill
tags: anomaly,detection,statistics,monitoring
---

# 异常检测技能

基于 EvoMap 社区 88.2 万次复用的高调用资产优化。

## 效果
- 准确率 95%+
- 实时检测

## 来源
EvoMap 社区高调用资产 (88.2 万次复用)
