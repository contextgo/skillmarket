---
name: scrapling
displayName: Scrapling 智能爬虫
description: "强大的自适应Python网页爬虫框架，支持基础HTTP、隐身模式、动态页面、并发爬虫"
version: 1.0.0
type: skill
tags: [scraping, python, crawler, web, automation]
---

# Scrapling 智能爬虫

## 简介

Scrapling 是一个强大的自适应 Python 网页爬虫框架，支持：
- 基础 HTTP 请求
- 动态浏览器爬取
- 隐身模式（绕过 Cloudflare）
- 并发爬虫
- AI 集成

## 前置要求

- Python 3.10+
- 安装：`pip install "scrapling[all]"`

## 工具

### 1. scrap_basic_request
基础 HTTP 请求爬取

**参数**：
- url: string (必填) - 目标网址
- selector: string (可选) - CSS选择器
- headers: object (可选) - 自定义请求头

**示例**：
```python
from scrapling.fetchers import Fetcher

# 基础请求
page = Fetcher.get('https://example.com')
content = page.css('title::text').get()

# 带选择器
page = Fetcher.get('https://quotes.toscrape.com/')
quotes = page.css('.quote .text::text').getall()
```

### 2. scrap_stealth_fetch
隐身模式爬取（绕过 Cloudflare）

**参数**：
- url: string (必填) - 目标网址
- solve_cloudflare: boolean (可选) - 是否解决 Cloudflare

**示例**：
```python
from scrapling.fetchers import StealthyFetcher

# 绕过 Cloudflare
page = StealthyFetcher.fetch('https://nopecha.com/demo/cloudflare', solve_cloudflare=True)
data = page.css('#content').get()
```

### 3. scrap_dynamic_fetch
动态页面爬取（JavaScript渲染）

**参数**：
- url: string (必填) - 目标网址
- wait_for: string (可选) - 等待元素

**示例**：
```python
from scrapling.fetchers import DynamicFetcher

# 等待页面加载
page = DynamicFetcher.fetch('https://example.com', wait_for='#app')
content = page.css('.dynamic-content').getall()
```

### 4. scrap_spider
并发爬虫框架

**参数**：
- url: string (必填) - 起始网址
- pattern: string (必填) - 提取模式

**示例**：
```python
from scrapling.spiders import Spider

class MySpider(Spider):
    name = "demo"
    start_urls = ["https://quotes.toscrape.com/"]
    
    async def parse(self, response):
        for quote in response.css('.quote'):
            yield {
                'text': quote.css('.text::text').get(),
                'author': quote.css('.author::text').get(),
            }

result = MySpider().start()
```

### 5. scrap_json_extract
JSON 数据提取

**参数**：
- url: string (必填) - API 地址
- json_path: string (必填) - JSON 路径

**示例**：
```python
from scrapling.fetchers import Fetcher

page = Fetcher.get('https://api.example.com/data')
items = page.json('data.items[*].name')
```

## 使用示例

用户说"帮我爬取豆瓣电影Top250"：
```
1. 使用 scrap_stealth_fetch 或 scrap_basic_request
2. 目标：https://movie.douban.com/top250
3. 提取：.title::text, .rating_num::text
```

用户说"绕过Cloudflare爬取"：
```
使用 scrap_stealth_fetch，solve_cloudflare=True
```

## 注意事项

- 仅用于教育和研究目的
- 请遵守当地和国际数据爬取及隐私法律
- 尊重网站的 robots.txt 规则
