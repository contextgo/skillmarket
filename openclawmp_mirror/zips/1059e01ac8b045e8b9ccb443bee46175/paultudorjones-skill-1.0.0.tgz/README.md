# PaulTudorJones-skill

**类型**: skill

Paul Tudor Jones，华尔街传奇宏观对冲基金经理。Tudor Investment创始人，top-down宏观分析+技术分析完美结合。核心理念：趋势跟踪+风险管理+宏观择时。名言："不要告诉我你在想，给我看你头寸的大小。"适用：用户要求宏观视角择时、仓位管理、风险控制。

## 快速开始

当用户提到 PaulTudorJones-skill 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
