#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
彩票开奖信息抓取脚本（CN版本）
支持：双色球、大乐透
"""

import requests
from bs4 import BeautifulSoup
from datetime import datetime
import re
import json


def fetch_ssq():
    """
    抓取双色球最新开奖信息
    来源：中国福利彩票官网
    """
    url = "https://www.cwl.gov.cn/ygkj/wqkjgg/ssq/"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找最新开奖信息
        latest_info = soup.find('div', class_='kjgg') or soup.find('div', class_='content')
        
        if latest_info:
            # 提取期号
            issue_match = re.search(r'(\d{7})', latest_info.get_text())
            issue = issue_match.group(1) if issue_match else "未知"
            
            # 提取日期
            date_match = re.search(r'(\d{4})年(\d{1,2})月(\d{1,2})日', latest_info.get_text())
            if date_match:
                date_str = f"{date_match.group(1)}-{date_match.group(2).zfill(2)}-{date_match.group(3).zfill(2)}"
            else:
                date_str = datetime.now().strftime('%Y-%m-%d')
            
            # 提取红球号码
            red_balls = re.findall(r'红球[：:]\s*(\d+)[、,\s]*(\d+)[、,\s]*(\d+)[、,\s]*(\d+)[、,\s]*(\d+)[、,\s]*(\d+)', latest_info.get_text())
            if not red_balls:
                # 尝试其他模式
                red_balls = re.findall(r'(\d{1,2})[^\d]*?(\d{1,2})[^\d]*?(\d{1,2})[^\d]*?(\d{1,2})[^\d]*?(\d{1,2})[^\d]*?(\d{1,2})', latest_info.get_text())
            
            # 提取蓝球号码
            blue_ball = re.search(r'蓝球[：:]\s*(\d+)', latest_info.get_text())
            
            return {
                'name': '双色球',
                'type': 'ssq',
                'date': date_str,
                'issue': issue,
                'red_balls': red_balls[0] if red_balls else [],
                'blue_ball': blue_ball.group(1) if blue_ball else ''
            }
        
        return None
    except Exception as e:
        print(f"抓取双色球信息失败: {e}")
        return None


def fetch_dlt():
    """
    抓取大乐透最新开奖信息
    来源：中国体彩网
    """
    url = "https://www.lottery.gov.cn/kj/kjlb.html?dlt"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找最新开奖信息
        latest_info = soup.find('div', class_='kjgg') or soup.find('div', class_='content')
        
        if latest_info:
            # 提取期号
            issue_match = re.search(r'第(\d{5})期', latest_info.get_text())
            issue = issue_match.group(1) if issue_match else "未知"
            
            # 提取日期
            date_match = re.search(r'(\d{4})年(\d{1,2})月(\d{1,2})日', latest_info.get_text())
            if date_match:
                date_str = f"{date_match.group(1)}-{date_match.group(2).zfill(2)}-{date_match.group(3).zfill(2)}"
            else:
                date_str = datetime.now().strftime('%Y-%m-%d')
            
            # 提取前区号码
            front_balls = re.findall(r'前区号码[：:]\s*(\d+)[\s]*(\d+)[\s]*(\d+)[\s]*(\d+)[\s]*(\d+)', latest_info.get_text())
            
            # 提取后区号码
            back_balls = re.findall(r'后区号码[：:]\s*(\d+)[\s]*(\d+)', latest_info.get_text())
            
            return {
                'name': '大乐透',
                'type': 'dlt',
                'date': date_str,
                'issue': issue,
                'front_balls': front_balls[0] if front_balls else [],
                'back_balls': back_balls[0] if back_balls else []
            }
        
        return None
    except Exception as e:
        print(f"抓取大乐透信息失败: {e}")
        return None


def format_lottery_result(data):
    """
    格式化彩票结果为指定格式
    格式：彩票名称揭晓 日期 期号 结果
    结果格式：数字用-分割，特殊号码用+，单位数前面补0
    """
    if not data:
        return None
    
    name = data.get('name', '')
    date = data.get('date', '')
    issue = data.get('issue', '')
    
    # 根据彩票类型格式化结果
    if data['type'] == 'ssq':
        # 双色球：6个红球 + 1个蓝球
        red_balls = [str(ball).zfill(2) for ball in data.get('red_balls', [])]
        blue_ball = str(data.get('blue_ball', '')).zfill(2)
        
        if red_balls and blue_ball:
            result = '-'.join(red_balls) + '+' + blue_ball
        else:
            result = '数据不完整'
    
    elif data['type'] == 'dlt':
        # 大乐透：5个前区 + 2个后区
        front_balls = [str(ball).zfill(2) for ball in data.get('front_balls', [])]
        back_balls = [str(ball).zfill(2) for ball in data.get('back_balls', [])]
        
        if front_balls and back_balls:
            result = '-'.join(front_balls) + '+' + '-'.join(back_balls)
        else:
            result = '数据不完整'
    else:
        result = '未知类型'
    
    return f"{name}揭晓 {date} {issue} {result}"


def main():
    """
    主函数：抓取并格式化所有彩票信息（仅CN版本）
    """
    results = []
    
    # 抓取双色球
    ssq_data = fetch_ssq()
    if ssq_data:
        results.append(format_lottery_result(ssq_data))
    
    # 抓取大乐透
    dlt_data = fetch_dlt()
    if dlt_data:
        results.append(format_lottery_result(dlt_data))
    
    # 输出结果
    for result in results:
        if result:
            print(result)
    
    return results


if __name__ == '__main__':
    main()
