# EventKit Sync

Full CRUD for macOS **Calendar.app** and **Reminders.app** via EventKit framework.

## Why EventKit over AppleScript

AppleScript inherits parent process TCC permissions — often fails with `-10004`. EventKit uses `requestFullAccessToEvents/Reminders` at runtime with a one-time permission prompt.

## Commands

Pipe JSON to the runner script. `cd {baseDir}`

```bash
echo '<json>' | bash scripts/ek-run.sh <action> [flags]
```

| Action | Description | JSON input |
|--------|------------|------------|
| `create` | Create events/reminders | Array of event objects |
| `list` | List upcoming events/reminders | None (use stdin redirect: `echo '' \|`) |
| `update` | Update existing events | Array with `id` + changed fields |
| `delete` | Delete events/reminders | Array with `id` |
| `search` | Search by keyword | `[{"query":"keyword","days":30}]` |

### Flags

| Flag | Effect |
|------|--------|
| `--events` | Calendar only |
| `--reminders` | Reminders only |
| _(neither)_ | Both Calendar and Reminders |
| `--calendar NAME` | Target specific calendar (case-insensitive) |
| `--reminder-list NAME` | Target specific reminder list |
| `--days N` | List: days ahead (default 7) |
| `--tz TIMEZONE` | Override timezone (default Asia/Shanghai) |
| `--dry-run` | Preview without writing |

## JSON Schema (create)

```json
[{
  "title": "Meeting",
  "start": "2026-04-08 09:00",
  "end": "2026-04-08 10:30",
  "location": "Room 301",
  "description": "Notes here",
  "remind_min": 15,
  "allday": false,
  "url": "https://example.com",
  "priority": "high",
  "recurrence": {"freq": "weekly", "byday": "MO,WE,FR", "count": 10}
}]
```

| Field | Required | Default | Notes |
|-------|----------|---------|-------|
| `title` | yes | "Untitled" | Event title |
| `start` | **yes** | — | `YYYY-MM-DD HH:mm`, `YYYY-MM-DD` (allday), or ISO 8601 |
| `end` | no | start + 60min | Same formats as start |
| `location` | no | — | Location string |
| `description` | no | — | Notes/description |
| `remind_min` | no | -1 (none) | Minutes before to alert. 0 = at event time |
| `allday` | no | false | All-day event |
| `url` | no | — | URL (calendar only) |
| `priority` | no | none | Reminders: "high"/"medium"/"low" or "高"/"中"/"低" or 1/5/9 |
| `recurrence` | no | — | See recurrence section |

### Recurrence

Either a structured object or raw RRULE string:

```json
{"freq": "daily", "interval": 1, "count": 10}
{"freq": "weekly", "byday": "MO,WE,FR"}
{"freq": "monthly", "bymonthday": 15, "until": "2026-12-31"}
{"rrule": "FREQ=DAILY;COUNT=5"}
```

### Update/Delete JSON

```json
[{"id": "EVENT_ID_FROM_LIST", "title": "New title", "start": "2026-04-09 10:00"}]
```

Get `id` from `list` or `search` output (first column).

## Workflow

User input can be **anything**. Your job: understand intent, produce JSON, run script.

### Step 1: Understand the intent

| Intent | Action |
|--------|--------|
| Add/sync/import events | `create` |
| "What's on my calendar" | `list` |
| "Move the meeting to 3pm" | `search` to find id, then `update` |
| "Cancel tomorrow's meeting" | `search` to find id, then `delete` |
| "Find all meetings about X" | `search` |

### Step 2: Extract events from any input

| Input type | How to handle |
|-----------|---------------|
| `.xlsx` / `.csv` file | Read with openpyxl/csv; match columns by semantics not exact names |
| Natural language | "明天下午3点开会" → resolve date, extract title/time/remind |
| Bullet list / table in chat | Each line/row = one event |
| Image / screenshot | Describe and extract |
| Vague input | At minimum need: what + when. Ask if truly ambiguous |

### Step 3: Normalize to JSON

Key inference rules:

**Time resolution:**
- "明天" / "后天" / "下周一" → resolve against current date
- "下午3点" / "3pm" → 15:00. Bare "3点" with no context → ask AM/PM
- "4.7" / "4月7日" / "Apr 7" → 2026-04-07 (use current/next year)
- Duration to end time: "60分钟" / "1小时" / "1.5h" / "一个半小时" → compute end

**Reminders:**
- "提前15分钟" / "15分钟前提醒" → 15
- "即刻提醒" / "立即" → 0
- "提前1小时" → 60
- "无" / not mentioned → -1

**Recurrence:**
- "每天" → `{"freq":"daily"}`
- "每周一三五" → `{"freq":"weekly","byday":"MO,WE,FR"}`
- "每月15号" → `{"freq":"monthly","bymonthday":15}`
- "连续5天" → `{"freq":"daily","count":5}`

**Priority (reminders):**
- "重要" / "紧急" / "!!" → "high"
- "一般" → "medium"
- Unmentioned → none

**All-day:**
- "全天" → true
- Date without any time → true

**Timezone:**
- Default Asia/Shanghai. "纽约时间" → use `--tz America/New_York`

### Step 4: Execute and report

Run the script, show user a readable summary of results.

## Examples

**Create from natural language:**
```bash
echo '[
  {"title":"团队周会","start":"2026-04-08 09:00","end":"2026-04-08 10:00","location":"会议室A","remind_min":10,"recurrence":{"freq":"weekly","byday":"TU"}},
  {"title":"午餐","start":"2026-04-08 12:00","end":"2026-04-08 13:00","remind_min":-1}
]' | bash scripts/ek-run.sh create
```

**List next 14 days:**
```bash
echo '' | bash scripts/ek-run.sh list --days 14
```

**Search and delete:**
```bash
echo '[{"query":"周会"}]' | bash scripts/ek-run.sh search --events
# Then with the id from output:
echo '[{"id":"FOUND_EVENT_ID"}]' | bash scripts/ek-run.sh delete --events
```

**Dry run preview:**
```bash
echo '[...]' | bash scripts/ek-run.sh create --dry-run
```