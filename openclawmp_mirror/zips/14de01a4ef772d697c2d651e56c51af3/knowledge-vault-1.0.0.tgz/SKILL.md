---
name: knowledge-vault
description: |
  Personal knowledge management system integrating local knowledge base and Obsidian vault.
  Use when: (1) User provides a book/PDF and wants notes created, (2) User provides a web URL for summarization, (3) User asks to organize or categorize knowledge, (4) User mentions "知识库", "笔记", "Obsidian", "做笔记", "整理笔记", "网页收藏".
  Triggers on: books, PDFs, web links, knowledge base, note-taking, Obsidian, 笔记, 知识库, 收藏.
---

# Knowledge Vault

Personal knowledge management skill. Processes books (PDF) and web content into structured Obsidian notes with bidirectional linking and auto-categorization.

## Setup

Before first use, configure your vault path in `~/.openclaw/workspace/skills/knowledge-vault/config.json`:

```json
{
  "vault_path": "~/Documents/ObsidianVault",
  "local_path": "~/.openclaw/workspace/knowledge",
  "categories": {
    "专业知识": ["你的专业领域1", "你的专业领域2"],
    "兴趣爱好": ["你的爱好1", "你的爱好2"]
  }
}
```

## Storage Locations

| Location | Default Path | Use Case |
|----------|-------------|----------|
| **Obsidian** | `~/Documents/ObsidianVault/` | Books, web bookmarks, general knowledge |
| **Local** | `~/.openclaw/workspace/knowledge/` | Technical notes, lessons, work references |

**Rule**: Always ask user which location if not specified. Default to Obsidian for new content.

## Obsidian Vault Structure

```
Vault/
├── 0-Inbox/              # 新内容暂存（待分类）
├── 1-专业知识/
│   ├── {专业领域1}/       # 书籍PDF/EPUB + 笔记共存
│   ├── {专业领域2}/
│   └── {新领域}/
├── 2-兴趣爱好/
│   ├── {爱好1}/           # 书籍PDF/EPUB + 笔记共存
│   └── {爱好2}/
├── 3-网页收藏/
│   ├── 技术/
│   ├── 学术/
│   └── 工具/
├── 4-书籍笔记/            # 仅存放笔记.md（引用分类目录中的书籍）
│   └── {按领域}/
├── Templates/            # 笔记模板
└── .obsidian/            # Obsidian 配置
```

**存储规则**：
- 📕 书籍文件(PDF/EPUB) → 放在对应分类目录（如 `1-专业知识/{领域}/`）
- 📝 书籍笔记(.md) → 放在 `4-书籍笔记/{领域}/`
- `source` 字段指向书籍所在分类目录

## Core Workflows

### Workflow 1: Book/PDF → Notes

1. **Fetch book metadata** from Douban（必须步骤）:
   ```bash
   python3 scripts/fetch_book_info.py "<书名>" --wechat
   ```
   返回字段：书名、作者、译者、出版社、出版年、页数、丛书、ISBN、装帧、定价、豆瓣评分、评分人数、简介、封面、微信读书链接
   - 备选：调用本地 `find-the-book` skill 的 `search_books_comprehensive()`
2. **Extract text** from PDF:
   - 文字PDF → `python3 scripts/extract_pdf_text.py <path>`
   - 扫描PDF → `python3 scripts/extract_pdf_ocr.py <path>`
3. **Process content**: 提取核心概念、章节结构、术语表
4. **Categorize**: 自动匹配已有分类，无匹配则建议新建
5. **Create note** 使用 `assets/templates/book-note-template.md`:
   - 填写所有元数据字段（书名加粗：《书名》）
   - 包含豆瓣链接 + 微信读书链接
   - 包含书籍简介
6. **Separate storage**（重要！）:
   - 📕 书籍文件(PDF/EPUB) → 对应分类目录（如 `1-专业知识/{领域}/`）
   - 📝 笔记(.md) → `4-书籍笔记/{领域}/`
   - `source` 字段指向书籍所在分类目录
7. **Bidirectional links**: 用 `[[笔记名]]` 链接相关笔记
8. **Save 笔记** 到 `4-书籍笔记/{领域}/`

### Workflow 2: Web URL → Notes

1. **Fetch content**: `web_fetch` 或 `scripts/fetch_web.py <url>`
2. **Summarize**: 核心要点、主要论点、有用数据
3. **Categorize**: 根据内容领域自动分类
4. **Create note** 使用 `assets/templates/web-note-template.md`
5. **Record source**: `source` 字段填 URL
6. **Save** 到 `3-网页收藏/{子分类}/`

### Workflow 3: Category Management

当内容不匹配已有分类时：
1. 分析内容领域
2. 模糊匹配已有分类
3. 向用户建议新分类名
4. 确认后创建目录 + index.md (MOC)

## Book Metadata Format（书籍信息格式）

笔记头部必须包含完整书籍信息：

```markdown
# 📖 《书名》

> **《书名》**
> ⭐ 评分：8.9（豆瓣）
> 作者：作者名
> 译者：译者名（如有）
> 出版社：XXX | 出版年：2022
> 页数：300 | ISBN：978-xxx
> 丛书：丛书名（如有）
> 
> 🔗 [豆瓣详情](douban_url) | 📖 [微信读书](wechat_url)
> 📁 源文件：`/path/to/pdf`
```

## Note Format Rules

Every note MUST include YAML frontmatter:

```yaml
---
title: "《书名》"
date: YYYY-MM-DD
type: book|web|article|note
source: "原始文件路径或URL"
douban_url: "豆瓣链接"
author: "作者"
translator: "译者"
publisher: "出版社"
pub_year: "出版年"
isbn: "ISBN"
tags: [标签1, 标签2]
status: draft|complete
rating: "豆瓣评分"
---
```

Bidirectional links:
- `[[相关笔记名]]` — link to existing notes
- `[[#章节锚点]]` — internal anchors
- Always scan existing vault for related notes to link

## Category Detection

Auto-detect category based on keywords. Customize in `config.json`:

| Example Keywords | Example Category |
|------------------|------------------|
| 化工, 化学, 反应, 催化 | 1-专业知识/化工 |
| 材料, 晶体, 半导体, 光电 | 1-专业知识/材料 |
| 摄影, 相机, 镜头, 曝光 | 2-兴趣爱好/摄影 |
| 小说, 文学, 故事 | 2-兴趣爱好/文学 |
| 技术文档, API, 编程 | 3-网页收藏/技术 |
| 论文, 研究, 学术 | 3-网页收藏/学术 |

## Scripts Usage

```bash
# 获取书籍元数据（豆瓣 + 微信读书）
python3 scripts/fetch_book_info.py "书名" --wechat

# 提取PDF文字
python3 scripts/extract_pdf_text.py <pdf_path> [--pages N]

# OCR提取扫描PDF
python3 scripts/extract_pdf_ocr.py <pdf_path> [--pages N] [--lang chi_sim]

# 抓取网页内容
python3 scripts/fetch_web.py <url> [--output <path>]
```

## Quality Checks

Before saving a note:
- [ ] 书籍元数据完整（书名/作者/出版社/ISBN/评分/简介）
- [ ] 豆瓣链接已添加
- [ ] Source field is populated
- [ ] Tags are relevant (3-5 tags)
- [ ] Bidirectional links added where relevant
- [ ] Content is structured (headers, lists, tables)
- [ ] Category matches existing structure or new one proposed

---
*Created: 2026-03-16 | Adapted for general use*
