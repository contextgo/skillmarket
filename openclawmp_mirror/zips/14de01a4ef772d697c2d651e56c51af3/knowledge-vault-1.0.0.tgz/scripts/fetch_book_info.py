#!/usr/bin/env python3
"""
Fetch book metadata from Douban using find-the-book skill + enhanced scraping.
Returns structured JSON with full book details.
"""

import argparse
import json
import re
import sys
import time
import random


def search_douban_book(query: str) -> dict:
    """Search Douban and return first matching book's full metadata."""
    from duckduckgo_search import DDGS
    import requests
    from bs4 import BeautifulSoup

    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    }

    # Search Douban
    douban_query = f"site:book.douban.com/subject {query}"
    print(f"[INFO] Searching: {douban_query}", file=sys.stderr)

    with DDGS() as ddgs:
        results = list(ddgs.text(douban_query, max_results=5))

    book_url = None
    for res in results:
        url = res['href']
        if "book.douban.com/subject/" in url and "/discussion" not in url and "/review" not in url:
            book_url = url
            break

    if not book_url:
        return {"error": "No book found on Douban"}

    print(f"[INFO] Found: {book_url}", file=sys.stderr)

    # Fetch book page
    time.sleep(random.uniform(0.5, 1.0))
    resp = requests.get(book_url, headers=headers, timeout=10)
    if resp.status_code != 200:
        return {"error": f"Failed to fetch page: {resp.status_code}"}

    soup = BeautifulSoup(resp.text, 'html.parser')
    book = {"douban_url": book_url}

    # Title
    h1 = soup.find('h1')
    if h1:
        book['title'] = h1.get_text(strip=True)

    # Rating
    rating_tag = soup.find('strong', class_='ll rating_num')
    book['rating'] = rating_tag.get_text(strip=True) if rating_tag else "暂无"

    # Rating count
    rating_count = soup.find('a', class_='rating_people')
    if rating_count:
        count_span = rating_count.find('span')
        if count_span:
            book['rating_count'] = count_span.get_text(strip=True)

    # Info block (contains author, publisher, year, pages, ISBN, etc.)
    info_div = soup.find('div', id='info')
    if info_div:
        info_text = info_div.get_text('\n', strip=True)
        lines = info_text.split('\n')

        current_key = None
        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Check for key:value patterns
            if '作者' in line and ':' not in line and '：' not in line:
                current_key = 'authors'
                continue
            elif '译者' in line:
                current_key = 'translators'
                continue
            elif '出版社' in line:
                current_key = None
                m = re.search(r'出版社[：:]\s*(.+)', line)
                if m:
                    book['publisher'] = m.group(1).strip()
            elif '出版年' in line:
                current_key = None
                m = re.search(r'出版年[：:]\s*(.+)', line)
                if m:
                    book['pub_year'] = m.group(1).strip()
            elif '页数' in line:
                current_key = None
                m = re.search(r'页数[：:]\s*(\d+)', line)
                if m:
                    book['pages'] = m.group(1).strip()
            elif '丛书' in line:
                current_key = None
                m = re.search(r'丛书[：:]\s*(.+)', line)
                if m:
                    book['series'] = m.group(1).strip()
            elif 'ISBN' in line:
                current_key = None
                m = re.search(r'ISBN[：:]\s*(\d+)', line)
                if m:
                    book['isbn'] = m.group(1).strip()
            elif '定价' in line:
                current_key = None
                m = re.search(r'定价[：:]\s*(.+)', line)
                if m:
                    book['price'] = m.group(1).strip()
            elif '装帧' in line:
                current_key = None
                m = re.search(r'装帧[：:]\s*(.+)', line)
                if m:
                    book['binding'] = m.group(1).strip()

        # Parse author links
        author_links = info_div.find_all('a', href=re.compile(r'/search/'))
        authors = []
        translators = []
        in_translator = False
        for child in info_div.children:
            if hasattr(child, 'name') and child.name == 'span':
                if '译者' in child.get_text():
                    in_translator = True
            if hasattr(child, 'name') and child.name == 'a' and '/search/' in child.get('('):
                name = child.get_text(strip=True)
                if in_translator:
                    translators.append(name)
                else:
                    authors.append(name)

        if authors:
            book['authors'] = ' / '.join(authors)
        if translators:
            book['translators'] = ' / '.join(translators)

    # Also try to extract authors from the span with class "pl" containing "作者"
    if 'authors' not in book:
        author_spans = info_div.find_all('span', class_='pl') if info_div else []
        for span in author_spans:
            if '作者' in span.get_text():
                # Get all sibling text and links after this span
                parent = span.parent
                if parent:
                    links = parent.find_all('a')
                    if links:
                        book['authors'] = ' / '.join([a.get_text(strip=True) for a in links[:5]])
                break

    # Summary / intro
    intro_div = soup.find('div', id='link-report')
    if intro_div:
        intro_span = intro_div.find('span', class_='short')
        if not intro_span:
            intro_span = intro_div.find('div', class_='intro')
        if intro_span:
            book['summary'] = intro_span.get_text(strip=True)[:500]

    # Cover image
    cover_img = soup.find('a', class_='nbg')
    if cover_img:
        img_tag = cover_img.find('img')
        if img_tag:
            book['cover_url'] = img_tag.get('src', '')

    return book


def search_wechat_read(title: str) -> str | None:
    """Search for WeChat Reading link."""
    from duckduckgo_search import DDGS

    query = f"site:weread.qq.com {title}"
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=1))
        if results and "weread.qq.com" in results[0]['href']:
            return results[0]['href']
    except Exception:
        pass
    return None


def main():
    parser = argparse.ArgumentParser(description="Fetch book metadata from Douban")
    parser.add_argument("query", help="Book title or search query")
    parser.add_argument("--wechat", action="store_true", help="Also search WeChat Reading link")
    parser.add_argument("--output", "-o", help="Output JSON file")
    args = parser.parse_args()

    print(f"[INFO] Searching for: {args.query}", file=sys.stderr)
    book = search_douban_book(args.query)

    if 'error' not in book and args.wechat:
        title = book.get('title', args.query)
        print(f"[INFO] Searching WeChat Read for: {title}", file=sys.stderr)
        wechat_url = search_wechat_read(title)
        if wechat_url:
            book['wechat_url'] = wechat_url

    output = json.dumps(book, ensure_ascii=False, indent=2)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"[OK] Saved to {args.output}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
