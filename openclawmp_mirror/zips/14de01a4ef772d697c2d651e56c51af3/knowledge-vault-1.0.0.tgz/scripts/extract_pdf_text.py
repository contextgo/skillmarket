#!/usr/bin/env python3
"""Extract text from text-based PDFs using pypdfium2 or pdfplumber."""

import argparse
import os
import sys


def extract_with_pdfplumber(pdf_path: str, max_pages: int = None) -> str:
    """Extract text using pdfplumber (available in markitdown venv)."""
    import pdfplumber

    text_parts = []
    with pdfplumber.open(pdf_path) as pdf:
        total = len(pdf.pages)
        pages = min(max_pages or total, total)
        print(f"[INFO] Total pages: {total}, extracting: {pages}", file=sys.stderr)

        for i in range(pages):
            page = pdf.pages[i]
            text = page.extract_text() or ""
            if text.strip():
                text_parts.append(f"\n--- 第 {i+1} 页 ---\n\n{text}")

    return "\n".join(text_parts)


def extract_with_pypdfium2(pdf_path: str, max_pages: int = None) -> str:
    """Extract text using pypdfium2 (fallback)."""
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(pdf_path)
    total = len(pdf)
    pages = min(max_pages or total, total)
    print(f"[INFO] Total pages: {total}, extracting: {pages}", file=sys.stderr)

    text_parts = []
    for i in range(pages):
        page = pdf[i]
        textpage = page.get_textpage()
        text = textpage.get_text_range()
        if text.strip():
            text_parts.append(f"\n--- 第 {i+1} 页 ---\n\n{text}")
        page.close()

    pdf.close()
    return "\n".join(text_parts)


def main():
    parser = argparse.ArgumentParser(description="Extract text from PDF")
    parser.add_argument("pdf_path", help="Path to PDF file")
    parser.add_argument("--pages", type=int, default=None, help="Max pages to extract")
    parser.add_argument("--output", "-o", help="Output file (default: stdout)")
    parser.add_argument("--engine", choices=["pdfplumber", "pypdfium2"], default="pdfplumber")
    args = parser.parse_args()

    if not os.path.exists(args.pdf_path):
        print(f"Error: File not found: {args.pdf_path}", file=sys.stderr)
        sys.exit(1)

    try:
        if args.engine == "pdfplumber":
            text = extract_with_pdfplumber(args.pdf_path, args.pages)
        else:
            text = extract_with_pypdfium2(args.pdf_path, args.pages)
    except ImportError:
        print("[WARN] Preferred engine not available, trying fallback...", file=sys.stderr)
        if args.engine == "pdfplumber":
            text = extract_with_pypdfium2(args.pdf_path, args.pages)
        else:
            text = extract_with_pdfplumber(args.pdf_path, args.pages)

    if not text.strip():
        print("[WARN] No text extracted. PDF may be scanned/image-based.", file=sys.stderr)
        print("[HINT] Use extract_pdf_ocr.py for scanned PDFs", file=sys.stderr)

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[OK] Saved to {args.output} ({len(text)} chars)", file=sys.stderr)
    else:
        print(text)


if __name__ == "__main__":
    main()
