#!/usr/bin/env python3
"""Fetch book metadata from multiple sources: Douban, Anna's Archive, Jiumo, etc.
Supports proxy (127.0.0.1:7890) for external access."""

import argparse
import json
import os
import re
import sys
import urllib.request
import urllib.parse

PROXY = None

def get_opener():
    """Create urllib opener with proxy."""
    proxy_handler = urllib.request.ProxyHandler({
        'http': PROXY,
        'https': PROXY
    })
    return urllib.request.build_opener(proxy_handler)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}


def fetch_url(url, timeout=15):
    """Fetch URL with proxy."""
    req = urllib.request.Request(url, headers=HEADERS)
    opener = get_opener()
    return opener.open(req, timeout=timeout)


# === Source 1: Douban (by ISBN) ===
def fetch_douban_by_isbn(isbn: str) -> dict:
    """Fetch book metadata from Douban using ISBN."""
    url = f"https://book.douban.com/isbn/{isbn}/"
    try:
        resp = fetch_url(url)
        html = resp.read().decode('utf-8', errors='replace')
        return parse_douban_page(html, resp.url)
    except Exception as e:
        return {"error": f"Douban ISBN: {e}", "source": "douban"}


def fetch_douban_by_title(title: str) -> dict:
    """Search Douban by title using Google site search."""
    query = urllib.parse.quote(f"site:book.douban.com/subject {title}")
    google_url = f"https://www.google.com/search?q={query}"
    try:
        resp = fetch_url(google_url)
        html = resp.read().decode('utf-8', errors='replace')
        # Find first douban subject link
        subjects = re.findall(r'https://book\.douban\.com/subject/\d+/', html)
        if subjects:
            # Deduplicate while preserving order
            seen = set()
            unique = []
            for s in subjects:
                if s not in seen:
                    seen.add(s)
                    unique.append(s)
            # Fetch first result
            resp2 = fetch_url(unique[0])
            html2 = resp2.read().decode('utf-8', errors='replace')
            return parse_douban_page(html2, unique[0])
        return {"error": "No Douban results via Google", "source": "douban"}
    except Exception as e:
        return {"error": f"Douban search: {e}", "source": "douban"}


def parse_douban_page(html: str, url: str) -> dict:
    """Parse Douban book subject page."""
    meta = {"source": "douban", "source_url": url}

    m = re.search(r'<span property="v:itemreviewed">(.*?)</span>', html)
    if m: meta['title'] = m.group(1).strip()

    m = re.search(r'v:average">(.*?)</', html)
    if m: meta['rating'] = m.group(1).strip()

    m = re.search(r'<span property="v:votes">(.*?)</span>', html)
    if m: meta['rating_count'] = m.group(1).strip()

    pl_matches = re.findall(r'<span class="pl">(.*?)</span>(.*?)<br', html, re.DOTALL)
    field_map = {
        '作者': 'author', '译者': 'translator', '出版社': 'publisher',
        '出版年': 'pub_year', '出版年月': 'pub_year', '页数': 'pages',
        '定价': 'price', '丛书': 'series', '副标题': 'subtitle',
        '原作名': 'original_title', 'ISBN': 'isbn',
    }
    for label, value in pl_matches:
        label_clean = re.sub(r'<[^>]+>', '', label).strip().rstrip(':').strip()
        value_clean = re.sub(r'<[^>]+>', '', value).strip().replace('&nbsp;', ' ')
        if label_clean in field_map and value_clean:
            val = value_clean
            if field_map[label_clean] == 'author':
                val = re.sub(r'\s+', ' ', val.replace('\n', ' ')).strip()
            meta[field_map[label_clean]] = val

    for pattern in [r'<span class="short">(.*?)</span>', r'<div class="intro">\s*<p>(.*?)</p>']:
        m = re.search(pattern, html, re.DOTALL)
        if m:
            desc = re.sub(r'<[^>]+>', '', m.group(1)).strip()
            if len(desc) > 20:
                meta['description'] = desc[:500]
                break

    meta['douban_link'] = url
    return meta


# === Source 2: Google Books API ===
def fetch_google_books(title: str) -> dict:
    """Fetch from Google Books API (no proxy needed, but proxy available)."""
    query = urllib.parse.quote(title)
    url = f"https://www.googleapis.com/books/v1/volumes?q={query}&maxResults=1&langRestrict=zh"
    try:
        resp = fetch_url(url)
        data = json.loads(resp.read().decode('utf-8'))
        if data.get('totalItems', 0) > 0:
            item = data['items'][0]['volumeInfo']
            meta = {
                "source": "google_books",
                "title": item.get('title', ''),
                "author": ', '.join(item.get('authors', [])),
                "publisher": item.get('publisher', ''),
                "pub_year": item.get('publishedDate', '')[:4],
                "pages": str(item.get('pageCount', '')),
                "description": item.get('description', '')[:500],
                "isbn": next((i['identifier'] for i in item.get('industryIdentifiers', []) if i['type'] == 'ISBN_13'), ''),
                "language": item.get('language', ''),
            }
            return meta
        return {"error": "No results", "source": "google_books"}
    except Exception as e:
        return {"error": f"Google Books: {e}", "source": "google_books"}


# === Source 3: Anna's Archive search (scraping) ===
def search_annas_archive(title: str) -> dict:
    """Search Anna's Archive for book info."""
    query = urllib.parse.quote(title)
    url = f"https://annas-archive.org/search?q={query}"
    try:
        resp = fetch_url(url)
        html = resp.read().decode('utf-8', errors='replace')
        # Extract first result info
        meta = {"source": "annas_archive", "search_url": url}
        # Find title patterns
        m = re.search(r'<h3[^>]*>(.*?)</h3>', html, re.DOTALL)
        if m:
            meta['found_title'] = re.sub(r'<[^>]+>', '', m.group(1)).strip()[:100]
        # Find download/info links
        links = re.findall(r'href="(/md5/[a-f0-9]+)"', html)
        if links:
            meta['detail_page'] = f"https://annas-archive.org{links[0]}"
        return meta
    except Exception as e:
        return {"error": f"Anna's Archive: {e}", "source": "annas_archive"}


# === Source 4: Jiumo Search ===
def search_jiumo(title: str) -> dict:
    """Search Jiumo (鸠摩搜书) for book."""
    query = urllib.parse.quote(title)
    url = f"https://www.jiumodiary.com/search?q={query}"
    try:
        resp = fetch_url(url)
        html = resp.read().decode('utf-8', errors='replace')
        meta = {"source": "jiumo", "search_url": url}
        # Extract results
        results = re.findall(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', html, re.DOTALL)
        for href, text in results[:5]:
            clean_text = re.sub(r'<[^>]+>', '', text).strip()
            if clean_text and len(clean_text) > 5:
                meta.setdefault('results', []).append({
                    'title': clean_text[:80],
                    'url': href if href.startswith('http') else f"https://www.jiumodiary.com{href}"
                })
        return meta
    except Exception as e:
        return {"error": f"Jiumo: {e}", "source": "jiumo"}


# === Main search orchestrator ===
def search_book(query: str, use_proxy=True) -> dict:
    """Search book from multiple sources, merge results."""
    results = {}

    # Check if ISBN
    clean = query.replace('-', '').replace(' ', '')
    is_isbn = clean.isdigit() and len(clean) in (10, 13)

    if is_isbn:
        print("[INFO] Searching by ISBN...", file=sys.stderr)
        douban = fetch_douban_by_isbn(clean)
        if 'error' not in douban:
            return douban
        # Fallback to Google Books
        gb = fetch_google_books(query)
        if 'error' not in gb:
            return gb
    else:
        print("[INFO] Searching by title...", file=sys.stderr)
        # Try Douban via Google
        print("  → Trying Douban (via Google)...", file=sys.stderr)
        douban = fetch_douban_by_title(query)
        if 'error' not in douban:
            return douban

        # Try Google Books API
        print("  → Trying Google Books API...", file=sys.stderr)
        gb = fetch_google_books(query)
        if 'error' not in gb:
            return gb

        # Try Anna's Archive
        print("  → Trying Anna's Archive...", file=sys.stderr)
        anna = search_annas_archive(query)
        results['annas_archive'] = anna

        # Try Jiumo
        print("  → Trying Jiumo...", file=sys.stderr)
        jiumo = search_jiumo(query)
        results['jiumo'] = jiumo

    return {"query": query, "results": results, "error": "Partial results only"}


def main():
    parser = argparse.ArgumentParser(description="Fetch book metadata from multiple sources")
    parser.add_argument("query", help="ISBN or book title")
    parser.add_argument("--output", "-o", help="Save JSON to file")
    parser.add_argument("--no-proxy", action="store_true", help="Disable proxy")
    args = parser.parse_args()

    if args.no_proxy:
        global PROXY
        PROXY = None

    result = search_book(args.query)
    output = json.dumps(result, ensure_ascii=False, indent=2)

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"[OK] Saved to {args.output}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
