#!/usr/bin/env python3
"""Extract text from scanned/image-based PDFs using OCR (tesseract)."""

import argparse
import os
import subprocess
import sys
import tempfile


def pdf_to_images(pdf_path: str, output_dir: str, max_pages: int = None, dpi: int = 200) -> list:
    """Convert PDF pages to images using pdfplumber."""
    import pdfplumber

    images = []
    with pdfplumber.open(pdf_path) as pdf:
        total = len(pdf.pages)
        pages = min(max_pages or total, total)
        print(f"[INFO] Total pages: {total}, converting: {pages} to images (DPI={dpi})", file=sys.stderr)

        for i in range(pages):
            page = pdf.pages[i]
            img = page.to_image(resolution=dpi)
            img_path = os.path.join(output_dir, f"page_{i+1:03d}.png")
            img.save(img_path)
            images.append(img_path)
            if (i + 1) % 10 == 0:
                print(f"  Converted {i+1}/{pages} pages...", file=sys.stderr)

    return images


def ocr_images(images: list, lang: str = "chi_sim", psm: int = 6) -> str:
    """Run tesseract OCR on image files."""
    text_parts = []
    total = len(images)

    for i, img_path in enumerate(images):
        page_num = i + 1
        try:
            result = subprocess.run(
                ["tesseract", img_path, "stdout", "-l", lang, "--psm", str(psm)],
                capture_output=True, text=True, timeout=60
            )
            text = result.stdout.strip()
            if text:
                text_parts.append(f"\n--- 第 {page_num} 页 ---\n\n{text}")
            else:
                text_parts.append(f"\n--- 第 {page_num} 页 ---\n\n(无文字内容)")
        except subprocess.TimeoutExpired:
            text_parts.append(f"\n--- 第 {page_num} 页 ---\n\n(OCR 超时)")
        except FileNotFoundError:
            print("[ERROR] tesseract not found. Install: sudo apt install tesseract-ocr", file=sys.stderr)
            sys.exit(1)

        if (i + 1) % 5 == 0:
            print(f"  OCR {i+1}/{total} pages...", file=sys.stderr)

    return "\n".join(text_parts)


def main():
    parser = argparse.ArgumentParser(description="OCR extract text from scanned PDF")
    parser.add_argument("pdf_path", help="Path to PDF file")
    parser.add_argument("--pages", type=int, default=None, help="Max pages to process")
    parser.add_argument("--lang", "-l", default="chi_sim", help="OCR language (default: chi_sim)")
    parser.add_argument("--dpi", type=int, default=200, help="Image DPI (default: 200)")
    parser.add_argument("--psm", type=int, default=6, help="Tesseract PSM mode (default: 6)")
    parser.add_argument("--output", "-o", help="Output file (default: stdout)")
    parser.add_argument("--keep-images", action="store_true", help="Keep intermediate images")
    args = parser.parse_args()

    if not os.path.exists(args.pdf_path):
        print(f"Error: File not found: {args.pdf_path}", file=sys.stderr)
        sys.exit(1)

    # Check tesseract
    try:
        subprocess.run(["tesseract", "--version"], capture_output=True, check=True)
    except FileNotFoundError:
        print("[ERROR] tesseract not found. Install: sudo apt install tesseract-ocr tesseract-ocr-chi-sim", file=sys.stderr)
        sys.exit(1)

    # Create temp dir for images
    with tempfile.TemporaryDirectory() as tmp_dir:
        print(f"[INFO] Converting PDF to images...", file=sys.stderr)
        images = pdf_to_images(args.pdf_path, tmp_dir, args.pages, args.dpi)

        print(f"[INFO] Running OCR (lang={args.lang})...", file=sys.stderr)
        text = ocr_images(images, args.lang, args.psm)

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[OK] Saved to {args.output} ({len(text)} chars)", file=sys.stderr)
    else:
        print(text)


if __name__ == "__main__":
    main()
