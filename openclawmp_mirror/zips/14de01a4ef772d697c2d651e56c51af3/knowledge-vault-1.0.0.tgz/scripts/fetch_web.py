#!/usr/bin/env python3
"""Fetch web content and convert to clean markdown."""

import argparse
import json
import os
import sys
import urllib.request
import urllib.parse


def fetch_with_builtin(url: str) -> str:
    """Fetch URL content using built-in urllib."""
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (compatible; KnowledgeVault/1.0)'
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode('utf-8', errors='replace')


def fetch_with_jina(url: str) -> str:
    """Fetch URL via r.jina.ai proxy (returns markdown)."""
    encoded = urllib.parse.quote(url, safe='')
    api_url = f"https://r.jina.ai/{encoded}"
    req = urllib.request.Request(api_url, headers={
        'Accept': 'text/markdown',
        'User-Agent': 'KnowledgeVault/1.0'
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode('utf-8', errors='replace')


def main():
    parser = argparse.ArgumentParser(description="Fetch web content as markdown")
    parser.add_argument("url", help="URL to fetch")
    parser.add_argument("--output", "-o", help="Output file (default: stdout)")
    parser.add_argument("--method", choices=["jina", "builtin"], default="jina",
                        help="Fetch method (default: jina for markdown)")
    parser.add_argument("--max-chars", type=int, default=50000, help="Max characters")
    args = parser.parse_args()

    print(f"[INFO] Fetching: {args.url}", file=sys.stderr)

    try:
        if args.method == "jina":
            content = fetch_with_jina(args.url)
        else:
            html = fetch_with_builtin(args.url)
            # Basic HTML to text (fallback)
            import re
            content = re.sub(r'<[^>]+>', ' ', html)
            content = re.sub(r'\s+', ' ', content).strip()
    except Exception as e:
        print(f"[ERROR] Failed to fetch: {e}", file=sys.stderr)
        sys.exit(1)

    if len(content) > args.max_chars:
        content = content[:args.max_chars] + "\n\n[... truncated ...]"

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[OK] Saved to {args.output} ({len(content)} chars)", file=sys.stderr)
    else:
        print(content)


if __name__ == "__main__":
    main()
