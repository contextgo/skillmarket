---
title: "《{{TITLE}}》"
date: {{DATE}}
type: book
source: "{{SOURCE}}"
tags: [{{TAGS}}]
status: draft
---

# 《{{TITLE}}》

## 📋 书籍信息

| 属性 | 值 |
|------|-----|
| **书名** | **《{{TITLE}}》** |
| 作者 | {{AUTHOR}} |
| 译者 | {{TRANSLATOR}} |
| 出版社 | {{PUBLISHER}} |
| 出版年 | {{PUB_YEAR}} |
| 页数 | {{PAGES}} |
| 丛书 | {{SERIES}} |
| ISBN | {{ISBN}} |
| 定价 | {{PRICE}} |
| ⭐ 评分 | {{RATING}} |

## 📖 书籍简介

{{DESCRIPTION}}

## 🔗 阅读资源

- [豆瓣详情]({{DOUBAN_LINK}})
- [微信读书]({{WECHAT_LINK}}) （如有）

## 📂 分类

[[{{CATEGORY}}]]

## 📝 章节笔记

### 第X章：章节标题

**核心概念**：
- 

**关键要点**：
1. 

**术语记录**：
| 术语 | 英文 | 含义 |
|------|------|------|

---

## 🔗 相关笔记

- [[相关笔记1]]

## 💡 个人思考

{{REFLECTIONS}}

---
*笔记创建时间：{{DATETIME}}*
*源文件：`{{SOURCE}}`*
