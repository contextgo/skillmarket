---
title: "{{TITLE}}"
date: {{DATE}}
type: web
source: "{{URL}}"
author: "{{AUTHOR}}"
tags: [{{TAGS}}]
status: complete
saved_date: {{DATETIME}}
---

# {{TITLE}}

> 🌐 **网页收藏**
> 来源：[{{URL_TITLE}}]({{URL}})
> 收藏日期：{{DATE}}

## 📝 内容摘要

{{SUMMARY}}

## 🔑 关键信息

### 核心要点

1. 

### 重要数据/引用

> 

### 实用信息

- 

---

## 🔗 相关笔记

- [[相关笔记1]]

## 📂 分类

[[{{CATEGORY}}]]

---
*收藏时间：{{DATETIME}}*
