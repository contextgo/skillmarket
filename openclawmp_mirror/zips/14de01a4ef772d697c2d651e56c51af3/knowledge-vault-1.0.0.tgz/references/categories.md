# Category Reference

## Obsidian Vault Structure

```
Library/
├── 0-Inbox/                    # 新内容暂存
├── 1-专业知识/
│   ├── 半导体/                 # 芯片、光刻、制造工艺、晶圆
│   ├── 反常热膨胀/             # 热力学、材料科学、热学性质
│   └── {自动生成}/             # 新领域自动创建
├── 2-兴趣爱好/
│   ├── 摄影知识/               # 相机、镜头、拍摄技巧
│   └── 小说/                   # 文学作品、书评
├── 3-网页收藏/
│   ├── 技术/                   # 编程、API、工具文档
│   ├── 学术/                   # 论文、研究报告
│   └── 工具/                   # 在线工具、效率应用
├── 4-书籍笔记/
│   ├── 半导体/
│   ├── 材料科学/
│   ├── 计算机科学/
│   └── 人文/
└── Templates/                  # 笔记模板
```

## Category Detection Rules

| Match Pattern | Target Directory |
|---------------|-----------------|
| 半导体, 芯片, 光刻, 刻蚀, 晶圆, CMOS, fab, 工艺 | `1-专业知识/半导体/` |
| 热膨胀, 热力学, 热学, 材料科学, 晶体 | `1-专业知识/反常热膨胀/` |
| 摄影, 相机, 镜头, 曝光, 光圈, ISO | `2-兴趣爱好/摄影知识/` |
| 小说, 文学, 故事, 读后感 | `2-兴趣爱好/小说/` |
| API, 编程, 代码, GitHub, 开发 | `3-网页收藏/技术/` |
| 论文, 研究, 学术, journal | `3-网页收藏/学术/` |
| 工具, app, 在线, 效率 | `3-网页收藏/工具/` |
| (其他书籍) | `4-书籍笔记/{领域}/` |

## Creating New Categories

When no existing category matches:
1. Propose category name (Chinese, descriptive)
2. Get user approval
3. Create directory under appropriate top-level
4. Add detection rule to this file
5. Create `index.md` in new directory (MOC - Map of Content)

## MOC (Map of Content) Template

Each category directory should have an `index.md`:

```markdown
# {分类名} — 知识地图

## 📚 收藏笔记

{{LIST_OF_NOTES}}

## 🔗 相关分类

- [[../其他分类/index|其他分类]]

---
*最后更新：{{DATE}}*
```
