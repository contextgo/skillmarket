# /resume-parser — Resume Parser Skill Definition

把「一堆混排的 PDF/docx 简历 → 结构化候选人库」这条 HR 高频工作流封装成一个斜杠路由技能。底层走 `pypdf-processor` 取 PDF 文字 + 代理内置 docx 读取器；字段抽取走 LLM 原生（prompt-driven），不用正则/NER。扫描件和解析失败文件单独列出，绝不静默丢弃。

---

## 一、触发方式

**仅手动触发** — 用户显式调用，不自动扫描附件目录、不静默处理。

### 斜杠命令

```
/resume-parser                                        # 默认 = parse，作用于当前目录或附件
/resume-parser parse folder:<path>                    # 批量抽 6 个核心字段
/resume-parser parse                                  # 省略 folder 则用附件 / 线程最近的简历批
/resume-parser score jd:<path-or-text>                # parse + 对照 JD 打 1-5 分
/resume-parser dedup                                  # parse + 标记 姓名+院校 疑似重复
/resume-parser score jd:<path> dedup                  # 组合：score + dedup 一起跑
```

### 中文别名
- `/简历解析`、`/简历抽取`、`/解析简历`、`/parse-resume` 均等价于 `/resume-parser`

### 自然语言触发

**中文（口语优先）：**
- 把这批简历的关键字段抽一下 · 这个文件夹里的简历给我整理成表格
- 这 50 份简历按 JD 打个匹配度 · 对照岗位要求给候选人打分
- 有没有重复投的？同名又同学校的标出来
- 哪些简历读不出来？单独列给我

**English:**
- parse these resumes · extract candidate fields from this folder
- score each candidate against this JD 1 to 5
- flag duplicates (same name + same school) in this batch
- which resumes failed to parse? list them separately

### 参数语法

- **键值对格式**：`key:value`，多值用逗号分隔
- `folder:<path>` — 简历所在目录（PC 本地路径或代理可寻址的云盘路径）
- `jd:<path>` 或 `jd:<text>` — JD 文件路径或直接粘贴的文本
- `fields:name,education,university,years,skills,salary` — 覆盖默认字段集（高级用法，默认就是这六个）
- `max_candidates:50` — 硬上限，默认 100；超过则截断并在 warnings 报告
- `feishu:<table-name>` — 可选；若 `飞书多维表格自动化` 已安装，把结果写入该多维表格

### 软提示

当用户上传一批 PDF/docx 但未发指令时，代理**可以**回复一行建议：「检测到 N 份简历，输入 `/resume-parser` 抽字段，或 `/resume-parser score jd:<JD路径>` 带 JD 打分。」但**不得**未经指令执行。

---

## 运行时行为

调用时执行 **router → dispatcher → (pypdf | docx) → LLM extractor → post-processor → formatter** 六阶段：

1. **Router（解析）**
   - 从斜杠命令解析 `op`（默认 `parse`）和 `key:value` 参数
   - 定位目标文件集：优先 `folder:<path>`，否则收集命令所在消息 + 线程中所有 `.pdf` / `.docx`
   - 校验 `jd:` 参数是否可读（score 操作必需）
   - 失败即返回错误 JSON，不下发到抽取层

2. **Dispatcher（分发）** — 每个文件按扩展名路由：
   | 扩展名 | 取文字方式 |
   |---|---|
   | `.pdf` | 调用 peer skill `pypdf-processor` → `/pdf extract`（全文） |
   | `.docx` | 代理内置 docx 读取器（纯文本层） |
   | `.doc`（老格式） | warnings: `["doc 格式不支持，请转换为 docx 或 PDF"]` → 进 `unreadable_resumes[]` |
   | 其他 | 同上，进 `unreadable_resumes[]`，reason: `"unsupported-format"` |

3. **扫描件检测** — 从 pypdf 拿到文字后：
   - 若文字总字数 < 50 **且**页数 ≥ 1 → 判定为 `scanned-no-text-layer`，进 `unreadable_resumes[]`，不送 LLM
   - 若文字总字数 ≥ 50 但 < 200 → `warnings` 里加 `"low-text-density"`，继续抽，但 `status` 倾向 `partial`

4. **LLM extractor（字段抽取）**
   - 对每份可读简历，注入 `references/prompts/extract.txt` 里的系统提示词 + 文件文字
   - 输出严格 JSON：6 个核心字段 + 原始薪资文本 + 归一化后的月薪（可空）
   - **缺字段 → `null`**，绝不编造
   - 敏感字段（电话、身份证、邮箱）在 JSON 里以 `***` 占位，原文不回传

5. **Post-processor（按 op 加工）**
   - `parse`：直出 `candidates[]`
   - `score`：读 `jd:` 文件/文本 → 抽 JD 关键词（技能、经验要求、学历门槛）→ 对每个候选人按关键词命中率给 1-5 分；5 分 = 强匹配、3 分 = 基本符合、1 分 = 差距大
   - `dedup`：按 `(姓名, 毕业院校)` 分组，组内 ≥ 2 人 → 全员 `is_suspected_duplicate: true` + 同一 `duplicate_group_id`（短 UUID）

6. **Formatter（格式化）**
   - 产出符合 `references/schema.json` 的 JSON（见第三节）
   - 生成人类可读 recap（见第六节）
   - 若 `feishu:<table>` 参数存在且 `飞书多维表格自动化` 已安装 → 委托写入；失败则 warnings 提示，不硬失败

### 跳过条件
- 无可寻址的 PDF/docx → "未找到简历文件，请指定 `folder:<path>` 或上传附件。"
- `score` 操作但缺 `jd:` → "score 操作需要 `jd:<path>` 或 `jd:<text>` 参数。"
- 批中 0 份可读（全部 scanned 或 unsupported）→ `status: failed`，`candidates: []`，`unreadable_resumes[]` 完整列出

### 原子性
任何文件的 LLM 调用失败 → 该文件进 `unreadable_resumes[]` with `reason: "extraction-failed"`，不影响其他文件。整批作业本身原子性不强制 —— 部分成功是 `status: partial`。

---

## 三、输出字段（按 operation 区分）

所有输出共享**基础信封**：

| 字段 | 类型 | 说明 |
|---|---|---|
| `processed_at` | string (ISO 8601) | 处理时间，默认 +08:00 |
| `operation` | string (enum) | `parse` / `score` / `dedup` |
| `status` | string (enum) | `success` / `partial` / `failed` |
| `source_folder` | string \| null | 输入目录路径（或 null 若是附件） |
| `total_files` | integer | 批中文件总数 |
| `parsed_count` | integer | 成功抽取的简历数 |
| `unreadable_count` | integer | 进 unreadable_resumes[] 的文件数 |
| `candidates` | array | 抽取到字段的候选人列表（见下） |
| `unreadable_resumes` | array | 失败/扫描/格式不支持的文件清单（见下） |
| `warnings` | array\<string\> | 非致命警告 |

### candidate 通用字段（所有 op 都有）

| 字段 | 类型 | 说明 |
|---|---|---|
| `source_file` | string | 原文件名 |
| `name` | string \| null | 姓名 |
| `education` | string \| null | 最高学历（高中/专科/本科/硕士/博士/其他） |
| `university` | string \| null | 毕业院校（最后一段学历的院校） |
| `experience_years` | number \| null | 相关工作经验年限（可含小数：2.5） |
| `top_3_skills` | array\<string\> | 3 条核心技能（不足 3 条则补齐到实际数量，不编造） |
| `expected_salary_text` | string \| null | 原文的期望薪资字符串（如 "12-15k·13薪"） |
| `expected_salary_monthly_cny` | integer \| null | 归一化月薪（人民币，取区间中点；"面议"/无信息 → null） |

### score 分支额外字段

- `jd_match_score`: integer in [1,5]
- `jd_match_reasons`: array\<string\>（命中/缺口说明，每条 < 50 字）

### dedup 分支额外字段

- `is_suspected_duplicate`: boolean
- `duplicate_group_id`: string \| null（短 UUID，同组同 ID；非重复则 null）

### unreadable_resume 条目

| 字段 | 类型 | 说明 |
|---|---|---|
| `filename` | string | 文件名 |
| `reason` | string (enum) | `scanned-no-text-layer` / `unsupported-format` / `extraction-failed` / `corrupted-file` / `oversize` |
| `detail` | string \| null | 补充说明（字数、错误码等） |

完整 JSON Schema 见 `references/schema.json`。

---

## 四、输出格式（因频道而异）

| 频道 | 显示 |
|---|---|
| 飞书 / WeCom / Slack / Discord | 折叠互动卡片：标题 `👥 解析完成 · N 份候选人 / M 份待复查`；正文前 3 名候选人（score 模式下按 jd_match_score 降序）；「查看全部」「导出 CSV」「写入飞书多维表格」按钮；底部「查看原始 JSON」按钮 |
| 微信 / Telegram / WhatsApp / iMessage / DingTalk | 纯文本 + 文件下载链接。默认列前 10 名候选人的姓名 + 学校 + 经验 + 匹配分（若有）；附一行「`M` 份简历需要人工复查，回复 `/recall unreadable` 查看清单」 |

无论哪种频道，**JSON 始终写入代理记忆层**作为权威状态。

---

## 五、边界情况

| 情况 | 行为 |
|---|---|
| 文件夹为空 | `status: failed`, recap: "文件夹里没有简历（pdf/docx）" |
| 单个文件 > 20 MB | 硬拒绝，进 `unreadable_resumes[]`，reason: `"oversize"` |
| 扫描件（无文字层） | 进 `unreadable_resumes[]`，reason: `"scanned-no-text-layer"` |
| 加密 PDF 无密码 | 进 `unreadable_resumes[]`，detail: `"encrypted — remove password first"` |
| doc / rtf / 图片简历 | 进 `unreadable_resumes[]`，reason: `"unsupported-format"` |
| 文字太短（< 200 字） | 仍抽取但 `warnings: ["low-text-density: 可能漏字段"]`，`status: partial` |
| 姓名识别不到 | `name: null`，其他字段尽量抽；dedup 时 null 姓名不参与分组 |
| 期望薪资是区间（"12k-15k"） | `expected_salary_text` 原样；`expected_salary_monthly_cny` 取中点 13500 |
| 期望薪资含 N 薪（"12k·13薪"） | `expected_salary_monthly_cny` 按月（不折算 13 薪） |
| 期望薪资是"面议" / "可谈" | `expected_salary_text: "面议"`, `expected_salary_monthly_cny: null` |
| JD 是图片 / 扫描 | `score` 失败，warnings: `["jd-unreadable"]`, 降级到 `parse` |
| 批中 > 100 份 | 截断到前 100，warnings: `["truncated to first 100 files"]` |
| 姓名为英文 / 多姓名同学校（同届校友） | `is_suspected_duplicate: false` —— dedup 只对**完全相同**的 (name, university) 对触发 |
| 个人信息（电话/身份证/邮箱） | 在 JSON 和 recap 里均以 `***` 占位，不回显原文 |
| 飞书多维表格自动化 未安装但用户指定了 `feishu:` | warnings: `["feishu-skill-not-installed — JSON only"]`, 不硬失败 |

---

## 系统提示词

运行时注入变量：`{{OPERATION}}` · `{{CANDIDATES_JSON}}` · `{{UNREADABLE_JSON}}` · `{{TOTAL_FILES}}` · `{{JD_SUMMARY}}` · `{{CHANNEL}}` · `{{LANG_HINT}}`

```
You are the StepClaw /resume-parser skill. You have just finished a batch parse
and must emit a structured response.

## Inputs
- {{OPERATION}} — one of: parse, score, dedup
- {{CANDIDATES_JSON}} — array of candidate objects already schema-validated
- {{UNREADABLE_JSON}} — array of failed-file entries
- {{TOTAL_FILES}} — total files in the input batch
- {{JD_SUMMARY}} — one-line JD description (score op only; else null)
- {{CHANNEL}} — "card" (feishu/slack/discord/wecom) or "plain" (wechat/tg/…)
- {{LANG_HINT}} — dominant language of the batch (zh / en / mixed)

## Output (emit in this exact order; nothing else)

1. A fenced ```json``` block matching references/schema.json EXACTLY for the
   given operation. Use null for absent-but-applicable values; never omit
   required keys.

2. A fenced ```recap``` block with a human-readable summary in the dominant
   language (Chinese if {{LANG_HINT}}=="zh" or user's last 3 turns are mostly
   zh, else English).
```

```
## Recap templates (口语化, 1 emoji 上限, 避免 AI 腔)

- parse  → 👥 {{PARSED_COUNT}}/{{TOTAL_FILES}} 份已解析；{{UNREADABLE_COUNT}} 份需人工复查
           前 3 名：{{TOP_3_NAMES}}（均含 学校 · 经验年限 · 期望薪资）
- score  → 🎯 对照 JD「{{JD_SUMMARY}}」：★★★★★ {{N5}} 人 · ★★★★ {{N4}} 人 · ★★★ {{N3}} 人 · ≤★★ {{NLOW}} 人
           最匹配前 3：{{TOP_3_BY_SCORE}}
- dedup  → 🔁 {{N_GROUPS}} 组疑似重复，共涉及 {{N_FLAGGED}} 人：{{GROUP_SUMMARY}}
```

```
## Rules
- Be faithful. Never invent fields; null > guessed.
- PII redaction: 电话/身份证/邮箱 in JSON and recap must be "***". Only 姓名 +
  毕业院校 + 工作经验描述可以明文出现。
- 期望薪资归一化：区间取中点；"面议"/null → monthly_cny = null。不要强行出数字。
- Reference candidates by 姓名 + 学校 in recap; never quote raw resume text
  verbatim.
- Score op: scores ∈ [1,5] integers only. 5 = 强匹配（核心技能 ≥ 80% 命中 + 学历/经验达标）;
  3 = 基本符合；1 = 差距大。reasons 字段每条 ≤ 50 字。
- Dedup op: group only when (name, university) are both present and identical.
  null 姓名或 null 学校的人永不进重复组。
- Timestamps: ISO 8601, default +08:00.
- No extra prose before the JSON block or after the recap block.
- If {{WARNINGS}} is non-empty, surface the most critical one in the recap's
  first line.
```

---

## 七、兼容性

- **StepClaw 版本**：≥ 0.3.0
- **Peer skill 依赖**：`pypdf-processor` ≥ 1.0.0（PDF 文字提取）
- **模型**：推荐 step-3.5-flash 或同级别；字段抽取不需要大模型，但要求严格 JSON 输出能力
- **频道**：所有 StepClaw 频道；卡片频道体验更佳（表格 + 按钮）
- **OpenClaw ClawHub 可移植性**：prompt + schema 框架无关，可直接镜像到 ClawHub；仅 `飞书多维表格自动化` 集成为 StepClaw 专属

---

## 八、权限

- **私聊**：任何人可调用全部操作
- **群聊**（默认）：
  - `parse` / `score` / `dedup`（读/只读计算）：任何人可调用
  - `feishu:<table>` 写入多维表格：**仅上传者或管理员**（`feishu_write_permission: uploader_only`）
- **读权限**：线程附件、指定的 `folder:<path>`、线程历史
- **写权限**：代理记忆层、线程消息；可选的飞书多维表格委托

---

## 安全注意

- **PII 红线**：电话、身份证号、邮箱、住址在 JSON 和 recap 中强制红显为 `***`。原文简历不上传到第三方，仅在代理进程内处理
- **JD 与候选人数据隔离**：JD 文本单独处理，不混入 candidate JSON
- **扫描件不做 OCR**：避免将简历图片经过第三方 OCR 服务（v2 可选本地 OCR 插件）
- **去重仅在本批内**：不跨批次查询历史简历库 —— 跨库去重需要独立的候选人数据库 skill
- **配额**：单次最多 100 份；批越大越容易触发模型速率限制，建议分批

---

## 参考

- `references/schema.json` — 输出 JSON Schema（oneOf by operation）
- `references/example-output.json` — 三种操作的示例输出
- `references/prompts/extract.txt` — 字段抽取系统提示词
- `test.md` — 本 skill 的 lean test 规格（inline synthetic data）

---

*See also:* 修炼手册 文档助手·案例 1 (简历信息提取) 和 飞书表格·案例 5 (简历筛选入候选人库) · peer skill: `pypdf-processor` · companion skill: `飞书多维表格自动化`
