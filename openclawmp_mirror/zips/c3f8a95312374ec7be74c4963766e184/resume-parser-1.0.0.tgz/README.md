# 简历解析器 /resume-parser

HR 的「一堆 PDF/docx 简历 → 结构化候选人库」这条高频工作流，封装成一个斜杠技能。默认抽 6 个核心字段（姓名 / 最高学历 / 毕业院校 / 相关经验年限 / 3 条核心技能 / 期望薪资），可选对照 JD 打 1-5 分，可选按 姓名+院校 标记疑似重复。LLM 原生抽取（不用正则/NER），中文简历和 "12-15k·13薪" 这种自由文本薪资都能处理。扫描件和格式不支持的文件单独列出给 HR 人工复查，绝不静默丢弃。

## 功能特性

- **一个路由技能，三种操作**：`parse`（默认）· `score`（JD 匹配打分 1-5）· `dedup`（姓名+院校 去重）
- **中英双语触发**：`/resume-parser`、`/简历解析`、`/解析简历`、`/parse-resume`，以及"把这批简历的关键字段抽一下"之类的自然语言
- **PDF + docx 混批**：PDF 走 peer skill `pypdf-processor`；docx 走代理内置读取器；扫描件自动识别并进复查清单
- **薪资归一化**：原文保留 `"12-15k·13薪"` + 归一化 `monthly_cny: 13500`；"面议" 直接 null 不编造
- **PII 自动红显**：电话 / 身份证 / 邮箱 / 住址在输出里强制 `***`，原始简历不上传第三方
- **飞书多维表格委托**：安装了 `飞书多维表格自动化` 时可一键写入候选人库；没装也不硬失败
- **原子执行**：单份失败不连累整批；扫描件 / 格式错 / 抽取失败各自归类，`unreadable_resumes[]` 完整列出

## 安装

```bash
openclawmp install skill/resume-parser --target-dir ~/.stepclaw/skills
# 强烈建议一并安装 peer:
openclawmp install skill/pypdf-processor --target-dir ~/.stepclaw/skills
```

## 使用方法

按操作各给一个示例：

| 操作 | 斜杠命令 | 自然语言 |
|---|---|---|
| 解析（默认） | `/resume-parser` 或 `/resume-parser parse folder:/Users/.../简历` | "把这批简历的关键字段抽出来" |
| JD 匹配打分 | `/resume-parser score jd:./jd.md` | "按这份岗位要求给候选人打 1-5 分" |
| 姓名+院校 去重 | `/resume-parser dedup` | "同名同学校的标一下疑似重复" |
| 组合：打分 + 去重 | `/resume-parser score jd:./jd.md dedup` | "打分 + 去重一起跑" |
| 写入飞书多维表格 | `/resume-parser parse feishu:Q2候选人池` | "结果写进飞书多维表格『Q2候选人池』" |

### 完整示例（修炼手册 文档助手·案例 1 改写）

```
/resume-parser parse folder:~/Downloads/2026春招简历 feishu:Q2候选人池
```

输出：
- 成功抽取的候选人数组（N 人）写入飞书多维表格『Q2候选人池』
- 扫描件 / 格式不支持的文件清单（`unreadable_resumes[]`）单独列出给 HR 人工复查
- recap 里前 3 名候选人快照

## 配置说明

| 配置项 | 说明 | 默认值 |
|---|---|---|
| `max_candidates` | 单次批量处理上限 | 100 |
| `max_file_size_mb` | 单文件大小上限 | 20 |
| `low_text_threshold` | 低字数阈值（< 此值仍抽取但标 partial） | 200 |
| `scanned_threshold` | 扫描件判定阈值（< 此值直接进复查清单） | 50 |
| `default_fields` | 默认抽取字段集 | `name,education,university,experience_years,top_3_skills,expected_salary` |
| `pii_redaction` | PII 红显开关（电话/身份证/邮箱） | `on` |
| `salary_normalize` | 是否计算 `expected_salary_monthly_cny` | `on` |
| `feishu_write_permission` | 群聊中谁能触发飞书写入 | `uploader_only` |
| `output_format` | JSON 输出模式（`compact` / `pretty`） | `compact` |

## 依赖

- StepClaw ≥ 0.3.0
- **Peer skill（必需）**：`pypdf-processor` ≥ 1.0.0
- **Companion skill（可选）**：`飞书多维表格自动化` — 装了就能一键写入候选人库
- 代理运行时 Python ≥ 3.8 (透传 pypdf 要求)
- 模型推荐 step-3.5-flash 或同级（严格 JSON 输出能力即可）

## 资产结构

```
resume-parser/
├── .metadata.json                   # 资产元数据
├── package.json                     # 依赖声明（peerDependencies: pypdf-processor）
├── README.md                        # 本文件
├── SKILL.md                         # Skill 完整定义（行为、触发、提示词）
├── test.md                          # Lean test 规格（inline synthetic data）
└── references/
    ├── schema.json                  # 输出 JSON Schema（oneOf by operation）
    ├── example-output.json          # 三种操作的示例输出
    └── prompts/
        └── extract.txt              # 字段抽取系统提示词
```

## 反馈

按 StepClaw 用户 FAQ 手册流程反馈：

```
【阶跃号】<UID>
【设备ID】<DID>
【技能】/resume-parser (resume-parser v1.0.0)
【问题描述】...
```

---

## 作者

LiXuan@StepFun · 2026-04-23

## 关联

- 修炼手册 **文档助手·案例 1**（简历信息提取）—— 这个 skill 就是为该案例填 `水产市场暂无简历解析专职 skill` 的坑
- 修炼手册 **飞书表格·案例 5**（简历筛选入候选人库 HR）—— 配合 `飞书多维表格自动化` 覆盖该工作流
- Peer skill `pypdf-processor` 处理 PDF 文字层提取
