# resume-parser — Lean Test Spec

*Run on: PC (any); inline synthetic data, no external fixtures.*

---

## Test 1: parse (6 核心字段抽取)

### Prompt

```
用 /resume-parser skill 把下面 5 份简历（以 `---FILE: <name>---` 分隔）批量抽取字段，
输出符合 references/schema.json parse 分支的 JSON。

---FILE: 张伟_后端开发.pdf---
姓名：张伟
电话：13800138000
邮箱：zhangwei@example.com
教育背景：2021-2024 上海交通大学 计算机科学与技术 硕士
2017-2021 上海交通大学 软件工程 本科
工作经历：2024-至今 字节跳动 后端开发工程师 (3 年)
技能：Java / Spring Boot / MySQL / Redis / Docker
期望薪资：25-30k·13薪

---FILE: 李思远_数据分析.docx---
李思远
复旦大学 统计学 本科 (2020-2024)
实习: 腾讯 数据分析实习生 6 个月
校招全职经验: 美团 数据分析师 1 年 6 个月
核心技能: Python · SQL · Tableau · Excel 高阶
期望: 面议

---FILE: 王芳_前端.docx---
王芳 · 同济大学软件工程本科 · 2 年前端经验
技能栈: React, TypeScript, Webpack, Vite
期望薪资: 18k

---FILE: 陈晓_扫描件.pdf---
（文字层只有 12 个字：某人的模糊名字）

---FILE: 刘洋_运营.doc---
（老 doc 格式，skill 应拒绝）
```

### Expected Output

`parse` 分支 JSON 必含：
- `total_files: 5`, `parsed_count: 3`, `unreadable_count: 2`
- `candidates[]` 长度 = 3
- `张伟` 对象：`education: "硕士"`, `university: "上海交通大学"`, `experience_years: 3`, `top_3_skills` 正好 3 条从 {Java, Spring Boot, MySQL, Redis, Docker} 中抽取，`expected_salary_text: "25-30k·13薪"`, `expected_salary_monthly_cny: 27500`
- `李思远` 对象：`experience_years: 1.5`（校招全职 1.5 年，实习不算），`expected_salary_text: "面议"`, `expected_salary_monthly_cny: null`
- `王芳` 对象：`experience_years: 2`, `expected_salary_monthly_cny: 18000`
- `unreadable_resumes[]` 长度 = 2，reasons = `scanned-no-text-layer` 和 `unsupported-format`
- 电话 `13800138000` 和邮箱 `zhangwei@example.com` **不得**出现在 JSON 任何字段里
- `status: "partial"`（因为 2 份不可读）

**Fail if:** experience_years 把实习算进去了 / top_3_skills 被 pad 到 4 条 / 期望薪资归一化错误（如 27500 ≠ (25000+30000)/2） / PII 出现 / 扫描件没进 unreadable_resumes。

---

## Test 2: score (对照 JD 打 1-5 分)

### Prompt

```
复用 Test 1 的 5 份简历，再加一条 JD：

---FILE: jd.md---
岗位：后端开发工程师
要求：3 年以上 Java/Spring 经验，熟悉分布式、MySQL、Redis，本科及以上学历。

用 /resume-parser score jd:<上面的 jd.md 内容> 对三个可读候选人打 1-5 分。
```

### Expected Output

`score` 分支 JSON 必含：
- `operation: "score"`, `jd_summary` 是一行 JD 摘要
- 每个 candidate 有 `jd_match_score` (integer 1-5) 和 `jd_match_reasons` (array, 每条 ≤ 50 字符)
- 张伟 ≥ 4 分（全命中）；李思远 ≤ 3 分（技能方向不符）；王芳 ≤ 2 分（前端 vs 后端）

**Fail if:** 分数不是 [1,5] 的整数 / 张伟得分 < 4 / 王芳得分 ≥ 4 / jd_match_reasons 某条超过 50 字符。

---

## Test 3: dedup (姓名+院校 去重)

### Prompt

```
复用 Test 1 的 3 个可读候选人，再加第 6 份：

---FILE: 张伟_后端_v2.docx---
张伟 · 上海交通大学 硕士 · Java / Redis / Kafka · 期望 30k · 3 年经验

用 /resume-parser dedup 标记同名同学校的疑似重复。
```

### Expected Output

`dedup` 分支 JSON 必含：
- `operation: "dedup"`, `duplicate_group_count: 1`
- 两个张伟 candidate 有相同的 `duplicate_group_id`（非空短 UUID），`is_suspected_duplicate: true`
- 李思远和王芳 `is_suspected_duplicate: false`, `duplicate_group_id: null`

**Fail if:** duplicate_group_id 两个张伟不一致 / 李思远或王芳被误标 / null 姓名或 null 学校的人被拉进组。

---

## Test 4: edge cases (归一化规则快速验)

### Prompt

```
用 /resume-parser parse 抽这 4 份 micro 简历：

---FILE: a.docx---
Alice · MIT · Ph.D. · 5 年 · Rust, Go, Python · 40k USD monthly

---FILE: b.docx---
陈工 · 北大博士 · 30W/年 · 8 年 · Python, C++, 算法

---FILE: c.docx---
小李 · 高中毕业 · 可谈 · 1 年 · 文案写作

---FILE: d.docx---
（完全空白文件）
```

### Expected Output

- Alice: `education: "博士"`, `experience_years: 5`, `expected_salary_monthly_cny: null`（USD 不归一化，只保留 text）
- 陈工: `expected_salary_monthly_cny: 25000`（30W/年 ÷ 12）
- 小李: `education: "高中"`, `top_3_skills: ["文案写作"]`（只有 1 条，不 pad），`expected_salary_monthly_cny: null`
- d.docx 进 `unreadable_resumes[]` with `reason: "extraction-failed"` 或 `"scanned-no-text-layer"`

**Fail if:** USD/SGD/HKD 被归一化成 CNY / 30W/年 错算（应 25000，不是 2.5k 也不是 360000） / top_3_skills 被 pad 到 3 条 / 空白文件没进 unreadable。

---

## Pass criteria (overall)

- ✅ 所有 JSON 对 `references/schema.json` 校验通过
- ✅ PII 全部红显为 `***`
- ✅ 薪资归一化 4 条规则全对（区间中点 / N 薪忽略 / 年薪除 12 / 非 CNY 置 null）
- ✅ experience_years 不把实习算进去
- ✅ top_3_skills 不编造，不 pad
- ✅ dedup 只对 (name, university) 都非 null 且完全相同才触发
- ✅ 扫描件 / doc 格式 / 空白文件都归类到 `unreadable_resumes[]`，各带对的 reason

匹配用户 `feedback_eval_strictness` — "does it work" 优先，不追求字段 100% 精确匹配 baseline。
