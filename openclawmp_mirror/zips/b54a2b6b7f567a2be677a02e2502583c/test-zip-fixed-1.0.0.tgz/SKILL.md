---
name: test-sqlite-db-v3
description: "Test SQLite pattern"
version: 1.0.0
---

# Test SQLite Pattern

This is a test skill content.
