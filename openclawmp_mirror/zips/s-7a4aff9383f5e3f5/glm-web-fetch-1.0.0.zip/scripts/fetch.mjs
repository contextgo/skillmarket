#!/usr/bin/env node

/**
 * GLM 网页读取
 * 使用智谱AI Web Fetch API
 */

function usage() {
  console.error(`Usage: fetch.mjs <url> [options]
Options:
  --format <f>   格式: markdown, text, html (default: markdown)
  --no-cache     禁用缓存
  --summary     仅返回摘要`);
  process.exit(2);
}

const args = process.argv.slice(2);
if (args.length === 0) usage();

let url = args[0];
let format = 'markdown';
let useCache = true;
let summaryOnly = false;

for (let i = 1; i < args.length; i++) {
  const a = args[i];
  if (a === '--format' && args[i + 1]) {
    format = args[i + 1];
    i++;
  } else if (a === '--no-cache') {
    useCache = false;
  } else if (a === '--summary') {
    summaryOnly = true;
  }
}

const API_KEY = process.env.ZHIPU_API_KEY;
if (!API_KEY) {
  console.error('错误: 请设置 ZHIPU_API_KEY 环境变量');
  process.exit(1);
}

const https = require('https');

const postData = JSON.stringify({
  url: url,
  format: format,
  cache: useCache,
  summary: summaryOnly
});

const options = {
  hostname: 'open.bigmodel.cn',
  path: '/api/paas/v4/tools/web_fetch',
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

console.log('📄 正在读取网页...');

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      
      if (result.error) {
        console.error('错误:', result.error.message);
        process.exit(1);
      }
      
      // 输出结果
      if (summaryOnly && result.summary) {
        console.log('📝 摘要:');
        console.log(result.summary);
      } else if (result.content) {
        console.log(result.content);
      } else {
        console.log(JSON.stringify(result, null, 2));
      }
      
    } catch (e) {
      console.error('解析失败:', e.message);
      console.error('原始数据:', data);
    }
  });
});

req.on('error', (e) => {
  console.error('请求错误:', e.message);
  process.exit(1);
});

req.write(postData);
req.end();
