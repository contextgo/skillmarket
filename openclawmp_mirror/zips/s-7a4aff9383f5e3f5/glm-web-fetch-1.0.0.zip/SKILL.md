---
name: glm-web-fetch
displayName: GLM 网页读取
description: 使用智谱AI读取并解析URL网页内容，支持多种格式和选项。
homepage: https://open.bigmodel.cn
---

# GLM 网页读取

> 使用智谱AI读取URL页面内容，智能解析

## 特点

- 读取任意URL内容
- 智能提取关键信息
- 支持缓存
- 可选择输出格式

## 环境要求

- Node.js 18+
- 智谱AI API Key

## 认证方式

```bash
export ZHIPU_API_KEY="your-api-key"
```

获取API Key: https://open.bigmodel.cn/usercenter/apikeys

## 使用方法

```bash
node {baseDir}/scripts/fetch.mjs "https://example.com"
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--format` | 输出格式: markdown, text, html | markdown |
| `--no-cache` | 禁用缓存 | false |
| `--summary` | 仅返回摘要 | false |

## 示例

```bash
# 基本用法
node {baseDir}/scripts/fetch.mjs "https://news.example.com/article"

# 输出纯文本
node {baseDir}/scripts/fetch.mjs "https://example.com" --format text

# 获取摘要
node {baseDir}/scripts/fetch.mjs "https://example.com" --summary

# 禁用缓存
node {baseDir}/scripts/fetch.mjs "https://example.com" --no-cache
```

## 返回格式

```json
{
  "title": "页面标题",
  "content": "页面内容...",
  "links": ["链接1", "链接2"],
  "images": ["图片1", "图片2"]
}
```

---

*基于智谱AI官方Web Fetch API*
