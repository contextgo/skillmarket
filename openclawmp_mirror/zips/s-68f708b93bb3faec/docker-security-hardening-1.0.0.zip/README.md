# Docker Security Hardening

## Image Security
- Use minimal base images (alpine, distroless)
- Multi-stage builds (build tools don't reach production)
- Pin image versions (no :latest in production)
- Scan images with Trivy/Snyk
- Sign images with Cosign/Notary

## Container Hardening

### Non-Root Execution
```dockerfile
RUN adduser -D appuser
USER appuser
```

### Read-Only Filesystem
```dockerfile
RUN --mount=type=tmpfs,target=/tmp ...
```

### Resource Limits
```yaml
deploy:
  resources:
    limits:
      cpus: '0.5'
      memory: 256M
```

## Secrets Management
- Docker Secrets (Swarm) or Kubernetes Secrets
- Never hardcode secrets in Dockerfile
- Use .dockerignore to exclude secrets
- Environment variables only for non-sensitive config
- External secret stores: Vault, AWS Secrets Manager

## Network Isolation
- Custom bridge networks per service
- Don't expose unnecessary ports
- Internal-only networks for inter-service communication
- Network policies in Kubernetes

## Runtime Protection
- Read-only root filesystem
- No new privileges (security_opt: no-new-privileges)
- Drop all capabilities, add only needed
- Seccomp profile for syscall filtering
- AppArmor/SELinux profiles

## Monitoring
- Container runtime logs
- Process monitoring ( Falco )
- Network traffic analysis
- Image vulnerability tracking