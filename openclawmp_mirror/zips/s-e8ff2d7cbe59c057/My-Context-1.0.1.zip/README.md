# 阶跃桌面活动上下文检索

从本地阶跃桌面（StepFun Desktop）的屏幕记录中，为当前任务补充相关历史上下文。

## 数据源

默认路径（自动推导）：
```
~/Library/Application Support/stepfun-desktop/desktop-share/summary/
```

可通过当前工作目录下的 `.env` 文件中的 `SUMMARY_BASE_DIR` 变量覆盖，示例见 `.env.example`。

目录结构：`YYYYMMDD/{开始时间戳}-{结束时间戳}.json`

每条 `screenImages[]` 的核心字段：`imageInfo`（截图文字识别内容）、`frontApp`、`windowTitle`、`timestamp`。  
文件级字段：`title`、`summary`、`startTime`、`endTime`。

## 使用流程

### 第一步：提取关键词

从用户任务描述中提取实体词和事件词：
- 应用名（如 `Cursor`、`Figma`、`Chrome`）
- 文件名、URL、域名
- 人名、项目名
- 操作对象（如 `JWT`、`部署`、`发票`）

保持关键词简短具体，通常 2～5 个。

### 第二步：运行检索脚本

```bash
python3 scripts/search_context.py --keywords 关键词1 关键词2 [--days N]
```

- `--days N`：限制只检索最近 N 天（不填则检索全部历史）
- 输出：JSON 数组，每条包含 `imageInfo`、`frontApp`、`windowTitle`、`matchedKeywords`、`score`、`file`、`startTime`、`endTime`

> **注意**：脚本路径为相对路径，需在技能所在目录下运行，或使用绝对路径。

### 第三步：Fallback（脚本失败时）

```bash
grep -rl "关键词" "${SUMMARY_BASE_DIR:-$HOME/Library/Application Support/stepfun-desktop/desktop-share/summary}" \
  | xargs grep -h "imageInfo" | head -50
```

### 第四步：最终 Fallback

若以上均失败，告知用户：
> 「未能检索到相关上下文，将基于已有信息执行任务。」

**不阻塞主流程，继续执行任务。**

## 结果使用

脚本已完成排序和截断（单关键词 TOP 5，多关键词每词 TOP 3 合并去重），直接使用输出结果即可：
- 提取 `imageInfo`、`frontApp`、`windowTitle` 作为上下文
- 禁止直接读取原始 JSON 文件，只使用脚本或命令行检索
- 结果为空数组时，告知用户无相关上下文，直接继续任务

## 配置说明（`.env`）

如数据目录不在默认位置，帮助用户在技能目录下创建 `.env` 文件并配置路径：

```bash
# 复制示例文件
cp .env.example .env
```
然后告知用户编辑 .env，取消注释并填入实际路径
SUMMARY_BASE_DIR=/你的/实际/路径