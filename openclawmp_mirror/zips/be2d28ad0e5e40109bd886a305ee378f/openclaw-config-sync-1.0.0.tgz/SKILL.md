---
name: openclaw-config-sync
description: 智能评估 OpenClaw 配置同步任务，判断本地代码是否需要提交，自动处理配置同步流程，包含变更检测、冲突解决、状态汇报等功能。
---

# OpenClaw 配置同步 Skill

## 功能概述

本 Skill 用于智能评估和执行 OpenClaw 配置同步任务，主要解决以下问题：

1. **变更检测** - 智能判断本地是否有需要提交的更改
2. **冲突解决** - 自动处理 Git 合并冲突
3. **状态汇报** - 生成清晰的同步结果报告
4. **错误恢复** - 处理网络故障、权限问题等异常情况

## 使用场景

- 定时任务【OpenClaw 配置自动同步】执行时调用
- 手动触发配置同步时调用
- 需要检查配置状态但不确定是否需要提交时

## 执行流程

### 1. 预检阶段

检查以下前提条件：

```powershell
# 检查备份目录是否存在
$backupDir = "$env:USERPROFILE/.stepclaw-backup"
if (-not (Test-Path $backupDir)) {
    return @{ Status = "ERROR"; Message = "备份目录不存在，请先克隆仓库" }
}

# 检查 Git 仓库状态
Set-Location $backupDir
$gitStatus = git status --porcelain
```

### 2. 变更检测

对比本地 `.stepclaw` 和备份目录的差异：

```powershell
# 定义同步项
$syncItems = @(
    @{ Source = "$env:USERPROFILE/.stepclaw/openclaw.json"; Target = "$backupDir/config/openclaw.json"; Type = "File" },
    @{ Source = "$env:USERPROFILE/.stepclaw/workspace"; Target = "$backupDir/data/workspace"; Type = "Directory" },
    @{ Source = "$env:USERPROFILE/.stepclaw/memory"; Target = "$backupDir/data/memory"; Type = "Directory" },
    @{ Source = "$env:USERPROFILE/.stepclaw/cron"; Target = "$backupDir/data/cron"; Type = "Directory"; Exclude = @("jobs.json", "runs") },
    @{ Source = "$env:USERPROFILE/.stepclaw/experiences"; Target = "$backupDir/data/experiences"; Type = "Directory" },
    @{ Source = "$env:USERPROFILE/.stepclaw/skills"; Target = "$backupDir/data/skills"; Type = "Directory" }
)

# 检测是否有实质变更
$hasChanges = $false
$changeDetails = @()

foreach ($item in $syncItems) {
    if ($item.Type -eq "File") {
        if (Test-Path $item.Source) {
            $sourceHash = Get-FileHash $item.Source -Algorithm SHA256 | Select-Object -ExpandProperty Hash
            if (Test-Path $item.Target) {
                $targetHash = Get-FileHash $item.Target -Algorithm SHA256 | Select-Object -ExpandProperty Hash
                if ($sourceHash -ne $targetHash) {
                    $hasChanges = $true
                    $changeDetails += "文件变更: $(Split-Path $item.Source -Leaf)"
                }
            } else {
                $hasChanges = $true
                $changeDetails += "新增文件: $(Split-Path $item.Source -Leaf)"
            }
        }
    } else {
        # 目录对比逻辑...
        $diffResult = Compare-Directories -Source $item.Source -Target $item.Target -Exclude $item.Exclude
        if ($diffResult.HasChanges) {
            $hasChanges = $true
            $changeDetails += $diffResult.Details
        }
    }
}
```

### 3. 决策逻辑

根据检测结果决定操作：

| 场景 | 本地状态 | 远程状态 | 操作 |
|------|---------|---------|------|
| 无变更 | 无修改 | 一致 | 跳过，汇报"无需同步" |
| 仅本地变更 | 有修改 | 一致 | 提交并推送 |
| 仅远程变更 | 无修改 | 有更新 | 拉取并合并 |
| 双向变更 | 有修改 | 有更新 | 自动合并（优先本地） |
| 冲突 | 有修改 | 有冲突 | 自动解决，保留本地 |

### 4. 执行同步

```powershell
# 阶段 1: 拉取远程更新
try {
    git fetch origin main
    $localCommit = git rev-parse HEAD
    $remoteCommit = git rev-parse origin/main
    
    if ($localCommit -ne $remoteCommit) {
        # 需要合并
        git merge origin/main --strategy-option ours
    }
} catch {
    return @{ Status = "ERROR"; Message = "拉取远程更新失败: $_" }
}

# 阶段 2: 复制文件
foreach ($item in $syncItems) {
    # 执行文件/目录同步...
    Sync-Item -Source $item.Source -Target $item.Target -Type $item.Type -Exclude $item.Exclude
}

# 阶段 3: 清理排除项
$excludePatterns = @("*.sqlite", "*.log", "*.tmp", "node_modules", "__pycache__", ".git", "jobs.json", "runs", "*.jsonl", "tmp")
foreach ($pattern in $excludePatterns) {
    Get-ChildItem $backupDir -Recurse -Filter $pattern -ErrorAction SilentlyContinue | 
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

# 阶段 4: 提交并推送
$status = git status --porcelain
if ([string]::IsNullOrWhiteSpace($status)) {
    return @{ Status = "NO_CHANGES"; Message = "无需要同步的更改" }
}

git add .
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
$changes = (git diff --cached --stat) | Out-String
git commit -m "sync: $timestamp`n`n$changes"

# 推送（带重试）
$maxRetries = 3
$retryCount = 0
while ($retryCount -lt $maxRetries) {
    try {
        git push origin main
        return @{ Status = "SUCCESS"; Message = "同步成功"; Changes = $changes }
    } catch {
        $retryCount++
        if ($retryCount -lt $maxRetries) {
            # 尝试解决冲突
            git fetch origin
            git merge origin/main --strategy-option ours
            git add .
            git commit -m "sync: $timestamp (auto-merge)" --no-verify
        }
    }
}

return @{ Status = "ERROR"; Message = "推送失败，已达到最大重试次数" }
```

### 5. 结果汇报

生成格式化的同步报告：

```markdown
## OpenClaw 配置同步报告

**执行时间**: 2026-04-16 15:40 (Asia/Shanghai)
**执行结果**: ✅ 成功 / ⚠️ 警告 / ❌ 失败 / ⏭️ 跳过

### 同步内容
- ✅ openclaw.json → config
- ✅ workspace → data/workspace
- ✅ memory → data/memory
- ✅ cron → data/cron
- ✅ experiences → data/experiences
- ✅ skills → data/skills

### 变更统计
- 新增文件: X 个
- 修改文件: X 个
- 删除文件: X 个

### 排除项
- \data\memory\main.sqlite
- \data\skills\notes-know-you\scripts\__pycache__
- ...

### Git 状态
- 提交 SHA: xxxxxxx
- 提交信息: sync: 2026-04-16 15:40

### 备注
如有错误或警告，在此说明
```

## 工具函数

### Compare-Directories

比较两个目录的差异，返回变更详情。

### Sync-Item

同步单个文件或目录，支持排除模式。

### Resolve-GitConflict

自动解决 Git 合并冲突，优先保留本地更改。

## 错误处理

| 错误类型 | 处理策略 |
|---------|---------|
| 网络超时 | 指数退避重试，最多3次 |
| 权限拒绝 | 检查 SSH key / Token 有效性 |
| 合并冲突 | 自动使用 `--strategy-option ours` |
| 仓库损坏 | 尝试 `git reset --soft` 恢复 |

## 使用示例

### 在定时任务中调用

```json
{
  "payload": {
    "kind": "agentTurn",
    "message": "执行 OpenClaw 配置同步 Skill：\n\n1. 检查 ~/.stepclaw-backup 是否存在\n2. 对比本地和备份目录的变更\n3. 如果有变更，执行同步流程\n4. 生成同步报告\n\n使用 openclaw-config-sync skill 完成以上任务。"
  }
}
```

### 手动调用

```powershell
# 直接执行 PowerShell 脚本
& ~/.stepclaw/skills/openclaw-config-sync/scripts/sync.ps1
```

## 自优化功能

本 Skill 具备**自优化能力**，能够：

1. **问题记录** - 每次执行遇到异常时，自动记录问题类型、错误详情、上下文
2. **趋势分析** - 分析最近7天的问题记录，识别高频问题模式
3. **自动优化** - 根据问题类型自动生成优化建议并应用

### 问题分类

| 分类 | 说明 | 自动优化策略 |
|------|------|-------------|
| `NETWORK_ERROR` | 网络连接失败 | 增加指数退避重试 |
| `MERGE_CONFLICT` | Git 合并冲突 | 优化自动合并逻辑 |
| `PERMISSION_DENIED` | 权限不足 | 增加权限预检 |
| `FILE_LOCKED` | 文件被占用 | 增加文件锁检测 |
| `TIMEOUT` | 操作超时 | 优化超时处理 |
| `SYNC_ERROR` | 文件同步失败 | 增强错误恢复 |
| `GIT_ERROR` | Git 操作失败 | 改进 Git 命令处理 |
| `PUSH_ERROR` | 推送失败 | 增强重试机制 |
| `CONFIG_ERROR` | 配置错误 | 改进配置验证 |

### 自优化触发方式

```powershell
# 手动执行自优化分析
& ~/.stepclaw/skills/openclaw-config-sync/scripts/sync.ps1 -SelfOptimize

# 正常同步（遇到问题会自动记录）
& ~/.stepclaw/skills/openclaw-config-sync/scripts/sync.ps1
```

### 优化日志位置

```
~/.stepclaw/skills/openclaw-config-sync/logs/
├── sync-YYYYMMDD-HHMMSS.log      # 每次执行的详细日志
├── issues.json                    # 问题记录（最近100条）
├── optimization-YYYYMMDD-HHMMSS.json  # 优化分析报告
└── applied-optimizations.json     # 已应用的优化记录
```

## 定时任务集成（带自优化）

在定时任务中，可以配置为每次同步后自动分析并优化：

```json
{
  "payload": {
    "kind": "agentTurn",
    "message": "执行 OpenClaw 配置同步任务：\n\n1. 执行同步脚本：~/.stepclaw/skills/openclaw-config-sync/scripts/sync.ps1\n2. 如果同步失败或遇到问题，自动记录问题\n3. 执行自优化分析：sync.ps1 -SelfOptimize\n4. 如果有优化建议，更新 SKILL.md 记录改进点\n5. 生成完整报告（同步结果 + 优化建议）"
  }
}
```

## 配置项

可在 `~/.stepclaw/experiences/openclaw-config-sync/config.json` 中自定义：

```json
{
  "backupDir": "~/.stepclaw-backup",
  "syncItems": [...],
  "excludePatterns": [...],
  "maxRetries": 3,
  "autoMerge": true,
  "notifyOnSuccess": true,
  "notifyOnError": true,
  "selfOptimize": {
    "enabled": true,
    "analyzeOnError": true,
    "keepIssuesDays": 30,
    "autoApplyFixes": true
  }
}
```
