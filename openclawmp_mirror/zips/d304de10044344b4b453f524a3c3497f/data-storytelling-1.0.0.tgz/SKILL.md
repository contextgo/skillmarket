---
name: data-storytelling
description: "Transform data into compelling narratives using visualization, context, and persuasive structure. Use when presenting analytics to stakeholders, creating data reports, or building executive presentations."
---

# Data Storytelling

Transform raw data into compelling narratives that drive decisions and inspire action.

## When to Use This Skill

- Presenting analytics to executives
- Creating quarterly business reviews
- Building investor presentations
- Writing data-driven reports
- Communicating insights to non-technical audiences
- Making recommendations based on data

---

## Execution Workflow

Follow these steps in order. Do not skip ahead.
Load referenced files only at the step that requires them.

### Step 1 — Understand the Request

Before producing any output, confirm the following four inputs.
If the user has already provided them, proceed to Step 2.
If any are missing, ask — but ask no more than two questions at once.

| Input | What to confirm |
|---|---|
| **Data** | What metrics, numbers, or findings does the user have? |
| **Audience** | Who receives this? (executives, investors, technical team, general stakeholders) |
| **Goal** | What decision or action should this story drive? |
| **Format** | What is the desired output? (slide deck, written report, one-page summary, email) |

> If the user provides partial context, infer what you can and proceed.
> Only ask for what is genuinely missing and would change the output.

### Step 2 — Select a Framework

Use this table to select the framework. Do not deliberate — pick the first match.

| Situation | Framework |
|---|---|
| There is a problem to solve or an opportunity to address | **Framework 1: Problem-Solution** |
| You are showing how things changed over time | **Framework 2: Trend** |
| You need to choose between two or more options | **Framework 3: Comparison** |
| Unclear or mixed situation | Default to **Framework 1** |

→ Load `references/frameworks.md` and read only the selected framework.

### Step 3 — Select a Template

Match the output format to the appropriate presentation template.

| Format | Template |
|---|---|
| Slide deck or multi-slide presentation | Template 2: Data Story Flow |
| Executive meeting or board summary | Template 1: Executive Summary Slide |
| Report, email, or one-page summary | Template 3: One-Page Dashboard Story |

→ Load `references/templates.md` and read only the selected template.

### Step 4 — Build and Deliver the Output

→ Load `references/writing-techniques.md` for headlines, transition phrases, and visualization reference.

1. Apply the selected framework structure to organize the user's data.
2. Fill in the selected template with the organized content.
3. Write the headline first using the formula: [Specific Number] + [Business Impact] + [Actionable Context].
4. Apply transition phrases to connect sections naturally.
5. Open your final output with a single-sentence headline insight — the "so what" — before any supporting detail.

---

## Core Concepts

### Story Structure

```
Setup → Conflict → Resolution

Setup:      Context and baseline
Conflict:   The problem or opportunity
Resolution: Insights and recommendations
```

### Narrative Arc

```
1. Hook         — Grab attention with a surprising insight
2. Context      — Establish the baseline
3. Rising Action — Build through data points
4. Climax       — The key insight
5. Resolution   — Recommendations
6. Call to Action — Next steps
```

### Three Pillars

| Pillar        | Purpose  | Components                        |
|---------------|----------|-----------------------------------|
| **Data**      | Evidence | Numbers, trends, comparisons      |
| **Narrative** | Meaning  | Context, causation, implications  |
| **Visuals**   | Clarity  | Charts, diagrams, highlights      |

---

## Best Practices

**Do:**
- Lead with the "so what" — front-load the key insight
- Use the rule of three — three points, three comparisons
- Connect to audience goals — make it personal
- End with a clear call to action

**Don't:**
- Data dump — curate ruthlessly
- Bury the insight — put it first
- Use jargon — match the audience's vocabulary
- Show methodology before context

---

## Resources

- [Storytelling with Data — Cole Nussbaumer](https://www.storytellingwithdata.com/)
- [The Pyramid Principle — Barbara Minto](https://www.amazon.com/Pyramid-Principle-Logic-Writing-Thinking/dp/0273710516)
- [Resonate — Nancy Duarte](https://www.duarte.com/resonate/)
