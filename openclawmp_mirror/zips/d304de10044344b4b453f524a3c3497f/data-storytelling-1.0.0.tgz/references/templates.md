# Presentation Templates

Load only the template selected in Step 3. Do not read the others.

---

## Template 1: Executive Summary Slide

Use for: executive meetings, board summaries.

Layout: Single page — headline insight at top, data and implications side by side.

```
┌─────────────────────────────────────────────────────────────┐
│  KEY INSIGHT                                                │
│  ══════════════════════════════════════════════════════════ │
│  "[One-sentence headline insight]"                          │
├──────────────────────┬──────────────────────────────────────┤
│  THE DATA            │  THE IMPLICATION                     │
│                      │                                      │
│  [Segment A]:        │  ✓ [Action 1]                        │
│  • Metric: value     │  ✓ [Action 2]                        │
│  • Metric: value     │  ✓ [Action 3]                        │
│  • Metric: value     │                                      │
│                      │  Investment: $X                      │
│  [Segment B]:        │  Expected ROI: Nx                    │
│  • Metric: value     │                                      │
│  • Metric: value     │                                      │
└──────────────────────┴──────────────────────────────────────┘
```

---

## Template 2: Data Story Flow

Use for: slide decks, multi-slide presentations.

Structure: 7 slides, each with a single focus.

```
Slide 1: THE HEADLINE
"[Specific Number] + [Business Impact] + [Actionable Context]"

Slide 2: THE CONTEXT
Current state metrics
Industry benchmarks
Gap analysis

Slide 3: THE DISCOVERY
What the data revealed
Surprising finding
Pattern identification

Slide 4: THE DEEP DIVE
Root cause analysis
Segment breakdowns
Statistical significance

Slide 5: THE RECOMMENDATION
Proposed actions
Resource requirements
Timeline

Slide 6: THE IMPACT
Expected outcomes
ROI calculation
Risk assessment

Slide 7: THE ASK
Specific request
Decision needed
Next steps
```

---

## Template 3: One-Page Dashboard Story

Use for: written reports, emails, one-page summaries.

Structure: Headline → Metrics snapshot → What's working / What needs attention → Root cause → Recommendation → Next focus.

```markdown
## THE HEADLINE
[Key insight: what changed and why it matters]

## KEY METRICS AT A GLANCE
┌────────┬────────┬────────┬────────┐
│ [M1]   │ [M2]   │ [M3]   │ [M4]   │
│ value  │ value  │ value  │ value  │
│ ▲/▼%   │ ▲/▼%   │ ▲/▼%   │ ▲/▼%   │
└────────┴────────┴────────┴────────┘

## WHAT'S WORKING
✓ [Positive finding 1]
✓ [Positive finding 2]
✓ [Positive finding 3]

## WHAT NEEDS ATTENTION
✗ [Issue 1]
✗ [Issue 2]

## ROOT CAUSE
[1-2 sentences identifying why the issue exists]

## RECOMMENDATION
1. [Action 1]
2. [Action 2]
3. [Action 3]

## NEXT PERIOD FOCUS
- [Priority 1]
- [Priority 2]
- [Priority 3]
```
