# Writing Techniques

Load this file in Step 4 when building the output.

---

## Headlines That Work

Formula: [Specific Number] + [Business Impact] + [Actionable Context]

```
BAD:  "Q4 Sales Analysis"
GOOD: "Q4 Sales Beat Target by 23% - Here's Why"

BAD:  "Customer Churn Report"
GOOD: "We're Losing $2.4M to Preventable Churn"

BAD:  "Marketing Performance"
GOOD: "Content Marketing Delivers 4x ROI vs. Paid"
```

---

## Transition Phrases

Building the narrative:
- "This leads us to ask..."
- "When we dig deeper..."
- "The pattern becomes clear when..."
- "Contrast this with..."

Introducing insights:
- "The data reveals..."
- "What surprised us was..."
- "The inflection point came when..."
- "The key finding is..."

Moving to action:
- "This insight suggests..."
- "Based on this analysis..."
- "The implication is clear..."
- "Our recommendation is..."

---

## Handling Uncertainty

Acknowledge limitations:
- "With 95% confidence, we can say..."
- "The sample size of 500 shows..."
- "While correlation is strong, causation requires..."

Present ranges:
- "Impact estimate: $400K-$600K"
- "Confidence interval: 15-20% improvement"
- "Best case: X, Conservative: Y"

---

## Visualization Reference

When charts or annotated visuals are needed, use this pattern as a
starting point. Replace all placeholder variables with actual values
before running.

```python
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(12, 6))

# Plot the main data — replace `dates` and `revenue` with real series
ax.plot(dates, revenue, linewidth=2, color='#2E86AB')

# Annotate a key event — replace with actual date and value
ax.annotate(
    'Product Launch\n+32% spike',
    xy=(launch_date, launch_revenue),
    xytext=(launch_date, launch_revenue * 1.2),
    fontsize=10,
    arrowprops=dict(arrowstyle='->', color='#E63946'),
    color='#E63946'
)

# Highlight a period — replace with actual start/end
ax.axvspan(growth_start, growth_end, alpha=0.2, color='green',
           label='Growth Period')

# Add a target line — replace with actual target value
ax.axhline(y=target, color='gray', linestyle='--',
           label=f'Target: ${target:,.0f}')

ax.set_title('Revenue Growth Story', fontsize=14, fontweight='bold')
ax.legend()
```
