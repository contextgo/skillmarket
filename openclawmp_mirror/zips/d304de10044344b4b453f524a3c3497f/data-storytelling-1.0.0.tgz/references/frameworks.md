# Story Frameworks

Load only the framework selected in Step 2. Do not read the others.

---

## Framework 1: The Problem-Solution Story

Use when: there is a problem to solve or an opportunity to address.

Structure: Hook → Context → Problem → Insight → Solution → Expected Impact → Call to Action

```markdown
## The Hook
"We're losing $2.4M annually to preventable churn."

## The Context
- Current churn rate: 8.5% (industry average: 5%)
- Average customer lifetime value: $4,800
- 500 customers churned last quarter

## The Problem
Analysis of churned customers reveals a pattern:
- 73% churned within first 90 days
- Common factor: < 3 support interactions
- Low feature adoption in first month

## The Insight
[Show engagement curve visualization]
Customers who don't engage in the first 14 days
are 4x more likely to churn.

## The Solution
1. Implement 14-day onboarding sequence
2. Proactive outreach at day 7
3. Feature adoption tracking

## Expected Impact
- Reduce early churn by 40%
- Save $960K annually
- Payback period: 3 months

## Call to Action
Approve $50K budget for onboarding automation.
```

---

## Framework 2: The Trend Story

Use when: showing how things changed over time.

Structure: Where We Started → What Changed → The Transformation → Key Insight → Going Forward

```markdown
## Where We Started
Q3 ended with $1.2M MRR, 15% below target.
Team morale was low after missed goals.

## What Changed
[Timeline visualization]
- Oct: Launched self-serve pricing
- Nov: Reduced friction in signup
- Dec: Added customer success calls

## The Transformation
[Before/after comparison chart]
| Metric         | Q3      | Q4     | Change |
|----------------|---------|--------|--------|
| Trial → Paid   | 8%      | 15%    | +87%   |
| Time to Value  | 14 days | 5 days | -64%   |
| Expansion Rate | 2%      | 8%     | +300%  |

## Key Insight
Self-serve + high-touch creates compound growth.
Customers who self-serve AND get a success call
have 3x higher expansion rate.

## Going Forward
Double down on hybrid model.
Target: $1.8M MRR by Q2.
```

---

## Framework 3: The Comparison Story

Use when: choosing between two or more options.

Structure: The Question → The Comparison → The Analysis → The Recommendation → Risk Mitigation

```markdown
## The Question
Should we expand into EMEA or APAC first?

## The Comparison
[Side-by-side market analysis]

### EMEA
- Market size: $4.2B
- Growth rate: 8%
- Competition: High
- Regulatory: Complex (GDPR)

### APAC
- Market size: $3.8B
- Growth rate: 15%
- Competition: Moderate
- Regulatory: Varied

## The Analysis
[Weighted scoring matrix]
| Factor      | Weight | EMEA | APAC |
|-------------|--------|------|------|
| Market Size | 25%    | 5    | 4    |
| Growth      | 30%    | 3    | 5    |
| Competition | 20%    | 2    | 4    |
| Ease        | 25%    | 2    | 3    |
| **Total**   |        | 2.9  | 4.1  |

## The Recommendation
APAC first. Higher growth, less competition.
Start with Singapore hub (English, business-friendly).
Enter EMEA in Year 2 with localization ready.

## Risk Mitigation
- Timezone coverage: Hire 24/7 support
- Cultural fit: Local partnerships
- Payment: Multi-currency from day 1
```
