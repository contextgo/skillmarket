---
name: write-utf8
description: Windows PowerShell UTF-8 file write tool to fix Chinese encoding issues
version: 1.0.0
tags: ["utf8", "encoding", "powershell", "chinese", "file"]
---

# UTF-8 File Writer

Fix Chinese encoding issues when writing files in Windows PowerShell.

## Problem

PowerShell defaults to UTF-16, causing garbled text when writing Chinese content.

## Solution

Use this skill to write UTF-8 encoded files without BOM.

## Usage

```powershell
# Write UTF-8 text file
$content = "中文内容"
[System.IO.File]::WriteAllText("output.txt", $content, [System.Text.Encoding]::UTF8)

# Write UTF-8 JSON
$data = @{name = "中文"; value = 123} | ConvertTo-Json
[System.IO.File]::WriteAllText("config.json", $data, [System.Text.Encoding]::UTF8)
```

## Requirements

- PowerShell 5.1 or 7.x
- Windows 10/11

## Author

林溪
