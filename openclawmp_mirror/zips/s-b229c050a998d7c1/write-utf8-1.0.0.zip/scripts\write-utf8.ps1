# UTF-8 File Writer for PowerShell
# 解决 Windows PowerShell 写入中文文件乱码问题
# Author: 林溪
# Version: 1.0.0

<#
.SYNOPSIS
    以 UTF-8 编码写入文件，解决中文乱码问题

.DESCRIPTION
    使用 .NET StreamWriter 确保文件以 UTF-8 编码写入，避免 PowerShell 默认编码问题

.PARAMETER Path
    目标文件路径

.PARAMETER Content
    要写入的内容

.PARAMETER Append
    是否以追加模式写入（默认覆盖）

.PARAMETER NoBOM
    是否不包含 BOM（默认包含 BOM）

.EXAMPLE
    Write-UTF8File -Path "output.txt" -Content "中文内容"

.EXAMPLE
    Write-UTF8File -Path "output.txt" -Content "追加内容" -Append
#>
function Write-UTF8File {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        
        [Parameter(Mandatory = $true)]
        [string]$Content,
        
        [Parameter(Mandatory = $false)]
        [switch]$Append,
        
        [Parameter(Mandatory = $false)]
        [switch]$NoBOM
    )
    
    # 确保目录存在
    $directory = Split-Path -Parent $Path
    if ($directory -and -not (Test-Path $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
    
    # 创建 UTF-8 编码（可选 BOM）
    $encoding = if ($NoBOM) {
        New-Object System.Text.UTF8Encoding($false)
    } else {
        [System.Text.Encoding]::UTF8
    }
    
    # 使用 StreamWriter 写入文件
    $writer = $null
    try {
        $writer = [System.IO.StreamWriter]::new($Path, $Append, $encoding)
        $writer.Write($Content)
    }
    finally {
        if ($writer) {
            $writer.Close()
            $writer.Dispose()
        }
    }
    
    Write-Verbose "文件已写入: $Path"
}

<#
.SYNOPSIS
    以 UTF-8 编码写入 JSON 文件

.DESCRIPTION
    将对象转换为 JSON 并以 UTF-8 编码写入文件

.PARAMETER Path
    目标文件路径

.PARAMETER Data
    要写入的数据对象

.PARAMETER Depth
    JSON 嵌套深度（默认 10）

.PARAMETER Compress
    是否压缩输出（默认 false）

.EXAMPLE
    Write-UTF8JSON -Path "config.json" -Data @{name = "中文"; value = 123}
#>
function Write-UTF8JSON {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        
        [Parameter(Mandatory = $true)]
        [object]$Data,
        
        [Parameter(Mandatory = $false)]
        [int]$Depth = 10,
        
        [Parameter(Mandatory = $false)]
        [switch]$Compress
    )
    
    # 转换为 JSON
    $json = $Data | ConvertTo-Json -Depth $Depth -Compress:$Compress
    
    # 使用 UTF-8 写入（无 BOM，JSON 标准推荐）
    Write-UTF8File -Path $Path -Content $json -NoBOM
    
    Write-Verbose "JSON 文件已写入: $Path"
}

<#
.SYNOPSIS
    批量转换文件编码为 UTF-8

.DESCRIPTION
    将指定目录下的文件转换为 UTF-8 编码

.PARAMETER Path
    源目录路径

.PARAMETER OutputPath
    输出目录路径（默认覆盖原文件）

.PARAMETER Filter
    文件过滤模式（默认 *.txt）

.PARAMETER Recurse
    是否递归处理子目录

.EXAMPLE
    Convert-ToUTF8 -Path "C:\source" -Filter "*.txt"
#>
function Convert-ToUTF8 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        
        [Parameter(Mandatory = $false)]
        [string]$OutputPath,
        
        [Parameter(Mandatory = $false)]
        [string]$Filter = "*.txt",
        
        [Parameter(Mandatory = $false)]
        [switch]$Recurse
    )
    
    # 获取所有匹配文件
    $files = Get-ChildItem -Path $Path -Filter $Filter -Recurse:$Recurse -File
    
    foreach ($file in $files) {
        # 确定输出路径
        if ($OutputPath) {
            $relativePath = $file.FullName.Substring($Path.Length).TrimStart('\', '/')
            $targetPath = Join-Path $OutputPath $relativePath
            $targetDir = Split-Path -Parent $targetPath
            if (-not (Test-Path $targetDir)) {
                New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
            }
        } else {
            $targetPath = $file.FullName
        }
        
        # 读取并重新写入
        $content = Get-Content -Path $file.FullName -Raw -Encoding Default
        Write-UTF8File -Path $targetPath -Content $content
        
        Write-Host "已转换: $($file.FullName) -> $targetPath"
    }
}

<#
.SYNOPSIS
    检测文件编码

.DESCRIPTION
    检测文件的编码格式

.PARAMETER Path
    文件路径

.EXAMPLE
    Get-FileEncoding -Path "test.txt"
#>
function Get-FileEncoding {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    
    if (-not (Test-Path $Path)) {
        throw "文件不存在: $Path"
    }
    
    $bytes = Get-Content -Path $Path -Encoding Byte -TotalCount 4
    
    # 检测 BOM
    if ($bytes.Count -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return "UTF-8 with BOM"
    }
    elseif ($bytes.Count -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return "UTF-16 LE"
    }
    elseif ($bytes.Count -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return "UTF-16 BE"
    }
    elseif ($bytes.Count -ge 4 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE -and $bytes[2] -eq 0x00 -and $bytes[3] -eq 0x00) {
        return "UTF-32 LE"
    }
    else {
        return "ANSI/GBK 或其他"
    }
}

# 导出函数
Export-ModuleMember -Function Write-UTF8File, Write-UTF8JSON, Convert-ToUTF8, Get-FileEncoding

Write-Host "UTF-8 文件写入工具已加载" -ForegroundColor Green
Write-Host "可用函数: Write-UTF8File, Write-UTF8JSON, Convert-ToUTF8, Get-FileEncoding" -ForegroundColor Cyan
