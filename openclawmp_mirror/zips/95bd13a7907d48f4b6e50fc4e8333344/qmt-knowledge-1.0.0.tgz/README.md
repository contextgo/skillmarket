# QMT (迅投) Python API 知识库

> 龙虾量化团队出品 | 基于 QMT 官方 Python API 文档 v3.3.6（171页）完整提取整理

## 这是什么

这是一份结构化的 QMT (迅投) 量化交易系统 Python API 知识库，将官方 PDF 文档中的 171 页内容整理为技能包格式，方便 AI Agent 在编写、调试 QMT 策略时快速查询 API 说明和参数。

## 覆盖内容

### 五个知识模块

| 模块 | 文档 | 内容概览 |
|------|------|---------|
| **运行机制与快速上手** | `references/01-quickstart.md` | Bar/Init/Handlebar 核心概念、三种驱动模式（Handlebar逐K线/Subscribe分笔/RunTime定时）、策略编辑器操作、参数设置、回测运行与结果分析 |
| **ContextInfo 数据API** | `references/02-contextinfo-api.md` | 50+数据方法：get_market_data取K线行情、get_local_data本地数据、get_financial_data财务数据、get_commission手续费率、get_longhubang龙虎榜、get_risk_free_rate无风险利率、get_sector板块成份股、get_option_list/iv/bsm_iv期权数据、get_north_finance_change北向资金、draw_*绘图接口等 |
| **交易下单函数** | `references/03-trading-functions.md` | 20+下单函数完整说明：passorder综合下单（含opType操作类型全表6+30种）、algo_passorder算法交易、smart_algo_passorder智能算法、order_lots/order_value/order_percent/order_target_value/order_target_percent/order_shares六种下单方式、stoploss_limitprice/stoploss_marketprice止损止盈、get_trade_detail_data交易明细、cancel/cancel_task撤单、do_order实时触发等 |
| **对象类型字段** | `references/04-object-types.md` | 9类对象完整字段说明：StockAccount资金账号、StockAsset资产、StockPosition持仓、order委托对象、trade成交对象、Compact融资融券持仓、CreditAccount信用账户、OptionCombination期权组合、Callback回调对象 |
| **枚举常量** | `references/05-enums.md` | EOrderType报单类型（EStockBuy=0买入/EStockSell=1卖出等）、EPositionDirection持仓方向、EOrderStatus报单状态、BROKER_PRICE_PROP_*价格属性（最新价/买一/卖一/指定价等）、EXTCompactStatus合约状态、OPT_*期权操作码 |

### 运行模式

- **Handlebar** — 逐K线驱动，每根K线触发一次 `handlebar(ContextInfo)`，用于回测/模拟/实盘
- **Subscribe** — 分笔订阅驱动，每笔行情触发 `on_tick(DataList)`，用于高频/实时
- **RunTime** — 定时任务，固定间隔触发 `run_time(ContextInfo)`，用于定期调仓/监控

### 运行环境

| 环境 | 代码标识 | 说明 |
|------|---------|------|
| 回测 | `BACKTEST` | 历史数据回测，策略运行在回测引擎 |
| 模拟 | `SIMULATION` | 模拟交易，实盘行情+虚拟资金 |
| 实盘 | `LIVE` | 真实资金交易，每笔委托真实发送柜台 |

## 适用场景

当 AI Agent 需要做以下事情时加载此技能：
- 编写 QMT 量化策略（回测/模拟/实盘）
- 查询 QMT Python API 函数说明和参数详情
- 调试 QMT 策略代码
- 理解 QMT 交易流程和运行机制
- 查看 passorder 的 opType 可选值
- 了解 ContextInfo 有哪些数据获取方法
- 查询持仓/订单/资金等对象字段含义
- 查看枚举常量（报单状态、价格属性等）

##SKILL 使用方式

1. 读取本 SKILL.md 了解整体架构和文档结构
2. 按需跳转到 `references/` 对应模块获取详细 API 说明
3. 结合参数说明和示例代码编写策略

## 数据来源

- 源文档：迅投QMT极速策略交易系统_模型资料_Python_API_说明文档_Python3 v3.3.6.pdf（171页，6.9MB）
- 文档版本：3.3.6，Python 3.6.8，更新日期 2021.12.20
- 文件位置：`E:\BaiduSyncdisk\IDE\1\QMT策略1\` 及子目录

## 本地策略框架参考

完整策略框架模板：
- `E:\BaiduSyncdisk\IDE\1\QMT 策略 5\QMT量化策略框架_xtquant版.py`
- 特性：环境自动识别（回测/模拟/实盘）、完整风控系统、市场状态自适应仓位、止损止盈、黑天鹅清仓

## 许可

MIT License
