# QMT (迅投) Python API 知识库

> QMT 极速策略交易系统 - Python API 完整参考手册（v1.0）
> 源文档: 迅投QMT极速策略交易系统_模型资料_Python_API_说明文档_Python3 v3.3.6

---

## 何时使用此技能
- 编写 QMT 量化策略（回测/模拟/实盘）
- 查询 QMT Python API 函数说明和参数
- 调试 QMT 策略代码
- 了解 QMT 运行机制和交易流程
- 触发词：QMT、迅投、xtquant、策略编写、量化交易下单

## 文档结构速查

| 文件 | 内容 |
|------|------|
| [快速上手与运行机制](references/01-quickstart.md) | Bar/Init/Handlebar概念、三种驱动模式、策略编辑器操作、参数设置、回测运行与结果分析 |
| [ContextInfo 数据API](references/02-contextinfo-api.md) | 50+数据方法：行情/财务/宏观/期权/龙虎榜/北向资金/港股等 |
| [交易下单函数](references/03-trading-functions.md) | passorder/algo_passorder/order_shares等20+下单函数及详细参数 |
| [对象类型字段](references/04-object-types.md) | 订单/持仓/资产/资金/回调等对象字段完整说明 |
| [枚举常量](references/05-enums.md) | 报单类型/状态/价格属性/操作类型等枚举值 |

## 核心运行模式

### 三种驱动机制
1. **Handlebar** - 逐K线驱动，每根K线触发一次 `handlebar(ContextInfo)`，用于 回测/模拟/实盘
2. **Subscribe** - 分笔订阅驱动，每笔行情触发 `on_tick(DataList)`，用于 高频/实时
3. **RunTime** - 定时任务，固定间隔触发 `run_time(ContextInfo)`，用于 定期调仓/监控

### 三种运行环境
| 环境 | 代码标识 | 说明 |
|------|---------|------|
| 回测 | `BACKTEST` | 使用历史数据回测，策略运行在回测引擎 |
| 模拟 | `SIMULATION` | 模拟交易，实盘行情+虚拟资金 |
| 实盘 | `LIVE` | 真实资金交易，每笔委托真实发送到柜台 |

## 策略文件模板

```python
# -*- coding: gbk -*-
from xtquant import xtdata, xttrader
from xtquant.xttype import StockAccount

def init(ContextInfo):
    """初始化（只在策略启动时执行一次）"""
    pass

def handlebar(ContextInfo):
    """K线驱动主函数（每根K线执行一次）"""
    pass

def stop(ContextInfo):
    """停止处理（可选）"""
    pass
```

## 使用方式

当用户需要编写QMT策略、查询API、理解交易机制时：
1. 首先阅读本 SKILL.md 了解整体架构
2. 根据需要跳转到对应的 references/ 章节获取详细API说明
3. 结合示例代码和参数说明编写策略

---

## 环境配置

### 安装 QMT
1. 安装 QMT 客户端（策略版/Mini版）
2. 登录资金账号
3. 安装 Python 依赖：`pip install xtquant`

### 本地策略目录
```
E:\BaiduSyncdisk\IDE\1\
├── QMT策略1\
│   └── QMT量化策略框架_xtquant版.py
├── QMT 策略 5\
│   ├── QMT量化策略框架_xtquant版.py
│   ├── AI 自动交易\
│   └── 解套QMT策略MINI\
├── QMT 策略 MINI\
│   └── AI 自动交易\
```

### 参考策略框架
完整策略框架模板见：
- `E:\BaiduSyncdisk\IDE\1\QMT 策略 5\QMT量化策略框架_xtquant版.py`
- 特性：环境自动识别（回测/模拟/实盘）、完整风控系统、市场状态自适应仓位、止损止盈、黑天鹅清仓
