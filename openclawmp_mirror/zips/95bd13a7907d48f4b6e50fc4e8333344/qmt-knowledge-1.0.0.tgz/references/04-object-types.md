# 对象类型字段说明

limit ： string ，画线控制，可取值：
'noaxis' ： 不影响坐标画线
'nodraw' ：不画线
返回： 无
示例： 
 
（ 2 ）在图形上显示文字 ContextInfo.draw_text() 
用法： ContextInfo.draw_text(condition, position, text)
释义： 在图形上显示数字
参数： 
condition ：条件
Position ：位置
text ：文字
返回： 无
示例： 
 
（ 3 ）在图形上显示数字 ContextInfo.draw_number() 
用法： ContextInfo.draw_number(cond, height, number, precision)
释义： 在图形上显示数字
参数： 
cond ： bool ，条件
height ： number ，显示文字的高度位置
text ： string ，显示的数字
precision ：为小数显示位数（取值范围 0 - 7 ）
返回： 无
示例： 
 
def handlebar(ContextInfo):
    realtimetag = ContextInfo.get_bar_timetag(ContextInfo.barpos)
    value = ContextInfo.get_close_price('', '', realtimetag) 
    ContextInfo.paint('close', value, -1, 0, 'white','noaxis')
1
2
3
4
def handlebar(ContextInfo):
    ContextInfo.draw_text(1, 10, ' 文字 ')
1
2
def handlebar(ContextInfo):
    close = ContextInfo.get_market_data(['close'])   
    ContextInfo.draw_number(1 > 0, close, 66, 1)
1
2
3

（ 4 ）在数字 1 和数字 2 之间绘垂直线 ContextInfo.draw_vertline() 
用法： ContextInfo.draw_vertline(cond, number1, number2, color = '', limit = '')
释义： 在数字 1 和数字 2 之间绘垂直线
参数： 
cond ： bool ，条件
number1 ： number ，数字 1
number2 ： number ，数字 2
color ： string ，颜色（不填默认为白色）目前支持以下几种颜色： 
blue ：蓝
brown ：棕
cyan ：蓝绿
green ：绿
magenta ：品红
red ：红
white ：白
yellow ：黄 
limit ： string ，画线控制，可取值：
'noaxis' ： 不影响坐标画线
'nodraw' ：不画线
返回： 无
示例： 
 
（ 5 ）在图形上绘制小图标 ContextInfo.draw_icon() 
用法： ContextInfo.draw_icon(cond, height, type)
释义： 在图形上绘制小图标
参数： 
cond ： bool ，条件
height ： number ，图标的位置
text ： number ，图标的类型，可取值：
1 ：椭圆
0 ：矩形
返回： 无
def handlebar(ContextInfo):
    close = ContextInfo.get_market_data(['close'])
    open = ContextInfo.get_market_data(['open'])
    ContextInfo.draw_vertline(1 > 0, close, open, 'cyan')
1
2
3
4

字段名 类型 释义与用例
fieldList List （必
须）
财报字段列表： ['ASHAREBALANCESHEET.fix_assets', ' 利润
表 . 净利润 ']
stockList List （必
须） 股票列表： ['600000.SH', '000001.SZ']
startDate Str （必
须） 开始时间： '20171209'
endDate Str （必
须） 结束时间： '20171212'
report_type Str （可
选）
报表时间类型，可缺省，默认是按照数据的公告期为区分取数据，设置
为 'report_time' 为按照报告期取数据， ' announce_time' 为
按照公告日期取数据
示例： 
 
4. 财务数据接口使用方法 
财务数据接口通过读取下载本地的数据取数，使用前需要补充本地数据。除公告日期和报表截止日期为
时间戳毫秒格式其他单位为元或 % ，数据主要包括资产负债表 (ASHAREBALANCESHEET) 、利润表
(ASHAREINCOME ）、现金流量表（ ASHARECASHFLOW ）、股本表（ CAPITALSTRUCTURE ）的主要字
段数据以及经过计算的主要财务指标数据（ PERSHAREINDEX ）。建议使用本文档对照表中的英文表名
和迅投英文字段。
 
4.1. Python 接口 
 
4.1.1. 用法 1 
ContextInfo.get_financial_data(fieldList, stockList, startDate, enDate, report_type = 
'announce_time')
返回： 
函数根据 stockList 代码列表 ,startDate,endDate 时间范围，返回不同的的数据类型。如下：
（ 1 ）代码列表 1 时间范围为 1 ，返回： pandas.Series index = 字段
（ 2 ）代码列表 1 时间范围为 n ，返回： pandas.DataFrame index = 时间 , columns = 字段
（ 3 ）代码列表 n 时间范围为 1 ，返回： pandas.DataFrame index = 代码 , columns = 字段
def handlebar(ContextInfo):
    close = ContextInfo.get_market_data(['close'])
    ContextInfo.draw_icon(1 > 0, close, 0)
1
2
3

字段名 类型 释义与用例
tabname Str （必
须） 表名： 'ASHAREBALANCESHEET'
colname Str （必
须） 字段名： 'fix_assets'
market Str （必
须） 市场： 'SH'
code Str （必
须） 代码： '600000'
report_type Str （可
选）
报表时间类型，可缺省，默认是按照数据的公告期为区分取数据，设置为
'report_time' 为按照报告期取数据， ' announce_time ' 为按照
公告日期取数据
barpos number 当前 bar 的索引
（ 4 ）代码列表 n 时间范围为 n ，返回： pandas.Panel items = 代码 , major_axis = 时间 , minor_axis = 
字段
示例： 
* 注：
选择按照公告期取数和按照报告期取数的区别：
若某公司当年 4 月 26 日发布上年度年报，如果选择按照公告期取数，则当年 4 月 26 日之后至下个财报
发布日期之间的数据都是上年度年报的财务数据。
若选择按照报告期取数，则上年度第 4 季度（上年度 10 月 1 日 - 12 月 31 日）的数据就是上年度报告
期的数据。
 
4.1.2. 用法 2 
ContextInfo.get_financial_data(tabname, colname, market, code, report_type = 'report_time', 
barpos) （与用法 1 可同时使用）
返回： 
number
示例： 
def handlebar(ContextInfo):
    # 取总股本和净利润
     fieldList = ['CAPITALSTRUCTURE.total_capital', ' 利润表 . 净利润 ']   
     stockList = ['600000.SH','000001.SZ']
     startDate = '20171209'
     endDate = '20171212'
     ContextInfo.get_financial_data(fieldList, stockList, startDate, endDate, 
report_type = 'report_time')
1
2
3
4
5
6
7

4.2. vba 接口 
 
4.2.1. 用法 1 
根据公告期获取报表原始数据：
getfindata(' 表格名称 ', ' 字段名称 ')
示例： 
固定资产：
 
4.2.2. 用法 2 
获取每年固定某个季度的数据，该年所有数据都是该季度的数据：
getfindata(' 表格名称 ', ' 字段名称 ', session)
示例： 
固定资产：
 
4.3. 财务数据字段对照表 
 
4.3.1. 资产负债表 (ASHAREBALANCESHEET) 
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    ContextInfo.get_financial_data('ASHAREBALANCESHEET', 'fix_assets', 'SH', 
'600000', index);
1
2
3
getfindata('ASHAREBALANCESHEET', 'fix_assets')1
// 获取每年三季报
getfindata('ASHAREBALANCESHEET', 'fix_assets', 3)
1
2

中文字段 迅投字段
应收利息 int_rcv
可供出售金融资产 fin_assets_avail_for_sale
持有至到期投资 held_to_mty_invest
长期股权投资 long_term_eqy_invest
固定资产 fix_assets
无形资产 intang_assets
递延所得税资产 deferred_tax_assets
资产总计 tot_assets
交易性金融负债 tradable_fin_liab
应付职工薪酬 empl_ben_payable
应交税费 taxes_surcharges_payable
应付利息 int_payable
应付债券 bonds_payable
递延所得税负债 deferred_tax_liab
负债合计 tot_liab
实收资本 ( 或股本 ) cap_stk
资本公积金 cap_rsrv
盈余公积金 surplus_rsrv
未分配利润 undistributed_profit
归属于母公司股东权益合计 tot_shrhldr_eqy_excl_min_int
少数股东权益 minority_int
负债和股东权益总计 tot_liab_shrhldr_eqy
所有者权益合计 total_equity
货币资金 cash_equivalents
应收票据 bill_receivable
应收账款 account_receivable
预付账款 advance_payment
其他应收款 other_receivable
其他流动资产 other_current_assets

中文字段 迅投字段
流动资产合计 total_current_assets
存货 inventories
在建工程 constru_in_process
工程物资 construction_materials
长期待摊费用 long_deferred_expense
非流动资产合计 total_non_current_assets
短期借款 shortterm_loan
应付股利 dividend_payable
其他应付款 other_payable
一年内到期的非流动负债 non_current_liability_in_one_year
其他流动负债 other_current_liability
长期应付款 longterm_account_payable
应付账款 accounts_payable
预收账款 advance_peceipts
流动负债合计 total_current_liability
应付票据 notes_payable
长期借款 long_term_loans
专项应付款 grants_received
其他非流动负债 other_non_current_liabilities
非流动负债合计 non_current_liabilities
专项储备 specific_reserves
商誉 goodwill
报告截止日 m_timetag
公告日 m_anntime
 
4.3.2. 利润表 (ASHAREINCOME)

中文字段 迅投字段
投资收益 plus_net_invest_inc
联营企业和合营企业的投资收益 incl_inc_invest_assoc_jv_entp
营业税金及附加 less_taxes_surcharges_ops
营业总收入 revenue
营业总成本 total_operating_cost
营业收入 revenue_inc
营业成本 total_expense
资产减值损失 less_impair_loss_assets
营业利润 oper_profit
营业外收入 plus_non_oper_rev
营业外支出 less_non_oper_exp
利润总额 tot_profit
所得税 inc_tax
净利润 net_profit_incl_min_int_inc
归属净利润 net_profit_excl_min_int_inc
管理费用 less_gerl_admin_exp
销售费用 sale_expense
财务费用 financial_expense
综合收益总额 total_income
归属于少数股东的综合收益总额 total_income_minority
公允价值变动收益 change_income_fair_value
已赚保费 earned_premium
报告截止日 m_timetag
公告日 m_anntime
 
4.3.3. 现金流量表 (ASHARECASHFLOW)

中文字段 迅投字段
收到其他与经营活动有关的现金 other_cash_recp_ral_oper_act
经营活动现金流入小计 stot_cash_inflows_oper_act
支付给职工以及为职工支付的现金 cash_pay_beh_empl
支付的各项税费 pay_all_typ_tax
支付其他与经营活动有关的现金 other_cash_pay_ral_oper_act
经营活动现金流出小计 stot_cash_outflows_oper_act
经营活动产生的现金流量净额 net_cash_flows_oper_act
取得投资收益所收到的现金 cash_recp_return_invest
处置固定资产、无形资产和其他长期投资收到的
现金 net_cash_recp_disp_fiolta
投资活动现金流入小计 stot_cash_inflows_inv_act
投资支付的现金 cash_paid_invest
购建固定资产、无形资产和其他长期投资支付的
现金 cash_pay_acq_const_fiolta
支付其他与投资的现金 other_cash_pay_ral_inv_act
投资活动产生的现金流出小计 stot_cash_outflows_inv_act
投资活动产生的现金流量净额 net_cash_flows_inv_act
吸收投资收到的现金 cash_recp_cap_contrib
取得借款收到的现金 cash_recp_borrow
收到其他与筹资活动有关的现金 other_cash_recp_ral_fnc_act
筹资活动现金流入小计 stot_cash_inflows_fnc_act
偿还债务支付现金 cash_prepay_amt_borr
分配股利、利润或偿付利息支付的现金 cash_pay_dist_dpcp_int_exp
支付其他与筹资的现金 other_cash_pay_ral_fnc_act
筹资活动现金流出小计 stot_cash_outflows_fnc_act
筹资活动产生的现金流量净额 net_cash_flows_fnc_act
汇率变动对现金的影响 eff_fx_flu_cash
现金及现金等价物净增加额 net_incr_cash_cash_equ
销售商品、提供劳务收到的现金 goods_sale_and_service_render_cash
收到的税费与返还 tax_levy_refund

中文字段 迅投字段
购买商品、接受劳务支付的现金 goods_and_services_cash_paid
处置子公司及其他收到的现金 net_cash_deal_subcompany
其中子公司吸收现金 cash_from_mino_s_invest_sub
处置固定资产、无形资产和其他长期资产支付的
现金净额 fix_intan_other_asset_dispo_cash_payment
报告截止日 m_timetag
公告日 m_anntime
中文字段 迅投字段
总股本 total_capital
已上市流通 A 股 circulating_capital
限售流通股份 restrict_circulating_capital
报告截止日 m_timetag
公告日 m_anntime
 
4.3.4. 股本表 (CAPITALSTRUCTURE) 
 
4.3.5. 主要指标 (PERSHAREINDEX)

中文字段 迅投字段
每股经营活动现金流量 s_fa_ocfps
每股净资产 s_fa_bps
基本每股收益 s_fa_eps_basic
稀释每股收益 s_fa_eps_diluted
每股未分配利润 s_fa_undistributedps
每股资本公积金 s_fa_surpluscapitalps
扣非每股收益 adjusted_earnings_per_share
主营收入 inc_revenue
毛利润 inc_gross_profit
利润总额 inc_profit_before_tax
净利润 du_profit
归属于母公司所有者的净利润 inc_net_profit
扣非净利润 adjusted_net_profit
净资产收益率 du_return_on_equity
销售毛利率 sales_gross_profit
主营收入同比增长 inc_revenue_rate
净利润同比增长 du_profit_rate
归属于母公司所有者的净利润同比增长 inc_net_profit_rate
扣非净利润同比增长 adjusted_net_profit_rate
营业总收入滚动环比增长 inc_total_revenue_annual
归属净利润滚动环比增长 inc_net_profit_to_shareholders_annual
扣非净利润滚动环比增长 adjusted_profit_to_profit_annual
加权净资产收益率 equity_roe
摊薄净资产收益率 net_roe
摊薄总资产收益率 total_roe
毛利率 gross_profit
净利率 net_profit
实际税率 actual_tax_rate
预收款营业收入 pre_pay_operate_income

中文字段 迅投字段
销售现金流营业收入 sales_cash_flow
资产负债比率 gear_ratio
存货周转率 inventory_turnover
市场 代码
上证所 SH
深交所 SZ
大商所 DF
郑商所 ZF
上期所 SF
中金所 IF
沪港通 HGT
深港通 SGT
外部自定义市场 ED
 
5. 附录 
 
5.1. 附录 1 市场简称代码 
 
5.2. 附录 2 is_typed_stock 函数证券分类表 
注： * 代表任意阿拉伯数字
5.2.1. 基础类型

类型描述 市场代码 类别标
号
沪市 ******,SH 1
深市 ******,SZ 2
中金 ******\|*****\|****\|***,IF 3
上期 ******\|*****\|****\|***,SF 4
大商 ******\|*****\|****\|***,DF 5
郑商 ******\|*****\|****\|***,ZF 6
开放基金 ******,OF 7
股票期权 ******,SHO 8
新三板 ******,NEEQ 9
     
沪市 A 股 60****,SH 101
沪市 B 股 90****,SH 102
沪市封基 50****,SH 103
沪市指数 000***,SH 104
沪市 ETF 510***\|511***\|512***\|513***\|518***,SH 105
沪市权证 58****,SH 106
沪市申购 73****\|78****,SH 107
沪市可交换公司债券 132***,SH 108
沪市可交换公司债券质押券出入
库 133***,SH 109
沪市可交换公司债券换股 192***,SH 110
沪市并购重组私募债券挂牌转
让 1355**\|1356**\|1357**\|1358**\|1359**,SH 111
沪市证券公司短期债券挂牌转
让 1350**\|1351**\|1352**\|1353**\|1354**,SH 112
沪市信贷资产支持证券交易
asset-backed securities 128***,SH 113
沪市公司债券质押券入库 102***\|134***,SH 114
沪市公司债 122***\|123***\|124***\|127***\|136***,SH 115
沪市公开发行优先股交易 330***,SH 116
沪市非公开发行优先股转让 360***,SH 117
沪市公开发行优先股申购 770***,SH 118
沪市公开发行优先股配股 / 配售 771***,SH 119
沪市公开发行优先股申购款分
配 772***,SH 120
沪市公开发行优先股申购配号 773***,SH 121
沪市国债回购（席位托管方
式） 201***,SH 122
沪市企业债回购 202***,SH 123
沪市国债买断式回购 203***,SH 124
沪市新质押式国债回购 204***,SH 125
沪市附息国债 010***\|019***,SH 127
沪市金融债 018***,SH 128
沪市贴现国债 020***,SH 129
沪市中央政府债（国债） 010***\|019***\|020***,SH 130
沪市分离债 126***,SH 131
沪市资产证券化 121***,SH 132
沪市信贷资产支持 128***,SH 133
沪市企业债（席位托管方式） 120***\|129***,SH 134
沪市可转债 100***\|110***\|112***\|113***\|128***,SH 135
沪市地方债 130***\|140***,SH 136
沪市政府债（国债 + 地方债） 010***\|019***\|020***\|130***,SH 137
上海可交换私募债 1380**,SH 138
沪市标准券 888880\|SHRQ88,SH 139
沪市封闭式基金 500***\|5058**,SH 140
沪市政策性金融债 018***\|028***\|038***,SH 141
沪市上海质押代码 09****\|102***\|103***\|104***\|105***\|106***\|107***\|108***\|133***,SH 142
2000 年前发行国债 009***,SH 143

类型描述 市场代码 类别标
号
记账式贴现国债质押式回购标准
券入库 107***,SH 144
公司债质押式回购标准券入库 1040**\|1041**\|1042**\|1043**\|1044**,SH 145
国债分销 7510**\|7511**,SH 146
地方政府债质押式回购标准券入
库 106***\|141***,SH 147
地方政府债分销 75190*\|75191*\|75192*\|75193*\|75194*\|75195*\|75196*,SH 148
分离债质押式回购标准券入库 1050**\|1051**\|1052**\|1053**\|1054**\|1055**\|1056**\|1057*\|1058**,SH 149
债券质押式报价回购 205***,SH 150
中小企业私募债券在固定收益平
台转让 125***,SH 151
跨境 ETF 513030\|513500\|513100\|510900\|513600\|513660,SH 152
跨境 LOF ,SH 153
上海创新型封闭式基金 5058**,SH 154
上海的固定收益类 511***,SH 155
上海黄金 518**0,SH 156
上海实时申赎货币基金 5198**\|5195**\|5199**,SH 157
上海交易型货币基金 5116**\|5117**\|5118**\|5119**,SH 158
上海股票申购代码 730***\|732***\|780***,SH 159
上海债券申购代码 733***\|783***,SH 160
上海基金申购代码 735***,SH 161
上海新股配号 741***\|791***\|736***,SH 162
上海配售首发配号 747***\|797***,SH 163
上海可转债资金申购配号 744***\|794***\|756***,SH 164
上海申购款 740***\|790***\|734***,SH 165
上海发债款 743***\|793***\|755***,SH 166
上海配股代码 700***\|760***\|742***,SH 167
上海配转债代码 704***\|764***\|753***,SH 168
上海 LOF 501***,SH 169
上海分级基金 502***,SH 170
沪新股额 SHXGED,SH 171
沪增发股 730***\|731***\|780***\|781***,SH 172
上海跨境 ETF 申赎代码 513031\|513501\|513101\|510901\|513601\|513661,SH 173
上海债券 ETF 511010\|511210\|511220,SH 174
上海企业债券挂牌转让 139***,SH 175
上海可交换私募债 1380**,SH 176
沪市 1 天回购 204001,SH 177
沪市 2 天回购 204002,SH 178
沪市 3 天回购 204003,SH 179
沪市 4 天回购 204004,SH 180
沪市 7 天回购 204007,SH 181
沪市 14 天回购 204014,SH 182
沪市 28 天回购 204028,SH 183
沪市 28 天以上回购 204091\|204182,SH 184
上海分级基金子基金 502**1\|502**2\|502**4\|502**5\|502**7\|502008\|502018\|502028\|502038\|502058\|502049\|502050,SH 185
     
深市 A 股 00****\|30****,SZ 10001
深市 B 股 20****,SZ 10002
深市封基 15****\|16****\|18****,SZ 10003
深市主板 000***\|001***,SZ 10004
深市小板 002***\|003***\|004***,SZ 10005
深市创业板 30****,SZ 10006
深市指数 39****,SZ 10007
深市 ETF 159***,SZ 10008
深市权证 03****,SZ 10009
深市国债回购 (131990 不是
的，需要业务支持 ) 131990,SZ 10010
深市附息国债 100***\|101***\|102***\|103***\|104***\|105***\|106***\|107***,SZ 10011

类型描述 市场代码 类别标
号
深市贴现国债 108***,SZ 10012
深市公司债 112***,SZ 10013
深市企业债 111***,SZ 10014
深市分离债 115***,SZ 10015
深市私募债 118***\|114***,SZ 10016
深市专项资金管理规划 119***,SZ 10017
深市地方政府债 109***,SZ 10018
深市可转债 12****,SZ 10019
深市标准券 131990\|SZRQ88,SZ 10020
深市封闭式基金 184***,SZ 10021
深市 LOF 16****,SZ 10022
深市分级基金 150***\|151***,SZ 10023
深市 中小企业可交换私募债 117***,SZ 10024
深市证券公司次级债 1189**,SZ 10025
深市其他中小企业私募债 1180**\|1181**\|1182**\|1183**\|1184**\|1185**\|1186**\|1187**\|1188**,SZ 10026
深市资产支持证券 1190**\|1191**\|1192**\|1193**\|1194**,SZ 10027
深市分级基金子基金 150***\|151***,SZ 10028
深市跨境 ETF 159920\|159941,SZ 10029
深市跨境 LOF 160125\|160416\|160717\|160719\|161116\|161210\|161714\|161815\|162411\|164701\|164815\|165510\|165513,SZ 10030
深市创新型封闭式基金 150***,SZ 10031
深市主板可转换公司债券 127***,SZ 10032
深市创业板可转换公司债券 123***,SZ 10033
深市中小板可转换公司债券 128***,SZ 10034
深市国债回购 (131900 不是
的，需要业务支持 ) 131***,SZ 10035
深市黄金 159934,SZ 10036
深市实时申赎货币基金 1590**,SZ 10037
深新股额 SZXGED,SZ 10038
深增发股 07****\|37***,SZ 10039
深圳配股 08****,SZ 10040
深圳债券 ETF 仅此一支 159926,SZ 10041
深市 1 天回购 131810,SZ 10042
深市 2 天回购 131811,SZ 10043
深市 3 天回购 131800,SZ 10044
深市 4 天回购 131809,SZ 10045
深市 7 天回购 131801,SZ 10046
深市 14 天回购 131802,SZ 10047
深市 28 天回购 131803,SZ 10048
深市 28 天以上回购 131805\|131806,SZ 10049
中金所指数期货 IF****\|IH****\|IC****\|IF**\|IH**\|IC**,IF 30001
中金所国债期货 TF****\|T****\|HTFF****\|TF**\|T**\|HTFF**,IF 30002
 
5.2.2. 扩展类型

类型描述 类型集合 类别标
号
沪深 A 股 沪市 A 股 \| 深市 A 股 100001
沪深 B 股 沪市 B 股 \| 深市 B 股 100002
沪深狭义股
票 沪深 A 股 \| 沪深 B 股 100003
沪深封基 沪市封基 \| 深市封基 100004
指数 沪市指数 \| 深市指数 100005
商品期货 上期 \| 大商 \| 郑商 100006
期货市场 中金 \| 商品期货 100007
股票 沪市 \| 深市 100008
深市中央政
府债（国
债）
深市附息国债 \| 深市贴现国债 100009
深市政府债 深市中央政府债（国债） \| 深市地方政府债 100010
深市所有债
券
深市附息国债 \| 深市贴现国债 \| 深市地方政府债 \| 深市可转债 \| 深市企业
债 \| 深市分离债 \| 深市私募债 \| 深市专项资金管理规划 100011
广义的股票 ! 指数 100012
ETF 沪市 ETF\| 深市 ETF 100013
封闭式基金 沪市封闭式基金 \| 深市封闭式基金 100014
权证 沪市权证 \| 深市权证 100015
债券 上海债券 \| 深市所有债券 100016
深市国债回
购
深市国债回购 (131900 不是的，需要业务支持 )&(! 深市国债回购 (131990
不是的，需要业务支持 )) 100017
标准券 沪市标准券 \| 深市标准券 100018
债券回购 沪市国债回购（席位托管方式） \| 深市国债回购 100020
质押式回购 沪市新质押式国债回购 \| 深市国债回购 100021
黄金 上海黄金 \| 深市黄金 100022
实时申赎货
币基金 上海实时申赎货币基金 \| 深市实时申赎货币基金 100023
货币基金 实时申赎货币基金 \| 上海交易型货币基金 100024
上海申购代
码 上海股票申购代码 \| 上海债券申购代码 \| 上海基金申购代码 100025

类型描述 类型集合 类别标
号
跨境 ETF 深市跨境 ETF\| 跨境 ETF 100026
跨境 LOF 跨境 LOF\| 深市跨境 LOF 100027
可交易的
沪深 A 股 \| 沪深封基 \|ETF\| 权证 \| 沪市申购 \| 深市创业板 \| 债券回购 \|
债券 ETF\| 上海的固定收益类 \| 黄金 \| 货币基金 \| 深市中央政府债（国
债） \| 沪市中央政府债（国债） \| 沪市地方债 \| 深市地方政府债 \| 上海申
购代码 \| 沪市上海质押代码 \| 跨境 ETF\| 跨境 LOF\| 上海配股代码 \| 上海
配转债代码 \| 深市可转债 \| 沪市可转债 \| 沪增发股 \| 深增发股
100028
主板 沪市 A 股 \| 深市主板 100029
回转交易 债券 \| 黄金 \| 上海的固定收益类 \| 权证 \| 跨境 ETF\| 跨境 LOF\| 上海交易
型货币基金 100030
上海配号 上海新股配号 \| 上海配售首发配号 \| 上海可转债资金申购配号 100031
沪深新股申
购额度 沪新股额 \| 深新股额 100032
沪深配股代
码 上海配股代码 \| 深圳配股 100033
固定收益：
跟踪债券指
数的交易型
开放式指数
基金、交易
型货币市场
基金
上海的固定收益类 100034
固定收益类
沪市附息国债 \| 深市附息国债 \| 沪市贴现国债 \| 深市贴现国债 \| 沪市政府
债（国债 + 地方债） \| 深市政府债 \| 深市企业债 \| 沪市企业债（席位托管方
式） \| 深市私募债 \| 沪市可转债 \| 深市可转债 \| 沪市分离债 \| 深市分离债
\| 债券回购 \| 标准券 \| 货币基金 \| 上海的固定收益类
100035
分级基金 上海分级基金 \| 深市分级基金 100036
LOF 上海 LOF\| 深市 LOF 100037
债券 ETF 上海债券 ETF\| 深圳债券 ETF 100038
上海债券
沪市政府债（国债 + 地方债） \| 沪市可转债 \| 沪市公司债 \| 沪市企业债（席
位托管方式） \| 沪市资产证券化 \| 沪市分离债 \| 沪市金融债 \| 沪市信贷资
产支持 \| 沪市可交换公司债券 \| 沪市并购重组私募债券挂牌转让 \| 沪市证
券公司短期债券挂牌转让 \| 上海可交换私募债 \| 上海企业债券挂牌转让 \|
上海可交换私募债
100039
1 天逆回购 沪市 1 天回购 \| 深市 1 天回购 100040
2 天逆回购 沪市 2 天回购 \| 深市 2 天回购 100041

类型描述 类型集合 类别标
号
3 天逆回购 沪市 3 天回购 \| 深市 3 天回购 100042
4 天逆回购 沪市 4 天回购 \| 深市 4 天回购 100043
7 天逆回购 沪市 7 天回购 \| 深市 7 天回购 100044
14 天逆回购 沪市 14 天回购 \| 深市 14 天回购 100045
28 天逆回购 沪市 28 天回购 \| 深市 28 天回购 100046
28 天以上逆
回购 沪市 28 天以上回购 \| 深市 28 天以上回购 100047
 
5.3. 附录 3 交易函数内含属性说明 
 
5.3.1. account 资金账号对象 
m_dMaxMarginRate: 保证金比率，股票的保证金率等于 1 ，股票不需要
m_dFrozenMargin: 冻结保证金，外源性，股票的保证金就是冻结资金，股票不需要
m_dFrozenCash: 冻结金额，内外源冻结保证金和手续费四个的和
m_dFrozenCommission: 冻结手续费，外源性冻结资金源
m_dRisk: 风险度，风险度，冻结资金 / 可用资金，股票不需要
m_dNav: 单位净值
m_dPreBalance: 期初权益，股票不需要，也叫静态权益
m_dBalance: 总资产，动态权益，即市值
m_dAvailable: 可用金额
m_dCommission: 手续费，已经用掉的手续费
m_dPositionProfit: 持仓盈亏
m_dCloseProfit: 平仓盈亏，股票不需要
m_dCashIn: 出入金净值
m_dCurrMargin: 当前使用的保证金，股票不需要
m_dInitBalance: 初始权益
m_strStatus: 状态
m_dInitCloseMoney: 期初平仓盈亏，初始平仓盈亏
m_dInstrumentValue: 总市值，合约价值，合约价值 
m_dDeposit: 入金
m_dWithdraw: 出金

m_dPreCredit: 上次信用额度，股票不需要
m_dPreMortgage: 上次质押，股票不需要
m_dMortgage: 质押，股票不需要
m_dCredit: 信用额度，股票不需要
m_dAssetBalance: 证券初始资金，股票不需要 
m_strOpenDate: 起始日期，股票不需要
m_dFetchBalance: 可取金额
m_strTradingDate: 交易日
m_dStockValue: 股票总市值，期货没有
m_dLoanValue: 债券总市值，期货没有
m_dFundValue: 基金总市值，包括 ETF 和封闭式基金，期货没有
m_dRepurchaseValue: 回购总市值，所有回购，期货没有
m_dLongValue: 多单总市值，现货没有
m_dShortValue: 单总市值，现货没有
m_dNetValue: 净持仓总市值，净持仓市值 = 多 - 空
m_dAssureAsset: 净资产
m_dTotalDebit: 总负债
m_dEntrustAsset: 可信资产，用于校对
m_dInstrumentValueRMB: 总市值（人民币），沪港通
m_dSubscribeFee: 申购费，申购费
m_dGoldValue: 库存市值，黄金现货库存市值
m_dGoldFrozen: 现货冻结，黄金现货冻结
m_dMargin: 占用保证金，维持保证金
m_strMoneyType: 币种 
m_dPurchasingPower: 购买力，盈透购买力
m_dRawMargin : 原始保证金 
m_dBuyWaitMoney: 买入待交收金额（元），买入待交收
m_dSellWaitMoney: 卖出待交收金额（元），卖出待交收
m_dReceiveInterestTotal: 本期间应计利息 
m_dRoyalty: 权利金收支，期货期权用 
m_dFrozenRoyalty: 冻结权利金，期货期权用
m_dRealUsedMargin: 实时占用保证金，用于股票期权
m_dRealRiskDegree: 实时风险度

5.3.2. order 委托对象 
m_strExchangeID: 证券市场
m_strExchangeName: 交易市场
m_strProductID: 品种代码
m_strProductName: 品种名称
m_strInstrumentID: 证券代码
m_strInstrumentName: 证券名称，合约名称 
m_nTaskId ：任务号
m_strOrderRef: 内部委托号，下单引用等于股票的内部委托号
m_nOrderPriceType: EBrokerPriceType 类型，例如市价单、限价单
m_nDirection: EEntrustBS 类型，操作，多空，期货多空，股票买卖永远是 48 ，其他的 dir 同理
m_nOffsetFlag: EOffset_Flag_Type 类型，操作，期货开平，股票买卖其实就是开平
m_nHedgeFlag: EHedge_Flag_Type 类型，投保
m_dLimitPrice: 委托价格 , 限价单的限价，就是报价
m_nVolumeTotalOriginal: 委托量，最初委托量
m_nOrderSubmitStatus: EEntrustSubmitStatus 类型，报单状态，提交状态，股票中不需要报
单状态
m_strOrderSysID: 合同编号，委托号
m_nOrderStatus: EEntrustStatus ，委托状态 
m_nVolumeTraded: 成交数量，已成交量 
m_nVolumeTotal: 委托剩余量，当前总委托量，股票的含义是总委托量减去成交量
m_nErrorID: 状态信息
m_dFrozenMargin: 冻结金额，冻结保证金
m_dFrozenCommission: 冻结手续费
m_strInsertDate: 委托日期，报单日期
m_strInsertTime: 委托时间
m_dTradedPrice: 成交均价（股票）
m_dCancelAmount: 已撤数量
m_strOptName: 买卖标记，展示委托属性的中文
m_dTradeAmount: 成交金额，成交额，期货 = 均价 * 量 * 合约乘数
m_eEntrustType: EEntrustTypes ，委托类别
m_strCancelInfo: 废单原因
m_strUnderCode: 标的证券代码
m_eCoveredFlag: ECoveredFlag ，备兑标记 '0' - 非备兑， '1' - 备兑

m_strCompactNo: 合约编号
m_strRemark ：投资备注
 
5.3.3. deal 成交对象 
m_strExchangeID: 证券市场，交易所代码
m_strExchangeName: 交易市场，交易所名称
m_strProductID: 品种代码
m_strProductName: 品种名称
m_strInstrumentID: 证券代码 
m_strInstrumentName: 证券名称
m_strTradeID: 成交编号
m_nTaskId ：任务号
m_strOrderRef: 下单引用，等于股票的内部委托号
m_strOrderSysID: 合同编号，报单编号，委托号
m_nDirection: EEntrustBS ，买卖方向
m_nOffsetFlag: EOffset_Flag_Type ，开平，股票的买卖
m_nHedgeFlag: EHedge_Flag_Type ，投保，股票不需要
m_dPrice: 成交均价
m_nVolume: 成交量，期货单位手，股票做到股
m_strTradeDate: 成交日期
m_strTradeTime: 成交时间 
m_dComssion: 手续费
m_dTradeAmount: 成交额，期货 = 均价 * 量 * 合约乘数
m_nOrderPriceType: EBrokerPriceType 类型，例如市价单、限价单
m_strOptName ：买卖标记，展示委托属性的中文
m_eEntrustType: EEntrustTypes 类型，委托类别
m_eFutureTradeType: EFutureTradeType 类型，成交类型 
m_nRealOffsetFlag: EOffset_Flag_Type 类型，实际开平，主要是区分平今和平昨
m_eCoveredFlag: ECoveredFlag 类型，备兑标记 '0' - 非备兑， '1' - 备兑
m_nCloseTodayVolume: 平今量，不显示
m_dOrderPriceRMB: 委托价格（人民币），目前用于港股通
m_dPriceRMB: 成交价格（人民币），目前用于港股通
m_dTradeAmountRMB ：成交金额（人民币），目前用于港股通
m_dReferenceRate: 汇率，目前用于港股通

m_strXTTrade: 是否是迅投交易
m_strCompactNo: 合约编号
m_dCloseProfit: 平仓盈亏 ，目前用于外盘
m_strRemark ：投资备注
 
5.3.4. position 持仓对象 
m_strExchangeID: 证券市场
m_strExchangeName: 市场名称
m_strProductID: 品种代码
m_strProductName: 品种名称
m_strInstrumentID: 证券代码
m_strInstrumentName: 证券名称
m_nHedgeFlag: EHedge_Flag_Type 类型，投保 ，股票不需要
m_nDirection: EEntrustBS 类型，买卖 ; 股票不需要
m_strOpenDate: 成交日期 
m_strTradeID: 成交号，最初开仓位的成交
m_nVolume: 当前拥股，持仓量
m_dOpenPrice: 持仓成本
m_strTradingDay: 在实盘运行中是当前交易日，在回测中是股票最后交易过的日期
m_dMargin: 使用的保证金，历史的直接用 ctp 的，新的自己用成本价 * 存量 * 系数算，股票不
需要
m_dOpenCost: 开仓成本，等于股票的成本价 * 第一次建仓的量，后续减持不影响，不算手续
费，股票不需要
m_dSettlementPrice: 最新价，结算价，对于股票的当前价
m_nCloseVolume: 平仓量，等于股票已经卖掉的 股票不需要
m_dCloseAmount: 平仓额，等于股票每次卖出的量 * 卖出价 * 合约乘数（股票为 1 ）的累加 股
票不需要
m_dFloatProfit: 浮动盈亏，当前量 * （当前价 - 开仓价） * 合约乘数（股票为 1 ）
m_dCloseProfit: 平仓盈亏，平仓额 - 开仓价 * 平仓量 * 合约乘数（股票为 1 ） 股票不需要
m_dMarketValue: 市值，合约价值
m_dPositionCost: 持仓成本，股票不需要
m_dPositionProfit: 持仓盈亏，股票不需要
m_dLastSettlementPrice: 最新结算价，股票不需要
m_dInstrumentValue: 合约价值，股票不需要 
m_bIsToday: 是否今仓

m_strStockHolder: 股东账号
m_nFrozenVolume: 冻结数量，冻结持仓，期货不用这个字段，冻结数量
m_nCanUseVolume: 可用余额，可用持仓，期货不用这个字段，股票的可用数量
m_nOnRoadVolume: 在途股份，在途持仓，期货不用这个字段，股票的在途数量
m_nYesterdayVolume: 昨夜拥股，期货不用这个字段，股票的股份余额
m_dLastPrice: 最新价，结算价，对于股票的当前价
m_dProfitRate: 盈亏比例，持仓盈亏比例
m_eFutureTradeType: EFutureTradeType ，成交类型
m_strExpireDate: 到期日，逆回购用
m_strComTradeID: 组合成交号 ，套利成交 ID
m_nLegId: 组合序号 ，组合 ID
m_dTotalCost: 累计成本，自定义累计成本，股票信用用到
m_dSingleCost: 单股成本，自定义单股成本，股票信用用到
m_nCoveredVolume: 备兑数量，用于个股期权
m_eSideFlag: ESideFlag 持仓类型 ，用于个股期权，标记 '0' - 权利， '1' - 义务， '2' - ' 备兑 '
m_dReferenceRate: 汇率，目前用于港股通
m_dStructFundVol: 分级基金可用（可分拆或可合并）
m_dRedemptionVolume: 分级基金可赎回量
m_nPREnableVolume: 申赎可用量（记录当日申购赎回的股票或基金数量）
m_dRealUsedMargin: 实时占用保证金，用于期权
m_dRoyalty: 权利金
 
5.3.5. CCreditAccountDetail 信用账号对象 ( 非查柜台 ) 
m_dMaxMarginRate: 保证金比率，股票的保证金率等于 1 ，股票不需要
m_dFrozenMargin: 冻结保证金，外源性，股票的保证金就是冻结资金，股票不需要
m_dFrozenCash: 冻结金额，内外源冻结保证金和手续费四个的和
m_dFrozenCommission: 冻结手续费，外源性冻结资金源
m_dRisk: 风险度，冻结资金 / 可用资金，股票不需要
m_dNav: 单位净值
m_dPreBalance: 期初权益，股票不需要，也叫静态权益
m_dBalance: 总资产，动态权益，即市值
m_dAvailable: 可用金额
m_dCommission: 手续费，已经用掉的手续费
m_dPositionProfit: 持仓盈亏

m_dCloseProfit: 平仓盈亏，股票不需要
m_dCashIn: 出入金净值
m_dCurrMargin: 当前使用的保证金，股票不需要
m_dInitBalance: 初始权益
m_strStatus: 状态
m_dInitCloseMoney: 期初平仓盈亏，初始平仓盈亏
m_dInstrumentValue: 总市值，合约价值，合约价值 
m_dDeposit: 入金
m_dWithdraw: 出金 
m_dPreCredit: 上次信用额度，股票不需要
m_dPreMortgage: 上次质押，股票不需要
m_dMortgage: 质押，股票不需要
m_dCredit: 信用额度，股票不需要
m_dAssetBalance: 证券初始资金，股票不需要 
m_strOpenDate: 起始日期股票不需要
m_dFetchBalance: 可取金额
m_strTradingDate: 交易日
m_dStockValue: 股票总市值，期货没有
m_dLoanValue: 债券总市值，期货没有
m_dFundValue: 基金总市值，包括 ETF 和封闭式基金，期货没有
m_dRepurchaseValue: 回购总市值，所有回购，期货没有
m_dLongValue: 多单总市值，现货没有
m_dShortValue: 单总市值，现货没有
m_dNetValue: 净持仓总市值，净持仓市值 = 多 - 空
m_dAssureAsset: 净资产
m_dTotalDebt: 总负债
m_dEntrustAsset: 可信资产，用于校对
m_dInstrumentValueRMB: 总市值（人民币），沪港通
m_dSubscribeFee: 申购费，申购费
m_dGoldValue: 库存市值，黄金现货库存市值
m_dGoldFrozen: 现货冻结，黄金现货冻结
m_dMargin: 占用保证金，维持保证金
m_strMoneyType: 币种 
m_dPurchasingPower: 购买力，盈透购买力

m_dRawMargin : 原始保证金 
m_dBuyWaitMoney: 买入待交收金额（元），买入待交收
m_dSellWaitMoney: 卖出待交收金额（元），卖出待交收
m_dReceiveInterestTotal: 本期间应计利息 
m_dRoyalty: 权利金收支，期货期权用 
m_dFrozenRoyalty: 冻结权利金，期货期权用
m_dRealUsedMargin: 实时占用保证金，用于股票期权
m_dRealRiskDegree: 实时风险度
m_dPerAssurescaleValue: 个人维持担保比例
m_dEnableBailBalance: 可用保证金
m_dUsedBailBalance: 已用保证金
m_dAssureEnbuyBalance: 可买担保品资金
m_dFinEnbuyBalance: 可买标的券资金
m_dSloEnrepaidBalance: 可还券资金 
m_dFinEnrepaidBalance: 可还款资金
m_dFinMaxQuota: 融资授信额度
m_dFinEnableQuota: 融资可用额度
m_dFinUsedQuota: 融资已用额度 
m_dFinUsedBail: 融资已用保证金额 
m_dFinCompactBalance: 融资合约金额 
m_dFinCompactFare: 融资合约费用
m_dFinCompactInterest: 融资合约利息
m_dFinMarketValue: 融资市值
m_dFinIncome: 融资合约盈亏
m_dSloMaxQuota: 融券授信额度
m_dSloEnableQuota: 融券可用额度
m_dSloUsedQuota: 融券已用额度
m_dSloUsedBail: 融券已用保证金额
m_dSloCompactBalance: 融券合约金额 
m_dSloCompactFare: 融券合约费用
m_dSloCompactInterest: 融券合约利息 
m_dSloMarketValue: 融券市值
m_dSloIncome: 融券合约盈亏
m_dOtherFare: 其它费用

m_dUnderlyMarketValue: 标的证券市值 
m_dFinEnableBalance: 可融资金额
m_dDiffEnableBailBalance: 可用保证金调整值 
m_dBuySecuRepayFrozenMargin: 买券还券冻结资金
m_dBuySecuRepayFrozenCommission: 买券还券冻结手续费
m_dSpecialEnableBalance: 专项可融金额
m_dEncumberedAssets: 担保资产
m_dSloSellBalance: 融券卖出资金
m_dDiffAssureEnbuyBalance: 可买担保品资金调整值
m_dDiffFinEnbuyBalance: 可买标的券资金调整值
m_dDiffFinEnrepaidBalance: 可还款资金调整值
m_dOtherRealCompactBalance: 其他负债合约金额
m_dOtherFinCompactInterest: 其他负债合约利息金额
m_dUsedSloSellBalance: 已用融券卖出资金 
m_dFetchAssetBalance: 可提出资产总额 
m_dTotalEnableQuota: 可用总信用额度
m_dTotalUsedQuota: 已用总信用额度 ;
m_dDebtProfit: 负债总浮盈
m_dDebtLoss: 负债总浮亏 
m_nContractEndDate: 合同到期日期
m_dFinDebt: 融资负债
m_dFinProfitAmortized: 融资浮盈折算 
m_dSloProfit: 融券浮盈 
m_dSloProfitAmortized: 融券浮盈折算 
m_dFinLoss: 融资浮亏 
m_dSloLoss: 融券浮亏 
 
5.3.6. CreditSloEnableAmount 可融券明细对象 
m_nPlatformID: 平台号 
m_strBrokerID: 经纪公司编号
m_strBrokerName: 证券公司，期货公司，经纪公司，证券公司 
m_strAccountID: 资金账号，账号，账号，资金账号
m_strExchangeID: 交易所
m_strInstrumentID: 证券代码

m_strInstrumentName: 股票名称
m_dSloRatio: 融券保证金比例
m_eSloStatus: EXTSubjectsStatus ，融券状态
m_nEnableAmount: 融券可融数量
m_eQuerySloType: EXTSloTypeQueryMode ，查询类型
m_strExpireDate: 到期日期 
 
5.3.7. StkCompacts 负债合约对象 
m_strExchangeID: 交易所
m_strInstrumentID: 证券代码
m_strExchangeName: 交易所名称
m_strInstrumentName: 股票名称
m_nOpenDate: 合约开仓日期
m_strCompactId: 合约编号
m_dCrdtRatio: 融资融券保证金比例
m_strEntrustNo: 委托编号
m_dEntrustPrice: 委托价格
m_nEntrustVol: 委托数量
m_nBusinessVol: 合约开仓数量 
m_dBusinessBalance: 合约开仓金额 
m_dBusinessFare: 合约开仓费用
m_eCompactType: EXTCompactType ，合约类型 
m_eCompactStatus: EXTCompactStatus ，合约状态
m_dRealCompactBalance: 未还合约金额
m_nRealCompactVol: 未还合约数量
m_dRealCompactFare: 未还合约费用
m_dRealCompactInterest: 未还合约利息 
m_dRepaidInterest: 已还利息
m_nRepaidVol: 已还数量 
m_dRepaidBalance: 已还金额
m_dCompactInterest: 合约总利息
m_dUsedBailBalance: 占用保证金
m_dYearRate: 合约年利率
m_nRetEndDate: 归还截止日
