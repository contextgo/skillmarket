# 交易下单函数完整参考

（ 5 ）形成委托，过风控
（ 6 ）成交
 
3.2.4.1. 交易函数基本信息 
QMT 系统提供了一系列的 Python 下单函数接口，如下所示。
* 注：在回测模式中，交易函数调用虚拟账号进行交易，在历史 K 线上记录买卖点，用以计算策略净值 /
回测指标；实盘运行调用策略中设置的资金账号进行交易，产生实际委托；模拟运行模式下交易函数无
效。其中， can_cancel_order, cancel_task, cancel 和 do_order 交易函数在回测模式中无实际意义，不建
议使用。
（ 1 ）交易函数

函数名 释义
passorder 综合交易下单
algo_passorder 算法交易下单
smart_algo_passorder 智能算法交易
get_trade_detail_data 取交易细明数据函数
get_value_by_order_id 根据委托 Id 取委托或成交信息
get_last_order_id 获取最新的委托或成交的委托 Id
can_cancel_order 查询委托是否可撤销
cancel 取消委托
cancel_task 撤销任务
pause_task 暂停任务
resume_task 继续任务
do_order 实时触发前一根 bar 信号函数
stoploss_limitprice 以限价单方式止损 / 止盈
stoploss_marketprice 以市价单方式止损 / 止盈
get_new_purchase_limit 获取账号新股申购额度
函数名 释义
order_lots 指定手数交易
order_value 指定价值交易
order_percent 一定比例下单
order_target_value 目标价值下单
order_target_percent 目标比例下单
order_shares 指定股数交易
（ 2 ）股票下单函数
（ 3 ）期货下单函数

函数名 释义
buy_open 买入开仓
sell_close_tdayfirst 卖出平仓，平今优先
sell_close_ydayfirst 卖出平仓，平昨优先
sell_open 卖出开仓
buy_close_tdayfirst 买入平仓，平今优先
buy_close_ydayfirst 买入平仓，平昨优先
 
3.2.4.2. 交易函数介绍 
（ 1 ）综合交易下单 passorder() 
用法： passorder(opType, orderType, accountid, orderCode, prType, modelprice, volume[, 
strategyName, quickTrade, userOrderId], ContextInfo)
释义： 综合交易下单
参数： 
opType ，操作类型，可选值：
期货六键：
0 ：开多
1 ：平昨多
2 ：平今多
3 ：开空
4 ：平昨空
5 ：平今空
期货四键：
6 ：平多 , 优先平今
7 ：平多 , 优先平昨
8 ：平空 , 优先平今
9 ：平空 , 优先平昨
期货两键：
10 ：卖出 , 如有多仓 , 优先平仓 , 优先平今 , 如有余量 , 再开空
11 ：卖出 , 如有多仓 , 优先平仓 , 优先平昨 , 如有余量 , 再开空
12 ：买入 , 如有空仓 , 优先平仓 , 优先平今 , 如有余量 , 再开多
13 ：买入 , 如有空仓 , 优先平仓 , 优先平昨 , 如有余量 , 再开多
14 ：买入 , 不优先平仓
15 ：卖出 , 不优先平仓

股票买卖：
23 ：股票买入，或沪港通、深港通股票买入
24 ：股票卖出，或沪港通、深港通股票卖出
融资融券：
27 ：融资买入
28 ：融券卖出
29 ：买券还券
30 ：直接还券
31 ：卖券还款
32 ：直接还款
33 ：信用账号股票买入
34 ：信用账号股票卖出
组合交易：
25 ：组合买入，或沪港通、深港通的组合买入
26 ：组合卖出，或沪港通、深港通的组合卖出
27 ：融资买入
28 ：融券卖出
29 ：买券还券
31 ：卖券还款
33 ：信用账号股票买入
34 ：信用账号股票卖出
35 ：普通账号一键买卖
36 ：信用账号一键买卖
40 ：期货组合开多
43 ：期货组合开空
46 ：期货组合平多 , 优先平今
47 ：期货组合平多 , 优先平昨
48 ：期货组合平空 , 优先平今
49 ：期货组合平空 , 优先平昨
期权交易：
50 ：买入开仓
51 ：卖出平仓
52 ：卖出开仓
53 ：买入平仓
54 ：备兑开仓
55 ：备兑平仓
56 ：认购行权
57 ：认沽行权

58 ：证券锁定
59 ：证券解锁
ETF 交易：
60 ：申购
61 ：赎回
专项两融：
70 ：专项融资买入
71 ：专项融券卖出
72 ：专项买券还券
73 ：专项直接还券
74 ：专项卖券还款
75 ：专项直接还款
可转债：
80 ：普通账户转股
81 ：普通账户回售
82 ：信用账户转股
83 ：信用账户回售
orderType ，下单方式
* 注：
一、期货不支持 1102 和 1202
二、对所有账号组的操作相当于对账号组里的每个账号做一样的操作，如 passorder(23, 
1202, 'testS', '000001.SZ', 5, -1, 50000, ContextInfo) ，意思就是对账号组 testS 里的所有账
号都以最新价开仓买入 50000 元市值的 000001.SZ 平安银行；
passorder(60,1101,"test",'510050.SH',5,-1,1,ContextInfo) 意思就是账号 test 申购 1 个单位
(900000 股 ) 的华夏上证 50ETF( 只申购不买入成分股 ) 。
可选值：
1101 ：单股、单账号、普通、股 / 手方式下单
1102 ：单股、单账号、普通、金额（元）方式下单（只支持股票）
1113 ：单股、单账号、总资产、比例 [0 ~ 1] 方式下单
1123 ：单股、单账号、可用、比例 [0 ~ 1] 方式下单
 
1201 ：单股、账号组（无权重）、普通、股 / 手方式下单
1202 ：单股、账号组（无权重）、普通、金额（元）方式下单（只支持股票）
1213 ：单股、账号组（无权重）、总资产、比例 [0 ~ 1] 方式下单
1223 ：单股、账号组（无权重）、可用、比例 [0 ~ 1] 方式下单
 
2101 ：组合、单账号、普通、按组合股票数量（篮子中股票设定的数量）方式下单 > 对应 
volume 的单位为篮子的份

2102 ：组合、单账号、普通、按组合股票权重（篮子中股票设定的权重）方式下单 > 对应 
volume 的单位为元
2103 ：组合、单账号、普通、按账号可用方式下单 > （底层篮子股票怎么分配？答：按可用
资金比例后按篮子中股票权重分配，如用户没填权重则按相等权重分配）只对股票篮子支持
 
2201 ：组合、账号组（无权重）、普通、按组合股票数量方式下单
2202 ：组合、账号组（无权重）、普通、按组合股票权重方式下单
2203 ：组合、账号组（无权重）、普通、按账号可用方式下单只对股票篮子支持
组合套利交易接口特殊设置（ accountID 、 orderType 特殊设置）
passorder(opType, orderType, accountID, orderCode, prType, hedgeRatio, volume, 
ContextInfo)
accountID = 'stockAccountID, futureAccountID'
orderCode = 'basketName, futureName'
hedgeRatio ：套利比例（ 0 ~ 2 之间值，相当于 %0 至 200% 套利）
volume ：份数 \ 资金 \ 比例
orderType （特殊设置）
orderType 可选值：
2331 ：组合、套利、合约价值自动套利、按组合股票数量方式下单
2332 ：组合、套利、按合约价值自动套利、按组合股票权重方式下单
2333 ：组合、套利、按合约价值自动套利、按账号可用方式下单
accountID ，资金账号
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：下单的账号 ID （可多个）或账号组名或套利组名（一个篮子一个套利账号，如 accountID = 
' 股票账户名 , 期货账号 ' ）
orderCode ，下单代码
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：
一、如果是单股或单期货、港股，则该参数填合约代码；
二、如果是组合交易 , 则该参数填篮子名称；
三、如果是组合套利，则填一个篮子名和一个期货合约名（如 orderCode = ' 篮子名 , 期货合
约名 ' ）
prType ，下单选价类型
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
可选值（特别的对于套利，这个 prType 只对篮子起作用，期货的采用默认的方式）：
-1 ：无效（实际下单时 , 需要用交易面板交易函数那设定的选价类型）
0 ：卖 5 价
1 ：卖 4 价
2 ：卖 3 价

3 ：卖 2 价
4 ：卖 1 价
5 ：最新价
6 ：买 1 价
7 ：买 2 价（组合不支持）
8 ：买 3 价（组合不支持）
9 ：买 4 价（组合不支持）
10 ：买 5 价（组合不支持）
11 ：（指定价）模型价（只对单股情况支持 , 对组合交易不支持）
12 ：涨跌停价
13 ：挂单价
14 ：对手价
27 ：市价即成剩撤 ( 仅对股票期权申报有效 )
28 ：市价即全成否则撤 ( 仅对股票期权申报有效 )
29 ：市价剩转限价 ( 仅对股票期权申报有效 )
42 ：最优五档即时成交剩余撤销申报 ( 仅对上交所申报有效 )
43 ：最优五档即时成交剩转限价申报 ( 仅对上交所申报有效 )
44 ：对手方最优价格委托 ( 仅对深交所申报有效 )
45 ：本方最优价格委托 ( 仅对深交所申报有效 )
46 ：即时成交剩余撤销委托 ( 仅对深交所申报有效 )
47 ：最优五档即时成交剩余撤销委托 ( 仅对深交所申报有效 )
48 ：全额成交或撤销委托 ( 仅对深交所申报有效 )
49 ：科创板盘后定价
price ，下单价格
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：
一、单股下单时， prType 是模型价 / 科创板盘后定价时 price 有效；其它情况无效；即单股
时， prType 参数为 11 ， 49 时被使用。 prType 参数不为 11 ， 49 时也需填写，填写的内容
可为 -1 ， 0 ， 2 ， 100 等任意数字；
二、组合下单时，是组合套利时， price 作套利比例有效，其它情况无效。
volume ，下单数量（股 / 手 / 元 / % ）
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
根据 orderType 值最后一位确定 volume 的单位：
单股下单时：
1 ：股 / 手
2 ：金额（元）
3 ：比例（ % ）
组合下单时：

1 ：按组合股票数量（份）
2 ：按组合股票权重（元）
3 ：按账号可用（ % ）
strategyName ， string ，自定义策略名，可缺省不写，用来区分 order 委托和 deal 成交来自不同
的策略。根据该策略名， get_trade_detail_data ， get_last_order_id 函数可以获取相应策略名对应
的委托或持仓结果。
* 注： strategyName 只对同账号本地客户端有效，即 strategyName 只对当前客户端下的单进行
策略区分，且该策略区分只能当前客户端使用。
quickTrade ， int ，设定是否立即触发下单，可选值：
0 ：否
1 ：是
 * 注： passorder 是对最后一根 K 线完全走完后生成的模型信号在下一根 K 线的第一个 tick 数据来时
触发下单交易；采用 quickTrade 参数设置为 1 时，非历史 bar 上执行时（ ContextInfo.is_last_bar()
为 True ），只要策略模型中调用到就触发下单交易。 quickTrade 参数设置为 2 时，不判断 bar 状
态，只要策略模型中调用到就触发下单交易，历史 bar 上也能触发下单，请谨慎使用。
userOrderId ， string ，用户自设委托 ID ，可缺省不写，写的时候必须把起前面的 strategyName 
和 quickTrade 参数也填写。对应 order 委托对象和 deal 成交对象中的 m_strRemark 属性，通过 
get_trade_detail_data 函数或委托主推函数 order_callback 和成交主推函数 deal_callback 可拿到
这两个对象信息。
userOrderParam ， string ，用户自定义交易参数模板名称，可缺省不写，写的时候必须把起前面
的 strategyName 和 quickTrade 参数也填写。
返回： 无
示例： 
 
（ 2 ）智能算法交易 smart_algo_passorder() 
用法： 
smart_algo_passorder(opType,orderType,accountid,orderCode,prType,modelprice,volume,strage
Name,quickTrade,userid,smartAlgoType,limitOverRate,minAmountPerOrder,
[targetPriceLevel,startTime,endTime,limitControl],ContextInfo)
释义： 智能算法交易
参数： 
def handlebar(ContextInfo):
    # 单股单账号期货最新价买入 10 手
    passorder(0, 1101, 'test', target, 5, -1, 10, ContextInfo)
    
    # 单股单账号期货指定价买入 10 手
    passorder(0, 1101, 'test', target, 11, 3000, ContextInfo)
    
    # 单股单账号股票最新价买入 100 股（ 1 手）   
    passorder(23, 1101, 'test', target, 5, 0, 100, ContextInfo)
    
    # 单股单账号股票指定价买入 100 股（ 1 手）  
    passorder(23, 1101, 'test', target, 11, 7, 100, ContextInfo)
1
2
3
4
5
6
7
8
9
10
11
12

opType ，操作类型，可选值：
股票买卖：
23 ：股票买入，或沪港通、深港通股票买入
24 ：股票卖出，或沪港通、深港通股票卖出
融资融券：
27 ：融资买入
28 ：融券卖出
29 ：买券还券
30 ：直接还券
31 ：卖券还款
32 ：直接还款
33 ：信用账号股票买入
34 ：信用账号股票卖出
35 ：普通账号一键买卖
36 ：信用账号一键买卖
orderType ，下单方式
可选值：
1101 ：单股、单账号、普通、股 / 手方式下单
1102 ：单股、单账号、普通、金额（元）方式下单（只支持股票）
1113 ：单股、单账号、总资产、比例 [0 ~ 1] 方式下单
1123 ：单股、单账号、可用、比例 [0 ~ 1] 方式下单
 
1201 ：单股、账号组（无权重）、普通、股 / 手方式下单
1202 ：单股、账号组（无权重）、普通、金额（元）方式下单（只支持股票）
1213 ：单股、账号组（无权重）、总资产、比例 [0 ~ 1] 方式下单
1223 ：单股、账号组（无权重）、可用、比例 [0 ~ 1] 方式下单
accountID ，资金账号
* 注：下单的账号 ID （可多个）或账号组名或套利组名（一个篮子一个套利账号 , 如 accountID=’ 股票
账户名 , 期货账号 ’ ）
orderCode ，下单代码
* 注：有两种如果是单股或单期货、港股 , 则该参数填合约代码；如果是组合交易 , 则该参数填篮子名
称 . 如果是组合套利 , 则填一个篮子名和一个期货合约名（如 orderCode=’ 篮子名 , 期货合约名 ’ ）
prType ，下单选价类型
* 注：特别的对于套利：这个 prType 只对篮子起作用，期货的采用默认的方式
可选值：
0 ：卖 5 价
1 ：卖 4 价
2 ：卖 3 价
3 ：卖 2 价

4 ：卖 1 价
5 ：最新价
6 ：买 1 价
7 ：买 2 价 ( 组合不支持 )
8 ：买 3 价 ( 组合不支持 )
9 ：买 4 价 ( 组合不支持 )
10 ：买 5 价 ( 组合不支持 )
11 ：（指定价）模型价（只对单股情况支持 , 对组合交易不支持）
12 ：涨跌停价
13 ：挂单价
14 ：对手价
如果 prType = 12, 则智能算法下涨跌停价 , 其他情况下限价
price ，下单价格
* 注： prType 是模型价时 price 有效；其它情况无效
volume ，下单数量（股 / 元 / % ）
根据 orderType 值最后一位确定 volume 的单位：
单股下单时：
1 ：股 
2 ：金额（元）
3 ：比例（ % ）
strageName ，策略名
不同于 passorder ，这里不可缺省
quickTrade ，参数内容说明
quickTrade ： int ，是否立马触发下单， 0 否， 1 是
* 注：
passorder 是对最后一根 K 线完全走完后生成的模型信号在下一根 K 线的第一个 tick 数据来时触发下
单交易；
采用 quickTrade 参数设置为 1 时，非历史 bar 上执行时（ ContextInfo.is_last_bar() 为 True ），只要
策略模型中调用到就触发下单交易。
quickTrade 参数设置为 2 时，不判断 bar 状态，只要策略模型中调用到就触发下单交易，历史 bar 上
也能触发下单，请谨慎使用。
userid ，投资备注
不同于 passorder ，这里不可缺省
smartAlgoType ， string ，智能算法类型
可选值：
VWAP ： VWAP
TWAP ： TWAP
VP ：跟量
PINLINE ：跟价
DMA ：快捷
FLOAT ：盘口

SWITCH ：换仓
ICEBERG ：冰山
MOC ：尾盘
limitOverRate ， int ，量比，数据范围 0-100 ，如果输入其他无效值，则 limitOverRate 为 0 。
* 注：网格算法无此项。
minAmountPerOrder ， int ，智能算法最小委托金额，数据范围 0-100000 ，默认为 0 。
targetPriceLevel ，智能算法目标价格
可选值：
1 ：己方盘口 1
2 ：己方盘口 2
3 ：己方盘口 3
4 ：己方盘口 4
5 ：己方盘口 5
6 ：最新价
7 ：对方盘口
* 注：
一、输入无效值则 targetPriceLevel 为 1 ；
二、本项只针对冰山算法 , 其他算法可缺省。
startTime ，智能算法开始时间
 格式 "HH:MM:SS" ，如 "10:30:00" 。如果缺省值，则默认为 "09:30:00"
endTime ，智能算法截止时间
 格式 "HH:MM:SS" ，如 "14:30:00" 。如果缺省值，则默认为 "15:30:00"
limitControl ，涨跌停控制
1 ：涨停不卖跌停不卖
0 ：无
 默认值为 1
返回： 无
示例： 
def handlebar(ContextInfo):
  smart_algo_passorder(23,1101,'600000105','000001.SZ',5,-1,50000,"strageName
",0,"remark","TWAP",20,0,ContextInfo);# 账户 600000105 最新价开仓买入 50000 股的
000001.SZ 平安银行 , 使用 TWAP 智能算法 , 量比 20%, 最小买卖金额 0
  smart_algo_passorder(23,1101,'600000105','000001.SZ',5,-1,50000,"strageName
",1,"remark","TWAP",20,0,0,'09:30:00','14:00:00',ContextInfo);# 账户 600000105 最
新价快速交易开仓买入 50000 股的 000001.SZ 平安银行 , 使用 TWAP 智能算法 , 量比 20%, 最小买卖金额 0 且
有效时长为 09:30-14:00
  smart_algo_passorder(23,1101,'600000105','000001.SZ',5,-1,50000,"strageName
",1,"remark","TWAP",20,0,0,'09:30:00','14:00:00',0,ContextInfo);# 账户 600000105
最新价快速交易开仓买入 50000 股的 000001.SZ 平安银行 , 使用 TWAP 智能算法 , 量比 20%, 最小买卖金额 0 
且有效时长为 09:30-14:00, 不对智能算法涨停做限制
1
2
3
4

（ 3 ）获取交易明细数据 get_trade_detail_data() 
用法： get_trade_detail_data(accountID, strAccountType, strDatatype, strategyName) 或不区分策略
get_trade_detail_data(accountID, strAccountType, strDatatype)
释义： 获取交易明细数据函数
参数： 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
strDatatype ： string ，数据类型：
'POSITION' ：持仓
'ORDER' ：委托
'DEAL' ：成交
'ACCOUNT' ：账号
'TASK' ：任务
strategyName ： string ，策略名，对应 passorder 下单函数中的参数 strategyName 的值，只对
委托 'ORDER' 、成交 'DEAL' 起作用。
返回： list ， list 中放的是 PythonObj ，通过 dir(pythonobj) 可返回某个对象的属性列表。
* 注：有五种交易相关信息，包括：
POSITION ：持仓 
ORDER ：委托 
DEAL ：成交 
ACCOUNT ：账号 
TASK ：任务
示例： 
def handlebar(ContextInfo):
    obj_list = get_trade_detail_data('6000000248','stock','position')
    for obj in obj_list:
        print(obj.m_strInstrumentID)
        # 查看有哪些属性字段
        print(dir(obj))
    # 可用资金查询
    acct_info = get_trade_detail_data('6000000248', 'stock', 'account')
1
2
3
4
5
6
7
8
9

（ 4 ）根据委托号获取委托或成交信息 get_value_by_order_id() 
用法： get_value_by_order_id(orderId, accountID, strAccountType, strDatatype)
释义： 根据委托号获取委托或成交信息。
参数： 
orderId ： string ，委托号。
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
strDatatype ： string ，数据类型：
'ORDER' ：委托
'DEAL' ：成交
返回： pythonObj
示例： 
 
    for i in acct_info:
        print(i.m_dAvailable)
    # 当前持仓查询
    position_info = get_trade_detail_data('6000000248', 'stock', 'position')
    for i in position_info:
        print(i.m_strInstrumentID, i.m_nVolume)
10
11
12
13
14
15
16
def init(ContextInfo):
    ContextInfo.accid = '6000000248'
def handlebar(ContextInfo):
    orderid = get_last_order_id(ContextInfo.accid, 'stock', 'order')
    print(orderid)
    obj = get_value_by_order_id(orderid,ContextInfo.accid, 'stock', 'order')
    print(obj.m_strInstrumentID)
1
2
3
4
5
6
7
8

（ 5 ）获取最新的委托或成交的委托号 get_last_order_id() 
用法： get_last_order_id(accountID, strAccountType, strDatatype, strategyName) 或不区分策略 
get_last_order_id(accountID, strAccountType, strDatatype)
释义： 获取最新的委托或成交的委托号。
参数： 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
strDatatype ： string ，数据类型：
'ORDER' ：委托
'DEAL' ：成交
strategyName ， string ，策略名，对应 passorder 下单函数中的参数 strategyName 的值。
返回： String ，委托号，如果没找到返回 '-1' 。
示例： 
 
（ 6 ）查询委托是否可撤销 can_cancel_order() 
用法： can_cancel_order(orderId, accountID, strAccountType)
释义： 查询委托是否可撤销。
参数： 
orderId ， string ，委托号。 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
def init(ContextInfo):
    ContextInfo.accid = '6000000248'
def handlebar(ContextInfo):
    orderid = get_last_order_id(ContextInfo.accid, 'stock', 'order')
    print(orderid)
    obj = get_value_by_order_id(orderid,ContextInfo.accid, 'stock', 'order')
    print(obj.m_strInstrumentID)
1
2
3
4
5
6
7
8

'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
返回： bool ，是否可撤，返回值含义：
True ：可撤销
False ：不可撤销
示例： 
 
（ 7 ）取消委托 cancel() 
用法： cancel(orderId, accountId, accountType, ContextInfo)
释义： 取消委托。
参数： 
orderId ， string ，委托号。 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
ContextInfo ： pythonobj
返回： bool ，是否发出了取消委托信号，返回值含义：
True ：是
False ：否
示例： 
def init(ContextInfo):
    ContextInfo.accid = '6000000248'
def handlebar(ContextInfo):
    orderid = get_last_order_id(ContextInfo.accid,'stock','order')
    print(orderid)
    can_cancel = can_cancel_order(orderid,ContextInfo.accid,'stock')
    print(' 是否可撤 :', can_cancel)
1
2
3
4
5
6
7
8
'''
（ 1 ）下单前 , 根据 get_trade_detail_data 函数返回账号的信息，判定资金是否充足，账号是否在
登录状态，统计持仓情况等等。
1
2

（ 8 ）撤销任务 cancel_task() 
用法： cancel_task(taskId,accountId,accountType,ContextInfo)
释义： 撤销任务。
参数： 
taskId ， string ，任务编号 , 为空的时候表示撤销所有该资金账号可撤的任务。 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
ContextInfo ： pythonobj
返回： bool ，是否发出了取消任务信号，返回值含义：
True ：是
False ：否
示例： 
（ 2 ）满足一定的模型条件，用 passorder 下单。
（ 3 ）下单后，时刻根据 get_last_order_id 函数获取委托和成交的最新 id ，注意如果委托生成
了，就有了委托号（这个 id 需要自己保存做一个全局控制）。
（ 4 ）用该委托号根据 get_value_by_order_id 函数查看委托的状态，各种情况等。
当一个委托的状态变成 “ 已成 ' 后，那么对应的成交 deal 信息就有一条成交数据；用该委托号可查看成
交情况。
* 注：委托列表和成交列表中的委托号是一样的 , 都是这个 m_strOrderSysID 属性值。
可用 get_last_order_id 获取最新的 order 的委托号 , 然后根据这个委托号获取 deal 的信息，
当获取成功后，也说明这笔交易是成了，可再根据 position 持仓信息再进一步验证。
（ 5 ）根据委托号获取委托信息，根据委托状态，或模型设定，用 cancel 取消委托。
'''
def init(ContextInfo):
    ContextInfo.accid = '6000000248'
def handlebar(ContextInfo):
    orderid = get_last_order_id(ContextInfo.accid, 'stock', 'order')
    print(cancel(orderid, ContextInfo.accid, 'stock', ContextInfo))
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17

（ 9 ）暂停任务 pause_task() 
用法： pause_task(taskId,accountId,accountType,ContextInfo)
释义： 暂停智能算法任务。
参数： 
taskId ， string ，任务编号 , 为空的时候表示暂停所有该资金账号可暂停的任务。 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
ContextInfo ： pythonobj
返回： bool ，是否发出了暂停任务信号，返回值含义：
True ：是
False ：否
示例： 
'''
（ 1 ）根据 get_trade_detail_data 函数返回任务的信息 , 获取任务编号（ m_nTaskId ），任务状态
等等；
（ 2 ）根据任务编号，用 cancel_task 取消委托。
'''
def init(ContextInfo):
    ContextInfo.accid = '6000000248'
def handlebar(ContextInfo):
    objlist = get_trade_detail_data(ContextInfo.accid,'stock','task')
    for obj in obj_list:
        cancel_task(obj.m_nTaskId,ContextInfo.accid,'stock',ContextInfo)
1
2
3
4
5
6
7
8
9
10
11
12

（ 10 ）继续任务 cancel_task() 
用法： cancel_task(taskId,accountId,accountType,ContextInfo)
释义： 继续智能算法任务。
参数： 
taskId ， string ，任务编号 , , 为空的时候表示启动所有该资金账号已暂停的任务。 
accountID ： string ，资金账号。
strAccountType ： string ，账号类型，可选值：
'FUTURE' ：期货
'STOCK' ：股票
'CREDIT' ：信用
'HUGANGTONG' ：沪港通
'SHENGANGTONG' ：深港通
'STOCK_OPTION' ：期权
ContextInfo ： pythonobj
返回： bool ，是否发出了重启信号，返回值含义：
True ：是
False ：否
示例： 
'''
（ 1 ）根据 get_trade_detail_data 函数返回任务的信息 , 获取任务编号（ m_nTaskId ），任务状态
等等；
（ 2 ）根据任务编号，用 pause_task 暂停智能算法任务。
'''
def init(ContextInfo):
    ContextInfo.accid = '6000000248' 
def handlebar(ContextInfo):
    objlist = get_trade_detail_data(ContextInfo.accid,'stock','task')
    for obj in obj_list:
        pause_task(obj.m_nTaskId,ContextInfo.accid,'stock',ContextInfo)
1
2
3
4
5
6
7
8
9
10
11

（ 11 ）实时触发前一根 bar 信号函数 do_order() 
用法： do_order(ContextInfo)
释义： 实时触发前一根 bar 信号函数。
系统实盘中交易下单函数一般是把上一个周期产生的信号在最新的周期的第一个 tick 下单出去，而日 K 
线第一个 tick 是在 9:25 分集合竞价结束时产生，如果策略模型在 9:25 分之后跑又想把前一天的下单信
号发出去，就可用 do_order 函数配合实现。
特别的，需要注意，有调用 do_order 函数的策略模型跑在 9:25 分之前或别的日内周期下时，原有下单
函数和 do_order 函数都有下单信号，有可能导致重复下单。、
参数： 无
返回： 无
示例： 
 
（ 12 ）指定手数交易 order_lots() 
用法： order_lots(stockcode, lots[, style, price], ContextInfo[, accId])
释义： 指定手数交易，指定手数发送买 / 卖单。如有需要落单类型当做一个参量传入，如果忽略掉落单
类型，那么默认以最新价下单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
lots ：手数， int
'''
（ 1 ）根据 get_trade_detail_data 函数返回任务的信息 , 获取任务编号（ m_nTaskId ），任务状态
等等；
（ 2 ）根据任务编号，用 resume_task 启动已暂停智能算法任务。
'''
def init(ContextInfo):
    ContextInfo.accid = '6000000248' 
def handlebar(ContextInfo):
    objlist = get_trade_detail_data(ContextInfo.accid,'stock','task')
    for obj in obj_list:
        resume_task(obj.m_nTaskId,ContextInfo.accid,'stock',ContextInfo)
1
2
3
4
5
6
7
8
9
10
11
# 实现跑日 K 线及以上周期下 , 在固定时间点把前一周期的交易信号发送出去
def init(ContextInfo):
    pass
def handlebar(ContextInfo):
    order_lots('000002.SZ', 1, ContextInfo, '600000248')
    ticktimetag = ContextInfo.get_tick_timetag()
    int_time = int(timetag_to_datetime(ticktimetag, '%H%M%S'))
    if 100500 <= int_time < 100505:
        do_order(ContextInfo)
1
2
3
4
5
6
7
8
9
10

style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 13 ）指定价值交易 order_value() 
用法： order_value(stockcode, value[, style, price], ContextInfo[, accId])
释义： 指定价值交易，使用想要花费的金钱买入 / 卖出股票，而不是买入 / 卖出想要的股数，正数代表
买入，负数代表卖出。股票的股数总是会被调整成对应的 100 的倍数（在中国 A 股市场 1 手是 100 
股）。当您提交一个卖单时，该方法代表的意义是您希望通过卖出该股票套现的金额，如果金额超出了
您所持有股票的价值，那么您将卖出所有股票。需要注意，如果资金不足，该 API 将不会创建发送订
单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
value ：金额（元）， double
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
def handlebar(ContextInfo):
    # 按最新价下 1 手买入
    order_lots('000002.SZ', 1, ContextInfo, '600000248')
    # 用对手价下 1 手卖出
    order_lots('000002.SZ', -1, 'COMPETE', ContextInfo, '600000248')
    # 用指定价 37.5 下 2 手卖出
    order_lots('000002.SZ', -2, 'fix', 37.5, ContextInfo, '600000248')
1
2
3
4
5
6
7
8
9

'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 14 ）指定比例交易 order_percent() 
用法： order_percent(stockcode, percent[, style, price], ContextInfo[, accId])
释义： 指定比例交易，发送一个等于目前投资组合价值（市场价值和目前现金的总和）一定百分比的买 
/ 卖单，正数代表买，负数代表卖。股票的股数总是会被调整成对应的一手的股票数的倍数（ 1 手是 100 
股）。百分比是一个小数，并且小于或等于 1 （小于等于 100% ）， 0.5 表示的是 50% 。需要注意，如果
资金不足，该 API 将不会创建发送订单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
percent ：比例， double
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
def handlebar(ContextInfo):
    # 按最新价下 10000 元买入
    order_value('000002.SZ', 10000, ContextInfo, '600000248')
    # 用对手价下 10000 元卖出
    order_value('000002.SZ', -10000, 'COMPETE', ContextInfo, '600000248')
    # 用指定价 37.5 下 20000 元卖出
    order_value('000002.SZ', -20000, 'fix', 37.5, ContextInfo, '600000248')
1
2
3
4
5
6
7
8
9

（ 15 ）指定目标价值交易 order_target_value() 
用法： order_target_value(stockcode, tar_value[, style, price], ContextInfo[, accId])
释义： 指定目标价值交易，买入 / 卖出并且自动调整该证券的仓位到一个目标价值。如果还没有任何该
证券的仓位，那么会买入全部目标价值的证券；如果已经有了该证券的仓位，则会买入 / 卖出调整该证
券的现在仓位和目标仓位的价值差值的数目的证券。需要注意，如果资金不足，该 API 将不会创建发送订
单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
tar_value ：目标金额（元）， double ，非负数 
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
def handlebar(ContextInfo):
    # 按最新价下 5.1% 价值买入
    order_percent('000002.SZ', 0.051, ContextInfo, '600000248')
    # 用对手价下 5.1% 价值卖出
    order_percent('000002.SZ', -0.051, 'COMPETE', ContextInfo, '600000248')
    # 用指定价 37.5 下 10.2% 价值卖出
    order_percent('000002.SZ', -0.102, 'fix', 37.5, ContextInfo, '600000248')
1
2
3
4
5
6
7
8
9

（ 16 ）指定目标比例交易 order_target_percent() 
用法： order_target_percent(stockcode, tar_percent[, style, price], ContextInfo[, accId])
释义： 指定目标比例交易，买入 / 卖出证券以自动调整该证券的仓位到占有一个指定的投资组合的目标
百分比。投资组合价值等于所有已有仓位的价值和剩余现金的总和。买 / 卖单会被下舍入一手股数（ A 
股是 100 的倍数）的倍数。目标百分比应该是一个小数，并且最大值应该小于等于 1 ，比如 0.5 表示 
50% ，需要注意，如果资金不足，该 API 将不会创建发送订单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
tar_percent ：目标百分比 [0 ~ 1] ， double
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
def handlebar(ContextInfo):
    # 按最新价下调仓到 10000 元持仓   
    order_target_value('000002.SZ', 10000, ContextInfo, '600000248')
    # 用对手价调仓到 10000 元持仓   
    order_target_value('000002.SZ', 10000, 'COMPETE', ContextInfo, 
'600000248')
    # 用指定价 37.5 下调仓到 20000 元持仓
    order_target_value('000002.SZ', 20000, 'fix', 37.5, ContextInfo, 
'600000248')
1
2
3
4
5
6
7
8
9

（ 17 ）指定股数交易 order_shares() 
用法： order_shares(stockcode, shares[, style, price], ContextInfo[, accId])
释义： 指定股数交易，指定股数的买 / 卖单 , 最常见的落单方式之一。如有需要落单类型当做一个参量传
入，如果忽略掉落单类型，那么默认以最新价下单。
参数： 
stockcode ：代码， string ，如 '000002.SZ'
shares ：股数， int 
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE5', 'SALE4', 'SALE3', 'SALE2', 'SALE1' ：卖 5-1 价
'BUY1', 'BUY2', 'BUY3', 'BUY4', 'BUY5' ：买 1-5 价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
def handlebar(ContextInfo):
    # 按最新价下买入调仓到 5.1% 持仓
    order_target_percent('000002.SZ', 0.051, ContextInfo, '600000248')
    # 用对手价调仓到 5.1% 持仓   
    order_target_percent('000002.SZ', 0.051, 'COMPETE', ContextInfo, 
'600000248')
    # 用指定价 37.5 调仓到 10.2% 持仓
    order_target_percent('000002.SZ', 0.102, 'fix', 37.5, ContextInfo, 
'600000248')
1
2
3
4
5
6
7
8
9
def handlebar(ContextInfo):
    # 按最新价下 100 股买入 
    order_shares('000002.SZ', 100, ContextInfo, '600000248')
    # 用对手价下 100 股卖出   
    order_shares('000002.SZ', -100, 'COMPETE', ContextInfo, '600000248')
    # 用指定价 37.5 下 200 股卖出
    order_shares('000002.SZ', -200, 'fix', 37.5, ContextInfo, '600000248')
1
2
3
4
5
6
7
8
9

（ 18 ）期货买入开仓 buy_open() 
用法： buy_open(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货买入开仓
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 19 ）期货买入平仓（平今优先） buy_close_tdayfirst() 
用法： buy_close_tdayfirst(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货买入平仓，平今优先
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
def handlebar(ContextInfo):
    # 按最新价 1 手买入开仓 
    buy_open('IF1805.IF', 1, ContextInfo, '110476')
    # 用对手价 1 手买入开仓   
    buy_open('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    # 用指定价 3750 元 2 手买入开仓
    buy_open('IF1805.IF', 2, 'fix', 3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9

'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 20 ）期货买入平仓（平昨优先） buy_close_ydayfirst() 
用法： buy_close_ydayfirst(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货买入开仓，平昨优先
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
def handlebar(ContextInfo):
    # 按最新价 1 手买入平仓，平今优先  
    buy_close_tdayfirst('IF1805.IF', 1, ContextInfo, '110476')
    # 用对手价 1 手买入平仓，平今优先   
    buy_close_tdayfirst('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    # 用指定价 3750 元 2 手买入平仓，平今优先
    buy_close_tdayfirst('IF1805.IF', 2, 'fix', 3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9

返回： 无
示例： 
 
（ 21 ）期货卖出开仓 sell_open() 
用法： sell_open(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货卖出开仓
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
def handlebar(ContextInfo):
    # 按最新价 1 手买入平仓，平昨优先
    buy_close_ydayfirst('IF1805.IF', 1, ContextInfo, '110476')
    # 用对手价 1 手买入平仓，平昨优先   
    buy_close_ydayfirst('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    # 用指定价 3750 元 2 手买入平仓，平昨优先
    buy_close_ydayfirst('IF1805.IF', 2, 'fix', 3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9
def handlebar(ContextInfo):
    # 按最新价 1 手卖出开仓
    sell_open('IF1805.IF', 1, ContextInfo, '110476')
    
    # 用对手价 1 手卖出开仓   
    sell_open('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    # 用指定价 3750 元 2 手卖出开仓
    sell_open('IF1805.IF', 2, 'fix',3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9

（ 22 ）期货卖出平仓（平今优先） sell_close_tdayfirst() 
用法： sell_close_tdayfirst(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货卖出平仓，平今优先
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 23 ）期货卖出平仓（平昨优先） sell_close_ydayfirst() 
用法： sell_close_ydayfirst(stockcode, amount[, style, price], ContextInfo[, accId])
释义： 期货卖出平仓，平今优先
参数： 
stockcode ：代码， string ，如 'IF1805.IF'
amount ：手数， int
style ：下单选价类型， string ，默认为最新价 'LATEST' ，可选值：
'LATEST' ：最新
def handlebar(ContextInfo):
    # 按最新价下 1 手卖出平仓，平今优先
    sell_close_tdayfirst('IF1805.IF', 1, ContextInfo, '110476')
    
    # 用对手价 1 手卖出平仓，平今优先
    sell_close_tdayfirst('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    
    # 用指定价 3750 元 2 手卖出平仓，平今优先
    sell_close_tdayfirst('IF1805.IF', 1, 'fix', 3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9

'FIX' ：指定
'HANG' ：挂单
'COMPETE' ：对手
'MARKET' ：市价
'SALE1' ：卖一价
'BUY1' ：买一价
price ：价格， double
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
accId ：账号， string
返回： 无
示例： 
 
（ 24 ）获取两融负债合约明细 get_debt_contract() 
用法： get_debt_contract(accId)
释义： 获取信用账户负债合约明细
参数： 
accId ：信用账户
返回： list ， list 中放的是 PythonObj ，通过 dir(pythonobj) 可返回某个对象的属性列表。
示例： 
 
（ 25 ）获取两融担保标的明细 get_assure_contract() 
用法： get_debt_contract(accId)
释义： 获取信用账户担保合约明细
参数： 
def handlebar(ContextInfo): 
    # 按最新价 1 手卖出平仓，平昨优先 
    sell_close_ydayfirst('IF1805.IF', 1, ContextInfo, '110476')
    # 用对手价 1 手卖出平仓，平昨优先   
    sell_close_ydayfirst('IF1805.IF', 1, 'COMPETE', ContextInfo, '110476')
    # 用指定价 3750 元 2 手卖出平仓，平昨优先
    sell_close_ydayfirst('IF1805.IF', 2, 'fix', 3750, ContextInfo, '110476')
1
2
3
4
5
6
7
8
9
def handlebar(ContextInfo):
    obj_list = get_debt_contract('6000000248')
    for obj in obj_list:
        # 输出负债合约名
        print(obj.m_strInstrumentName)
1
2
3
4
5

accId ：信用账户
示例： 
 
（ 26 ）获取可融券明细 get_enable_short_contract() 
用法： get_enable_short_contract(accId)
释义： 获取信用账户当前可融券的明细
参数： 
accId ：信用账户
示例： 
 
（ 27 ）以限价单方式止损 / 止盈 stoploss_limitprice() 
用法：stoploss_limitprice(mode,accountid,stockcode,stopprice,limitprice,volume,orderderction)
释义： 以限价单方式止损 / 止盈
参数： 
mode ： int ，止损： 0 ，止盈： 1
accountid ： string ，账号
stockcode ： string ，需要止损的品种，代码 . 市场格式 (600000.SH,IF2003.IF)
stopprice ： double ，止损点
limitprice ： double ，限价单的指定价
volume ： int ，止损单的下单量，不填写时候默认平该品种全仓
orderderction ： string ，买卖方向，期货止损时候必须填写 "short" 对应平空， "long" 对应平多，品
种为股票时填写 ""
示例： 
 
def handlebar(ContextInfo): 
    obj_list = get_assure_contract('6000000248')
    for obj in obj_list:
        # 输出担保合约名
        print(obj.m_strInstrumentName) 
1
2
3
4
5
def handlebar(ContextInfo):
    obj_list = get_enable_short_contract('6000000248')
    for obj in obj_list:
        # 输出可融券合约名
        print(obj.m_strInstrumentName)
1
2
3
4
5
def handlebar(ContextInfo):
    stoploss_limitprice(0,'10455','IF2003.IF',3000.12,3000.05,1,"short")
1
2

（ 28 ）以市价单方式止损 / 止盈 stoploss_marketprice() 
用法： stoploss_marketprice(mode,accountid,stockcode,stopprice,volume,orderderction)
释义： 以市价单方式止损 / 止盈
参数： 
mode ： int ，止损： 0 ，止盈： 1
accountid ： string ，账号
stockcode ： string ，需要止损的品种，代码 . 市场格式 (600000.SH,IF2003.IF)
stopprice ： double ，止损点
volume ： int ，止损单的下单量，不填写时候默认平该品种全仓
orderderction ： string ，买卖方向，期货止损时候必须填写 "short" 对应平空， "long" 对应平多，品
种为股票时填写 ""
示例： 
 
（ 29 ）获取当日新股新债信息 get_ipo_data() 
用法： get_ipo_data([,type])
释义： 获取当日新股新债信息，返回结果为一个字典 , 包括新股申购代码 , 申购名称 , 最大申购数量 , 最小申
购数量等数据
参数： 
type ：为空时返回新股新债信息， type="STOCK" 时只返回新股申购信息， type="BOND" 时只返回
新债申购信息
示例： 
 
（ 30 ）获取账户新股申购额度 get_new_purchase_limit() 
用法： get_new_purchase_limit(accid)
释义： 获取账户新股申购额度，返回结果为一个字典 , 包括上海主板 , 深圳市场 , 上海科创版的申购额度
参数： 
accid ：资金账号，必须时股票账号或者信用账号
示例： 
def handlebar(ContextInfo):
    stoploss_marketprice(0,'10455','IF2003.IF',3000.12,1,"long")
1
2
def init(ContextInfo):
    ipoData=get_ipo_data()# 返回新股新债信息
    ipoStock=get_ipo_data("STOCK")# 返回新股信息
    ipoCB=get_ipo_data("BOND")# 返回新债申购信息
1
2
3
4
def init(ContextInfo):
    ContextInfo.accid="10000001"# 返回新股新债信息
    purchase_limit=get_new_purchase_limit(ContextInfo.accid)
1
2
3

（ 31 ）算法交易下单 algo_passorder() 
用法： algo_passorder(opType, orderType, accountid, orderCode, prType, modelprice, volume[, 
strategyName, quickTrade, userOrderId, userOrderParam], ContextInfo)
释义： 算法交易下单，此时使用交易面板 - 程序交易 - 函数交易 - 函数交易参数中设置的下单类型（普通交
易 , 算法交易 , 随机量交易）。
 如果函数交易参数使用未修改的默认值，此函数和 passorder 函数一致。
 设置了函数交易参数后，将会使用函数交易参数的超价等拆单参数 , 如果入参的 prType = -1 ，同
时将会使用函数交易参数的报价方式。
参数： 
opType ，操作类型，可选值：
期货六键：
0 ：开多
1 ：平昨多
2 ：平今多
3 ：开空
4 ：平昨空
5 ：平今空
期货四键：
6 ：平多 , 优先平今
7 ：平多 , 优先平昨
8 ：平空 , 优先平今
9 ：平空 , 优先平昨
期货两键：
10 ：卖出 , 如有多仓 , 优先平仓 , 优先平今 , 如有余量 , 再开空
11 ：卖出 , 如有多仓 , 优先平仓 , 优先平昨 , 如有余量 , 再开空
12 ：买入 , 如有空仓 , 优先平仓 , 优先平今 , 如有余量 , 再开多
13 ：买入 , 如有空仓 , 优先平仓 , 优先平昨 , 如有余量 , 再开多
14 ：买入 , 不优先平仓
15 ：卖出 , 不优先平仓
股票买卖：
23 ：股票买入，或沪港通、深港通股票买入
24 ：股票卖出，或沪港通、深港通股票卖出
融资融券：
27 ：融资买入
28 ：融券卖出
29 ：买券还券

30 ：直接还券
31 ：卖券还款
32 ：直接还款
33 ：信用账号股票买入
34 ：信用账号股票卖出
组合交易：
25 ：组合买入，或沪港通、深港通的组合买入
26 ：组合卖出，或沪港通、深港通的组合卖出
27 ：融资买入
28 ：融券卖出
29 ：买券还券
31 ：卖券还款
33 ：信用账号股票买入
33 ：信用账号股票卖出
40 ：期货组合开多
43 ：期货组合开空
46 ：期货组合平多 , 优先平今
47 ：期货组合平多 , 优先平昨
48 ：期货组合平空 , 优先平今
49 ：期货组合平空 , 优先平昨
期权交易：
50 ：买入开仓
51 ：卖出平仓
52 ：卖出开仓
53 ：买入平仓
54 ：备兑开仓
55 ：备兑平仓
56 ：认购行权
57 ：认沽行权
58 ：证券锁定
59 ：证券解锁
orderType ，下单方式
* 注：
一、期货不支持 1102 和 1202
二、对所有账号组的操作相当于对账号组里的每个账号做一样的操作，如 passorder(23, 
1202, 'testS', '000001.SZ', 5, -1, 50000, ContextInfo) ，意思就是对账号组 testS 里的所有账
号都以最新价开仓买入 50000 元市值的 000001.SZ 平安银行；
passorder(60,1101,"test",'510050.SH',5,-1,1,ContextInfo) 意思就是账号 test 申购 1 个单位
(900000 股 ) 的华夏上证 50ETF( 只申购不买入成分股 ) 。

可选值：
1101 ：单股、单账号、普通、股 / 手方式下单
1102 ：单股、单账号、普通、金额（元）方式下单（只支持股票）
1113 ：单股、单账号、总资产、比例 [0 ~ 1] 方式下单
1123 ：单股、单账号、可用、比例 [0 ~ 1] 方式下单
 
1201 ：单股、账号组（无权重）、普通、股 / 手方式下单
1202 ：单股、账号组（无权重）、普通、金额（元）方式下单（只支持股票）
1213 ：单股、账号组（无权重）、总资产、比例 [0 ~ 1] 方式下单
1223 ：单股、账号组（无权重）、可用、比例 [0 ~ 1] 方式下单
 
2101 ：组合、单账号、普通、按组合股票数量（篮子中股票设定的数量）方式下单 > 对应 
volume 的单位为篮子的份
2102 ：组合、单账号、普通、按组合股票权重（篮子中股票设定的权重）方式下单 > 对应 
volume 的单位为元
2103 ：组合、单账号、普通、按账号可用方式下单 > （底层篮子股票怎么分配？答：按可用
资金比例后按篮子中股票权重分配，如用户没填权重则按相等权重分配）只对股票篮子支持
 
2201 ：组合、账号组（无权重）、普通、按组合股票数量方式下单
2202 ：组合、账号组（无权重）、普通、按组合股票权重方式下单
2203 ：组合、账号组（无权重）、普通、按账号可用方式下单只对股票篮子支持
accountID ，资金账号
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：下单的账号 ID （可多个）或账号组名或套利组名（一个篮子一个套利账号，如 accountID = 
' 股票账户名 , 期货账号 ' ）
orderCode ，下单代码
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：
一、如果是单股或单期货、港股，则该参数填合约代码；
二、如果是组合交易 , 则该参数填篮子名称；
三、如果是组合套利，则填一个篮子名和一个期货合约名（如 orderCode = ' 篮子名 , 期货合
约名 ' ）
prType ，下单选价类型
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
可选值（特别的对于套利，这个 prType 只对篮子起作用，期货的采用默认的方式）：
-1 ：无效（实际下单时 , 需要用交易面板交易函数那设定的选价类型）
0 ：卖 5 价
1 ：卖 4 价
2 ：卖 3 价

3 ：卖 2 价
4 ：卖 1 价
5 ：最新价
6 ：买 1 价
7 ：买 2 价（组合不支持）
8 ：买 3 价（组合不支持）
9 ：买 4 价（组合不支持）
10 ：买 5 价（组合不支持）
11 ：（指定价）模型价（只对单股情况支持 , 对组合交易不支持）
12 ：涨跌停价
13 ：挂单价
14 ：对手价
27 ：市价即成剩撤 ( 仅对股票期权申报有效 )
28 ：市价即全成否则撤 ( 仅对股票期权申报有效 )
29 ：市价剩转限价 ( 仅对股票期权申报有效 )
42 ：最优五档即时成交剩余撤销申报 ( 仅对上交所申报有效 )
43 ：最优五档即时成交剩转限价申报 ( 仅对上交所申报有效 )
44 ：对手方最优价格委托 ( 仅对深交所申报有效 )
45 ：本方最优价格委托 ( 仅对深交所申报有效 )
46 ：即时成交剩余撤销委托 ( 仅对深交所申报有效 )
47 ：最优五档即时成交剩余撤销委托 ( 仅对深交所申报有效 )
48 ：全额成交或撤销委托 ( 仅对深交所申报有效 )
49 ：科创板盘后定价
price ，下单价格
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
* 注：
一、单股下单时， prType 是模型价 / 科创板盘后定价时 price 有效；其它情况无效；即单股
时， prType 参数为 11 ， 49 时被使用。 prType 参数不为 11 ， 49 时也需填写，填写的内容
可为 -1 ， 0 ， 2 ， 100 等任意数字；
二、组合下单时，是组合套利时， price 作套利比例有效，其它情况无效。
volume ，下单数量（股 / 手 / 元 / % ）
passorder(opType, orderType, accountID, orderCode, prType, price, volume, ContextInfo)
根据 orderType 值最后一位确定 volume 的单位：
单股下单时：
1 ：股 / 手
2 ：金额（元）
3 ：比例（ % ）
组合下单时：

1 ：按组合股票数量（份）
2 ：按组合股票权重（元）
3 ：按账号可用（ % ）
strategyName ， string ，自定义策略名，可缺省不写，用来区分 order 委托和 deal 成交来自不同
的策略。根据该策略名， get_trade_detail_data ， get_last_order_id 函数可以获取相应策略名对应
的委托或持仓结果。
* 注： strategyName 只对同账号本地客户端有效，即 strategyName 只对当前客户端下的单进行
策略区分，且该策略区分只能当前客户端使用。
quickTrade ， int ，设定是否立即触发下单，可选值：
0 ：否
1 ：是
 * 注： passorder 是对最后一根 K 线完全走完后生成的模型信号在下一根 K 线的第一个 tick 数据来时
触发下单交易；采用 quickTrade 参数设置为 1 时，非历史 bar 上执行时（ ContextInfo.is_last_bar()
为 True ），只要策略模型中调用到就触发下单交易。 quickTrade 参数设置为 2 时，不判断 bar 状
态，只要策略模型中调用到就触发下单交易，历史 bar 上也能触发下单，请谨慎使用。
userOrderId ， string ，用户自设委托 ID ，可缺省不写，写的时候必须把起前面的 strategyName 
和 quickTrade 参数也填写。对应 order 委托对象和 deal 成交对象中的 m_strRemark 属性，通过 
get_trade_detail_data 函数或委托主推函数 order_callback 和成交主推函数 deal_callback 可拿到
这两个对象信息。
userOrderParam ， string ，用户自定义交易参数 , 主要用于修改算法交易的参数。
m_eOrderType 普通交易 :0 算法交易 :1 、随机量交易 :2
m_ePriceType 报价方式 : 数值同 pyType
m_nMaxOrderCount 最大下单次数
m_bSinglePriceRange 波动区间是否单向
m_ePriceRangeType 波动区间类型按比例 :0, 按数值 1
m_dPriceRangeValue 波动区间 ( 按数值 )[0-1]
m_dPriceRangeRate 波动区间 ( 按比例 )
m_eSuperPriceType 单笔超价类型按比例 :0, 按数值 1
m_dSuperPriceRate 单笔超价 ( 按比例 )[0-1]
m_dSuperPriceValue 单笔超价 ( 按数值 )
m_eVolumeType 单笔基准量类型 ( 与界面列表的序号一致 ) 卖 1+2+3+4+5 量 :0, 卖 1+2+3+4
量 :1,... 目标剩余量 :11,
m_dVolumeRate 单比下单比率
m_nSingleNumMin 单比下单量最小值
m_nSingleNumMax 单比下单量最大值
m_nValidTimeElapse 有效持续时间
m_eUndealtEntrustRule 未成委托处理数值同 pyType
m_bUseTrigger 是否触价
m_eTriggerType 触价类型 : 最新价大于 :0, 最新价小于 :2
m_dTriggerPrice 触价价格

示例： 
 
（ 32 ）获取股票篮子 get_basket() 
用法： get_basket(basketName)
释义： 获取股票篮子
参数： 
basketName ：股票篮子名称 
示例： 
 
（ 33 ）设置股票篮子 set_basket() 
用法： set_basket(basketDict)
释义： 设置 passorder 的股票篮子 , 仅用于 passorder 进行篮子交易 , 设置成功后 , 用 get_basket 可以取出后
即可进行 passorder 组合交易下单
参数： 
basketDict ：股票篮子 {'name': 股票篮子名称 ,'stocks':[{'stock': 股票名称 ,'weight', 权重 ,'quantity':
数量 ,'optType': 交易类型 }]} 。 
示例： 
 
（ 34 ）获取未了结负债合约明细 get_unclosed_compacts() 
用法： get_unclosed_compacts(accountID,accountType)
释义： 获取未了结负债合约明细
参数： 
accountID ： str ，资金账号
accountType ： str ，账号类型
返回： 
list([ CStkUnclosedCompacts, ... ]) 负债列表， CStkUnclosedCompacts 属性如下：
m_strAccountID - str 账号 ID
userparam="m_nMaxOrderCount:20,m_eSuperPriceType:1,m_dSuperPriceValue:1.12"
algo_passorder(23,1101,ContextInfo.accid,'000001.SZ',11,15,1000,'',1,'strReMa
rk',userparam,ContextInfo);
# 表示修改算法交易的最大委托次数为 20, 单笔下单基准类型为按价格类型超价 , 单笔超价 1.12 元 , 其他参
数同函数交易参数中设置
1
2
3
print( get_basket('basket1') )1
print( get_basket('basket1') )1

m_nBrokerType - int 账号类型 (1- 期货账号 ,2- 股票账号 ,3- 信用账号 ,5- 期货期权账号 ,6- 股票期权账
号 ,7- 沪港通账号 ,11- 深港通账号 )
m_strExchangeID - str 市场
m_strInstrumentID - str 证券代码
m_eCompactType - int 合约类型 (32- 不限制 ,48- 融资 ,49- 融券 )
m_eCashgroupProp - int 头寸来源 (32- 不限制 ,48- 普通头寸 ,49- 专项头寸 )
m_nOpenDate - int 开仓日期 ( 如 '20201231')
m_nBusinessVol - int 合约证券数量
m_nRealCompactVol - int 未还合约数量
m_nRetEndDate - int 到期日 ( 如 '20201231')
m_dBusinessBalance - float 合约金额
m_dBusinessFare - float 合约息费
m_dRealCompactBalance - float 未还合约金额
m_dRealCompactFare - float 未还合约息费
m_dRepaidFare - float 已还息费
m_dRepaidBalance - float 已还金额
m_strCompactId - str 合约编号
m_strEntrustNo - str 委托编号
m_nRepayPriority - int 偿还优先级
m_strPositionStr - str 定位串
m_eCompactRenewalStatus - int 合约展期状态 (48- 可申请 ,49- 已申请 ,50- 审批通过 ,51- 审批不通
过 ,52- 不可申请 ,53- 已执行 ,54- 已取消 )
m_nDeferTimes - int 展期次数
示例： 
 
（ 35 ）获取已了结负债合约明细 get_closed_compacts() 
用法： get_closed_compacts(accountID,accountType)
释义： 获取已了结负债合约明细
参数： 
accountID ： str ，资金账号
accountType ： str ，账号类型
返回： 
list([ CStkUnclosedCompacts, ... ]) 负债列表， CStkUnclosedCompacts 属性如下：
get_unclosed_compacts('6000000248', 'CREDIT')1

m_strAccountID - str 账号 ID
m_nBrokerType - int 账号类型 (1- 期货账号 ,2- 股票账号 ,3- 信用账号 ,5- 期货期权账号 ,6- 股票期权账
号 ,7- 沪港通账号 ,11- 深港通账号 )
m_strExchangeID - str 市场
m_strInstrumentID - str 证券代码
m_eCompactType - int 合约类型 (32- 不限制 ,48- 融资 ,49- 融券 )
m_eCashgroupProp - int 头寸来源 (32- 不限制 ,48- 普通头寸 ,49- 专项头寸 )
m_nOpenDate - int 开仓日期 ( 如 '20201231')
m_nBusinessVol - int 合约证券数量
m_nRetEndDate - int 到期日 ( 如 '20201231')
m_nDateClear - int 了结日期 ( 如 '20201231')
m_nEntrustVol - int 委托数量
m_dEntrustBalance - float 委托金额
m_dBusinessBalance - float 合约金额
m_dBusinessFare - float 合约息费
m_dRepaidFare - float 已还息费
m_dRepaidBalance - float 已还金额
m_strCompactId - str 合约编号
m_strEntrustNo - str 委托编号
m_strPositionStr - str 定位串
示例： 
 
（ 36 ）获取沪深港通汇率数据 get_hkt_exchange_rate() 
用法： get_hkt_exchange_rate(accountID,accountType)
释义： 获取沪深港通汇率数据
参数： 
accountID ： string, 账号；
accountType:string, 账号类型 , 必须填 HUGANGTONG 或者 SHENGANGTONG
返回： 
dict, 字段释义：
bidReferenceRate: 买入参考汇率
askReferenceRate: 卖出参考汇率
dayBuyRiseRate: 日间买入参考汇率浮动比例
get_closed_compacts('6000000248', 'CREDIT')1

daySaleRiseRate: 日间卖出参考汇率浮动比例
示例： 
 
（ 37 ）取可融券明细 get_enable_short_contract() 
用法： get_enable_short_contract(accountID)
释义： 取可融券明细
参数： 
accountID ： string, 账号
返回： list,list 中放的是 PythonObj, 通过 dir(pythonobj) 可返回某个对象的属性列表
示例： 
 
（ 38 ）取期权标的持仓 get_option_subject_position() 
用法：get_option_subject_position(accountID)
释义： 取期权标的持仓
参数： 
accountID ： string, 账号
返回： list,list 中放的是 PythonObj, 通过 dir(pythonobj) 可返回某个对象的属性列表
示例： 
 
（ 39 ）取期权组合持仓 get_comb_option() 
用法： get_comb_option(accountID)
释义： 取期权组合持仓
参数： 
accountID ： string, 账号
def init(ContextInfo):
      data=get_hkt_exchange_rate('6000000248','HUGANGTONG')
      print(data)
1
2
3
def handlebar(ContextInfo):
    obj_list = get_enable_short_contract('6000000248')
    for obj in obj_list:
        print( obj.m_strInstrumentName)
1
2
3
4
data=get_option_subject_position('880399990383')
print(len(data));
forobjindata:
    print(obj.m_strInstrumentName,obj.m_lockVol,obj.m_coveredVol);
1
2
3
4

返回： list,list 中放的是 PythonObj, 通过 dir(pythonobj) 可返回某个对象的属性列表
示例： 
 
（ 40 ）构建期权组合持仓 make_option_combination() 
用法： 
make_option_combination(combType,orderCodeDict,modelVolume,accountID,strategyName,user
OrderId,ContextInfo)
释义： 构建期权组合持仓
参数： 
combType ：组合策略类型
50: 认购牛市价差策略
51: 认沽熊市价差策略
52: 认沽牛市价差策略
53: 认购熊市价差策略
54: 跨式空头
55: 宽跨式空头
56: 保证金开仓转备兑开仓
57: 备兑开仓转保证金开仓
orderCodeDict ：期权组合， {option:holdType} 。其中， option: 期权代码 , 格式如
10000001.SHO ， holdType:
48: 权利
49: 义务
50: 备兑
modelVolume ：下单量
strategyName ：策略名
userOrderId ：投资备注
示例： 
obj_list=get_comb_option('880399990383')
print(len(obj_list));
forobjinobj_list:
   
 print(obj.m_strCombCodeName,obj.m_strCombID,obj.m_nVolume,obj.m_nFrozenVolum
e)
1
2
3
4

（ 41 ）解除期权组合持仓 release_option_combination() 
用法： release_option_combination(combID,accountID,strategyName,userOrderId,contextInfo)
释义： 解除期权组合持仓
参数： 
combID: 持仓中期权组合编码
accountID ： string, 账号
strategyName:string, 策略名
userOrderId:string, 投资备注
示例： 
 
3.2.5. 成交回报实时主推函数 
* 注：成交回报实时主推函数仅在实盘运行模式下生效。
（ 1 ）资金账号状态变化主推 account_callback() 
用法： account_callback(ContextInfo, accountInfo)
释义： 当资金账号状态有变化时，运行这个函数
参数： 
ContextInfo ：特定对象 
accountInfo ：资金账号对象，可对应查看5.3. 附录 3 交易函数内含属性说明
返回： 无
示例： 
ContextInfo.accid='880399990383'
make_option_combination(50,
{'10003006.SHO':48,'10003259.SHO':49},1,ContextInfo.accid,'stragegyName','str
Remark',ContextInfo);
# 第一个参数 50 为认购牛市价差策略
# 第二个参数 10003006.SHO(50ETF 购 6 月 3400),48( 权利仓 )10003259.SHO(50ETF 购 6 月
4400)49( 义务仓 )
#50ETF 购 6 月 3400/50ETF 购 6 月 4400g 构建认购牛市价差策略
1
2
3
4
5
ContextInfo.accid='880399990383'
release_option_combination('V950034404',ContextInfo.accid,'strategyName','use
rOrderId',ContextInfo)
# 解除组合号码为 V950034404 的组合期权 ( 同组合策略持仓中的组合号码 )
1
2
3

（ 2 ）账号委托状态变化主推 order_callback() 
用法： order_callback(ContextInfo, orderInfo)
释义： 当账号委托状态有变化时，运行这个函数
参数： 
ContextInfo ：特定对象 
orderInfo ：委托账号对象，可对应查看5.3. 附录 3 交易函数内含属性说明
返回： 无
示例： 
 
（ 3 ）账号成交状态变化主推 deal_callback() 
用法： deal_callback(ContextInfo, dealInfo)
释义： 当账号成交状态有变化时，运行这个函数
参数： 
ContextInfo ：特定对象 
dealInfo ：资金账号对象，可对应查看5.3. 附录 3 交易函数内含属性说明
返回： 无
示例： 
def init(ContextInfo):
    # 设置对应的资金账号
    ContextInfo.set_account('6000000058')
def handlebar(ContextInfo):
    pass
def account_callback(ContextInfo, accountInfo):
    print('accountInfo')
    print(accountInfo.m_strStatus) # m_strStatus 为资金账号的属性之一，表示资金账
号的状态
1
2
3
4
5
6
7
8
9
10
def init(ContextInfo):
    # 设置对应的资金账号
    ContextInfo.set_account('6000000058')
    
def handlebar(ContextInfo):
    pass
def order_callback(ContextInfo, orderInfo):
    print('orderInfo')
1
2
3
4
5
6
7
8
9

（ 4 ）账号持仓状态变化主推 position_callback() 
用法： position_callback(ContextInfo, positonInfo)
释义： 当账号持仓状态有变化时，运行这个函数
参数： 
ContextInfo ：特定对象 
positonInfo ：资金账号对象，可对应查看5.3. 附录 3 交易函数内含属性说明
返回： 无
示例： 
 
（ 5 ）账号异常下单主推 orderError_callback() 
用法： orderError_callback(ContextInfo,orderArgs,errMsg)
释义： 当账号下单异常时，运行这个函数
参数： 
ContextInfo ：特定对象 
orderArgs ：下单参数，可对应查看 [5.3. 附录 3 交易函数内含属性说明 ]
errMsg ：错误信息
返回： 无
示例： 
def init(ContextInfo):
    # 设置对应的资金账号
    ContextInfo.set_account('6000000058')
    
def handlebar(ContextInfo):
    pass
def deal_callback(ContextInfo, dealInfo):
    print('dealInfo')
1
2
3
4
5
6
7
8
9
def init(ContextInfo):
    # 设置对应的资金账号
    ContextInfo.set_account('6000000058')
    
def handlebar(ContextInfo):
    pass
def position_callback(ContextInfo, positonInfo):
    print('positonInfo')
1
2
3
4
5
6
7
8
9

（ 6 ）查询信用账户明细 query_credit_account() 
用法： query_credit_account(accountId,seq,ContextInfo)
释义： 查询信用账户明细。本函数只能有一个查询，如果前面的查询正在进行中，后面的查询将会提前
返回。本函数从服务器查询数据，建议平均查询时间间隔 30s 一次，不可频繁调用。
参数： 
accountId ： string ，查询的两融账号
seq ： int ，查询序列号，建议输入唯一值以便对应结果回调
示例： 
 
（ 7 ）查询信用账户明细回调 credit_account_callback() 
用法： credit_account_callback(ContextInfo,seq,result)
释义： 查询信用账户明细回调
参数： 
ContextInfo ：策略模型全局对象
seq:query_credit_account 时输入查询 seq
result: 查询到的结果
 
（ 8 ）查询两融最大可下单量 query_credit_opvolume() 
用法： query_credit_opvolume(accountId,stockCode,opType,prType,price,seq,ContextInfo)
释义： 查询两融最大可下单量。本函数一次最多查询 200 只股票的两融最大下单量，且同时只能有一个
查询 , 如果前面的查询正在进行中 , 后面的查询将会提前返回。本函数从服务器查询数据 , 建议平均查询时
间间隔 30s 一次 , 不可频繁调用。
参数： 
accountId: 查询的两融账号
stockCode: 需要查询的股票代码 ,stockCode 为 List 的类型 , 可以查询多只股票
opType: 两融下单类型 , 同 passorder 的下单类型
def init(ContextInfo):
    # 设置对应的资金账号
    ContextInfo.set_account('6000000058')
    
def handlebar(ContextInfo):
    pass
def position_callback(ContextInfo,orderArgs,errMsg):
    print('orderArgs')
    print(errMsg)
1
2
3
4
5
6
7
8
9
10
query_credit_account(ContextInfo.accid,int(time.time()),ContextInfo);
 # 查询 accid 账号某时刻资金账号详细
1
2

prType: 报单价格类型 , 同 passorder 的报价类型
seq: 查询序列号 ,int 型，建议输入唯一值以便对应结果回调
price: 报价 ( 非限价单可以填任意值 ), 如果 stockCode 为 List 类型 , 报价也需要为长度相同的 List
示例： 
 
（ 9 ）查询两融最大可下单量的回调 credit_opvolume_callback() 
用法： credit_opvolume_callback(ContextInfo,accid,seq,ret,result)
释义： 查询两融最大可下单量的回调。
参数： 
ContextInfo ：策略模型全局对象
accid: 查询的账号
seq:query_credit_opvolume 时输入查询 seq
ret: 查询结果状态。正常返回 :1, 正在查询中 -1, 输入账号非法 :-2, 输入查询参数非法 :-3, 超时等服务器
返回报错 :-4
result: 查询到的结果
示例： 
 
3.2.6. 引用函数 
* 注：以下函数均支持回测和实盘 / 模拟运行模式。
（ 1 ）获取扩展数据 ext_data() 
用法： ext_data(extdataname, stockcode, deviation, ContextInfo)
释义： 获取扩展数据
参数： 
extdataname ： string ，扩展数据名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
deviation ： number ， K 线偏移，可取值：
0 ：不偏移
N ：向右偏移 N
-N ：向左偏移 N
query_credit_opvolume(ContextInfo.accid,'600000.SH',33,11,10,int(time.time())
,ContextInfo);
# 查询 accid 账号担保品买入 600000.SH 限价 10 元的最大可下单量
query_credit_opvolume(ContextInfo.accid,['600000.SH','000001.SZ'],33,11,
[10,20],int(time.time()),ContextInfo);
# 查询 accid 账号担保品买入 600000.SH 限价 10 元 ,000001.SZ 担保品买入限价 20 元的最大可下单量
1
2
3
4
query_credit_account(ContextInfo.accid,int(time.time()),ContextInfo);
 # 查询 accid 账号某时刻资金账号详细
1
2

ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： number
示例： 
 
（ 2 ）获取引用的扩展数据的数值在所有品种中的排名 ext_data_rank() 
用法： ext_data_rank(extdataname, stockcode, deviation, ContextInfo)
释义： 获取引用的扩展数据的数值在所有品种中的排名
参数： 
extdataname ： string ，扩展数据名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
deviation ： number ， K 线偏移，可取值：
0 ：不偏移
N ：向右偏移 N
-N ：向左偏移 N
ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： number
示例： 
 
（ 3 ）获取引用的扩展数据的数值在指定时间区间内所有品种中的排名
ext_data_rank_range()
 
用法： ext_data_rank_range(extdataname, stockcode, begintime, endtime, ContextInfo)
释义： 获取引用的扩展数据的数值在指定时间区间内所有品种中的排名
参数： 
extdataname ： string ，扩展数据名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
begintime ： string ，区间的起始时间（包括该时间点在内）格式为 '2016-08-02 12:12:30' 
endtime ： string ，区间的结束时间（包括该时间点在内）格式为 '2017-08-02 12:12:30' 
ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： pythonDict
示例： 
def handlebar(ContextInfo):
    print(ext_data('mycci', '600000.SH', 0, ContextInfo))
1
2
def handlebar(ContextInfo):
    print(ext_data_rank('mycci', '600000.SH', 0, ContextInfo))
1
2

（ 4 ）获取扩展数据在指定时间区间内的值 ext_data_range() 
用法： ext_data_range(extdataname, stockcode, begintime, endtime, ContextInfo)
释义： 获取扩展数据在指定时间区间内的值
参数： 
extdataname ： string ，扩展数据名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
begintime ： string ，区间的起始时间（包括该时间点在内）格式为 '2016-08-02 12:12:30' 
endtime ： string ，区间的结束时间（包括该时间点在内）格式为 '2017-08-02 12:12:30' 
ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： pythonDict
示例： 
 
（ 5 ）获取因子数据 get_factor_value() 
用法： get_factor_value(factorname, stockcode, deviation, ContextInfo)
释义： 获取因子数据
参数： 
factorname ： string ，因子名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
deviation ： number ， K 线偏移， 0 不偏移， N 向右偏移 N ， -N 向左偏移 N 
ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： number
示例： 
 
（ 6 ）获取引用的因子数据的数值在所有品种中排名 get_factor_rank() 
用法： get_factor_rank(factorname, stockcode, deviation, ContextInfo)
释义： 获取引用的因子数据的数值在所有品种中排名
参数： 
def handlebar(ContextInfo):
    print(ext_data_rank_range('mycci', '600000.SH', '2016-08-02 12:12:30', 
'2017-08-02 12:12:30', ContextInfo))
1
2
def handlebar(ContextInfo):
    print(ext_data_range('mycci', '600000.SH', '2016-08-02 12:12:30', '2017-
08-02 12:12:30', ContextInfo))
1
2
def handlebar(ContextInfo):
    print(get_factor_value('zzz', '600000.SH', 0, ContextInfo))
1
2

factorname ： string ，因子名
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH'
deviation ： number ， K 线偏移， 0 不偏移， N 向右偏移 N ， -N 向左偏移 N 
ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： number
示例： 
 
（ 7 ）获取引用的 VBA 模型运行的结果 call_vba() 
用法： call_vba(factorname, stockcode, [period, dividend_type, barpos, ]ContextInfo)
释义： 获取引用的 VBA 模型运行的结果
* 注：使用该函数时需补充好本地 K 线或分笔数据
参数： 
factorname ： string ，模型名及引用变量，如 'MA.ma1'
stockcode ： string ，形式如 'stkcodemarket' ，如 '600000.SH '
period ： string ， K 线周期类型，可缺省，默认为当前主图周期线型，可选值：
'tick' ：分笔线
'1d' ：日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线
dividend_type ： string ，除复权，可缺省，默认当前图复权方式，可选值：
'none' ：不复权
'front' ：向前复权
'back' ：向后复权
'front_ratio' ：等比向前复权
'back_ratio' ：等比向后复权 
barpos ： number ，对应 bar 下标，可缺省，默认当前主图调用到的 bar 的对应下标
def handlebar(ContextInfo):
    print(get_factor_rank('zzz', '600000.SH', 0, ContextInfo))
1
2

ContextInfo ： pythonObj ， Python 对象，这里必须是 ContextInfo
返回： number
示例： 
 
（ 8 ）调用 VBA 组合模型 call_formula() 
用法： 
call_formula(formulaName,code,period,divideType,basket,argsDict,startime="",endTime="",count
=-1)
释义： python 调用组合模型，返回 GruopModelInfo 结构体
* 注：使用该函数时需补充好本地 K 线或分笔数据
参数： 
formulaName ： string ，组合模型名
stockcode ： string ，组合模型主图代码形式如 'stkcode.market', 如 '000300.SH'
period ： string ， K 线周期类型，可缺省，默认为当前主图周期线型，可选值：
'tick' ：分笔线
'1d' ：日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线
dividend_type ： string ，除复权，可缺省，默认当前图复权方式，可选值：
'none' ：不复权
'front' ：向前复权
'back' ：向后复权
'front_ratio' ：等比向前复权
'back_ratio' ：等比向后复权 
basket ： dict ，组合模型的股票池权重，形如 {'SH600000':0.06,'SZ000001':0.01}
def handlebar(ContextInfo):
    call_vba('MA.ma1', '600036.SH', ContextInfo)
1
2

argsDict ： dict ，组合模型的入参， { 参数名 : 参数值 } ，形如 {'a':1}
startTime ： string ，缺失参数，组合模型运行起始时间，形如 :'20200101'
endTime ： string ，缺失参数，组合模型运截止时间，形如 :'20200101'
count ： int ，缺省参数，组合模型运行范围为向前 count 根 bar
返回： GruopModelInfo 结构体。 GruopModelInfo.result 为当前模型的运行结果，运行
GruopModelInfo.unsubscribe() 会取消组合模型的运行， GruopModelInfo 随着 python 的析构也会调用
取消组合模型运行。
示例： 
 
3.2.7. 绘图函数 
* 注：以下函数均支持回测和实盘 / 模拟运行模式。
（ 1 ）在界面上画图 ContextInfo.paint() 
用法： ContextInfo.paint(name, value, index, line_style, color = 'white', limit = '')
释义： 在界面上画图
参数： 
name ： string ，需显示的指标名 
value ： number ，需显示的数值 
index ： number ，显示索引位置，填 -1 表示按主图索引显示 
line_style ： number ，线型，可取值：
0 ：曲线
42 ：柱状线 
color ： string ，颜色（不填默认为白色）目前支持以下几种颜色： 
blue ：蓝
brown ：棕
cyan ：蓝绿
green ：绿
magenta ：品红
red ：红
white ：白
yellow ：黄 
def handlebar(ContextInfo):
    basket={'SH600000':0.06,'SZ000001':0.01}
    argsDict={'a':100}
   
 groupModelInfo=call_formula('testGroupModel','000300.SH',basket,argsDict);
    print(groupModelInfo.result);
    groupModelInfo.unsubscribe();# 取消组合模型运行
1
2
3
4
5
6
