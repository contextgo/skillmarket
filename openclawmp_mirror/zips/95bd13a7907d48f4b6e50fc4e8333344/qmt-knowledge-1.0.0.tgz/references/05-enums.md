# 枚举常量与状态码

m_strDateClear: 了结日期
m_strPositionStr: 定位串
m_dPrice: 最新价
m_nOpenTime: 合约开仓时间
m_nCancelVol: 合约撤单数量
m_eCashgroupProp: EXTCompactBrushSource ，头寸来源
m_dUnRepayBalance: 负债金额 
m_nRepayPriority: 偿还优先级
m_dRealDefaultInterest: 未还罚息
m_dOtherRealCompactBalance: 其他负债合约金额
m_dOtherRealCompactInterest: 其他负债合约利息金额
 
5.3.8. StkSubjects 担保标的对象 
m_nPlatformID: 平台号 // 目前主要用于区别不同的行情，根据此来选择对应行情
m_strBrokerID: 经纪公司编号
m_strBrokerName: 证券公司，期货公司，经纪公司，证券公司
m_strExchangeID: 交易所 
m_strInstrumentID: 证券代码 
m_strInstrumentName: 股票名称 
m_dSloRatio: 融券保证金比例
m_eSloStatus: EXTSubjectsStatus ，融券状态
m_nEnableAmount: 融券可融数量 
m_dFinRatio: 融资保证金比例
m_eFinStatus: EXTSubjectsStatus ， 融资状态 
m_dAssureRatio: 担保品折算比例 
m_eAssureStatus: EXTSubjectsStatus ，是否可做担保 
m_dFinRate: 融资日利率
m_dSloRate: 融券日利率
m_dFinPenaltyRate: 融资日罚息利率 
m_dSloPenaltyRate: 融券日罚息利率 
m_strAccountID: 资金账号，账号，账号，资金账号
m_eAssureUseSloCashStatus: EXTSpecialAssure ，是否可以用融券资金买入

5.3.9 PassorderArguments 下单函数参数对象 
opType: passorder 的 opType 参数
orderType: passorder 的 orderType 参数
accountID: 资金账号
orderCode: 交易代码
prType: passorder 的 prType ，价格类型
modelPrice: 下单价格
modelVolume: 下单量（手数或股数）
strategyName: 策略名 _ &&& _ 投资备注
5.3.10 CTaskDetail 任务对象 
m_nTaskId ：任务号
m_eStatus ：任务状态 ETaskStatus 类型 , 见 ETaskStatus 说明
m_strMsg ：任务状态消息
m_startTime ： 任务开始时间 , 时间戳类型
m_endTime ：任务结束时间 , 时间戳类型
m_cancelTime ： 任务取消时间
m_nBusinessNum ： 已成交量
m_bServerRun ： 是否服务器运行 
m_nGroupId ： 组合 Id 
m_stockCode ： 下单代码 ( 不针对组合下单 )
m_strAccountID ： 下单用户 ( 单用户下单 )
m_eOperationType ： 下单操作：开平、多空 ……EOperationType 类型 , 见 EOperationType 说明
m_eOrderType ： 算法交易、普通交易 EOrderType 类型 , 见 EOrderType 说明
m_ePriceType ： 报价方式：对手、最新 …… EPriceType 类型见 EPriceType 说明
m_dFixPrice ： 委托价
m_nNum ： 委托量
5.3.11 CCreditDetail 两融资金信息 ( 查柜台 ) 
m_dPerAssurescaleValue: 维持担保比例
m_dBalance: 总资产
m_dTotalDebt: 总负债 
m_dAssureAsset: 净资产 
m_dMarketValue: 总市值
m_dEnableBailBalance: 可用保证金

m_dAvailable: 可用资金
m_dFinDebt: 融资负债
m_dFinDealAvl: 融资本金 
m_dFinFee: 融资息费 
m_dSloDebt: 融券负债 
m_dSloMarketValue: 融券市值 
m_dSloFee: 融券息费 
m_dOtherFare: 其它费用 
m_dFinMaxQuota: 融资授信额度
m_dFinEnableQuota: 融资可用额度 
m_dFinUsedQuota: 融资冻结额度
m_dSloMaxQuota: 融券授信额度 
m_dSloEnableQuota: 融券可用额度
m_dSloUsedQuota: 融券冻结额度
m_dSloSellBalance : 融券卖出资金
m_dUsedSloSellBalance: 已用融券卖出资金 
m_dSurplusSloSellBalance: 剩余融券卖出资金 
m_dStockValue: 股票市值
m_dFundValue: 基金市值
error: 错误信息
 
5.3.12 CLockPosition 期权标的持仓 
 m_strAccountID 账号名
 
 m_strExchangeID 交易所 
 
 m_strExchangeName 交易所名
 
 m_strInstrumentID 标的代码
 
 m_strInstrumentName 标的名称
 
 m_totalVol   总持仓量
 
 m_lockVol   可用锁定量
 
 m_unlockVol 未锁定量
 
 m_coveredVol 备兑量
 
 m_nOnRoadcoveredVol 在途备兑量
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

5.3.13 CStkOptCombPositionDetail 期权组合持仓 
5.4. 附录 4 对象中属性一些需要的状态字段释义 
4-1.enum_EEntrustBS // 买卖方向
ENTRUST_BUY: 48 // 买入，多
ENTRUST_SELL: 49 // 卖出，空
ENTRUST_PLEDGE_IN: 81 // 质押入库
ENTRUST_PLEDGE_OUT: 66 // 质押出库
 
 m_strAccountID 账号名
 
 m_strExchangeID 交易所 
 
 m_strExchangeName 交易所名
 
 m_strContractAccount 合约账号
 
 m_strCombID 组合编号
 
 m_strCombCode 组合策略编码
 
 m_strCombCodeName 组合策略名称
 
 m_nVolume 持仓量
 
 m_nFrozenVolume 冻结数量
 
 m_nCanUseVolume 可用数量
 
 m_strFirstCode 合约一
 
 m_eFirstCodeType 合约一类型   认购 :48, 认沽 :49
 
 m_strFirstCodeName 合约一名称
 
 m_eFirstCodePosType 合约一持仓类型 权利 :48, 义务 :49, 备兑 :50
 
 m_nFirstCodeAmt 合约一数量
 
 m_strSecondCode 合约二
 
 m_eSecondCodeType 合约二类型 认购 :48, 认沽 :49
 
 m_strSecondCodeName 合约二名称
 
 m_eSecondCodePosType 合约二持仓类型 权利 :48, 义务 :49, 备兑 :50
 
 m_nSecondCodeAmt 合约二数量
 
 m_dCombBailBalance 占用保证金
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41

4-2.EEntrustSubmitStatus// 报单状态
48 // 已经提交
49 // 撤单已经提交
50 // 修改已经提交
51 // 已经接受
52 // 报单已经被拒绝
53 // 撤单已经被拒绝
54 // 改单已经被拒绝
 
4-3.enum_EEntrustTypes // 委托类型
ENTRUST_BUY_SELL: 48 // 买卖
ENTRUST_QUERY: 49 // 查询
ENTRUST_CANCE: 50 // 撤单
ENTRUST_APPEND: 51 // 补单
ENTRUST_COMFIRM: 52 // 确认
ENTRUST_BIG: 53 // 大宗
ENTRUST_FIN: 54 // 融资委托
ENTRUST_SLO: 55 // 融券委托
ENTRUST_CLOSE: 56 // 信用平仓
ENTRUST_CREDIT_NORMAL: 57 // 信用普通委托
ENTRUST_CANCEL_OPEN: 58 // 撤单补单
ENTRUST_TYPE_OPTION_EXERCISE: 59 // 行权
ENTRUST_TYPE_OPTION_SECU_LOCK: 60 // 锁定
ENTRUST_TYPE_OPTION_SECU_UNLOCK: 61 // 解锁
ENTRUST_QUOTATION_REPURCHASE:62; // 报价回购
ENTRUST_TYPE_OPTION_ABANDON : 63; // 放弃行权
ENTRUST_AGREEMENT_REPURCHASE: 64; // 协议回购
ENTRUST_TYPE_OPTION_COMB_EXERCISE: 65; // 组合行权
ENTRUST_TYPE_OPTION_BUILD_COMB_STRATEGY : 66; // 构建组合策略持仓
ENTRUST_TYPE_OPTION_RELEASE_COMB_STRATEGY: 67; // 解除组合策略持仓
ENTRUST_TYPE_LMT_LOAN: 68; // 转融通出借
ENTRUST_TYPE_LMT_LOAN_DEFER: 69; // 转融通出借展期
ENTRUST_TYPE_LMT_LOAN_FINISH_AHEAD: 70; // 转融通出借提前了结
ENTRUST_CROSS_MARKET_IN 71; // 跨市场场内

ENTRUST_CROSS_MARKET_OUT 72; // 跨市场场外
4-4.enum_EEntrustStatus // 委托状态
ENTRUST_STATUS_WAIT_END: 0 // 委托状态已经在 ENTRUST_STATUS_CANCELED 或以上，
但是成交数额还不够，等成交回报来
ENTRUST_STATUS_UNREPORTED: 48 // 未报
ENTRUST_STATUS_WAIT_REPORTING: 49 // 待报
ENTRUST_STATUS_REPORTED: 50 // 已报
ENTRUST_STATUS_REPORTED_CANCEL: 51 // 已报待撤
ENTRUST_STATUS_PARTSUCC_CANCEL: 52 // 部成待撤
ENTRUST_STATUS_PART_CANCEL: 53 // 部撤
ENTRUST_STATUS_CANCELED: 54 // 已撤
ENTRUST_STATUS_PART_SUCC: 55 // 部成
ENTRUST_STATUS_SUCCEEDED: 56 // 已成
ENTRUST_STATUS_JUNK: 57 // 废单
ENTRUST_STATUS_DETERMINED: 86 // 已确认
ENTRUST_STATUS_UNKNOWN: 255 // 未知
 
4-5.enum_EHedge_Flag_Type
HEDGE_FLAG_SPECULATION: 49 // 投机
HEDGE_FLAG_ARBITRAGE: 50 // 套利
HEDGE_FLAG_HEDGE: 51 // 套保
 
4-6.enum_EFutureTradeType // 成交类型
FUTRUE_TRADE_TYPE_COMMON: 48 // 普通成交
FUTURE_TRADE_TYPE_OPTIONSEXECUTION: 49 // 期权成交， ptionsExecution
FUTURE_TRADE_TYPE_OTC: 50 //OTC 成交
FUTURE_TRADE_TYPE_EFPDIRVED: 51 // 期转现衍生成交
FUTURE_TRADE_TYPE_COMBINATION_DERIVED: 52 // 组合衍生成交
 
4-7.enum_EBrokerPriceType // 价格类型
BROKER_PRICE_ANY: 49 // 市价
BROKER_PRICE_LIMIT: 50 // 限价
BROKER_PRICE_BEST: 51 // 最优价
BROKER_PRICE_PROP_ALLOTMENT: 52 // 配股
BROKER_PRICE_PROP_REFER: 53 // 转托

BROKER_PRICE_PROP_SUBSCRIBE: 54 // 申购
BROKER_PRICE_PROP_BUYBACK: 55 // 回购
BROKER_PRICE_PROP_PLACING: 56 // 配售
BROKER_PRICE_PROP_DECIDE: 57 // 指定
BROKER_PRICE_PROP_EQUITY: 58 // 转股
BROKER_PRICE_PROP_SELLBACK: 59 // 回售
BROKER_PRICE_PROP_DIVIDEND: 60 // 股息
BROKER_PRICE_PROP_SHENZHEN_PLACING: 68 // 深圳配售确认
BROKER_PRICE_PROP_CANCEL_PLACING: 69 // 配售放弃
BROKER_PRICE_PROP_WDZY: 70 // 无冻质押
BROKER_PRICE_PROP_DJZY: 71 // 冻结质押
BROKER_PRICE_PROP_WDJY: 72 // 无冻解押
BROKER_PRICE_PROP_JDJY: 73 // 解冻解押
BROKER_PRICE_PROP_ETF: 81 //ETF 申购
BROKER_PRICE_PROP_VOTE: 75 // 投票
BROKER_PRICE_PROP_YYSGYS: 92 // 要约收购预售
BROKER_PRICE_PROP_YSYYJC: 77 // 预售要约解除
BROKER_PRICE_PROP_FUND_DEVIDEND // 基金设红
BROKER_PRICE_PROP_FUND_ENTRUST: 79 // 基金申赎
BROKER_PRICE_PROP_CROSS_MARKET: 80 // 跨市转托
BROKER_PRICE_PROP_EXERCIS: 83 // 权证行权
BROKER_PRICE_PROP_PEER_PRICE_FIRST: 84 // 对手方最优价格
BROKER_PRICE_PROP_L5_FIRST_LIMITPX: 85 // 最优五档即时成交剩余转限价
BROKER_PRICE_PROP_MIME_PRICE_FIRST: 86 // 本方最优价格
BROKER_PRICE_PROP_INSTBUSI_RESTCANCEL: 87 // 即时成交剩余撤销
BROKER_PRICE_PROP_L5_FIRST_CANCEL: 88 // 最优五档即时成交剩余撤销
BROKER_PRICE_PROP_FULL_REAL_CANCEL: 89 // 全额成交并撤单 
BROKER_PRICE_PROP_DIRECT_SECU_REPAY: 101 // 直接还券
BROKER_PRICE_PROP_FUND_CHAIHE: 90 // 基金拆合
BROKER_PRICE_PROP_DEBT_CONVERSION: 91 // 债转股
BROKER_PRICE_BID_LIMIT: 92 // 港股通竞价限价
BROKER_PRICE_ENHANCED_LIMIT: 93 // 港股通增强限价
BROKER_PRICE_RETAIL_LIMIT: 94 // 港股通零股限价
BROKER_PRICE_PROP_INCREASE_SHARE: 'j' // 增发

BROKER_PRICE_PROP_COLLATERAL_TRANSFER: 107 // 担保品划转
BROKER_PRICE_PROP_NEEQ_PRICING: 'w' // 定价（全国股转 - 挂牌公司交易 - 协议转让）
BROKER_PRICE_PROP_NEEQ_MATCH_CONFIRM: 'x' // 成交确认（全国股转 - 挂牌公司交易 - 
协议转让）
BROKER_PRICE_PROP_NEEQ_MUTUAL_MATCH_CONFIRM: 'y' // 互报成交确认（全国股转 - 挂
牌公司交易 - 协议转让）
BROKER_PRICE_PROP_NEEQ_LIMIT: 'z' // 限价（用于挂牌公司交易 - 做市转让 - 限价买卖和两
网及退市交易 - 限价买卖）
 
4-8.enum_EOffset_Flag_Type // 操作类型
EOFF_THOST_FTDC_OF_INVALID: -1
EOFF_THOST_FTDC_OF_Open: 48 // 买入，开仓
EOFF_THOST_FTDC_OF_Close: 49 // 卖出，平仓
EOFF_THOST_FTDC_OF_ForceClose: 50 // 强平
EOFF_THOST_FTDC_OF_CloseToday: 51 // 平今
EOFF_THOST_FTDC_OF_CloseYesterday: 52 // 平昨
EOFF_THOST_FTDC_OF_ForceOff: 53 // 强减
EOFF_THOST_FTDC_OF_LocalForceClose: 54 // 本地强平
EOFF_THOST_FTDC_OF_PLEDGE_IN: 81 // 质押入库
EOFF_THOST_FTDC_OF_PLEDGE_OUT: 66 // 质押出库
EOFF_THOST_FTDC_OF_ALLOTMENT: 67 // 股票配股
 
4-9.enum EXTSubjectsStatus // 融资融券状态
SUBJECTS_STATUS_NORMAL: 48 // 正常
SUBJECTS_STATUS_PAUSE: 49 // 暂停
SUBJECTS_STATUS_NOT: 50 // 作废
 
4-10.enum EXTSloTypeQueryMode // 查询类型
XT_SLOTYPE_QUERYMODE_NOMARL: 48 // 普通
XT_SLOTYPE_QUERYMODE_SPECIAL: 49 // 专项
 
4-11.enum EXTCompactType // 合约类型
COMPACT_TYPE_ALL: 32 // 不限制
COMPACT_TYPE_FIN: 48 // 融资
COMPACT_TYPE_SLO: 49 // 融券

4-12 enum EXTCompactStatus // 合约状态
COMPACT_STATUS_ALL: 32 // 不限制
COMPACT_STATUS_UNDONE: 48 // 未归还
COMPACT_STATUS_PART_DONE: 49 // 部分归还
COMPACT_STATUS_DONE: 50 // 已归还
COMPACT_STATUS_DONE_BY_SELF: 51 // 自行了结
COMPACT_STATUS_DONE_BY_HAND: 52 // 手工了结
COMPACT_STATUS_NOT_DEBT: 53 // 未形成负债
COMPACT_STATUS_EXPIRY: 54 // 合约已过期
 
4-13.enum EXTCompactBrushSource // 头寸来源
XT_COMPACT_BRUSH_SOURCE_ALL: 32 // 不限制
XT_COMPACT_BRUSH_SOURCE_NORMAL: 48 // 普通头寸
XT_COMPACT_BRUSH_SOURCE_SPECIAL: 49 // 专项头寸
 
4-14.enum_EXTSpecialAssure // 是否可以用融券资金买入
ASSURE_USE_SLO_CASH_DISABLE: 48 // 担保品买入不允许使用融券资金
ASSURE_USE_SLO_CASH_ENABLE: 49 // 担保品买入允许使用融券资金
4-15 enum_EOperationType : // 下单操作类型 主要交易类型
OPT_OPEN_LONG| 开多 : 0; // 期货操作的第 1 个，请保持此 OPT 在期货操作的第 1 个，否则客
户端判断操作是期货还是股票的代码会有问题
OPT_CLOSE_LONG_HISTORY:1 // 平昨多 黄金用平多表示
OPT_CLOSE_LONG_TODAY ： 2 // 平今多
OPT_OPEN_SHORT ： 3 // 开空
OPT_CLOSE_SHORT_HISTORY ： 4 // 平昨空 , 平昨空 , 平昨空 , 平昨空 , 平昨空 , 平昨空 , 平昨
空 , 平昨空 , 平空 ; // 黄金用平空表示
OPT_CLOSE_SHORT_TODAY ： 5 // 平今空 ;
OPT_CLOSE_LONG_TODAY_FIRST ： 6 // 平多优先平今 ;
OPT_CLOSE_LONG_HISTORY_FIRST ： 7 // 平多优先平昨 ;
OPT_CLOSE_SHORT_TODAY_FIRST ： 8 // 平空优先平今 ;
OPT_CLOSE_SHORT_HISTORY_FIRST ： 9 //| 平空优先平昨 ;
OPT_CLOSE_LONG_TODAY_HISTORY_THEN_OPEN_SHORT ： 10 // 卖出优先平今 ;
OPT_CLOSE_LONG_HISTORY_TODAY_THEN_OPEN_SHORT ： 11// 卖出优先平昨 ;
OPT_CLOSE_SHORT_TODAY_HISTORY_THEN_OPEN_LONG ： 12// 买入优先平今 ;

OPT_CLOSE_SHORT_HISTORY_TODAY_THEN_OPEN_LONG ： 13// 买入优先平昨 ;
OPT_CLOSE_LONG ： 14 // 平多 
OPT_CLOSE_SHORT ： 15 // 平空
OPT_OPEN ： 16 // 开仓
OPT_CLOSE ： 17 // 平仓 
OPT_BUY ： 18 // 买入
OPT_SELL ： 19 // 卖出
OPT_FIN_BUY ： 20 // 融资买入
OPT_SLO_SELL ： 21 // 融券卖出
OPT_BUY_SECU_REPAY ： 22 // 买券还券
OPT_DIRECT_SECU_REPAY ： 23 // 直接还券
OPT_SELL_CASH_REPAY ： 24 // 卖券还款
OPT_DIRECT_CASH_REPAY ： 25 // 直接还款
4-16 enum_EOrderType : // 算法交易、普通交易类型
OTP_ORDINARY; 0 // 常规
OTP_ALGORITHM; 1 // 算法交易
OTP_RANDVOLUME; 2 // 随机量交易
OTP_ALGORITHM3 3 // 算法交易 3
OTP_ZXJT; 4 // 中信建投算法
OTP_ZSGS; 5 // 隔时交易
OTP_ORDINARY_BASKET_TRIGGER_SINGLE_ORDER; 6 // 普通交易的触价单笔委托方式
OTP_ALGORITHM_BASKET_TRIGGER_SINGLE_ORDER; 7 // 算法交易的触价单笔委托方式
OTP_ZXZQ; 8 // 中信证券算法
OTP_GENUS; 9 // 金纳算法
OTP_JAZZ; 10 // 爵士算法
OTP_VWAP; 11 // 智能 VWAP
OTP_TWAP; 12 // 智能 TWAP
OTP_XTALGO; 13 // 智能算法
OTP_HUACHUANG; 14 // 华创算法
OTP_HUARUN; 15 // 华润算法
OTP_CUSTOM; 16 // 回转算法
OPT_EXTERN; 17 // 主动算法
OTP_GUANGFA; 18 // 广发算法
4-17 enum_EPriceType : // 价格类型

PRTP_SALE5; 0 // 卖 5
PRTP_SALE4; 1 // 卖 4
PRTP_SALE3; 2 // 卖 3
PRTP_SALE2; 3 // 卖 2
PRTP_SALE1; 4 // 卖 1
PRTP_LATEST; 5 // 最新价
PRTP_BUY1; 6 // 买 1
PRTP_BUY2; 7 // 买 2
PRTP_BUY3; 8 // 买 3
PRTP_BUY4; 9 // 买 4
PRTP_BUY5; 10 // 买 5
PRTP_FIX; 11 // 指定价
PRTP_MARKET; 12 // 市价 _ 涨跌停价
PRTP_HANG; 13 // 挂单价
PRTP_COMPETE; 14 // 对手价
PRTP_AUTO; 15 // 自动盘口
PRTP_CLOSE; 16 // 昨收价
PRTP_AVERAGE; 17 // 大宗加权平均价
PRTP_MARKET_BEST;18 // 市价 _ 最优价
PRTP_MARKET_CANCEL;19 // 市价 _ 即成剩撤
PRTP_MARKET_CANCEL_ALL;20 // 市价 _ 全额成交或撤
PRTP_MARKET_CANCEL_1; 21 // 市价 _ 最优 1 档即成剩撤
PRTP_MARKET_CANCEL_5; 22 // 市价 _ 最优 5 档即成剩撤
PRTP_MARKET_CONVERT_1;23 // 市价 _ 最优 1 档即成剩转
PRTP_MARKET_CONVERT_5;24 // 市价 _ 最优 5 档即成剩转
PRTP_STK_OPTION_ASK;25 // 询价
PRTP_STK_OPTION_FIX_CANCEL_ALL; 26 // 限价即时全部成交否则撤单
PRTP_STK_OPTION_MARKET_CACEL_LEFT;27 // 市价即时成交剩余撤单
PRTP_STK_OPTION_MARKET_CANCEL_ALL;28 // 市价即时全部成交否则撤单
PRTP_STK_OPTION_MARKET_CONVERT_FIX;29 // 市价剩余转限价
PRTP_SALE6; 30 // 卖 6
PRTP_SALE7; 31 // 卖 7
PRTP_SALE8; 32 // 卖 8
PRTP_SALE9; 33 // 卖 9

PRTP_SALE10; 34 // 卖 10
PRTP_BUY6; 35 // 买 6
PRTP_BUY7; 36 // 买 7
PRTP_BUY8; 37 // 买 8
PRTP_BUY9; 38 // 买 9
PRTP_BUY10; 39 // 买 10
PRTP_UPPER_LIMIT_PRICE; 40 // 涨停价
PRTP_LOWER_LIMIT_PRICE; 41 // 跌停价
PRTP_MARKET_SH_CONVERT_5_CANCEL; 42 // 最优五档即时成交剩余撤销
PRTP_MARKET_SH_CONVERT_5_LIMIT; 43 // 最优五档即时成交剩转限价
PRTP_MARKET_PEER_PRICE_FIRST; 44 // 对手方最优价格委托
PRTP_MARKET_MINE_PRICE_FIRST; 45 // 本方最优价格委托
PRTP_MARKET_SZ_INSTBUSI_RESTCANCEL; 46 // 即时成交剩余撤销委托
PRTP_MARKET_SZ_CONVERT_5_CANCEL; 47 // 最优五档即时成交剩余撤销委托
PRTP_MARKET_SZ_FULL_REAL_CANCEL; 48 // 全额成交或撤销委托
PRTP_AFTER_FIX_PRICE; 49 // 盘后定价申报
4-18 enum_ETaskStatus : // 任务状态
TASK_STATUS_UNKNOWN : 0;// 未知
TASK_STATUS_WAITING;// 等待
TASK_STATUS_COMMITING;
TASK_STATUS_RUNNING;// 执行中
TASK_STATUS_PAUSE;// 暂停
TASK_STATUS_CANCELING_DEPRECATED;// 撤销中
TASK_STATUS_EXCEPTION_CANCELING_DEPRECATED;// 异常撤销中
TASK_STATUS_COMPLETED;// 完成
TASK_STATUS_CANCELED;// 已撤
TASK_STATUS_REJECTED;// 打回
TASK_STATUS_EXCEPTION_CANCELED;// 异常终止
TASK_STATUS_DROPPED;// 放弃，目前用于组合交易中，放弃补单
TASK_STATUS_FORCE_CANCELED_DEPRECATED;// 强制终止
 
5.5. 附录 5 行情数据字段列表

tick - 分笔数据 
time - int 时间戳
stime - str 时间戳
lastPrice - float 最新价
open - float 开盘价
high - float 最高价
low - float 最低价
lastClose - float 前收盘价
amount - float 成交总额
volume - int 成交总量
pvolume - int 原始成交总量 ( 未经过股手转换的成交总量 )
stockStatus - int 证券状态
openInt - int 持仓量
transactionNum - float 成交笔数 ( 期货没有，单独计算 )
lastSettlementPrice - float 前结算 ( 股票为 0)
settlementPrice - float 今结算 ( 股票为 0)
askPrice - list[float] 多档委卖价
askVol - list[int] 多档委卖量
bidPrice - list[float] 多档委买价
bidVol - list[int] 多档委买量
1m / 5m / 1d - K 线数据 
time - int 时间戳
stime - str 时间戳
open - float 开盘价
high - float 最高价
low - float 最低价
close - float 收盘价
volume - int 成交量
amount - float 成交额
settelementPrice - float 今结算
openInterest - int 持仓量
Level2 行情快照 
time - int 时间戳
stime - str 时间戳
lastPrice - float 最新价
open - float 开盘价
high - float 最高价
low - float 最低价
amount - float 成交额
volume - int 成交总量
pvolume - int 原始成交总量 ( 未经过股手转换的成交总量 )
stockStatus - int 证券状态
openInt - int 持仓量
transactionNum - int 成交笔数 ( 期货没有，单独计算 )
lastClose - float 前收盘价
lastSettlementPrice - float 前结算 ( 股票为 0)

settlementPrice - float 今结算 ( 股票为 0)
askPrice - list[float] 多档委卖价
askVol - list[int] 多档委卖量
bidPrice - list[float] 多档委买价
bidVol - list[int] 多档委买量
Level2 行情快照补充 
time - int 时间戳
stime - str 时间戳
avgBidPrice - float 委买均价
totalBidQuantity - int 委买总量
avgOffPrice - float 委卖均价
totalOffQuantity - int 委卖总量
withdrawBidQuantity - int 买入撤单总量
withdrawBidAmount - float 买入撤单总额
withdrawOffQuantity - int 卖出撤单总量
withdrawOffAmount - float 卖出撤单总额
Level2 逐笔委托 
time - int 时间戳
stime - float 时间戳
price - float 委托价
volume - int 委托量
entrustNo - int 委托号
entrustType - int 委托类型
entrustDirection - int 委托方向
0 - 未知
1 - 买入
2 - 卖出
4 - 撤单
Level2 逐笔成交 
time - int 时间戳
stime - str 时间戳
price - float 成交价
volume - int 成交量
amount - float 成交额
tradeIndex - int 成交记录号
buyNo - int 买方委托号
sellNo - int 卖方委托号
tradeType - int 成交类型
tradeFlag - int 成交标志
0 - 未知

1 - 外盘
2 - 内盘
3 - 撤单
Level2 逐笔成交统计 
time - int 时间戳
stime - str 时间戳
bidNumber - int 主买单总单数
bidMostVolmue - int 主买特大单成交量
bidBigVolmue - int 主买大单成交量
bidMediumVolmue - int 主买中单成交量
bidSmallVolmue - int 主买小单成交量
offNumber - int 主卖单总单数
offMostVolmue - int 主卖特大单成交量
offBigVolmue - int 主卖大单成交量
offMediumVolmue - int 主卖中单成交量
offSmallVolmue - int 主卖小单成交量
bidMostAmount - float 主买特大单成额
bidBigAmount - float 主买大单成交额
bidMediumAmount - float 主买中单成交额
bidSmallAmount - float 主买小单成交额
offMostAmount - float 主卖特大单成交额
offBigAmount - float 主卖大单成交额
offMediumAmount - float 主卖中单成交额
offSmallAmount - float 主卖小单成交额
ddx - float 大单动向
ddy - float 涨跌动因
ddz - float 大单差分
zjbyNetInflow - int 资金博弈 净流入
zjbyMost - int 资金博弈 超大单
zjbyBig - int 资金博弈 大单
zjbyMedium - int 资金博弈 中单
zjbySmall - int 资金博弈 小单
netOrder - int 净挂
netWithdraw - int 净撤
withdrawBid - int 总撤买
withdrawOff - int 总撤卖
unactiveBidMostVolmue - int 被动买特大单成交量
unactiveBidBigVolmue - int 被动买大单成交量
unactiveBidMediumVolmue - int 被动买中单成交量
unactiveBidSmallVolmue - int 被动买小单成交量
unactiveOffMostVolmue - int 被动卖特大单成交量
unactiveOffBigVolmue - int 被动卖大单成交量
unactiveOffMediumVolmue - int 被动卖中单成交量
unactiveOffSmallVolmue - int 被动卖小单成交量
unactiveBidMostAmount - float 被动买特大单成额
unactiveBidBigAmount - float 被动买大单成交额
unactiveBidMediumAmount - float 被动买中单成交额 
unactiveBidSmallAmount - float 被动买小单成交额

unactiveOffMostAmount - float 被动卖特大单成交额
unactiveOffBigAmount - float 被动卖大单成交额
unactiveOffMediumAmount - float 被动卖中单成交额
unactiveOffSmallAmount - float 被动卖小单成交额
Level2 委买委卖队列 
time - int 时间戳
stime - str 时间戳
bidLevelPrice - float 委买价
bidLevelVolume - list[int] 委买量
offerLevelPrice - float 委卖价
offerLevelVolume - list[int] 委卖量
证券状态 
0,10 - 默认为未知
11 - 开盘前 S
12 - 集合竞价时段 C
13 - 连续交易 T
14 - 休市 B
15 - 闭市 E
16 - 波动性中断 V
17 - 临时停牌 P
18 - 收盘集合竞价 U
19 - 盘中集合竞价 M
20 - 暂停交易至闭市 N
21 - 获取字段异常
22 - 盘后固定价格行情
23 - 盘后固定价格行情完毕
委托方向 
0 - 未知
1 - 买入
2 - 卖出
4 - 撤单
成交标记 
0 - 未知
1 - 外盘
2 - 内盘
3 - 撤单
