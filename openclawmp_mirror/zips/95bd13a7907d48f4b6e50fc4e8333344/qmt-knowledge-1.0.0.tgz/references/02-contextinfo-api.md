# ContextInfo 数据API完整参考

（ 5 ）检查安装结果
 安装位置 \bin.x64\Lib\site-packages 检查安装库
 新建策略输出确认
 import pip
 installed_packages = pip.get_installed_distributions()
 installed_packages_list = sorted(["%s==%s" % (i.key, i.version) for i in installed_packages])
 print(installed_packages_list)

3.2. 使用说明 
3.2.1. 概述 
3.2.1.1. 一般规定 
在编写一个策略时，首先需要在代码的最前一行写上：
#coding:gbk 统一脚本的编码格式是 GBK
 
3.2.1.2. 重要方法 
QMT 系统 Python API 策略代码结构分两个部分，初始化函数 init() 和行情事件函数 handlebar() 。
初始化函数 init() 在整个策略中只执行一次，一般在此函数中设置交易佣金、滑点、基准等一些常用参
数。
行情事件函数 handlebar() 为行情数据的处理函数，当前图中每根 K 线为一个行情数据， handlebar() 
在每根 K 线上分别依次执行一次。特别的，对于实时行情，最后一根 K 线还没确定时，每个 tick 执行一
次 handlebar() 。 handlebar() 里面一般写整个策略的执行逻辑。

Python 策略中必须有包含这两个基本方法，否则策略将运行不起来。
 
（ 1 ）初始化函数 init() 
用法： init(ContextInfo)
释义： 初始化函数，只在整个策略开始时调用运行一次
参数： ContextInfo ：策略运行环境对象，可以用于存储自定义的全局变量
返回： 无
示例： 
 
（ 2 ）行情事件函数 handlebar() 
用法： handlebar(ContextInfo)
释义： 行情事件函数，每根 K 线运行一次；实时行情获取状态下，先每根历史 K 线运行一次，再在每个 
tick 数据来后驱动运行一次
参数： ContextInfo ：策略运行环境对象，可以用于存储自定义的全局变量
返回： 无
示例： 
def init(ContextInfo):
    ContextInfo.initProfit = 0
1
2

3.2.2. ContextInfo 对象 
ContextInfo 是策略运行环境对象，是 init() 和 handlebar() 这两个基本方法必传参数，里面包括了终端
自带的属性和方法。一般情况下不建议对 ContextInfo 添加自定义属性， ContextInfo 会随着 bar 的切换而
重置到上一根 bar 的结束状态，建议用自建的全局变量来存储。
* 注：除特殊标明外，以下函数均支持回测和实盘 / 模拟运行模式。
（ 1 ）设定股票池 ContextInfo.set_universe() 
用法： ContextInfo.set_universe(stocklist)
释义： 设定股票池
参数： list
返回： 无
示例： 
 
（ 2 ）设定交易账号 ContextInfo.set_account() 
用法： ContextInfo.set_account(account)
释义： 设定交易账号，并将该账号用于之后的交易主推订阅。
* 注：
一、可多次调用以设置多个账号，应在 init 中进行设置完毕， init 执行后再设置将不再订阅交易主
推；
二、调用 passorder 传入账号为空时会使用最后一次设置的账号作为下单账号。
参数： string
返回： 无
示例： 
 
def handlebar(ContextInfo):
    # 输出当前运行到的 K 线的位置
    print(ContextInfo.barpos)
1
2
3
def init(ContextInfo):
    stocklist = ['000300.SH','000004.SZ']
    ContextInfo.set_universe(stocklist)
1
2
3
def init(ContextInfo):
    account = '6000000223'
    ContextInfo.set_account(account)
1
2
3

（ 3 ）设定回测起止时间 ContextInfo.start / ContextInfo.end 
用法： ContextInfo.start / ContextInfo.end
释义： 设定回测起止时间，标准格式如 "2009-07-14 01:13:30" ，读写
* 注：
一、此函数只支持回测模式；
二、仅在 init 中设置生效，应在 init 中设置完毕；
三、缺省值为策略编辑界面设定的回测时间范围；
四、回测起止时间也可在策略编辑器的回测参数面板中设置，若两处同时设置，则以代码中设置的
值为准；
五、结束时间小于等于开始时间则计算范围为空。
参数： 无
返回： 无
示例： 
 
（ 4 ）设定回测初始资金 ContextInfo.capital 
用法： ContextInfo.capital
释义： 设定回测初始资金，读写，默认为 1000000
* 注：此函数只支持回测模式。回测初始资金也可在策略编辑器的回测参数面板中设置，若两处同时设
置，则以代码中设置的值为准。
参数： 无
返回： number
示例： 
 
（ 5 ）设定策略回测滑点 ContextInfo.set_slippage() 
用法： ContextInfo.set_slippage(slippageType, slippage)
释义： 设定策略回测滑点，默认值 0.00
* 注：此函数只支持回测模式。回测滑点也可在策略编辑器的回测参数面板中设置，若两处同时设置，则
以代码中设置的值为准。
def init(ContextInfo):
    ContextInfo.start = '2012-06-06 10:00:00'
    ContextInfo.end = '2013-08-08 14:30:00'
1
2
3
def init(ContextInfo):
    ContextInfo.capital = 10000000
def handlebar(ContextInfo):
    print(ContextInfo.capital)
1
2
3
4
5

参数： 
slippageType ：滑点类型，可选值：
0 ： tick 跳数设置滑点
1 ：按照固定值（价格）设置滑点
2 ：价格比例设置滑点
slippage ：滑点值
返回： 无
示例： 
 
（ 6 ）设定策略回测各种手续费率 ContextInfo.set_commission() 
用法： ContextInfo.set_commission(commissionType, commissionList)
释义： 设定策略回测各种手续费率，默认类型值 0 按比例，默认值 0.000
* 注：此函数只支持回测模式。回测各种手续费率也可在策略编辑器的回测参数面板中设置，若两处同时
设置，则以代码中设置的值为准。
参数： 
commissionType ： number ，可选值：
0 ：按比例
1 ：按每手（股）
commissionList ： list ，包含六个值， commissionList = [open_tax, close_tax, 
open_commission, close_commission, close_tdaycommission, min_commission]
open_tax ：买入印花税
close_tax ：卖出印花税
open_commission ：开仓手续费 ;
close_commission ：平仓（平昨）手续费
close_tdaycommission ：平今手续费
min_commission ：最少手续费
* 注：如果只填写一个参数则代表输入的参数值赋值给 open_commission = close_commission = 
close_today_commission ，其他的值均为 0 ，这时 commissionType 为 0
返回： 无
示例 1 ： 
def init(ContextInfo):
    # 按照固定值（价格）设置滑点值为 0.01
    ContextInfo.set_slippage(1, 0.01)
1
2
3

示例 2 ： 
 
（ 7 ）获取股票池中的股票 ContextInfo.get_universe() 
用法： ContextInfo.get_universe()
释义： 获取股票池中的股票
参数： 无
返回： list
示例： 
 
（ 8 ）获取当前周期 ContextInfo.period 
用法： ContextInfo.period
释义： 获取当前周期，即基本信息中设置的默认周期，只读 
参数： 无
返回： string ，返回值含义：
'1d' ：日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
def init(ContextInfo):
    # 万三
    commission = 0.0003
    
    # 设定开仓手续费和平仓手续费以及平今手续费均为 0.0003 ，其余为 0   
    ContextInfo.set_commission(commission)
1
2
3
4
5
6
def init(ContextInfo):
    commissionList = [0,0.0001, 0.0003, 0.0003, 0, 5]
    
    # 设定买入印花税为 0 ，卖出印花税为 0.0001 ，开仓手续费和平仓（平昨）手续费均为万三，平
今手续费为 0 ，最小手续费为 5
    ContextInfo.set_commission(0, commissionList)
1
2
3
4
5
def handlebar(ContextInfo):
    print(ContextInfo.get_universe()) 
1
2

'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线 
示例： 
 
（ 9 ）获取当前运行到 K 线索引号 ContextInfo.barpos 
用法： ContextInfo.barpos
释义： 获取当前运行到 K 线索引号，只读，索引号从 0 开始
参数： 无
返回： number
示例： 
 
（ 10 ）获取当前图 K 线数目 ContextInfo.time_tick_size 
用法： ContextInfo.time_tick_size
释义： 获取当前图 K 线数目，只读
参数： 无
返回： number
示例： 
 
（ 11 ）判定是否为最后一根 K 线 ContextInfo.is_last_bar() 
用法： ContextInfo.is_last_bar()
释义： 判定是否为最后一根 K 线
参数： 无
返回： bool ，返回值含义：
True ：是
def handlebar(ContextInfo):
    print(ContextInfo.period)
1
2
def handlebar(ContextInfo):
    print(ContextInfo.barpos)
1
2
def handlebar(ContextInfo):
    print(ContextInfo.time_tick_size)
1
2

False ：否
示例： 
 
（ 12 ）判定是否为新的 K 线 ContextInfo.is_new_bar() 
用法： ContextInfo.is_new_bar()
释义： 某根 K 线的第一个 tick 数据到来时，判定该 K 线为新的 K 线
参数： 无
返回： bool ，返回值含义：
True ：是
False ：否
示例： 
 
（ 13 ）判定股票是否停牌 ContextInfo.is_suspended_stock() 
用法： ContextInfo.is_suspended_stock(stockcode.market)
释义： 判定股票是否停牌
参数： 股票市场和代码
返回： bool ，返回值含义：
True ：停牌
False ：未停牌
示例： 
 
（ 14 ）判定给定股票代码是否在指定的板块中 is_sector_stock() 
用法： is_sector_stock(sectorname, market, stockcode)
释义： 判定给定股票代码是否在指定的板块中
参数： 
sectorname ： string ，板块名
market ： string ，市场
def handlebar(ContextInfo):
    print(ContextInfo.is_last_bar())
1
2
def handlebar(ContextInfo):
    print(ContextInfo.is_new_bar())
1
2
def handlebar(ContextInfo):
    print(ContextInfo.is_suspended_stock('600004.SH'))
1
2

stockcode ： string ，股票代码
返回： bool ，返回值含义：
True ：在板块中
False ：不在板块中
示例： 
 
（ 15 ）判定给定股票是否属于某个类别 is_typed_stock() 
用法： is_typed_stock(stocktypenum, market, stockcode)
释义： 判定给定股票是否属于某个类别
参数： 
stocktypenum ： number ，类别标号，如股票类别标号为 100003 ，详细见5.2. 附录 2 
is_typed_stock 函数证券分类表，或者见 xtstocktype.lua 文件
market ： string ，市场
stockcode ： string ，股票代码
返回： number ，返回值含义：
1 ： True
0 ： False
示例： 
 
（ 16 ）判定给定股票代码是否在指定的行业分类中
get_industry_name_of_stock()
 
用法： get_industry_name_of_stock(industryType, stockcode)
释义： 判定给定股票代码是否在指定的行业分类中
参数： 
industryType ： string ，行业类别，有 'CSRC' 和 'SW' 两种
stockcode ： string ，形式如 'stockcode.market' ，如 '600000.SH'
返回： string ：对应行业名，找不到则返回空 string
示例： 
def handlebar(ContextInfo):
    print(is_sector_stock(' 沪深 300','SH','600000'))
1
2
def handlebar(ContextInfo):
    print(is_typed_stock(100003,'SH','600000'))
1
2
def handlebar(ContextInfo):
    print(get_industry_name_of_stock('SW','600000.SH'))
1
2

（ 17 ）获取当前图代码 ContextInfo.stockcode 
用法： ContextInfo.stockcode
释义： 获取当前图代码，只读
参数： 无
返回： string ：对应主图代码
示例： 
 
（ 18 ）获取当前主图复权处理方式 ContextInfo.dividend_type 
用法： ContextInfo.dividend_type
释义： 获取当前主图复权处理方式 
参数： 无
返回： string ，返回值含义：
'none' ：不复权
'front' ：向前复权
'back' ：向后复权
'front_ratio' ：等比向前复权
'back_ratio' ：等比向后复权
示例： 
 
（ 19 ）获取当前主图市场 ContextInfo.market 
用法： ContextInfo.market
释义： 获取当前主图市场，只读
参数： 无
返回： string ：对应主图市场
示例： 
def handlebar(ContextInfo):
    print(ContextInfo.stockcode)
1
2
def handlebar(ContextInfo):
    print(ContextInfo.dividend_type)
1
2
def handlebar(ContextInfo):
    print(ContextInfo.market)
1
2

（ 20 ）根据代码获取名称 ContextInfo.get_stock_name() 
用法： ContextInfo.get_stock_name('stockcode')
释义： 根据代码获取名称
参数： stockcode ：股票代码，如 '000001.SZ' ，缺省值 ' ' 默认为当前图代码
返回： string （ GBK 编码） 
示例： 
 
（ 21 ）根据代码返回对应股票的上市时间 get_open_date() 
用法： get_open_date('stockcode')
释义： 根据代码返回对应股票的上市时间
参数： stockcode ：股票代码，如 '000001.SZ' ，缺省值 ' ' 默认为当前图代码
返回： number 
示例： 
 
（ 22 ）表示当前是否开启回测模式 ContextInfo.do_back_test 
用法： ContextInfo.do_back_test
释义： 设定是否开启回测模式，只读，默认值为 False 
参数： 无
返回： bool
 
（ 23 ）获取回测基准 ContextInfo.benchmark 
用法： ContextInfo.benchmark
释义： 获取回测基准，只读
* 注：此函数只支持回测模式。
参数： 无
返回： string
示例： 
def handlebar(ContextInfo):
    print(ContextInfo.get_stock_name('000001.SZ'))
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_open_date('000001.SZ'))
1
2

（ 24 ）设定回测系统输出日志显示级别 ContextInfo.data_info_level 
用法： ContextInfo.data_info_level
释义： 设定回测系统输出日志显示级别，默认是 0 ，可设置的值有： 0 信息， 1 警告， 2 错误， 3 致命，
根据设定显示大于等于该级别的日志
* 注：此函数只支持回测模式。
参数： 无
返回： 无
示例： 
 
（ 25 ）获取某个记录类型对应的某个时刻的记录情况 get_result_records() 
用法： get_result_records (recordtype, index, ContextInfo)
释义： 获取某个记录类型对应的某个时刻的记录情况。
* 注：模型回测时有效，获取的为回测面板中的记录结果
参数： 
Recordtype ： string ，面板类型，可选值：
'buys' ：买入持仓 
'sells' ：卖出持仓 
'holdings' ：当前持仓 
'historysums' ：历史汇总 
'dealdetails' ：交易明细 
index ： number ，当前主图对应 K 线索引 
ContextInfo ： PythonObj ， Python 对象，这里必须是 ContextInfo
返回： list ，返回的 list 结构中包含 0 个或多个 Python 对象，该 Python 对象内含如下属性值： 
market ： string ，市场代码
stockcode ： string ，合约代码
open_close ： number ，期货开平： 1 开 0 平；股票： 1 买 0 卖
direction ： number ，方向： 1 多 -1 空；回购： 1 逆回购 -1 正回购
trade_price ： number ，持仓成本
def handlebar(ContextInfo):
    print(ContextInfo.benchmark)
1
2
def init(ContextInfo):
    # 显示 ' 错误 ' 级别以上的信息
    ContextInfo.data_info_level = 2
1
2
3

current_price ： number ，最新价，持仓中用这个价
profit ： number ，持仓盈亏
position ： number ，仓位数量
current_weight ： number ，仓位权重 [ 暂无有效数据 ]
benefit_weight ： number ，盈利占比权重，记录类型是 'historysums' 时有效
holding_periods ： number ，累计持仓天数，记录类型是 'historysums' 时有效
buy_sell_times ： number ，交易次数，记录类型是 'historysums' 时有效
commission ： number ，手续费
trade_balance ： number ，成交额或市值
operate_type ： number ，操作类型，记录类型是 'dealdetails' 时有效
trade_date ： number ，交易日期，毫秒标记，记录类型是 'dealdetails' 时有效
示例： 
 
（ 26 ）设置定时器 run_time(funcName,period,startTime,market) 
用法： run_time(funcName,period,startTime,market)
释义： 设置定时器
* 注：模型回测时无效，定时器没有结束方法，会随着策略的结束而结束。另外定时器函数在一次运行前
会先等待一个 period
参数： 
funcName ：回调函数名
period ：重复调用的时间间隔 ,'5nSecond' 表示每 5 秒运行 1 次回调函数 ,'5nDay' 表示每 5 天运行一次
回调函数 ,'500nMilliSecond' 表示每 500 毫秒运行 1 次回调函数
startTime ：表示定时器第一次启动的时间 , 如果要定时器立刻启动 , 可以设置历史的时间 
回调函数参数： ContextInfo ：策略模型全局对象 
示例： 
 
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    print(get_result_records('buys', index, ContextInfo))
1
2
3
import time
def init(ContextInfo):
    ContextInfo.run_time("myHandlebar","5nSecond","2019-10-14 13:20:00","SH")
def myHandlebar(ContextInfo):
    print('hello world')
def handlebar(ContextInfo):
    pass
# 此例为自 2019-10-14 13:20:00 后每 5s 运行一次 myHandlebar
1
2
3
4
5
6
7
8

（ 27 ）停止处理函数 stop() 
用法： stop(ContextInfo)
释义： PY 策略模型关闭停止前运行到的函数，复杂策略模型，如中间有起线程可通过在该函数内实现停
止线程操作。
* 注： PY 策略可不用该函数
参数： ContextInfo ：策略模型全局对象 
示例： 
 
3.2.3. 获取数据 
* 注：除特殊标明外，以下函数均支持回测和实盘 / 模拟运行模式。
（ 1 ）获取最新流通股本 ContextInfo.get_last_volume() 
用法： ContextInfo.get_last_volume(stockcode)
释义： 获取最新流通股本
参数： string ：必须是 'stock.market' 形式
返回： number
示例： 
 
（ 2 ）获取当前 K 线对应时间的时间戳 ContextInfo.get_bar_timetag() 
用法： ContextInfo.get_bar_timetag(index)
释义： 获取当前 K 线对应时间的时间戳
参数： number ： K 线索引号
返回： number
示例： 
 
def stop(ContextInfo):
    print( 'strategy is stop !')
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_last_volume('000002.SZ'))
1
2
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    print(ContextInfo.get_bar_timetag(index))
1
2
3

（ 3 ）获取当前主图品种最新分笔对应的时间的时间戳
ContextInfo.get_tick_timetag()
 
用法： ContextInfo.get_tick_timetag()
释义： 获取当前主图品种最新分笔对应的时间的时间戳
参数： 无
返回： number
示例： 
 
（ 4 ）获取指数成份股 ContextInfo.get_sector() 
用法： ContextInfo.get_sector(sector, realtime)
释义： 获取板块成份股，只支持取指数成份股
参数： 
string ：必须是 'stock.market' 形式，如 '000300.SH' ，可取如沪深 300 （ 000300.SH ）、中证
500 （ 000905.SH ）、上证 50 （ 000016.SH ）等指数的历史成份股
realtime ：毫秒级时间戳，如不填则默认取目前最新成份股
返回： list ：内含成份股代码，里面股票代码为 '000002.SZ' 形式
示例： 
 
（ 5 ）获取行业成份股 ContextInfo.get_industry() 
用法： ContextInfo.get_industry(industry)
释义： 获取行业成份股
参数： string ：如 'CSRC1 矿业 '
返回： list ：内含成份股代码，里面股票代码为 '000002.SZ' 形式
示例： 
 
def handlebar(ContextInfo):
    print(ContextInfo.get_tick_timetag())
1
2
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    realtime = ContextInfo.get_bar_timetag(index)
    print(ContextInfo.get_sector('000300.SH', realtime))
1
2
3
4
def handlebar(ContextInfo):
    print(ContextInfo.get_industry('CSRC1 采矿业 '))
1
2

（ 6 ）获取板块成份股 ContextInfo.get_stock_list_in_sector() 
用法： ContextInfo.get_stock_list_in_sector(sectorname, realtime)
释义： 获取板块成份股，支持客户端左侧板块列表中任意的板块，包括自定义板块
参数： 
string ：板块名，如 ' 沪深 300' ， ' 中证 500' 、 ' 上证 50' 、 ' 我的自选 ' 等
realtime ：毫秒级时间戳
返回： list ：内含成份股代码，代码形式为 'stockcode.market' ，如 '000002.SZ'
示例： 
 
（ 7 ）获取某只股票在某指数中的绝对权重 ContextInfo.get_weight_in_index() 
用法： ContextInfo.get_weight_in_index(indexcode, stockcode)
释义： 获取某只股票在某指数中的绝对权重
参数： 
indexcode ： string ，指数代码，形式如 'stockcode.market' ，如 '000300.SH' 
stockcode ： string ，股票代码，形式如 'stockcode.market' ，如 '600004.SH'
返回： number ：返回的数值单位是 % ，如 1.6134 表示权重是 1.6134%
示例： 
 
（ 8 ）获取合约乘数 ContextInfo.get_contract_multiplier() 
用法： ContextInfo.get_contract_multiplier(contractcode)
释义： 获取合约乘数
参数： string ：合约代码，形式如 'code.market' ，如 'IF1707.IF'
返回： number
示例： 
 
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    realtime = ContextInfo.get_bar_timetag(index)
    print(ContextInfo.get_stock_list_in_sector(' 沪深 300', realtime))
1
2
3
4
def handlebar(ContextInfo):
    print(ContextInfo.get_weight_in_index('000300.SH', '000002.SZ'))
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_contract_multiplier('IF1707.IF'))
1
2

（ 9 ）获取无风险利率 ContextInfo.get_risk_free_rate() 
用法： ContextInfo.get_risk_free_rate(index)
释义： 获取无风险利率，用十年期国债收益率 CGB10Y 作无风险利率
参数： number ：当前图 K 线索引号
返回： number
示例： 
 
（ 10 ）获取给定日期对应的 K 线索引号 ContextInfo.get_date_location() 
用法： ContextInfo.get_date_location(strdate)
释义： 获取给定日期对应的 K 线索引号，如给定日期小于当前图 K 线对应的最早的日期，结果返回 0 ；
如给定日期大于当前图 K 线对应的最新日期，结果返回最新 K 线的索引号
参数： string ：形式如 'yyyymmdd' ，如 '20170711'
返回： number
示例： 
 
（ 11 ）获取策略设定的滑点 ContextInfo.get_slippage() 
用法： ContextInfo.get_slippage()
释义： 获取策略设定的滑点
* 注：此函数只支持回测模式。
参数： 无
返回： dict ， key 包括：
slippage_type
slippage
示例： 
 
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    print(ContextInfo.get_risk_free_rate(index))
1
2
3
def handlebar(ContextInfo):
    print(ContextInfo.get_date_location('20170711'))
1
2
def init(ContextInfo):
    ContextInfo.set_slippage(0.003)
def handlebar(ContextInfo):
    print(ContextInfo.get_slippage())
1
2
3
4
5

（ 12 ）获取策略设定的各种手续费率 ContextInfo.get_commission() 
用法： ContextInfo.get_commission()
释义： 获取策略设定的各种手续费率
* 注：此函数只支持回测模式。
参数： 无
返回： dict ， key 包括
commission_type
open_tax
close_tax
open_commission
close_commission
close_tdaycommission
min_commission
示例： 
 
（ 13 ）获取策略回测的净值 ContextInfo.get_net_value() 
用法： ContextInfo.get_net_value(index)
释义： 获取策略回测的净值
* 注：此函数只支持回测模式。
参数： index = ContextInfo.barpos
返回： number
示例： 
 
def init(ContextInfo):
    ContextInfo.set_commission(0.0003)
def handlebar(ContextInfo):
    print(ContextInfo.get_commission())
1
2
3
4
5
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    print(ContextInfo.get_net_value(index))
1
2
3

（ 14 ）获取财务数据 ContextInfo.get_financial_data() 
用法： 
ContextInfo.get_financial_data(fieldList,stockList,startDate,endDate,report_type='announce_time')
释义： 获取财务数据
参数： 
fieldList ：字段列表，如 ['CAPITALSTRUCTURE.total_capital', 
'ASHAREINCOME.net_profit_incl_min_int_inc'] （例子中取了股本结构中的总股本，与利润表中
的净利润），更多支持字段参见4. 财务数据接口使用方法
stockList ：股票列表，如 ['600000.SH', '000001.SZ']
startDate ：开始时间，如 '20171209' 
endDate ：结束时间，如 '20171212'
report_type: 时间类型 , 可缺省 , 默认是按照数据的公告期为区分取数据 , 设置为 'report_time' 为按照
报告期取数据 , 可选值 :'announce_time','report_time'
返回： 
函数根据 stockList 代码列表 ,startDate,endDate 时间范围的大小范围不同的数据类型
(1) 代码列表 1- 时间范围为 1 返回： pandas.Series index= 字段
(2) 代码列表 1- 时间范围为 n 返回： pandas.DataFrame index= 时间 ,columns= 字段
(3) 代码列表 n- 时间范围为 1 返回： pandas.DataFrame index= 代码 ,columns= 字段
(4) 代码列表 n- 时间范围为 n 返回： pandas.Panel items= 代码 ,major_axis= 时间 ,minor_axis= 字段
选择按照公告期取数和按照报告期取数的区别 : 若某公司当年 4 月 26 日发布上年度年报 , 如果选择按
照公告期取数 , 则当年 4 月 26 日之后至下个财报发布日期之间的
数据都是上年度年报的财务数据 , 如果选择按照报告期取数 , 则上年度第 4 季度 ( 上年度 10 月 1 日 -12 月
31 日 ) 的数据就是上年度报告期的数据 . 代码 1- 时间 1 ： pandas.Series index = 字段
* 注：必须安装 pandas
示例： 
 
（ 15 ）获取财务数据 ContextInfo.get_financial_data() 
用法： 
ContextInfo.get_financial_data(tabname,colname,market,code,report_type='report_time',barpos) 
( 与上一个 ContextInfo.get_financial_data 可同时使用 )
释义： 获取财务数据
def handlebar(ContextInfo):
    # 取股本结构中的总股本，与利润表中的净利润
    fieldList = ['CAPITALSTRUCTURE.total_capital', 
'ASHAREINCOME.net_profit_incl_min_int_inc']
    stockList = ['600000.SH', '000001.SZ']
    startDate = '20171209'
    endDate = '20171212'
    # 获取 20171209-20171212 时间段浦发银行和平安银行的总股本及利润表的净利润
    ContextInfo.get_financial_data(fieldList, stockList, startDate, endDate)
1
2
3
4
5
6
7
8

参数： 
tabname ：表格名称
colname ：字段名称
market ：市场
code ：股票代码
barpos ：当前 bar 的索引
report_type: 时间类型 , 可缺省 , 默认是按照数据的公告期为区分取数据 , 设置为 'report_time' 为按照
报告期取数据 , 可选值 :'announce_time','report_time
返回： number
示例： 
 
（ 16 ）获取历史行情数据 ContextInfo.get_history_data() 
用法： ContextInfo.get_history_data(len, period, field, dividend_type = 0, skip_paused = True)
释义： 获取历史行情数据
* 注：必须先通过 ContextInfo.set_universe() 设定基础股票池，获取历史行情数据是获取的是股票池中
的历史行情数据。
参数： 
len ： number ，需获取的历史数据长度
period ： string ，需获取的历史数据的周期，可选值：
'tick' ：分笔线
'1d' ：日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线
field ： string ，需获取的历史数据的类型，可选值：
'open'
def handlebar(ContextInfo):
    index = ContextInfo.barpos
    # 获取当前时间点浦发银行利润表的净利润，更多支持字段参见 [ 财务数据接口使用方法 ]
    ContextInfo.get_financial_data('ASHAREINCOME', 
'net_profit_incl_min_int_inc', 'SH', '600000', index)
1
2
3
4

'high'
'low'
'close'
'quoter' （结构见 get_market_data ）
dividend_type ：默认参数， number ，除复权，默认不复权，可选值：
0 ：不复权
1 ：向前复权
2 ：向后复权
3 ：等比向前复权
4 ：等比向后复权
skip_paused ：默认参数， bool ，是否停牌填充，默认填充
* 注：可缺省参数： dividend_type ， skip_paused
返回： 一个字典 dict 结构， key 为 stockcode.market, value 为行情数据 list ， list 中第 0 位为最早的价
格，第 1 位为次早价格，依次下去。
示例： 
 
（ 17 ）获取行情数据 ContextInfo.get_market_data() 
用法： ContextInfo.get_market_data(fields, stock_code = [], start_time = '', end_time = '', 
skip_paused = True, period = 'follow', dividend_type = 'follow', count = -1)
释义： 获取行情数据
参数： 
fields ：字段列表：
'open' ：开
'high' ：高 
'low' ：低
'close' ：收
'volume' ：成交量
'amount' ：成交额
'settle' ：结算价
def init(ContextInfo):
    ContextInfo.set_universe(['000300.SH', '000004.SZ'])
def handlebar(ContextInfo):
    # 获取股票池中所有股票的最近两日的收盘价
    hisdict = ContextInfo.get_history_data(2, '1d', 'close')
    for k, v in hisdict.items():
        if len(v) > 1:
            # 今日涨幅
            print(k, ':', v[1] - v[0])
1
2
3
4
5
6
7
8
9
10

'quoter' ：分笔数据（包括历史）
'quoter' 分笔数据结构： dict
{
lastPrice ：最新价
amount ：成交额
volume ：成交量
pvolumn ：前成交量
openInt ：持仓量
stockStatus ：股票状态
lastSettlementPrice ：最新结算价
open ：开盘价
high ：最高价 
low ：最低价
settlementPrice ：结算价
lastClose ：收盘价
askPrice ：列表，卖价五档 
bidPrice ：列表，买价五档
askVol ：列表，卖量五档
bidVol ；列表，买量五档
 } 
stock_code ：默认参数，合约代码列表，合约格式 code.market, 如 '600000.SH' ，不指定时为当
前图合约 
start_time ：默认参数，开始时间，格式 '20171209' 或 '20171209010101' 
end_time ：默认参数，结束时间，格式 '20171209' 或 '20171209010101' 
skip_paused ：默认参数，可选值：
true ：如果是停牌股，会自动填充未停牌前的价格作为停牌日的价格
False ：停牌数据为 nan
period ：默认参数，周期类型：
'tick' ：分笔线
'1d' ：日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
'1mon' ：月线

'1q' ：季线
'1hy' ：半年线
'1y' ：年线
dividend_type ：默认参数，缺省值为 'none' ，除复权，可选值：
'none' ：不复权
'front' ：向前复权
'back' ：向后复权
'front_ratio' ：等比向前复权
'back_ratio' ：等比向后复权 
count 取
值
时间设置是否生
效 开始时间和结束时间设置效果
count >= 
0 生效 返回数量取决于开始时间与结束时间和 count 与结束时间
的交集
count = 
-1 生效 同时设置开始时间和结束时间，在所设置的时间段内取值
count = 
-1 生效 开始时间结束时间都不设置，取当前最新 bar 的值
count = 
-1 生效 只设置开始时间，取所设开始时间到当前时间的值
count = 
-1 生效 只设置结束时间，取股票上市第一根 bar 到所设结束时间
的值
count ：默认参数，缺省值为 -1 ，大于等于 0 时，效果与 get_history_data 保持一致。
count 和开始时间、结束时间同时设置的效果如下表： 
* 注：
1. 特别的，默认参数需带上参数名方可生效，调用方式与 Python 别无二致
2. 策略点击运行，以策略代码中所设置的开始时间和结束时间为准，策略点击回测，以 ' 回测参数 ' 里
所设置的开始时间和结束时间为准。
3. 可缺省参数： start_time ， end_time ， skip_paused ， dividend_type ， count
4. 传入 count 和 end_time 的组合时，返回的行情数量为以 end_time 为结束时间且数量为 count 根
返回：

count 字段数
量
股票数
量
时间
点 返回类型
=-1 =1 =1 =1 float
=-1 >1 =1 默认
值 pandas.Series
>=-1 >=1 =1 >=1 pandas.DataFrame( 字段数量和时间点不同时为
1)
=-1 >=1 >1 默认
值 pandas.DataFrame
>1 =1 =1 =1 pandas.DataFrame
>=-1 >=1 >1 >=1 pandas.Panel
* 注 时间点是指 start_time 和 end_time 组成的时间区间，默认值是指 start_time 和 end_time 均传入默认
值
count >= 0 ，不同的参数，返回的数据结构不同，以下举例说明了不同的数据结构的类型。（代码指股
票代码；时间即为函数中所设置的时间，主要由 count 、 start_time 、 end_time 决定；字段即 fields 里
的字段） 
（ 1 ） 1 支股票代码，在 1 个时间点（ count 缺省默认为 -1 ，即为当前时间点的 bar ），取 1 个字段的
值，则返回相应字段的值。
代码： 
输出： 
17.40
 
（ 2 ） 1 支股票代码，在一个时间点（ count 、 start_time 、 end_time 都缺省，即为当前时间点的 
bar ），取多个字段的值，返回 pandas.Series （ pandas 一维数组）类型的值。 
代码： 
def init(ContextInfo):
    ContextInfo.set_universe(['000831.SZ'])
def handlebar(ContextInfo):
    df = ContextInfo.get_market_data(['close'], stock_code = 
ContextInfo.get_universe(), skip_paused = True, period = '1d', dividend_type 
= 'front')
    print(df)
1
2
3
4
5
6

输出： 
close 17.40
open 17.11
 
（ 3 ） 1 支股票代码，在一个时间段取值，返回 pandas.DataFrame （ pandas 二维表格型数据结构）类
型的值。 
代码： 
输出： 
close open
20190618 17.59 17.60
20190619 17.40 17.11
 
（ 4 ）多个股票代码，在一个时间点取值，返回 pandas.DataFrame （ pandas 二维表格型数据结构）
类型的值。 
代码：
输出： 
close open
def init(ContextInfo):
    ContextInfo.set_universe(['000831.SZ'])
def handlebar(ContextInfo):
    df = ContextInfo.get_market_data(['close', 'open'], stock_code = 
ContextInfo.get_universe(), skip_paused = True, period = '1d', dividend_type 
= 'front')
    print(df)
1
2
3
4
5
6
def init(ContextInfo):
    ContextInfo.set_universe(['000831.SZ'])
def handlebar(ContextInfo):
    df = ContextInfo.get_market_data(['close', 'open'], stock_code = 
ContextInfo.get_universe(), skip_paused = True, period = '1d', dividend_type 
= 'front', count = 2)
    print(df)
1
2
3
4
5
6
def init(ContextInfo):
    ContextInfo.set_universe(['000831.SZ', '600000.SH'])
def handlebar(ContextInfo):
    df = ContextInfo.get_market_data(['close', 'open'], stock_code = 
ContextInfo.get_universe(), skip_paused = True, period = '1d', dividend_type 
= 'front', count = -1)
    print(df)
1
2
3
4
5
6

000831.SZ 17.40 17.11
600000.SH 11.88 12.04
 
（ 5 ）多支股票代码，在一个时间段取值，返回 pandas.Panel （ pandas 三维数组结构）类型的值。 
代码：
输出： 
 <class 'pandas.core.panel.Panel'>
Dimensions: 2 (items) x 2 (major_axis) x 2 (minor_axis)
Items axis: 000831.SZ to 600000.SH
Major_axis axis: 20190618 to 20190619
Minor_axis axis: close to open
 
* 注：
1. 需要下载历史数据；
2. pandas 相关介绍详见 pandas 官方文档；
3. Python 需要安装 pandas ；
4. 时间区间：两边闭区间。
5. get_history_data() 和 get_market_data() 两者区别： get_history_data() 是获取设定的股票池中
股票某段行情，主要用来构建简单的指标； get_market_data() 可获取任意股票行情，返回行情数
据可以是 dataframe ，可用于复杂的分析。
示例 1 ： 
示例 2 ： 
def init(ContextInfo):
    ContextInfo.set_universe(['000831.SZ', '600000.SH'])
def handlebar(ContextInfo):
    df = ContextInfo.get_market_data(['close', 'open'], stock_code = 
ContextInfo.get_universe(), skip_paused = True, period = '1d', dividend_type 
= 'front', count = 2)
    print(df)
1
2
3
4
5
6
def handlebar(ContextInfo):
    # 以 period 参数指定需要的周期
    Result = ContextInfo.get_market_data(['open','high','low','close'], 
['600000.SH'], '20170101', '20170102', True, '1d', 'none')
    d_m = ContextInfo.get_market_data(['close'], ['600000.SH'], start_time = 
'20181230', end_time = '20190107', period = '1d')
    print(d_m)
    m_m = ContextInfo.get_market_data(['close'], ['600000.SH'], start_time = 
'20181230', end_time = '20190107', period = '1m')
    print(m_m)
1
2
3
4
5
6
7
def init(ContextInfo):1

（ 18 ）获取分笔数据 ContextInfo.get_full_tick() 
用法： ContextInfo.get_full_tick(stock_code=[]) 
释义： 获取最新分笔数据，该函数只能取最新的分笔，不能取历史分笔
参数： 
stock_code ： number ，默认参数，合约代码列表，如 ['600000.SH','600036.SH'] ，不指定时为当
前主图合约。
返回：根据 stock_code 返回一个 dict ，该字典的 key 值是股票代码，其值仍然是一个 dict ，在该 dict 中存
放股票代码对应的最新的数据。 dict ，除权除息日与复权因子的映射字典
示例： 
 
（ 20 ）获取当前期货主力合约 ContextInfo.get_main_contract() 
用法： ContextInfo.get_main_contract(codemarket)
释义： 获取当前期货主力合约
参数： codemarket ：合约和市场，合约格式为品种名加 00 ，如 IF00.IF ， zn00.SF
返回： str ，合约代码
示例： 
 
def handlebar(ContextInfo):
    if not ContextInfo.is_last_bar():
        return
    Result=ContextInfo.get_full_tick(['600000.SH','000001.SZ'])
1
2
3
4
def handlebar(ContextInfo):
    Result = ContextInfo.get_divid_factors('600000.SH')
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_main_contract('IF00.IF'))
1
2

（ 21 ）将毫秒时间转换成日期时间 timetag_to_datetime() 
用法： timetag_to_datetime(timetag, format)
释义： 将毫秒时间转换成日期时间
参数： 
timetag ：毫秒时间， 1512748800000
Format ：格式字符串， '%Y-%m-%d %H:%M:%S' 等任意格式
返回： str ，合约代码
示例： 
 
（ 22 ）获取总股数 ContextInfo.get_total_share() 
用法： ContextInfo.get_total_share(stockcode)
释义： 获取总股数
参数： stockcode ： string ，股票代码，缺省值 '' ，默认为当前图代码 , 如： '600000.SH'
返回： number
示例： 
 
（ 23 ）获取指定个股 / 合约 / 指数的 K 线（交易日）列表
ContextInfo.get_trading_dates()
 
用法： ContextInfo.get_trading_dates(stockcode, start_date, end_date, count, period)
释义： 获取指定个股 / 合约 / 指数的 K 线（交易日）列表
* 注： 该接口在 init 函数里不可用
参数： 
stockcode ： string ，股票代码，缺省值 '' ，默认为当前图代码，如 '600000.SH'
start_date ： string ，开始时间，缺省值 '' ，为空时不使用，如 '20170101' ， '20170101000000' 
end_date ： string ，结束时间，缺省值 '' ，默认为当前 bar 的时间，如 
'20170102' ， '20170102000000' 
count ： int ， K 线个数，必须大于 0 ，取包括 end_date 往前的 count 个 K 线， start_date 不为空
时不使用 
period ： string ， K 线类型如下：
'1d' ：日线
'1m' ： 1 分钟线
def handlebar(ContextInfo):
    print(timetag_to_datetime(1512748860000, '%Y%m%d %H:%M:%S'))
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_total_share('600000.SH'))
1
2

'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'30m' ： 30 分钟线
'1h' ：小时线
'1w' ：周线
'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线
* 注：可缺省参数： start_date ， end_date
返回： List ， K 线周期（交易日）列表， period 为日线时返回 ['20170101', '20170102', ...] ，其它返回
['20170101010000', '20170102020000', ...]
示例： 
 
（ 24 ）根据代码获取对应股票的内盘成交量 ContextInfo.get_svol() 
用法： ContextInfo.get_svol(stockcode)
释义： 根据代码获取对应股票的内盘成交量
参数： stockcode ：股票代码，如 '000001.SZ' ，缺省值 '' ，默认为当前图代码
返回： string
示例： 
 
（ 25 ）根据代码获取对应股票的外盘成交量 ContextInfo.get_bvol() 
用法： ContextInfo.get_bvol(stockcode)
释义： 根据代码获取对应股票的外盘成交量
参数： stockcode ：股票代码，如 '000001.SZ' ，缺省值 '' ，默认为当前图代码
返回： string
示例： 
def handlebar(ContextInfo):
    print(ContextInfo.get_trading_dates('600000.SH', '20170101', '20170401', 
1, '1d'))
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_svol('000001.SZ'))
1
2
def handlebar(ContextInfo):
    print(ContextInfo.get_bvol('000001.SZ'))
1
2

（ 26 ）获取龙虎榜数据 ContextInfo.get_longhubang() 
用法： ContextInfo.get_longhubang(stock_list, startTime, endTime)
释义： 获取龙虎榜数据
参数： 
stock_list ：股票列表， list ，如 ['600000.SH', '600036.SH'] 
startTime ：起始时间，如 '20170101'
endTime ：结束时间，如 '20180101'
返回： Dataframe ，字段：
reason ：上榜原因
close ：收盘价
spreadRate ：涨跌幅
TurnoverVolune ：成交量
Turnover_Amount ：成交金额
buyTraderBooth ：买方席位 ,datframe
sellTraderBooth ：卖方席位 ,datframe
buyTraderBooth 或 sellTraderBooth 包含字段： 
traderName ：交易营业部名称
buyAmount ：买入金额
buyPercent ：买入金额占总成交占比 
sellAmount ：卖出金额
sellPercent ：卖出金额占总成交占比
totalAmount ：该席位总成交金额
rank ：席位排行
direction ：买卖方向
示例： 
 
（ 27 ）获取十大股东数据 ContextInfo.get_top10_share_holder() 
用法： get_top10_share_holder(self, stock_list, data_name, start_time, end_time)
释义： 获取十大股东数据
参数： 
data_name ： flow_holder 或 holder
def handlebar(ContextInfo):
    print(ContextInfo.get_longhubang(['000002.SZ'],'20100101','20180101'))
1
2

stock_list ：股票列表， list ，如 ['600000.SH', '600036.SH']
startTime ：起始时间，如 '20170101'
endTime ：结束时间，如 '20180101'
返回： 
series （一只股票一个季度）
dataframe （多只股票一个季度数据或者一只股票多个季度数据）
panel （多只股票多个季度）
字段
holdName ：股东名称
holderType ：持股类型
holdNum ：持股数量 ,
changReason ：变动原因
holdRatio ：持股比例
stockType ：股份性质
rank ：持股排名
status ：持股状态
changNum ：增减数量
changeRatio ：增减比例
示例： 
 
（ 28 ）获取指定期权品种的详细信息
ContextInfo.get_option_detail_data(optioncode)
 
用法： ContextInfo.get_option_detail_data(optioncode)
释义： 获取指定期权品种的详细信息
参数： 
optioncode ：期权代码 , 如 '10001506.SHO', 当填写空字符串时候默认为当前主图的期权品种
返回： 
dict
字段
ExchangeID: 期权市场代码
InstrumentID: 期权代码
ProductID: 期权标的的产品 ID
OpenDate: 发行日期
def handlebar(ContextInfo):
    print(ContextInfo.get_top10_share_holder(['000002.SZ'], 'flow_holder', 
'20100101', '20180101'))
1
2

ExpireDate: 到期日
PreClose: 前收价格
SettlementPrice: 前结算价格
UpStopPrice: 当日涨停价
DownStopPrice: 当日跌停价
LongMarginRatio: 多头保证金率
ShortMarginRatio: 空头保证金率
PriceTick: 最小变价单位
VolumeMultiple: 合约乘数
MaxMarketOrderVolume: 涨跌停价最大下单量
MinMarketOrderVolume: 涨跌停价最小下单量
MaxLimitOrderVolume: 限价单最大下单量
MinLimitOrderVolume: 限价单最小下单量
OptUnit: 期权合约单位
MarginUnit: 期权单位保证金
OptUndlCode: 期权标的证券代码
OptUndlMarket: 期权标的证券市场
OptExercisePrice: 期权行权价
NeeqExeType: 全国股转转让类型
OptUndlRiskFreeRate: 期权标的无风险利率
OptUndlHistoryRate: 期权标的历史波动率
EndDelivDate: 期权行权终止日
示例： 
 
（ 29 ）获取一篮子证券编码数据 ContextInfo.load_stk_list() 
用法：ContextInfo.load_stk_list(filePath ， fileName)
释义： 获取一篮子证券编码数据
txt 文件信息格式： 600000.SH,600004.SH,600006.SH, 或 600000.SH600004.SH600006.SH( 最后一个字
段 600006.SH 需要增加分隔符 )
csv 文件信息格式： 600000.SH,600004.SH,600006.SH,( 最后一个 600006.SH 需要增加分隔符 )
参数： 
filePath ：文件路径
fileName ：文件名 ( 比如： a.txt,b.csv)
返回： 返回文档内容
示例： 
def handlebar(ContextInfo):
    print ContextInfo.get_option_detail_data('10001506.SHO')
1
2

（ 30 ）获取一篮子证券编码及数量数据 ContextInfo.load_stk_vol_list() 
用法： ContextInfo.load_stk_vol_list(filePath ， fileName)
释义： 获取一篮子证券编码及数量数据
txt 文件信息格式： 600000.SH,100,600004.SH,200, 或 600000.SH100600004.SH200( 篮子数据成对存在
( 前面是合约代码，后面是数量 ) 且数量字段 200 后需要增加分隔符 )
csv 文件信息格式： 600000.SH,100,600004.SH,200,( 篮子数据成对存在 ( 前面是合约代码，后面是数量 )
且数量字段 200 后需要增加分隔符 )
参数： 
filePath ：文件路径
fileName ：文件名 ( 比如： a.txt,b.csv)
返回： 返回文档内容
示例： 
 
（ 31 ）获取本地行情数据 ContextInfo.get_local_data() 
用法： 
ContextInfo.get_local_data(stock_code,start_time='',end_time='',period='1d',divid_type='none',cou
nt=-1)
释义： 获取本地行情数据
参数： 
stock_code ：默认参数，合约代码 code.market 不指定时为当前图合约
start_time ：默认参数，开始时间，格式 '20171209' 或 '20171209010101'
end_time ：默认参数，结束时间，格式同 start_time
period ： string ，默认参数，， K 线类型，可选值：
'tick' ：分笔线（只用于获取 'quoter' 字段数据）
'realtime' ：实时线
'1d' ：日线
'md' ：多日线
'1m' ： 1 分钟线
'3m' ： 3 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
def handlebar(ContextInfo):
   ContextInfo.load_stk_list('D:/data/','list.txt')
1
2
def handlebar(ContextInfo):
   ContextInfo.load_stk_vol_list('D:/data/','list.txt')
1
2

'30m' ： 30 分钟线
'mm' ：多分钟线
'1h' ：小时线
'mh' ：多小时线
'1w' ：周线
'1mon' ：月线
'1q' ：季线
'1hy' ：半年线
'1y' ：年线
dividend_type ：默认参数， number ，除复权，可选值：
'none' ：不复权
'front' ：向前复权
'back' ：向后复权
'front_ratio' ：等比向前复权
'back_ratio' ：等比向后复权
count ：默认参数，大于等于 0 时，若指定了 start_time ， end_time ，此时以 end_time 为基准向前
取 count 条；若 start_time ， end_time 缺省，默认取本地数据最新的 count 条数据；若 start_time ，
end_time ， count 都缺省时，默认取本地全部数据。
特别的，默认参数需带上参数名方可生效，调用方式与 python 别无二致。
返回：返回一个 dict ，键值为 timetag ， value 为另一个 dict(valuedict)
period='tick' 时函数获取分笔数据， valuedict 字典数据 key 值有：
lastPrice ：最新价
amount ：成交额
volume ：成交量
pvolume ：前成交量
openInt ：持仓量
stockStatus ：股票状态
lastSettlementPrice ：最新结算价
open ：开盘价
high ：最高价
low ：最低价
settlementPrice ：结算价
lastClose ：收盘价
askPrice ：列表 , 卖价五档
bidPrice ：列表 , 买价五档
askVol ：列表 , 卖量五档
bidVol ：列表 , 买量五档
period 为其他值时， valuedict 字典数据 key 值有：

amount ：成交额
volume ：成交量
open ：开盘价
high ：最高价
low ：最低价
close ：收盘价
* 注：时间区间两边闭区间
示例： 
 
（ 32 ）获取换手率 ContextInfo.get_turnover_rate() 
用法：ContextInfo.get_turnover_rate(stock_list,startTime,endTime)
释义： 获取换手率
参数： 
stock_list ：股票列表， list, 如 ['600000.SH','000001.SZ']
startTime ：起始时间，如 '20170101'
endTime ：结束时间，如 '20180101'
返回： dataframe
示例： 
 
（ 33 ）根据 ETF 基金代码获取 ETF 申赎清单及对应成分股数据 get_etf_info() 
用法： get_etf_info(stockcode)
释义： 根据 ETF 基金代码获取 ETF 申赎清单及对应成分股数据
参数： 
stockcode ： ETF 基金代码（如 "510050.SH" ）
返回：返回一个 dict ，键值为 timetag ， value 为另一个 dict(valuedict)
etfCode ： ETF 代码
etfExchID ： ETF 市场
prCode ：基金申赎代码
cashBalance ：现金差额（单位：元）
maxCashRatio ：现金替代比例上限
reportUnit ：最小申购、赎回单位（单位：份）
def handlebar(ContextInfo):
  Result=ContextInfo.get_local_data(stock_code='600000.SH',start_time='201701
01',end_time='20170102',period='1d',divid_type='none')
1
2
def handlebar(ContextInfo):
    print( 
ContextInfo.get_turnover_rate(['000002.SZ'],'20170101','20180101'))
1
2

name ：基金名称
navPerCU ：最小申购、赎回单位净值（单位：元）
nav ：基金份额净值（单位：元）
ecc ：预估现金差额（单位：元）
needPublish ：是否需要公布 IOPV （ 1 ：是， 0 ：否）
enableCreation ：是否允许申购（ 1 ：是， 0 ：否）
enableRedemption ：是否允许赎回（ 1 ：是， 0 ：否）
creationLimit ：申购上限（单位 : 份， 0 ：不限制）
redemptionLimit ：赎回上限（单位 : 份， 0 ：不限制）
tradingDay ：交易日期（格式 YYYYMMDD ）
preTradingDay ：前交易日期（格式 YYYYMMDD ）
stocks ：成分股列表
exchangeID ： ETF 基金市场代码
etfCode ： ETF 基金代码
etfName ： ETF 基金名称
componentExchID ：成份股市场代码
componentCode ：成份股代码
componentName ：成份股名称
componentVolume ：成份股数量
ReplaceFlag ：替代标记 (48 ：禁止替代， 49 ：允许替代， 50 ：必须替代， 51 ：替补替代 )
ReplaceRatio ：溢价比率
ReplaceBalance ：替代金额
示例： 
 
（ 34 ）根据 ETF 基金代码获取 ETF 的基金份额参考净值 get_etf_iopv() 
用法： get_etf_iopv(stockcode)
释义： 根据 ETF 基金代码获取 ETF 的基金份额参考净值
参数： 
stockcode ： ETF 基金代码（如 "510050.SH" ）
返回：IOPV ，基金份额参考净值
示例： 
 
（ 35 ）根据代码获取合约详细信息 ContextInfo.get_instrumentdetail() 
用法： ContextInfo.get_instrumentdetail(stockcode)
释义： 根据代码获取合约详细信息
参数：
stockcode ： string ，股票代码 , 如 '600000.SH' 
get_etf_info("510050.SH")# 获取 ETF 基金代码为 511050 的全部 ETF 申赎清单数据1
get_etf_iopv("510050.SH")1

返回：根据 stockcode 返回一个 dict 。int ，合约到期日
def handlebar(ContextInfo):
    print ContextInfo.get_instrumentdetail('600000.SH')
1
2

示例： 
 
（ 37 ）获取历史 st 状态 st_status() 
用法：st_status(stockcode)
释义： 获取历史 st 状态，本函数需要下载历史 ST 数据
参数： 
stockcode ：股票代码，如 000004.SZ （可为空，为空时取主图代码）
返回：
0 ：正常
1 ： ST
2 ： *ST
3 ： PT
示例： 
 
（ 38 ）获取某只股票 ST 的历史 ContextInfo.get_his_st_data() 
用法：ContextInfo.get_his_st_data(stockcode)
释义：获取某只股票 ST 的历史
参数： 
stockcode ： string ，股票代码， 'stkcode.market' ，如 '000004.SZ'
返回：dict,st 历史， key 为 ST,*ST,PT, 历史未 ST 会返回 {}
示例： 
 
def handlebar(ContextInfo):
    print( ContextInfo.get_contract_expire_date('IF00.IF'))
1
2
def handlebar(ContextInfo):
    a:st_status('000004.SZ');
    b:st_status('');
1
2
3
def handlebar(ContextInfo):
    print( ContextInfo.get_his_st_data('000004.SZ'))
1
2

（ 39 ）获取某只指数历史调整日的历史的成分股列表
ContextInfo.get_his_index_data()
 
用法：ContextInfo.get_his_index_data(stockcode)
释义：获取某只指数历史调整日的历史的成分股列表，需要下载历史数据
参数： 
stockcode ： string ，股票代码， 'stkcode.market' ，如 '000300.SH'
返回：dict,{date:[stockList]};
示例： 
 
（ 40 ）下载指定合约代码指定周期对应时间范围的行情数据 down_history_data() 
用法：down_history_data(stockcode,period,startTime,endTime)
释义：下载指定合约代码指定周期对应时间范围的行情数据
参数： 
stockcode ： string ，股票代码，形式如 'stkcode.market' ，如 '600000.SH'
period ： string ， K 线周期类型， 'tick' ：分笔线， '1d' ：日线， '1m' ：分钟线， '5m' ： 5 分钟线
startTime ， endTime ： string ，起止时间， "20200101" 或 "20200101093000" ，可以为空
示例： 
 
（ 41 ）订阅行情数据 ContextInfo.subscribe_quote() 
用法：ContextInfo.subscribe_quote(stockcode,period,dividend_type,callback)
释义：订阅行情数据
参数： 
stockcode ： string ，股票代码， 'stkcode.market' ，如 '600000.SH'
period ： string ， K 线周期类型， 'follow' ：当前主图周期， 'tick' ：分笔线， '1d' ：日线， '1m' ：分钟
线， '5m' ： 5 分钟线 , （暂只支持分笔线周期）
dividend_type ： string ，除复权， 'follow' ：当前图复权方式， 'none' ：不复权， 'front' ：向前复
权， 'back' ：向后复权， 'front_ratio' ：等比向前复权， 'back_ratio' ：等比向后复权 , （分笔周期返
回数据均为不复权）
callback ：推送行情的回调
返回：订阅号，用于反订阅
示例： 
def handlebar(ContextInfo):
    print( ContextInfo.get_his_index_data('000300.SH'))# 获取沪深 300 函数历次调整时
的指数成分列表 , 计算对应权重可以进一步取历史股本进行计算
1
2
down_history_data("600000.SH","1d","","")1

（ 42 ）反订阅行情数据 ContextInfo.unsubscribe_quote() 
用法：ContextInfo.unsubscribe_quote(subId)
释义：反订阅行情数据
参数： 
subId ：行情订阅返回的订阅号
示例： 
 
（ 43 ）获取当前所有的行情订阅信息 ContextInfo.get_all_subscription() 
用法：ContextInfo.get_all_subscription()
释义：反订阅行情数据
返回： dict ： "stockCode" ：合约代码， "period" ：周期， "dividendType" ：除权方式
示例： 
 
（ 44 ）获取行情数据 第二版 ContextInfo.get_market_data_ex() 
用法： ContextInfo.get_market_data_ex(fields=[], stock_code=[], period='follow', start_time='', 
end_time='', count=-1,
dividend_type='follow', fill_data=True, subscribe=True)
释义： 获取行情数据 第二版
参数： 
fields ： list ，字段列表，对不同周期的数据取值范围不同。默认为空 list ，代表所有字段。
stock_code ： list ，合约代码列表
period ： string ，周期，默认为 'follow' ，为当前主图周期，可选值：
注：行情数据字段列表见附录 5.5
'tick' ：分笔线
def quote_callback(s):
 def callback(data):
 print(s,data)
 return
 return callback
def init(ContextInfo):
 
ContextInfo.subscribe_quote("600000.SH","tick","none",quote_callback('600000.
SH'))
1
2
3
4
5
6
7
ContextInfo.unsubscribe_quote(subId)1
data=ContextInfo.get_all_subscription()1

'1d' ：日线
'1m' ： 1 分钟线
'5m' ： 5 分钟线
'15m' ： 15 分钟线 
'l2quote' ： Level2 行情快照
'l2quoteaux' ： Level2 行情快照补充
'l2order' ： Level2 逐笔委托
'l2transaction' ： Level2 逐笔成交
'l2transactioncount' ： Level2 大单统计
'l2orderqueue' ： Level2 委买委卖队列
start_time ：开始时间，为空视为最早，时间格式为 '20201231' 或 '20201231093000'
end_time ：结束时间，为空视为最新，时间格式为 '20201231' 或 '20201231093000'
count ：数据最大个数， -1 视为不做个数限制
dividend_type ：复权方式，默认为 'follow' ，为当前主图复权方式，可选值：
'none' ：不复权
'front': 前复权
'back': 后复权
'front_ratio': 等比前复权
'back_ratio': 等比后复权
fill_data ：停牌填充方式，默认为 True （暂不可用）
subscribe ：订阅数据开关，默认为 True ，设置为 False 时不做数据订阅，只读取本地已有数据。
订阅模式下，除分笔以外的周期只会自动补充当天数据，分笔周期不自动补充数据。
返回：{code1: data1, code2: data2, ...} 
示例： 
 
（ 45 ）获取指定期权列表 ContextInfo.get_option_list() 
用法： ContextInfo.get_option_list(undl_code,dedate,opttype,isavailable)
释义： 获取指定期权列表。如获取历史期权，需先下载过期合约列表
参数： 
undl_code ：期权标的代码 , 如 '510300.SH'
dedate ：期权到期月或当前交易日期， "YYYYMM" 格式为期权到期月， "YYYYMMDD" 格式为获取
当前日期交易的期权
opttype ：期权类型，默认值为空， "CALL" ， "PUT" ，为空时认购认沽都取
isavailable ：是否可交易，当 dedate 的格式为 "YYYYMMDD" 格式为获取当前日期交易的期权时，
isavailable 为 True 时返回当前可用，为 False 时返回当前和历史可用
data=ContextInfo.get_market_data_ex(['open','high','low','close'],
['000300.SH'],period='1d',start_time='',end_time='',count=-1,dividend_type='f
ollow',fill_data=True,subscribe=True)
1

返回： 期权合约列表 list
示例： 
 
（ 46 ）获取股票期权的实时隐含波动率 ContextInfo.get_option_iv() 
用法： ContextInfo.get_option_iv(optioncode)
释义： 获取股票期权的实时隐含波动率
参数： 
optioncode ：期权代码，如 '10003280.SHO'
返回： double
示例： 
 
（ 47 ）基于 BS 模型计算欧式期权理论价格 ContextInfo.bsm_price() 
用法： ContextInfo.bsm_price(optionType,objectPrices,strikePrice,riskFree,sigma,days,dividend)
释义： 基于 Black-Scholes-Merton 模型，输入期权标的价格、期权行权价、无风险利率、期权标的年化
波动率、剩余天数、标的分红率、计算期权的理论价格
参数： 
optionType ：期权类型，认购： 'C' ，认沽： 'P'
objectPrices ：期权标的价格，可以是价格列表或者单个价格
strikePrice ：期权行权价
riskFree ：无风险收益率
sigma ：标的波动率
days ：剩余天数
dividend ：分红率
返回： 
objectPrices 为 float 时，返回 float
objectPrices 为 list 时，返回 list
计算结果最小值 0.0001 ，结果保留 4 位小数 , 输入非法参数返回 nan
示例： 
data=ContextInfo.get_option_list('510300.SH','202101',"CALL")# 获取到期月份为
202101 的上交所 510300ETF 认购合约
data=ContextInfo.get_option_list('510300.SH','20210104',"CALL",True);获取
20210104 当天上交所 510300ETF 可交易的认购合约
data=ContextInfo.get_option_list('510300.SH','20210104',"CALL",False);获取
20210104 当天上交所 510300ETF 已经上市的认购合约(包括退市)
1
2
3
def handlebar(ContextInfo):
    print( ContextInfo.get_option_iv('10003280.SHO'))
1
2

（ 48 ）基于 BS 模型计算欧式期权隐含波动率 ContextInfo.bsm_iv() 
用法： ContextInfo.bsm_iv(optionType,objectPrices,strikePrice,optionPrice,riskFree,days,dividend)
释义： 基于 Black-Scholes-Merton 模型 , 输入期权标的价格、期权行权价、期权现价、无风险利率、剩余
天数、标的分红率 , 计算期权的隐含波动率
参数： 
optionType ：期权类型，认购： 'C' ，认沽： 'P'
objectPrice ：期权标的价格
strikePrice ：期权行权价
optionPrice ：期权现价
riskFree ：无风险收益率
days ：剩余天数
dividend ：分红率
返回： double
示例： 
 
（ 49 ）取原始财务数据 ContextInfo.get_raw_financial_data() 
用法： 
ContextInfo.get_raw_financial_data(fieldList,stockList,startDate,endDate,report_type='announce_ti
me')
释义： 取原始财务数据，与 get_financial_data 相比不填充每个交易日的数据
参数： 
fieldList 字段列表， list ，如： [' 资产负债表 . 固定资产 ',' 利润表 . 净利润 ']
stockList ：股票列表， list ，如： ['600000.SH','000001.SZ']
startDate ：开始时间， string ，如： '20171209'
endDate ：结束时间， string ，如： '20171212'
report_type: 时间类型 , 可缺省 , 默认是按照数据的公告期为区分取数据 , 设置为 'report_time' 为按照
报告期取数据 , 可选值 :'announce_time','report_time'
返回：
import numpy as np
object_prices=list(np.arange(3,4,0.01));
# 计算剩余 15 天的行权价 3.5 的认购期权 , 在无风险利率 3%, 分红率为 0, 标的年化波动率为 23% 时标的价格
从 3 元到 4 元变动过程中期权理论价格序列
prices=ContextInfo.bsm_price('C',object_prices,3.5,0.03,0.23,15,0)
print(prices);
# 计算剩余 15 天的行权价 3.5 的认购期权 , 在无风险利率 3%, 分红率为 0, 标的年化波动率为 23% 时标的价格
为 3.51 元的平值期权的理论价格
price=ContextInfo.bsm_price('C',3.51,3.5,0.03,0.23,15,0)
print(price);
1
2
3
4
5
6
7
8
iv=ContextInfo.bsm_iv('C',3.51,3.5,0.0725,0.03,15);
# 计算剩余 15 天的行权价 3.5 的认购期权 , 在无风险利率 3%, 分红率为 0 时 , 标的现价 3.51 元 , 期权价格
0.0725 元时的隐含波动率
1
2

函数根据 stockList 代码列表 ,startDate,endDate 时间范围的大小范围不同的数据类型
(1) 代码列表 1- 时间范围为 1 返回： pandas.Series index= 字段
(2) 代码列表 1- 时间范围为 n 返回： pandas.DataFrame index= 时间 ,columns= 字段
(3) 代码列表 n- 时间范围为 1 返回： pandas.DataFrame index= 代码 ,columns= 字段
(4) 代码列表 n- 时间范围为 n 返回： pandas.Panel items= 代码 ,major_axis= 时间 ,minor_axis= 字段
选择按照公告期取数和按照报告期取数的区别 : 若某公司当年 4 月 26 日发布上年度年报 , 如果选择按照公告
期取数 , 则当年 4 月 26 日之后至下个财报发布日期之间的
数据都是上年度年报的财务数据 , 如果选择按照报告期取数 , 则上年度第 4 季度 ( 上年度 10 月 1 日 -12 月 31 日 )
的数据就是上年度报告期的数据 .
示例： 
 
（ 50 ）获取市场已退市合约 ContextInfo.get_his_contract_list() 
用法： ContextInfo.get_his_contract_list(market)
释义： 获取市场已退市合约，需要手动补充过期合约列表
参数： 
market: 市场 ,SH,SZ,SHO,SZO,IF 等
返回： list, 合约代码列表
示例： 
 
（ 51 ）获取指定期权标的对应的期权品种列表
ContextInfo.get_option_undl_data()
 
用法： ContextInfo.get_option_undl_data(undl_code_ref)
释义： 获取指定期权标的对应的期权品种列表
参数： 
undl_code_ref: 期权标的代码 , 如 '510300.SH' ，传空字符串时获取全部标的数据
返回： 
fieldList = 
['ASHAREBALANCESHEET.fix_assets','ASHAREINCOME.net_profit_incl_min_int_inc']
stockList = ['600000.SH','000001.SZ']
startDate = '20200101'
endDate = '20210101'
ContextInfo.get_raw_financial_data(fieldList,stockList,startDate,endDate)
1
2
3
4
5
def handlebar(ContextInfo):
    print( ContextInfo.get_his_contract_list('IF'))
def handlebar(ContextInfo):
    print( ContextInfo.get_his_contract_list('SHO'))
1
2
3
4
5

指定期权标的代码时返回对应该标的的期权合约列表 list
期权标的代码为空字符串时返回全部标的对应的品种列表的字典 dict
示例： 
 
（ 52 ）获取对应周期的北向数据 ContextInfo.get_north_finance_change() 
用法： ContextInfo.get_north_finance_change(period)
释义： 获取对应周期的北向数据
参数： 
period:1d 日线数据 1m 一分钟数据
返回： 
根据 period 返回一个 dict ，该字典的 key 值是北向数据的时间戳，其值仍然是一个 dict ，其值的 key 值是
北向数据的字段类型，其值是对应字段的值。 
根据 stockcode 返回一个 dict ，该字典的 key 值是北向持股统计数据的时间戳，其值仍然是一个 dict ，其
值的 key 值是北向持股统计数据的字段类型，其值是对应字段的值， 
根据 stockcode 返回一个 dict ，该字典的 key 值是北向持股明细数据的时间戳，其值仍然是一个 dict ，其
值的 key 值是北向持股明细数据的字段类型，其值是对应字段的值， 市场最新时间
示例： 
 
3.2.4. 交易函数 
交易函数下单跟界面人工点击下单走的下单、风控流程是一样的，唯一的区别是：交易函数下单通过解
析下单函数接口传过来的参数，形成相应的下单任务；而界面人工点击下单通过解析界面的输入、选
择，形成相应的下单任务。
运作流程：
（ 1 ）编写测试策略
（ 2 ）运行策略
（ 3 ）触发下单，解析参数
（ 4 ）生成任务
get_market_time("SH")1
