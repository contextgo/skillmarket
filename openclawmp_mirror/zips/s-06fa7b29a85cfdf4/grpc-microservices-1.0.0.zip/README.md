# gRPC 微服务通信指南

## 优势
HTTP/2 + Protobuf(比JSON小3-10倍) + 强类型 + 双向流 + 多语言

## Proto 定义
syntax = "proto3";
service UserService {
  rpc GetUser(Request) returns (User);
  rpc StreamUsers(Request) returns (stream User);
  rpc CreateUser(stream Request) returns (User);
  rpc Chat(stream Msg) returns (stream Msg);
}

## 拦截器
认证、日志、限流、追踪中间件

## 错误码
OK/CANCELLED/INVALID_ARGUMENT/NOT_FOUND/PERMISSION_DENIED/
RESOURCE_EXHAUSTED/UNAVAILABLE/DEADLINE_EXCEEDED/UNAUTHENTICATED

## 最佳实践
必须设 deadline/timeout
指数退避重试（3次，最大30s）
幂等设计（客户端生成 request ID）