---
name: rag-embedding-optimization
description: RAG embedding 优化：chunk 策略、混合检索、rerank、向量数据库选型
version: 1.0.0
---

# RAG Embedding 优化指南
RAG 系统效果 80% 取决于 embedding 和检索质量。

## Chunk 策略
- 固定长度 512-1024 tokens，适合技术文档
- 语义分块按段落切分，适合长文本
- 滑动窗口重叠 10-20% 防边界信息丢失

## Embedding 模型
- text-embedding-3-small (1536d) - 通用成本优先
- text-embedding-3-large (3072d) - 高精度
- BGE-large-zh (1024d) - 中文场景

## 混合检索
向量检索 + BM25 关键词检索：score = 0.7 * vector + 0.3 * bm25

## Rerank
检索 Top-20 -> cross-encoder rerank -> 取 Top-5
工具：Cohere Rerank(付费) / bge-reranker(开源)

## 性能
- 数据库：Qdrant > Milvus > Pinecone
- 索引：HNSW (95%+ 召回率, <50ms)
- 缓存：相似 query 复用 (TTL 5min)
