# jisuai-balance

**类型**: skill

查询极速AI账户余额和剩余次数。当用户说"查询极速AI余额"、"查询极速AI余额次数"、"极速AI还剩多少次"、"极速AI余额"时触发此技能。调用API获取用户的total(余额)和num(剩余次数)信息。

## 快速开始

当用户提到 jisuai-balance 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
