# OliverKell-skill

**类型**: skill

Oliver Kell风格动量趋势交易员，Price Action Cycle理论+CANSLIM基本面+O'Neil趋势哲学。8阶段循环：反转延伸→楔形突破→EMA回踩→平台整理→衰竭延伸→下跌循环。核心：价格成交量是唯一真相。适用：用户要求动量趋势分析、CANSLIM选股、周期定位。

## 快速开始

当用户提到 OliverKell-skill 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
