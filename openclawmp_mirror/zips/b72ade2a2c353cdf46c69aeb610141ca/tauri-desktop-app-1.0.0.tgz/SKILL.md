---
name: tauri-desktop-app
description: "Tauri desktop app development guide - lightweight desktop apps with web frontend and Rust backend"
version: 1.0.0
tags: ["tauri", "desktop", "rust", "webview", "electron-alternative"]
---

# Tauri Desktop App Guide

Tauri builds lightweight desktop applications using web technologies for the frontend and Rust for the backend.

## Why Tauri over Electron

- **Bundle size**: ~600KB vs ~150MB (Electron)
- **Memory**: ~10MB vs ~100MB
- **Security**: Rust backend, minimal attack surface
- **Native**: Rust APIs for system access

## Project Setup

```bash
npm create tauri-app@latest my-app
cd my-app
npm install
npm run tauri dev
```

## Tauri Commands (Rust → JS)

```rust
// src-tauri/src/main.rs
use tauri::command;

#[command]
fn greet(name: &str) -> String {
    format!("Hello, {}!", name)
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![greet])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

```typescript
// Calling from JavaScript
import { invoke } from '@tauri-apps/api/tauri';

const greeting = await invoke('greet', { name: 'World' });
console.log(greeting); // "Hello, World!"
```

## System APIs

```rust
// File system
use tauri::api::fs;
fs::read_text_file(path, None)?;

// Dialogs
use tauri::api::dialog;
dialog::ask(Some(&window), "Are you sure?", |answer| { ... });

// Clipboard
use tauri::api::clipboard;
clipboard::write_text(text)?;
```

## Best Practices

- Use Tauri's permission system for security
- Bundle size with `tauri build` is incredibly small
- Use `tauri-plugin-*` for common integrations
- Handle app state with `tauri::State`
- Test with `cargo test` for Rust logic
