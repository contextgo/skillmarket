# 道生一

> 道生一，一生二，二生三，三生万物。

一套完整的 **AI 工作流编排系统**，实现人机协作的闭环管理。

## 工作流程

```
人下达任务 → OpenClaw制定方向 → Claude执行 → Obsidian存储
                                              ↓
人验收完成 ← OpenClaw检阅结果 ← Claude返工修改 ← OpenClaw验收
```

## 角色分工

| 角色 | 工具 | 职责 |
|------|------|------|
| **人** | - | 下达任务、最终验收 |
| **OpenClaw** | 主控 | 制定方案、分配任务、检阅结果、验收 |
| **Claude** | ACP/Subagent | 具体执行、返工修改 |
| **Obsidian** | 黑曜石笔记 | 存储信息、记录结果 |

## 快速开始

### 1. 下达任务

```
@道生一 帮我写一篇关于AI的小红书文案
```

### 2. 自动执行

系统会自动：
1. **制定方案** - OpenClaw 分析任务并制定执行计划
2. **分配执行** - Claude 按照计划执行任务
3. **存储结果** - 自动保存到 Obsidian
4. **质量检阅** - OpenClaw 检查结果
5. **返工优化** - 如不合格，自动返工修改
6. **最终验收** - 通知人类验收

### 3. 验收完成

人类查看结果，确认完成或提出修改意见。

## 使用示例

### 示例一：内容创作

```
@道生一 写一篇关于"AI助手"的知乎回答
```

执行流程：
1. OpenClaw 制定写作大纲
2. Claude 撰写内容
3. 保存到 Obsidian: `AI助手知乎回答.md`
4. OpenClaw 检查质量
5. 如需要，Claude 优化修改
6. 通知人类验收

### 示例二：代码开发

```
@道生一 写一个Python爬虫，抓取豆瓣Top250电影
```

执行流程：
1. OpenClaw 制定技术方案
2. Claude 编写代码
3. 保存到 Obsidian: `douban_spider.py`
4. OpenClaw 代码审查
5. 如需要，Claude 修复Bug
6. 通知人类验收

### 示例三：数据分析

```
@道生一 分析这份销售数据，生成报告
```

执行流程：
1. OpenClaw 制定分析方案
2. Claude 执行分析
3. 保存到 Obsidian: `销售数据分析报告.md`
4. OpenClaw 检查分析质量
5. 如需要，Claude 补充分析
6. 通知人类验收

## 配置要求

### 必需技能

| 技能 | 用途 |
|------|------|
| `黑曜石笔记` | 存储执行结果 |
| `writing-plans` | 制定执行方案 |
| `executing-plans` | 执行计划 |

### 可选技能

| 技能 | 用途 |
|------|------|
| `code` | 代码相关任务 |
| `docx` | 生成Word文档 |
| `xlsx` | 处理Excel数据 |
| `pptx` | 生成PPT |

### 配置 Obsidian

编辑 `~/.stepclaw/skills/黑曜石笔记/SKILL.md` 配置你的 Obsidian 库路径。

## 工作流配置

在 `~/.stepclaw/openclaw.json` 中添加：

```json
{
  "workflow": {
    "道生一": {
      "storage": {
        "type": "obsidian",
        "path": "~/Documents/Obsidian/Workflow"
      },
      "agents": {
        "executor": "claude",
        "reviewer": "openclaw"
      },
      "quality": {
        "autoReview": true,
        "maxRetries": 3
      }
    }
  }
}
```

## 高级用法

### 自定义工作流

```
@道生一 --plan-only 帮我规划一个项目
```

只制定方案，不执行。

### 跳过存储

```
@道生一 --no-store 快速生成一个草稿
```

不保存到 Obsidian，直接返回结果。

### 指定执行者

```
@道生一 --agent gpt-4 用GPT-4执行这个任务
```

使用指定的 AI 执行。

## 故障排查

### 任务卡住不动

```bash
# 查看任务状态
openclaw workflow status

# 取消任务
openclaw workflow cancel <task-id>
```

### Obsidian 存储失败

1. 检查 Obsidian 库路径配置
2. 确保 Obsidian 已安装
3. 检查磁盘空间

### Claude 执行失败

1. 检查 Claude 是否已配置
2. 查看执行日志
3. 调整任务描述，使其更清晰

## 设计理念

**道生一**：人类的一个想法（道）

**一生二**：分解为计划和执行（二）

**二生三**：加入存储和检阅（三）

**三生万物**：循环往复，生成无限可能

## 相关链接

- OpenClaw: https://github.com/openclaw/openclaw
- 黑曜石笔记: https://obsidian.md
- Claude: https://claude.ai

## 许可

MIT License