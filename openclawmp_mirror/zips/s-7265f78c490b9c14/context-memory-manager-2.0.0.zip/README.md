# Context & Memory Manager

**综合性的上下文与记忆管理工具**

结合 CLI 会话监控和智能记忆优化，解决：
- AI CLI 工具无回复问题
- 上下文膨胀导致的性能下降
- 记忆读取效率低下
- 信息遗忘和重复

---

## 核心功能

### 1. 会话上下文管理

**自动检测问题**
- 监控 `replies=0` 无回复情况
- 检测会话文件大小（阈值：500KB）
- 检测消息数量（阈值：300行）

**智能压缩**
- 保留最近 N 条消息（默认100条）
- 保留系统配置信息
- 自动创建备份
- 失败时自动恢复

**支持工具**
| 工具 | 路径 | 状态 |
|------|------|------|
| OpenClaw | `~/.openclaw/agents/main/sessions/*.jsonl` | ✅ |
| Claude Code | `~/.claude/sessions/*.jsonl` | ✅ |
| Aider | `~/.aider/sessions/*.jsonl` | ✅ |
| Cursor | `~/.cursor/sessions/*.jsonl` | ✅ |

### 2. 分层记忆存储

```
┌─────────────────────────────────────────┐
│      Context & Memory Manager           │
├─────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐      │
│  │  会话层     │  │  工作层     │      │
│  │ (短期)     │  │ (中期)     │      │
│  │ 4000 tokens│  │ 20000 tokens│      │
│  └─────────────┘  └─────────────┘      │
│  ┌─────────────┐  ┌─────────────┐      │
│  │  知识层     │  │  索引缓存   │      │
│  │ (长期)     │  │ (快速查询)  │      │
│  │ 100000 tokens│ │            │      │
│  └─────────────┘  └─────────────┘      │
└─────────────────────────────────────────┘
```

**三层记忆**
- **会话层 (Session)** - 当前对话上下文，关闭后清除
- **工作层 (Working)** - 项目/任务相关记忆，长期保存
- **知识层 (Knowledge)** - 通用知识、用户偏好，永久保存

### 3. 按需加载策略

```javascript
// 只加载需要的部分
const context = await cmm.load({
  layer: 'working',
  type: 'task',
  relevance: 'high',
  limit: 10
})
```

**加载优先级**
1. 会话层（当前对话）
2. 工作层（相关任务）
3. 知识层（用户偏好）

### 4. 摘要压缩

**自动触发条件**
- 消息超过 2000 tokens
- 会话超过 100 条消息
- 手动触发压缩

**压缩策略**
- 提取关键信息（what, who, when, result）
- 保留重要决策和结论
- 删除冗余对话

### 5. 主动记录机制

**三问法**（对话结束前自动触发）
1. 用户有什么重要信息需要记住？
2. 有什么任务还没完成？
3. 下次见面需要先读什么？

---

## 使用方法

### 快速检查

```bash
# 检查所有会话健康状态
cmm check

# 检查特定工具
cmm check --tool openclaw
```

### 智能压缩

```bash
# 压缩所有过大的会话和记忆
cmm compress

# 压缩特定会话
cmm compress --file /path/to/session.jsonl

# 自定义保留消息数
cmm compress --keep-messages 50
```

### 记忆管理

```bash
# 查看记忆统计
cmm memory stats

# 清理过期记忆
cmm memory cleanup

# 导出记忆
cmm memory export --format json
```

### 自动监控

```bash
# 添加到 cron，每30分钟检查一次
*/30 * * * * /usr/local/bin/cmm check --auto-compress
```

---

## 配置文件

### CONFIG.json

```json
{
  "context": {
    "thresholds": {
      "maxSizeKB": 500,
      "maxLines": 300,
      "maxTokens": 4000
    },
    "compression": {
      "keepMessages": 100,
      "keepSystemLines": 5,
      "createBackup": true
    },
    "tools": {
      "openclaw": {
        "sessionDir": "~/.openclaw/agents/main/sessions",
        "enabled": true
      },
      "claude-code": {
        "sessionDir": "~/.claude/sessions",
        "enabled": true
      }
    }
  },
  "memory": {
    "layers": {
      "session": { "maxTokens": 4000, "ttl": "session" },
      "working": { "maxTokens": 20000, "ttl": "30d" },
      "knowledge": { "maxTokens": 100000, "ttl": "forever" }
    },
    "autoCompress": true,
    "compressThreshold": 2000,
    "lazyLoad": true,
    "activeRecord": true
  },
  "integration": {
    "autoCompressBeforeSave": true,
    "syncSessionToWorking": true,
    "pruneOldMemories": true
  }
}
```

---

## 工作流程

### 场景 1: 会话无回复

```
用户: AI 没有回复了

Agent:
1. 检测 replies=0
2. 检查会话文件大小: 2MB (>500KB)
3. 执行智能压缩
   - 保留最近100条消息
   - 创建备份
4. 验证压缩结果
5. 返回: "已压缩会话，从 2MB 降至 200KB"
```

### 场景 2: 记忆读取优化

```
用户: 之前说的那个项目怎么样了

Agent:
1. 按需加载工作层记忆
2. 匹配关键词 "项目"
3. 返回相关记忆
4. 更新访问时间
```

### 场景 3: 主动记录

```
对话结束前:

Agent:
1. 三问法检查
2. 提取重要信息
3. 自动分类存储
   - 任务 → 工作层
   - 偏好 → 知识层
4. 生成摘要
```

---

## 触发词

- "检查会话健康"
- "压缩上下文"
- "清理记忆"
- "管理上下文"
- "优化记忆"
- "cmm"

---

## 故障排除

### 会话压缩后仍然无回复

1. 检查工具日志
2. 验证会话格式
3. 尝试重启工具

### 记忆读取失败

1. 检查记忆层配置
2. 验证索引缓存
3. 手动重建索引

---

## 相关技能

- **memory-optimizer** - 记忆读取优化（已合并）
- **cli-context-manager** - CLI 上下文管理（已合并）
- **dataclaw-tools** - 数据导出工具

---

**版本**: 2.0.0  
**更新日期**: 2026-02-28  
**合并来源**: memory-optimizer + cli-context-manager