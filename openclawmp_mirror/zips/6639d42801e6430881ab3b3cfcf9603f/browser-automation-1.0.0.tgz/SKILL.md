---
name: browser-automation
description: "基于 Playwright 的浏览器自动化技能，支持页面导航、截图、表单填写和交互操作"
version: 1.1.0
---

# 浏览器自动化技能

基于 Playwright 的页面导航、截图、表单填写和交互操作，让 AI Agent 能够自动化浏览器任务。

## 能力

- **页面导航**：打开 URL、前进后退、刷新页面
- **元素操作**：点击、输入、选择、悬停、拖拽
- **截图捕捉**：全页截图、元素截图、PDF 导出
- **表单填写**：自动填写输入框、选择下拉菜单、上传文件
- **等待策略**：智能等待元素出现/可见/可交互

## 使用方式

### 基础导航

```bash
# 打开页面并截图
browser open "https://example.com"
browser screenshot --full-page
```

### 表单填写

```bash
# 填写登录表单
browser fill "#email" "user@example.com"
browser fill "#password" "secret"
browser click "#login-btn"
```

### 数据提取

```bash
# 提取页面文本内容
browser snapshot --selector ".content"
browser extract --type table --selector "table.data"
```

## 最佳实践

1. 使用 CSS 选择器定位元素，优先使用 data-testid
2. 设置合理的超时时间（默认 30s）
3. 失败时先截图再重试，便于调试
4. 复杂操作拆分为多步，每步验证结果
