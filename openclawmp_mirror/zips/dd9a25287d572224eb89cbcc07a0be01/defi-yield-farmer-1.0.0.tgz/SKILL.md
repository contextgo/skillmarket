---
name: defi-yield-farmer
displayName: DeFi收益农场助手
description: DeFi收益农场助手，流动性挖矿、质押收益、自动复投、APY对比分析
version: 1.1.0
type: skill
tags:
  - defi
  - yield
  - farming
  - staking
  - liquidity
category: finance/crypto
---

# DeFi收益农场助手 🌾

> DeFi世界的高收益导航仪

## 何时使用

当用户提到以下场景时激活此技能：
- 查询DeFi协议收益
- 进行流动性挖矿
- 对比各协议APY
- 评估智能合约风险
- 了解质押收益
- 检测rug pull风险

## 核心功能

### 💰 收益排行
- 各协议APY实时对比
- 主流池子收益排行
- 稳定币/主流币收益
- 新项目高息池发现

### 🌾 流动性挖矿
- 单币/双币池指导
- 最佳池子推荐
- 智能合约安全检测
- gas费用优化

### 🔄 自动复投
- 收益自动复投
- 复投频率设置
- 收益累积计算
- 一键操作

### ⚠️ 风险提示
- 智能合约风险评估
- rug pull检测
- TVL变化监控
- 退出时机建议

## 前置要求

### 必需配置
- 钱包（MetaMask等）
- 目标协议的钱包网络
- 少量Gas代币

### 推荐配置
```bash
# 推荐使用硬件钱包
export DEFI_WALLET_TYPE="hardware"
```

### 知识要求
- 理解流动性池原理
- 了解无常损失概念
- 熟悉Gas费用机制
- 理解智能合约风险

## 使用示例

```
现在哪个池子收益最高？
帮我检测这个DeFi合约的安全性
ETH质押收益怎么样？
哪个协议APY最高？
这个项目有没有rug pull风险？
```

## 最佳实践

### 💰 收益优化
1. **分散投资**：不要把所有资金放一个池子
2. **关注无常损失**：双币池要考虑币价波动
3. **Gas优化**：选择低Gas时段操作
4. **复投策略**：收益及时复投增加收益

### 🌾 池子选择
1. **安全第一**：优先选择审计过的协议
2. **TVL考量**：太低可能跑路，太高收益低
3. **团队背景**：了解项目方背景
4. **及时退出**：高收益池往往风险大

### ⚠️ 风险管理
1. **只投可承受损失**：DeFi高风险
2. **分散风险**：多个协议、多个池子
3. **关注TVL**：大幅下降可能是预警
4. **及时提款**：发现异常立即退出

## 相关技能

| 技能 | 用途 |
|------|------|
| `binance-trader` | 交易执行 |
| `crypto-wallet-guard` | 钱包安全 |
| `on-chain-analyzer` | 链上数据分析 |
| `whale-tracker` | 巨鲸追踪 |
| `portfolio-manager` | 投资组合管理 |

## 支持协议

Uniswap | Curve | Aave | Compound | Lido | Rocket Pool | Yearn | Synthetix

## 风险提示

- ⚠️ DeFi高收益伴随高风险
- ⚠️ 智能合约可能存在漏洞
- ⚠️ 项目可能跑路（rug pull）
- ⚠️ 无常损失可能导致亏损
- ⚠️ 建议只投入可承受损失的资金

## 安装

```bash
openclawmp install skill/@u-38a9d2a1117b45e69b21/defi-yield-farmer
```

## 更新日志

### v1.1.0 (2026-03-11)
- 新增：何时使用章节
- 新增：前置要求、最佳实践章节
- 新增：相关技能关联
- 新增：frontmatter 增强（displayName, tags, type, category）
- 新增：支持协议列表
- 优化：文档结构重组

### v1.0.0
- 初始版本

---

**作者**：Batman0506  
**版本**：1.1.0  
**标签**：DeFi、收益农场、流动性挖矿、质押
