#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
团队规模计算器
用于工程团队规模规划和招聘计划
"""

import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum


class ProjectComplexity(Enum):
    """项目复杂度"""

    SIMPLE = 1
    MODERATE = 2
    COMPLEX = 3
    VERY_COMPLEX = 4
    EXTREMELY_COMPLEX = 5


class EngineerLevel(Enum):
    """工程师级别"""

    JUNIOR = 1
    MID = 2
    SENIOR = 3
    STAFF = 4
    PRINCIPAL = 5


@dataclass
class Project:
    """项目信息"""

    name: str
    description: str
    complexity: ProjectComplexity
    duration_months: float  # 项目周期（月）
    priority: int  # 优先级，1为最高
    required_skills: List[str]
    dependencies: Optional[List[str]] = None

    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []

    @property
    def effort_points(self) -> float:
        """计算工作量点数"""
        # 复杂度 × 周期 = 工作量点数
        return self.complexity.value * self.duration_months

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "description": self.description,
            "complexity": self.complexity.name,
            "complexity_value": self.complexity.value,
            "duration_months": self.duration_months,
            "priority": self.priority,
            "required_skills": self.required_skills,
            "dependencies": self.dependencies,
            "effort_points": self.effort_points,
        }


@dataclass
class Engineer:
    """工程师信息"""

    name: str
    level: EngineerLevel
    skills: List[str]
    productivity: float  # 生产力系数，1.0为标准
    availability: float  # 可用性，0-1
    current_project: Optional[str] = None

    @property
    def effective_productivity(self) -> float:
        """有效生产力"""
        return self.productivity * self.availability * self.level.value

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "level": self.level.name,
            "level_value": self.level.value,
            "skills": self.skills,
            "productivity": self.productivity,
            "availability": self.availability,
            "current_project": self.current_project,
            "effective_productivity": self.effective_productivity,
        }


@dataclass
class HiringNeed:
    """招聘需求"""

    role: str
    level: EngineerLevel
    quantity: int
    priority: int
    required_skills: List[str]
    target_hire_date: str
    budget: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "role": self.role,
            "level": self.level.name,
            "quantity": self.quantity,
            "priority": self.priority,
            "required_skills": self.required_skills,
            "target_hire_date": self.target_hire_date,
            "budget": self.budget,
        }


class TeamSizeCalculator:
    """团队规模计算器"""

    def __init__(self):
        self.projects: List[Project] = []
        self.engineers: List[Engineer] = []
        self.hiring_needs: List[HiringNeed] = []

    def add_project(self, project: Project) -> None:
        """添加项目"""
        self.projects.append(project)

    def add_engineer(self, engineer: Engineer) -> None:
        """添加工程师"""
        self.engineers.append(engineer)

    def add_hiring_need(self, hiring_need: HiringNeed) -> None:
        """添加招聘需求"""
        self.hiring_needs.append(hiring_need)

    def calculate_team_capacity(self) -> float:
        """计算团队总产能"""
        return sum(eng.effective_productivity for eng in self.engineers)

    def calculate_project_demand(self) -> float:
        """计算项目总需求"""
        return sum(proj.effort_points for proj in self.projects)

    def calculate_capacity_gap(self) -> float:
        """计算产能缺口"""
        return self.calculate_project_demand() - self.calculate_team_capacity()

    def analyze_skill_gaps(self) -> Dict[str, Dict[str, Any]]:
        """分析技能缺口"""
        # 收集所有项目需要的技能
        required_skills = {}
        for project in self.projects:
            for skill in project.required_skills:
                if skill not in required_skills:
                    required_skills[skill] = {"demand": 0, "supply": 0}
                required_skills[skill]["demand"] += project.effort_points

        # 收集工程师拥有的技能
        for engineer in self.engineers:
            for skill in engineer.skills:
                if skill in required_skills:
                    required_skills[skill]["supply"] += engineer.effective_productivity

        # 计算缺口
        result = {}
        for skill, data in required_skills.items():
            gap = data["demand"] - data["supply"]
            if gap > 0:
                result[skill] = {
                    "demand": data["demand"],
                    "supply": data["supply"],
                    "gap": gap,
                    "gap_percentage": (gap / data["demand"]) * 100
                    if data["demand"] > 0
                    else 0,
                }

        return result

    def optimize_team_allocation(self) -> List[Dict[str, Any]]:
        """优化团队分配"""
        # 按优先级排序项目
        sorted_projects = sorted(self.projects, key=lambda p: p.priority)

        # 按生产力排序工程师
        sorted_engineers = sorted(
            self.engineers, key=lambda e: e.effective_productivity, reverse=True
        )

        allocations = []
        remaining_capacity = self.calculate_team_capacity()

        for project in sorted_projects:
            if remaining_capacity <= 0:
                break

            # 分配工程师到项目
            project_engineers = []
            assigned_capacity = 0

            for engineer in sorted_engineers:
                if (
                    engineer.current_project is None
                    and assigned_capacity < project.effort_points
                ):
                    # 检查技能匹配
                    skill_match = any(
                        skill in engineer.skills for skill in project.required_skills
                    )
                    if skill_match or not project.required_skills:
                        project_engineers.append(engineer.name)
                        assigned_capacity += engineer.effective_productivity
                        engineer.current_project = project.name

            allocation = {
                "project": project.name,
                "required_effort": project.effort_points,
                "assigned_engineers": project_engineers,
                "assigned_capacity": assigned_capacity,
                "capacity_gap": project.effort_points - assigned_capacity,
                "coverage_percentage": (assigned_capacity / project.effort_points * 100)
                if project.effort_points > 0
                else 0,
            }
            allocations.append(allocation)
            remaining_capacity -= assigned_capacity

        return allocations

    def generate_hiring_recommendations(self) -> List[Dict[str, Any]]:
        """生成招聘建议"""
        capacity_gap = self.calculate_capacity_gap()
        skill_gaps = self.analyze_skill_gaps()

        recommendations = []

        # 基于产能缺口的建议
        if capacity_gap > 0:
            avg_engineer_productivity = (
                self.calculate_team_capacity() / len(self.engineers)
                if self.engineers
                else 2.0
            )
            needed_engineers = max(1, round(capacity_gap / avg_engineer_productivity))

            recommendations.append(
                {
                    "type": "capacity",
                    "reason": f"产能缺口: {capacity_gap:.1f} 工作量点数",
                    "recommendation": f"招聘 {needed_engineers} 名工程师",
                    "priority": "高" if capacity_gap > 10 else "中",
                    "estimated_impact": f"填补 {capacity_gap:.1f} 工作量缺口",
                }
            )

        # 基于技能缺口的建议
        for skill, gap_data in skill_gaps.items():
            if gap_data["gap_percentage"] > 30:  # 缺口超过30%
                recommendations.append(
                    {
                        "type": "skill",
                        "skill": skill,
                        "reason": f"技能 '{skill}' 缺口: {gap_data['gap_percentage']:.1f}%",
                        "recommendation": f"招聘具有 '{skill}' 技能的工程师",
                        "priority": "高" if gap_data["gap_percentage"] > 50 else "中",
                        "estimated_impact": f"填补 {gap_data['gap']:.1f} 技能缺口",
                    }
                )

        return recommendations

    def generate_quarterly_plan(self, quarters: int = 4) -> Dict[str, Any]:
        """生成季度计划"""
        plan = {}

        for quarter in range(1, quarters + 1):
            quarter_key = f"Q{quarter}"

            # 模拟季度增长（假设每季度招聘1-2人）
            new_hires = min(2, max(1, quarter - 1))
            projected_capacity = self.calculate_team_capacity() + (
                new_hires * 2.0
            )  # 假设新员工生产力为2.0

            # 计算本季度可完成的项目
            quarterly_capacity = projected_capacity / quarters
            completed_projects = []
            remaining_capacity = quarterly_capacity

            for project in sorted(self.projects, key=lambda p: p.priority):
                if (
                    remaining_capacity >= project.effort_points
                    and project.name not in completed_projects
                ):
                    completed_projects.append(project.name)
                    remaining_capacity -= project.effort_points

            plan[quarter_key] = {
                "projected_team_size": len(self.engineers) + new_hires,
                "projected_capacity": projected_capacity,
                "quarterly_capacity": quarterly_capacity,
                "target_projects": completed_projects,
                "hiring_target": new_hires,
                "budget_estimate": new_hires * 150000,  # 假设平均年薪15万
            }

        return plan

    def export_report(self, filename: str) -> None:
        """导出报告"""
        report = {
            "summary": {
                "team_capacity": self.calculate_team_capacity(),
                "project_demand": self.calculate_project_demand(),
                "capacity_gap": self.calculate_capacity_gap(),
                "team_size": len(self.engineers),
                "project_count": len(self.projects),
            },
            "team_analysis": {
                "engineers": [eng.to_dict() for eng in self.engineers],
                "total_productivity": self.calculate_team_capacity(),
            },
            "project_analysis": {
                "projects": [proj.to_dict() for proj in self.projects],
                "total_demand": self.calculate_project_demand(),
            },
            "skill_gap_analysis": self.analyze_skill_gaps(),
            "team_allocation": self.optimize_team_allocation(),
            "hiring_recommendations": self.generate_hiring_recommendations(),
            "quarterly_plan": self.generate_quarterly_plan(),
            "hiring_needs": [need.to_dict() for need in self.hiring_needs],
        }

        with open(filename, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        print(f"报告已导出到 {filename}")

    def print_summary(self) -> None:
        """打印摘要"""
        print("\n" + "=" * 80)
        print("团队规模分析报告")
        print("=" * 80)

        print(f"\n1. 产能分析:")
        print(f"   团队总产能: {self.calculate_team_capacity():.1f} 工作量点数")
        print(f"   项目总需求: {self.calculate_project_demand():.1f} 工作量点数")
        print(f"   产能缺口: {self.calculate_capacity_gap():.1f} 工作量点数")

        print(f"\n2. 团队构成:")
        print(f"   工程师总数: {len(self.engineers)}")
        level_counts = {}
        for eng in self.engineers:
            level = eng.level.name
            level_counts[level] = level_counts.get(level, 0) + 1

        for level, count in level_counts.items():
            print(f"   {level}: {count}人")

        print(f"\n3. 项目分析:")
        print(f"   项目总数: {len(self.projects)}")
        for project in sorted(self.projects, key=lambda p: p.priority):
            print(
                f"   - {project.name}: {project.effort_points:.1f}点数 (优先级: {project.priority})"
            )

        print(f"\n4. 技能缺口分析:")
        skill_gaps = self.analyze_skill_gaps()
        if skill_gaps:
            for skill, gap_data in skill_gaps.items():
                print(
                    f"   {skill}: 需求{gap_data['demand']:.1f} - 供应{gap_data['supply']:.1f} = 缺口{gap_data['gap']:.1f} ({gap_data['gap_percentage']:.1f}%)"
                )
        else:
            print("   无显著技能缺口")

        print(f"\n5. 招聘建议:")
        recommendations = self.generate_hiring_recommendations()
        for rec in recommendations:
            print(f"   [{rec['priority']}] {rec['recommendation']} - {rec['reason']}")


def create_sample_data() -> TeamSizeCalculator:
    """创建示例数据"""
    calculator = TeamSizeCalculator()

    # 添加工程师
    calculator.add_engineer(
        Engineer(
            name="张三",
            level=EngineerLevel.SENIOR,
            skills=["Python", "Django", "PostgreSQL", "AWS"],
            productivity=1.2,
            availability=0.9,
        )
    )

    calculator.add_engineer(
        Engineer(
            name="李四",
            level=EngineerLevel.MID,
            skills=["JavaScript", "React", "Node.js", "MongoDB"],
            productivity=1.0,
            availability=1.0,
        )
    )

    calculator.add_engineer(
        Engineer(
            name="王五",
            level=EngineerLevel.JUNIOR,
            skills=["Python", "Flask", "MySQL"],
            productivity=0.8,
            availability=0.8,
        )
    )

    # 添加项目
    calculator.add_project(
        Project(
            name="用户管理系统",
            description="开发完整的用户管理功能",
            complexity=ProjectComplexity.COMPLEX,
            duration_months=3.0,
            priority=1,
            required_skills=["Python", "Django", "PostgreSQL"],
        )
    )

    calculator.add_project(
        Project(
            name="前端仪表板",
            description="开发数据可视化仪表板",
            complexity=ProjectComplexity.MODERATE,
            duration_months=2.0,
            priority=2,
            required_skills=["JavaScript", "React", "Node.js"],
        )
    )

    calculator.add_project(
        Project(
            name="API网关",
            description="开发统一的API网关",
            complexity=ProjectComplexity.VERY_COMPLEX,
            duration_months=4.0,
            priority=3,
            required_skills=["Python", "FastAPI", "Redis", "Docker"],
        )
    )

    # 添加招聘需求
    calculator.add_hiring_need(
        HiringNeed(
            role="后端工程师",
            level=EngineerLevel.SENIOR,
            quantity=1,
            priority=1,
            required_skills=["Python", "FastAPI", "微服务"],
            target_hire_date="2024-06-01",
            budget=180000,
        )
    )

    calculator.add_hiring_need(
        HiringNeed(
            role="前端工程师",
            level=EngineerLevel.MID,
            quantity=1,
            priority=2,
            required_skills=["React", "TypeScript", "Next.js"],
            target_hire_date="2024-07-01",
            budget=150000,
        )
    )

    return calculator


def main():
    """主函数"""
    print("团队规模计算器")
    print("=" * 50)

    # 创建示例数据
    calculator = create_sample_data()

    # 生成报告
    calculator.print_summary()

    # 导出详细报告
    calculator.export_report("team_planning_report.json")

    print("\n6. 季度计划:")
    quarterly_plan = calculator.generate_quarterly_plan()
    for quarter, plan in quarterly_plan.items():
        print(f"\n   {quarter}:")
        print(f"     预计团队规模: {plan['projected_team_size']}人")
        print(f"     预计产能: {plan['projected_capacity']:.1f}点数")
        print(f"     招聘目标: {plan['hiring_target']}人")
        print(f"     预算估算: ¥{plan['budget_estimate']:,.0f}")
        print(f"     目标项目: {', '.join(plan['target_projects'])}")

    print("\n" + "=" * 80)
    print("使用说明:")
    print("1. 工作量点数 = 项目复杂度 × 项目周期")
    print("2. 工程师有效生产力 = 级别系数 × 生产力系数 × 可用性")
    print("3. 产能缺口 = 项目总需求 - 团队总产能")
    print("4. 建议基于产能缺口和技能缺口分析")
    print("=" * 80)


if __name__ == "__main__":
    main()
