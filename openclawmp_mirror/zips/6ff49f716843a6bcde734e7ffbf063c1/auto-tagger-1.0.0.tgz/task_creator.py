#!/usr/bin/env python3
"""
Task Creator with Auto Tagger - 任务创建 + 自动打标签
"""

import sys
import json
sys.path.insert(0, '/root/.openclaw/workspace/skills/auto-tagger')
from auto_tagger import suggest_tags

def create_task_with_tags(task_name, task_type="工作", priority="🟡 P1", note=""):
    """创建任务并自动打标签"""
    
    # 自动分析标签
    result = suggest_tags(task_name, note)
    tags = result["tags"]
    
    # 返回任务数据
    task_data = {
        "任务名称": task_name,
        "类型": task_type,
        "优先级": priority,
        "状态": "⏳ 待办",
        "备注": note,
        "标签": tags
    }
    
    return task_data, result

def main():
    """命令行测试"""
    if len(sys.argv) < 2:
        print("用法: python task_creator.py '任务名称' [类型] [优先级] [备注]")
        sys.exit(1)
    
    task_name = sys.argv[1]
    task_type = sys.argv[2] if len(sys.argv) > 2 else "工作"
    priority = sys.argv[3] if len(sys.argv) > 3 else "🟡 P1"
    note = sys.argv[4] if len(sys.argv) > 4 else ""
    
    task_data, result = create_task_with_tags(task_name, task_type, priority, note)
    
    print(f"📋 任务: {task_name}")
    print(f"   类型: {task_type}")
    print(f"   优先级: {priority}")
    print(f"   自动标签: {' '.join(tags for tags in [task_data['标签']][0])}")
    print(f"   匹配关键词: {result['matched_keywords']}")
    
    # 输出 JSON 供外部调用
    print("\n--- JSON ---")
    print(json.dumps(task_data, ensure_ascii=False))

if __name__ == "__main__":
    main()
