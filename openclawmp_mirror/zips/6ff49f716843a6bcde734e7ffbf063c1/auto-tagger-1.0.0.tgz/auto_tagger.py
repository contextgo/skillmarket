#!/usr/bin/env python3
"""
Auto Tagger - 自动分析任务内容，智能推荐标签
"""

import json
import re
from pathlib import Path

MAPPING_FILE = "/root/.openclaw/workspace/skills/auto-tagger/keyword-mapping.json"

def load_mapping():
    """加载关键词映射表"""
    with open(MAPPING_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def extract_tags(text, mapping=None):
    """从文本中提取标签"""
    if mapping is None:
        mapping = load_mapping()
    
    tags = set()
    matched_keywords = []
    
    # 遍历关键词映射
    for keyword, tag_list in mapping.get("keywords", {}).items():
        if keyword in text:
            tags.update(tag_list)
            matched_keywords.append(keyword)
    
    return list(tags), matched_keywords

def suggest_tags(task_name, note=""):
    """分析任务名称和备注，返回建议标签"""
    full_text = f"{task_name} {note}"
    tags, keywords = extract_tags(full_text)
    
    return {
        "tags": sorted(tags),
        "matched_keywords": keywords,
        "confidence": "high" if len(keywords) > 0 else "low"
    }

def main():
    """测试"""
    test_cases = [
        "自考公司法复习",
        "给老婆买生日礼物",
        "学习Python编程",
        "完成季度报告",
        "参加项目会议",
        "干部网络学院学习",
        "做雪花酥",
        "接入Obsidian知识库"
    ]
    
    print("🧪 自动打标签测试")
    print("=" * 50)
    
    for task in test_cases:
        result = suggest_tags(task)
        tags_str = " ".join(result["tags"]) if result["tags"] else "无匹配"
        print(f"\n📋 {task}")
        print(f"   关键词: {result['matched_keywords']}")
        print(f"   标签: {tags_str}")
        print(f"   置信度: {result['confidence']}")

if __name__ == "__main__":
    main()
