---
name: random-picker
description: 随机决策器。帮助用户从多个选项中随机选择、生成随机数、抽签、摇骰子、生成随机密码。适用于：(1) 用户选择困难（"中午吃什么""看什么电影"），(2) 抽签/抽奖（从名单中随机抽取），(3) 随机分组/排序，(4) 生成随机数或随机密码，(5) 摇骰子/掷硬币。NOT for: 需要加密安全级别随机数的场景、正式抽奖（需公证）。
---

# 随机决策器

## 使用方式

```bash
python3 <skill_dir>/scripts/picker.py <command> [args]
```

## 命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `pick` | 从选项中随机选一个 | `picker.py pick "火锅" "烧烤" "寿司" "麻辣烫"` |
| `pick-n` | 从选项中随机选 N 个 | `picker.py pick-n 2 "张三" "李四" "王五" "赵六"` |
| `number` | 生成随机数 | `picker.py number 1 100` |
| `dice` | 摇骰子 | `picker.py dice 2` (摇2个) |
| `coin` | 掷硬币 | `picker.py coin 3` (掷3次) |
| `shuffle` | 随机排序 | `picker.py shuffle "A" "B" "C" "D"` |
| `group` | 随机分组 | `picker.py group 2 "甲" "乙" "丙" "丁" "戊" "己"` |
| `password` | 生成随机密码 | `picker.py password 16` |
| `uuid` | 生成 UUID | `picker.py uuid` |

## 常见场景

### 吃什么
```bash
picker.py pick "火锅" "烧烤" "日料" "麻辣烫" "沙拉" "饺子"
```

### 从名单抽3人
```bash
picker.py pick-n 3 "张三" "李四" "王五" "赵六" "孙七" "周八"
```

### 团队随机分2组
```bash
picker.py group 2 "Alice" "Bob" "Charlie" "Diana" "Eve" "Frank"
```

## 无外部依赖

纯 Python 标准库实现，无需安装任何包。
