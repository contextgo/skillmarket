#!/usr/bin/env python3
"""
picker.py — 随机决策器
纯标准库实现，零依赖。

Usage:
    picker.py pick "A" "B" "C"           # 随机选一个
    picker.py pick-n 2 "A" "B" "C" "D"  # 随机选N个
    picker.py number 1 100               # 随机数
    picker.py dice [n]                   # 摇骰子
    picker.py coin [n]                   # 掷硬币
    picker.py shuffle "A" "B" "C"        # 随机排序
    picker.py group 2 "A" "B" "C" "D"   # 随机分组
    picker.py password [length]          # 随机密码
    picker.py uuid                       # 生成 UUID
"""

import random
import string
import sys
import uuid as uuid_mod
import math


def cmd_pick(args):
    if not args:
        print("❌ 请提供至少一个选项")
        sys.exit(1)
    choice = random.choice(args)
    print(f"🎯 选中：{choice}")
    print(f"（从 {len(args)} 个选项中随机抽取）")


def cmd_pick_n(args):
    if len(args) < 2:
        print("❌ 用法：pick-n <数量> <选项1> <选项2> ...")
        sys.exit(1)
    try:
        n = int(args[0])
    except ValueError:
        print(f"❌ '{args[0]}' 不是有效数字")
        sys.exit(1)
    items = args[1:]
    if n > len(items):
        print(f"❌ 要选 {n} 个，但只有 {len(items)} 个选项")
        sys.exit(1)
    chosen = random.sample(items, n)
    print(f"🎯 选中 {n} 个：")
    for i, c in enumerate(chosen, 1):
        print(f"   {i}. {c}")
    print(f"（从 {len(items)} 个选项中随机抽取）")


def cmd_number(args):
    lo, hi = 1, 100
    if len(args) >= 2:
        lo, hi = int(args[0]), int(args[1])
    elif len(args) == 1:
        hi = int(args[0])
    result = random.randint(lo, hi)
    print(f"🔢 随机数：{result}（范围 {lo}-{hi}）")


def cmd_dice(args):
    n = int(args[0]) if args else 1
    results = [random.randint(1, 6) for _ in range(n)]
    dice_faces = {1: "⚀", 2: "⚁", 3: "⚂", 4: "⚃", 5: "⚄", 6: "⚅"}
    display = " ".join(f"{dice_faces[r]} ({r})" for r in results)
    print(f"🎲 {display}")
    if n > 1:
        print(f"   总和：{sum(results)}")


def cmd_coin(args):
    n = int(args[0]) if args else 1
    results = [random.choice(["正面 🪙", "反面 💿"]) for _ in range(n)]
    for i, r in enumerate(results, 1):
        if n > 1:
            print(f"   第{i}次：{r}")
        else:
            print(f"🪙 {r}")
    if n > 1:
        heads = sum(1 for r in results if "正面" in r)
        print(f"   统计：正面 {heads} 次，反面 {n - heads} 次")


def cmd_shuffle(args):
    if not args:
        print("❌ 请提供要排序的选项")
        sys.exit(1)
    items = list(args)
    random.shuffle(items)
    print("🔀 随机顺序：")
    for i, item in enumerate(items, 1):
        print(f"   {i}. {item}")


def cmd_group(args):
    if len(args) < 2:
        print("❌ 用法：group <组数> <成员1> <成员2> ...")
        sys.exit(1)
    try:
        n_groups = int(args[0])
    except ValueError:
        print(f"❌ '{args[0]}' 不是有效数字")
        sys.exit(1)
    members = list(args[1:])
    if n_groups > len(members):
        print(f"❌ 要分 {n_groups} 组，但只有 {len(members)} 个成员")
        sys.exit(1)
    random.shuffle(members)
    groups = [[] for _ in range(n_groups)]
    for i, m in enumerate(members):
        groups[i % n_groups].append(m)
    print(f"👥 随机分为 {n_groups} 组：")
    for i, g in enumerate(groups, 1):
        print(f"   第{i}组：{', '.join(g)}")


def cmd_password(args):
    length = int(args[0]) if args else 16
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    # 确保至少包含各类字符
    pw = [
        random.choice(string.ascii_uppercase),
        random.choice(string.ascii_lowercase),
        random.choice(string.digits),
        random.choice("!@#$%^&*"),
    ]
    pw += [random.choice(chars) for _ in range(length - 4)]
    random.shuffle(pw)
    password = "".join(pw)
    print(f"🔐 随机密码（{length}位）：{password}")
    bits = math.log2(len(chars)) * length
    print(f"   强度：~{bits:.0f} bits")


def cmd_uuid(args):
    print(f"🆔 {uuid_mod.uuid4()}")


COMMANDS = {
    "pick": cmd_pick,
    "pick-n": cmd_pick_n,
    "number": cmd_number,
    "dice": cmd_dice,
    "coin": cmd_coin,
    "shuffle": cmd_shuffle,
    "group": cmd_group,
    "password": cmd_password,
    "uuid": cmd_uuid,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print("随机决策器 🎲")
        print()
        print("命令：")
        print("  pick <选项...>          随机选一个")
        print("  pick-n <N> <选项...>    随机选N个")
        print("  number [min] [max]      随机数（默认1-100）")
        print("  dice [n]                摇骰子（默认1个）")
        print("  coin [n]                掷硬币（默认1次）")
        print("  shuffle <选项...>       随机排序")
        print("  group <组数> <成员...>  随机分组")
        print("  password [长度]         随机密码（默认16位）")
        print("  uuid                    生成UUID")
        sys.exit(0)

    cmd = sys.argv[1]
    if cmd not in COMMANDS:
        print(f"❌ 未知命令：{cmd}")
        print(f"可用命令：{', '.join(COMMANDS.keys())}")
        sys.exit(1)

    COMMANDS[cmd](sys.argv[2:])


if __name__ == "__main__":
    main()
