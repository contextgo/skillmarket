# 随机决策器 🎲

一个简单实用的随机决策 Skill，帮用户解决选择困难症。

## 功能清单

- **pick** — 从多个选项中随机选一个
- **pick-n** — 随机选 N 个
- **number** — 生成指定范围随机数
- **dice** — 摇骰子（支持多骰）
- **coin** — 掷硬币（支持多掷）
- **shuffle** — 随机排序
- **group** — 随机分组
- **password** — 生成强随机密码
- **uuid** — 生成 UUID

## 使用示例

```bash
# 中午吃什么
python3 scripts/picker.py pick "火锅" "烧烤" "日料" "麻辣烫"

# 从10人中随机抽3人
python3 scripts/picker.py pick-n 3 "张三" "李四" "王五" "赵六" "孙七" "周八" "吴九" "郑十" "钱一" "冯二"

# 生成1-100随机数
python3 scripts/picker.py number 1 100

# 摇两个骰子
python3 scripts/picker.py dice 2

# 掷硬币5次
python3 scripts/picker.py coin 5

# 随机分组（6人分2组）
python3 scripts/picker.py group 2 "甲" "乙" "丙" "丁" "戊" "己"

# 生成16位强密码
python3 scripts/picker.py password 16
```

## 特点

- **零依赖**：纯 Python 标准库实现，开箱即用
- **覆盖广**：覆盖常见随机场景（选择、抽签、分组、密码等）
- **交互友好**：每个命令都有清晰的输出说明
