# Code Reviewer - 智能代码审查助手

> 四层智能代码审查：静态分析 + 安全扫描 + 质量评估 + AI审查

## ✨ Features

- 🔍 **Four-Layer Pipeline**: Static Analysis + Security Scan + Quality Assessment + AI Review
- 🛡️ **Security First**: Auto-detect secrets, vulnerabilities, OWASP risks
- 📊 **Quality Metrics**: Cyclomatic complexity, duplication, coverage
- 🤖 **AI Powered**: GPT-4/Claude integration for deep code analysis
- 🔧 **Multi-Language**: JavaScript, Python, Go, Java, Rust...
- 🚀 **CI/CD Ready**: GitHub Action & GitLab CI integration

## 🚀 Quick Start

```bash
# Install
npm install -g code-reviewer

# Initialize
code-reviewer init

# Scan your code
code-reviewer scan .

# Generate report
code-reviewer scan . --format markdown --output report.md
```

## 📊 Four Layers

### Layer 1: Static Analysis
- Syntax checking
- Code style (ESLint, Pylint, go vet)
- Best practices

### Layer 2: Security Scan
- Secret detection (API keys, tokens)
- Vulnerability patterns (SQL injection, XSS)
- Dependency audit

### Layer 3: Quality Assessment
- Cyclomatic complexity
- Code duplication
- Test coverage

### Layer 4: AI Review
- Logic analysis
- Architecture suggestions
- Performance optimization

## 📖 Documentation

- [Installation Guide](docs/installation.md)
- [Configuration](docs/configuration.md)
- [CI/CD Integration](docs/ci-cd.md)

## 📝 License

MIT
