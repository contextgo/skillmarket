---
name: code-reviewer
description: 四层智能代码审查助手，提供静态分析、安全扫描、质量评估和AI智能审查功能
version: 1.0.0
tags: ["code-review", "static-analysis", "security", "quality", "automation"]
author: HunterJW-Agent
---

# Code Reviewer - 智能代码审查助手

## 适用场景

- 代码提交前的自动审查
- 项目质量监控
- 安全漏洞检测
- 团队协作规范检查

## 核心功能

### 四层审查管道

1. **静态分析层**
   - JavaScript/TypeScript (ESLint)
   - Python (Pylint)
   - Go (go vet)

2. **安全扫描层**
   - API密钥泄露检测
   - 常见漏洞模式识别
   - 依赖安全检查

3. **质量评估层**
   - 圈复杂度分析
   - 重复代码检测
   - 代码统计

4. **AI审查层** (Phase 2)
   - GPT-4逻辑分析
   - 架构建议
   - 最佳实践推荐

## 使用方法

```bash
# 安装
npm install -g code-reviewer

# 初始化配置
code-reviewer init

# 扫描代码
code-reviewer scan .

# 生成报告
code-reviewer scan . --format markdown --output report.md
```

## 配置说明

编辑 `~/.code-reviewer/config.json`:

```json
{
  "languages": ["javascript", "python", "go"],
  "severity": {
    "critical": true,
    "high": true,
    "medium": true,
    "low": false
  }
}
```

## 输出示例

控制台输出：
```
🔍 扫描完成
📁 文件数: 25
📝 问题总数: 12
   🔴 Critical: 2
   🟠 High: 5
   🟡 Medium: 5
```

Markdown报告包含详细的问题描述和修复建议。

## 集成CI/CD

### GitHub Action

```yaml
name: Code Review
on: [pull_request]
jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run Code Review
        run: npx code-reviewer scan . --format markdown
```

## 注意事项

- 首次运行需要初始化配置
- 大型项目扫描可能需要较长时间
- 建议定期更新以获取最新规则

## 相关链接

- GitHub: https://github.com/zhangjingwen2008/code-reviewer
- 文档: 见README.md
