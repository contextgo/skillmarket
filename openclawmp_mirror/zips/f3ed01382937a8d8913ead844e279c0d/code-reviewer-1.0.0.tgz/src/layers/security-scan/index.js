const fs = require('fs');

class SecurityScanLayer {
  constructor() {
    this.secretPatterns = [
      { name: 'AWS Access Key', pattern: /AKIA[0-9A-Z]{16}/, severity: 'critical' },
      { name: 'AWS Secret Key', pattern: /['"`][0-9a-zA-Z/+]{40}['"`]/, severity: 'critical' },
      { name: 'GitHub Token', pattern: /ghp_[a-zA-Z0-9]{36}/, severity: 'critical' },
      { name: 'OpenAI API Key', pattern: /sk-[a-zA-Z0-9]{48}/, severity: 'critical' },
      { name: 'Private Key', pattern: /-----BEGIN.*PRIVATE KEY-----/, severity: 'critical' },
      { name: 'Password in Code', pattern: /password\s*[:=]\s*['"`][^'"`]+['"`]/i, severity: 'high' },
      { name: 'API Key', pattern: /api[_-]?key\s*[:=]\s*['"`][^'"`]+['"`]/i, severity: 'high' },
      { name: 'Secret', pattern: /secret\s*[:=]\s*['"`][^'"`]+['"`]/i, severity: 'high' },
      { name: 'Token', pattern: /token\s*[:=]\s*['"`][^'"`]+['"`]/i, severity: 'medium' },
    ];

    this.vulnerabilityPatterns = [
      { 
        name: 'SQL Injection Risk', 
        pattern: /(query|execute)\s*\(\s*["'`].*\$\{.*\}/,
        severity: 'critical',
        description: '可能存在SQL注入风险，使用参数化查询'
      },
      { 
        name: 'Eval Usage', 
        pattern: /eval\s*\(/,
        severity: 'high',
        description: '使用eval()存在代码注入风险'
      },
      { 
        name: 'InnerHTML XSS Risk', 
        pattern: /innerHTML\s*=/,
        severity: 'high',
        description: 'innerHTML可能导致XSS攻击，使用textContent或DOMPurify'
      },
      { 
        name: 'Insecure HTTP', 
        pattern: /http:\/\/[^\/\s'"`]+/,
        severity: 'medium',
        description: '使用不安全的HTTP协议，建议改为HTTPS'
      },
    ];
  }

  async scan(files) {
    const results = [];
    
    for (const file of files) {
      try {
        const content = fs.readFileSync(file, 'utf8');
        const lines = content.split('\n');
        
        // 密钥泄露检测
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          
          for (const secret of this.secretPatterns) {
            if (secret.pattern.test(line)) {
              results.push({
                file,
                line: i + 1,
                ruleId: `secret-${secret.name.toLowerCase().replace(/\s+/g, '-')}`,
                message: `发现可能的 ${secret.name} 泄露`,
                severity: secret.severity,
                category: 'security',
                type: 'secret-leak',
                recommendation: '将敏感信息移至环境变量或配置文件，并加入.gitignore'
              });
            }
          }
          
          // 漏洞模式检测
          for (const vuln of this.vulnerabilityPatterns) {
            if (vuln.pattern.test(line)) {
              results.push({
                file,
                line: i + 1,
                ruleId: `vuln-${vuln.name.toLowerCase().replace(/\s+/g, '-')}`,
                message: vuln.description,
                severity: vuln.severity,
                category: 'security',
                type: 'vulnerability',
                recommendation: '参考OWASP最佳实践修复'
              });
            }
          }
        }
        
        // 检查依赖文件
        if (file.endsWith('package.json')) {
          results.push(...await this.checkNpmVulnerabilities(file));
        }
        
      } catch (error) {
        results.push({
          file,
          ruleId: 'security-scan-error',
          message: `安全扫描出错: ${error.message}`,
          severity: 'warning',
          category: 'security'
        });
      }
    }
    
    return results;
  }

  async checkNpmVulnerabilities(packageJsonPath) {
    const results = [];
    
    try {
      const content = fs.readFileSync(packageJsonPath, 'utf8');
      const pkg = JSON.parse(content);
      
      // 检查已知有漏洞的依赖版本（简化版）
      const vulnerablePackages = {
        'lodash': '<4.17.21',
        'axios': '<0.21.1',
        'express': '<4.17.3',
        'minimist': '<1.2.6'
      };
      
      const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
      
      for (const [name, version] of Object.entries(allDeps)) {
        if (vulnerablePackages[name]) {
          results.push({
            file: packageJsonPath,
            line: 0,
            ruleId: 'vulnerable-dependency',
            message: `${name}@${version} 可能存在已知漏洞，建议升级到 ${vulnerablePackages[name]}`,
            severity: 'high',
            category: 'security',
            type: 'dependency-vuln',
            recommendation: `运行 npm audit 查看详情并升级: npm update ${name}`
          });
        }
      }
    } catch (error) {
      // 忽略解析错误
    }
    
    return results;
  }
}

module.exports = SecurityScanLayer;
