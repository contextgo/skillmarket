const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class StaticAnalysisLayer {
  constructor() {
    this.supportedLanguages = {
      javascript: ['.js', '.jsx', '.mjs'],
      typescript: ['.ts', '.tsx'],
      python: ['.py'],
      go: ['.go'],
      java: ['.java'],
      rust: ['.rs']
    };
  }

  async analyze(files, language) {
    const results = [];
    
    try {
      switch(language) {
        case 'javascript':
        case 'typescript':
          results.push(...await this.runESLint(files));
          break;
        case 'python':
          results.push(...await this.runPylint(files));
          break;
        case 'go':
          results.push(...await this.runGoVet(files));
          break;
        default:
          results.push({
            ruleId: 'unsupported-language',
            message: `暂不支持 ${language} 语言的静态分析`,
            severity: 'warning'
          });
      }
    } catch (error) {
      results.push({
        ruleId: 'analysis-error',
        message: `静态分析出错: ${error.message}`,
        severity: 'error'
      });
    }
    
    return results;
  }

  async runESLint(files) {
    const results = [];
    
    for (const file of files) {
      try {
        // 基础语法检查
        const content = fs.readFileSync(file, 'utf8');
        
        // 检查常见语法问题
        if (content.includes('console.log')) {
          results.push({
            file,
            line: this.findLine(content, 'console.log'),
            ruleId: 'no-console',
            message: '发现 console.log，生产环境建议移除',
            severity: 'warning',
            category: 'best-practices'
          });
        }
        
        if (content.includes('debugger;')) {
          results.push({
            file,
            line: this.findLine(content, 'debugger;'),
            ruleId: 'no-debugger',
            message: '发现 debugger 语句，建议移除',
            severity: 'error',
            category: 'best-practices'
          });
        }
        
        // 检查未定义变量（简化版）
        const undefinedVars = this.detectUndefinedVariables(content);
        undefinedVars.forEach(variable => {
          results.push({
            file,
            line: variable.line,
            ruleId: 'no-undef',
            message: `变量 '${variable.name}' 可能未定义`,
            severity: 'error',
            category: 'variables'
          });
        });
        
      } catch (error) {
        results.push({
          file,
          ruleId: 'file-read-error',
          message: `无法读取文件: ${error.message}`,
          severity: 'error'
        });
      }
    }
    
    return results;
  }

  async runPylint(files) {
    const results = [];
    
    for (const file of files) {
      try {
        const content = fs.readFileSync(file, 'utf8');
        
        // 检查 Python 常见问题
        if (content.includes('print ') && !content.includes('print(')) {
          results.push({
            file,
            line: this.findLine(content, 'print '),
            ruleId: 'python3-print',
            message: 'Python 2 风格的 print 语句，建议使用 print() 函数',
            severity: 'warning',
            category: 'python3-compatibility'
          });
        }
        
        if (content.includes('except:') && !content.includes('except Exception')) {
          results.push({
            file,
            line: this.findLine(content, 'except:'),
            ruleId: 'bare-except',
            message: '裸 except 子句会捕获所有异常包括 KeyboardInterrupt，建议指定异常类型',
            severity: 'warning',
            category: 'error-handling'
          });
        }
        
      } catch (error) {
        results.push({
          file,
          ruleId: 'file-read-error',
          message: `无法读取文件: ${error.message}`,
          severity: 'error'
        });
      }
    }
    
    return results;
  }

  async runGoVet(files) {
    const results = [];
    
    for (const file of files) {
      try {
        // 尝试运行 go vet
        const output = execSync(`go vet ${file}`, { encoding: 'utf8', stdio: 'pipe' });
        
        if (output) {
          const lines = output.split('\n');
          lines.forEach(line => {
            if (line.includes(':')) {
              const [filePath, lineNum, message] = line.split(':');
              results.push({
                file: filePath.trim(),
                line: parseInt(lineNum) || 0,
                ruleId: 'go-vet',
                message: message?.trim() || 'Go vet 发现问题',
                severity: 'warning',
                category: 'go-specific'
              });
            }
          });
        }
      } catch (error) {
        // go vet 返回非零退出码表示发现问题
        if (error.stdout) {
          const lines = error.stdout.toString().split('\n');
          lines.forEach(line => {
            if (line.includes(':')) {
              const parts = line.split(':');
              results.push({
                file: parts[0]?.trim() || file,
                line: parseInt(parts[1]) || 0,
                ruleId: 'go-vet',
                message: parts.slice(2).join(':').trim() || 'Go vet 发现问题',
                severity: 'warning',
                category: 'go-specific'
              });
            }
          });
        }
      }
    }
    
    return results;
  }

  findLine(content, searchStr) {
    const lines = content.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].includes(searchStr)) {
        return i + 1;
      }
    }
    return 0;
  }

  detectUndefinedVariables(content) {
    // 简化的未定义变量检测
    const variables = [];
    const declaredVars = new Set();
    const usedVars = [];
    
    // 提取声明的变量 (const, let, var)
    const declarationRegex = /(?:const|let|var)\s+(\w+)/g;
    let match;
    while ((match = declarationRegex.exec(content)) !== null) {
      declaredVars.add(match[1]);
    }
    
    // 提取函数参数
    const paramRegex = /function\s*\w*\s*\(([^)]*)\)/g;
    while ((match = paramRegex.exec(content)) !== null) {
      const params = match[1].split(',').map(p => p.trim().split('=')[0].trim());
      params.forEach(p => declaredVars.add(p));
    }
    
    // 提取使用的变量
    const usageRegex = /(\w+)(?!\s*[:=])/g;
    const lines = content.split('\n');
    lines.forEach((line, index) => {
      while ((match = usageRegex.exec(line)) !== null) {
        const varName = match[1];
        if (!declaredVars.has(varName) && 
            !['console', 'require', 'module', 'exports', 'process', 'Buffer', 'Array', 'Object', 'String', 'Number', 'Boolean', 'Date', 'Math', 'JSON', 'Promise', 'Set', 'Map'].includes(varName) &&
            !/^[A-Z]/.test(varName)) {
          usedVars.push({ name: varName, line: index + 1 });
        }
      }
    });
    
    return usedVars;
  }

  detectLanguage(file) {
    const ext = path.extname(file).toLowerCase();
    
    for (const [lang, extensions] of Object.entries(this.supportedLanguages)) {
      if (extensions.includes(ext)) {
        return lang;
      }
    }
    
    return 'unknown';
  }
}

module.exports = StaticAnalysisLayer;
