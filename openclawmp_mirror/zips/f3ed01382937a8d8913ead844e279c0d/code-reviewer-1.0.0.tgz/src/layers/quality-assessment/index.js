const fs = require('fs');

class QualityAssessmentLayer {
  async assess(files, language) {
    const results = [];
    let totalLines = 0;
    let totalComplexity = 0;
    let duplicateBlocks = [];
    
    for (const file of files) {
      try {
        const content = fs.readFileSync(file, 'utf8');
        const lines = content.split('\n');
        const lineCount = lines.length;
        totalLines += lineCount;
        
        // 圈复杂度计算（简化版）
        const complexity = this.calculateComplexity(content, language);
        totalComplexity += complexity;
        
        // 检查长函数
        const longFunctions = this.detectLongFunctions(content, language);
        longFunctions.forEach(func => {
          results.push({
            file,
            line: func.line,
            ruleId: 'function-too-long',
            message: `函数 '${func.name}' 过长 (${func.lines} 行)，建议拆分为小函数`,
            severity: func.lines > 100 ? 'error' : 'warning',
            category: 'quality',
            metric: { type: 'function-length', value: func.lines }
          });
        });
        
        // 检查文件长度
        if (lineCount > 500) {
          results.push({
            file,
            line: 1,
            ruleId: 'file-too-long',
            message: `文件过大 (${lineCount} 行)，建议拆分为多个模块`,
            severity: lineCount > 1000 ? 'error' : 'warning',
            category: 'quality',
            metric: { type: 'file-length', value: lineCount }
          });
        }
        
        // 检查注释率
        const commentRatio = this.calculateCommentRatio(content, language);
        if (commentRatio < 0.1 && lineCount > 50) {
          results.push({
            file,
            line: 1,
            ruleId: 'low-comment-ratio',
            message: `注释率较低 (${(commentRatio * 100).toFixed(1)}%)，建议添加更多注释`,
            severity: 'info',
            category: 'quality',
            metric: { type: 'comment-ratio', value: commentRatio }
          });
        }
        
        // 复杂度过高
        if (complexity > 20) {
          results.push({
            file,
            line: 1,
            ruleId: 'high-complexity',
            message: `文件圈复杂度过高 (${complexity})，建议简化逻辑`,
            severity: complexity > 30 ? 'error' : 'warning',
            category: 'quality',
            metric: { type: 'cyclomatic-complexity', value: complexity }
          });
        }
        
      } catch (error) {
        results.push({
          file,
          ruleId: 'quality-assessment-error',
          message: `质量评估出错: ${error.message}`,
          severity: 'warning',
          category: 'quality'
        });
      }
    }
    
    // 重复代码检测（简化版：基于字符串相似度）
    duplicateBlocks = await this.detectDuplicates(files);
    duplicateBlocks.forEach(dup => {
      results.push({
        file: dup.file1,
        line: dup.line1,
        ruleId: 'duplicate-code',
        message: `发现与 ${dup.file2}:${dup.line2} 重复的代码块 (${dup.lines} 行)`,
        severity: 'warning',
        category: 'quality',
        metric: { type: 'duplication', value: dup.similarity }
      });
    });
    
    return {
      issues: results,
      metrics: {
        totalLines,
        averageComplexity: files.length > 0 ? Math.round(totalComplexity / files.length) : 0,
        duplicateBlocks: duplicateBlocks.length
      }
    };
  }

  calculateComplexity(content, language) {
    let complexity = 1; // 基础复杂度
    
    // 统计条件分支
    const branchPatterns = [
      /\bif\s*\(/g,
      /\belse\s+if\s*\(/g,
      /\bswitch\s*\(/g,
      /\bcase\s+/g,
      /\bfor\s*\(/g,
      /\bwhile\s*\(/g,
      /\bcatch\s*\(/g,
      /\?\s*[^:]+\s*:/g, // 三元运算符
      /\|\||&&/g // 逻辑运算符
    ];
    
    branchPatterns.forEach(pattern => {
      const matches = content.match(pattern);
      if (matches) {
        complexity += matches.length;
      }
    });
    
    return complexity;
  }

  detectLongFunctions(content, language) {
    const functions = [];
    const lines = content.split('\n');
    
    // JavaScript/TypeScript 函数检测
    if (language === 'javascript' || language === 'typescript') {
      const functionPattern = /(?:function\s+(\w+)|(\w+)\s*[:=]\s*(?:async\s+)?function|(\w+)\s*[:=]\s*\(.*\)\s*=>)/g;
      let match;
      
      while ((match = functionPattern.exec(content)) !== null) {
        const funcName = match[1] || match[2] || match[3] || 'anonymous';
        const startPos = match.index;
        const startLine = content.substring(0, startPos).split('\n').length;
        
        // 简单估算函数结束位置（找匹配的括号）
        let braceCount = 0;
        let endLine = startLine;
        let foundFirstBrace = false;
        
        for (let i = startLine - 1; i < lines.length; i++) {
          const line = lines[i];
          for (const char of line) {
            if (char === '{') {
              braceCount++;
              foundFirstBrace = true;
            } else if (char === '}') {
              braceCount--;
            }
          }
          
          if (foundFirstBrace && braceCount === 0) {
            endLine = i + 1;
            break;
          }
        }
        
        const funcLength = endLine - startLine + 1;
        if (funcLength > 50) {
          functions.push({
            name: funcName,
            line: startLine,
            lines: funcLength
          });
        }
      }
    }
    
    return functions;
  }

  calculateCommentRatio(content, language) {
    const lines = content.split('\n');
    let codeLines = 0;
    let commentLines = 0;
    let inBlockComment = false;
    
    for (const line of lines) {
      const trimmed = line.trim();
      
      if (trimmed === '') continue;
      
      if (language === 'javascript' || language === 'typescript' || language === 'java' || language === 'go') {
        if (inBlockComment) {
          commentLines++;
          if (trimmed.includes('*/')) {
            inBlockComment = false;
          }
        } else if (trimmed.startsWith('//')) {
          commentLines++;
        } else if (trimmed.startsWith('/*')) {
          commentLines++;
          if (!trimmed.includes('*/')) {
            inBlockComment = true;
          }
        } else {
          codeLines++;
        }
      } else if (language === 'python') {
        if (trimmed.startsWith('#')) {
          commentLines++;
        } else if (trimmed.startsWith('"""') || trimmed.startsWith("'''")) {
          commentLines++;
        } else {
          codeLines++;
        }
      } else {
        codeLines++;
      }
    }
    
    const total = codeLines + commentLines;
    return total > 0 ? commentLines / total : 0;
  }

  async detectDuplicates(files) {
    const duplicates = [];
    const blocks = [];
    
    // 提取所有文件的代码块（简化版：每10行为一个块）
    for (const file of files) {
      try {
        const content = fs.readFileSync(file, 'utf8');
        const lines = content.split('\n');
        
        for (let i = 0; i < lines.length - 5; i++) {
          const block = lines.slice(i, i + 5).join('\n').replace(/\s+/g, ' ').trim();
          if (block.length > 50) {
            blocks.push({ file, line: i + 1, content: block });
          }
        }
      } catch (error) {
        // 忽略读取错误
      }
    }
    
    // 检测相似块（简化版）
    for (let i = 0; i < blocks.length; i++) {
      for (let j = i + 1; j < blocks.length; j++) {
        const block1 = blocks[i];
        const block2 = blocks[j];
        
        // 不同文件之间的重复
        if (block1.file !== block2.file) {
          const similarity = this.calculateSimilarity(block1.content, block2.content);
          if (similarity > 0.8) {
            duplicates.push({
              file1: block1.file,
              line1: block1.line,
              file2: block2.file,
              line2: block2.line,
              lines: 5,
              similarity
            });
          }
        }
      }
    }
    
    return duplicates.slice(0, 10); // 限制返回数量
  }

  calculateSimilarity(str1, str2) {
    // 简化的相似度计算
    const len1 = str1.length;
    const len2 = str2.length;
    const maxLen = Math.max(len1, len2);
    
    if (maxLen === 0) return 1;
    
    // 计算编辑距离（简化版）
    let common = 0;
    const minLen = Math.min(len1, len2);
    for (let i = 0; i < minLen; i++) {
      if (str1[i] === str2[i]) common++;
    }
    
    return common / maxLen;
  }
}

module.exports = QualityAssessmentLayer;
