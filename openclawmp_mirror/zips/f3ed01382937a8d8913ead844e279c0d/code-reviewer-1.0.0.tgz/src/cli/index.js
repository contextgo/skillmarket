#!/usr/bin/env node

const { Command } = require('commander');
const chalk = require('chalk');
const CodeReviewer = require('../core/reviewer');

const program = new Command();

program
  .name('code-reviewer')
  .description('四层智能代码审查助手')
  .version('1.0.0');

program
  .command('init')
  .description('初始化配置文件')
  .action(async () => {
    console.log(chalk.blue('🚀 初始化 code-reviewer...'));
    const reviewer = new CodeReviewer();
    await reviewer.init();
    console.log(chalk.green('✅ 初始化完成！'));
  });

program
  .command('scan <path>')
  .description('扫描代码并生成审查报告')
  .option('-f, --format <type>', '输出格式 (json|markdown|html)', 'markdown')
  .option('-o, --output <file>', '输出文件路径')
  .option('--language <lang>', '指定语言 (javascript|python|go)')
  .action(async (targetPath, options) => {
    console.log(chalk.blue(`🔍 开始扫描: ${targetPath}`));
    
    const reviewer = new CodeReviewer();
    const results = await reviewer.scan(targetPath, options);
    
    if (options.output) {
      await reviewer.saveReport(results, options.output, options.format);
      console.log(chalk.green(`✅ 报告已保存: ${options.output}`));
    } else {
      console.log(reviewer.formatConsoleOutput(results));
    }
  });

program
  .command('config')
  .description('查看或修改配置')
  .action(() => {
    console.log(chalk.blue('⚙️  配置管理'));
    console.log('编辑 ~/.code-reviewer/config.json 修改配置');
  });

program.parse();
