const fs = require('fs').promises;
const path = require('path');
const glob = require('glob');
const chalk = require('chalk');

const StaticAnalysisLayer = require('../layers/static-analysis');
const SecurityScanLayer = require('../layers/security-scan');
const QualityAssessmentLayer = require('../layers/quality-assessment');
const AIReviewLayer = require('../layers/ai-review');

class CodeReviewer {
  constructor() {
    this.config = null;
    this.layers = [
      new StaticAnalysisLayer(),
      new SecurityScanLayer(),
      new QualityAssessmentLayer(),
      new AIReviewLayer()
    ];
  }

  async init() {
    const configDir = path.join(process.env.HOME, '.code-reviewer');
    await fs.mkdir(configDir, { recursive: true });
    
    const defaultConfig = {
      version: '1.0.0',
      languages: ['javascript', 'typescript', 'python'],
      rules: {
        maxComplexity: 10,
        maxFunctionLength: 50,
        minTestCoverage: 80
      },
      security: {
        checkSecrets: true,
        checkVulnerabilities: true
      },
      ai: {
        enabled: true,
        provider: 'openai',
        model: 'gpt-4'
      }
    };
    
    await fs.writeFile(
      path.join(configDir, 'config.json'),
      JSON.stringify(defaultConfig, null, 2)
    );
  }

  async scan(targetPath, options = {}) {
    const files = await this.getTargetFiles(targetPath, options.language);
    const results = {
      summary: {
        totalFiles: files.length,
        totalIssues: 0,
        errors: 0,
        warnings: 0,
        info: 0
      },
      layers: {}
    };

    console.log(chalk.blue(`📁 找到 ${files.length} 个文件`));

    // 执行四层审查
    for (const layer of this.layers) {
      console.log(chalk.blue(`🔍 正在执行: ${layer.name}...`));
      const layerResults = await layer.analyze(files);
      results.layers[layer.id] = layerResults;
      
      // 统计问题
      if (layerResults.issues) {
        results.summary.totalIssues += layerResults.issues.length;
        layerResults.issues.forEach(issue => {
          if (issue.severity === 'error') results.summary.errors++;
          else if (issue.severity === 'warning') results.summary.warnings++;
          else results.summary.info++;
        });
      }
    }

    return results;
  }

  async getTargetFiles(targetPath, language) {
    const stats = await fs.stat(targetPath);
    
    if (stats.isFile()) {
      return [targetPath];
    }

    // 根据语言确定文件模式
    const patterns = {
      javascript: '**/*.{js,jsx,ts,tsx}',
      python: '**/*.py',
      go: '**/*.go',
      java: '**/*.java'
    };

    const pattern = language ? patterns[language] : '**/*.{js,jsx,ts,tsx,py,go,java}';
    
    return new Promise((resolve, reject) => {
      glob(pattern, {
        cwd: targetPath,
        absolute: true,
        ignore: ['**/node_modules/**', '**/.git/**', '**/dist/**']
      }, (err, files) => {
        if (err) reject(err);
        else resolve(files);
      });
    });
  }

  formatConsoleOutput(results) {
    let output = '\n' + chalk.bold('📊 代码审查报告\n');
    output += '═'.repeat(50) + '\n\n';
    
    // 概览
    output += chalk.bold('📈 概览\n');
    output += `  总文件数: ${results.summary.totalFiles}\n`;
    output += `  问题总数: ${results.summary.totalIssues}\n`;
    output += chalk.red(`  ❌ Errors: ${results.summary.errors}\n`);
    output += chalk.yellow(`  ⚠️  Warnings: ${results.summary.warnings}\n`);
    output += chalk.blue(`  ℹ️  Info: ${results.summary.info}\n`);
    output += '\n';

    // 各层结果
    for (const [layerId, layerResults] of Object.entries(results.layers)) {
      if (layerResults.issues && layerResults.issues.length > 0) {
        output += chalk.bold(`🔍 ${layerResults.name}\n`);
        layerResults.issues.slice(0, 5).forEach(issue => {
          const color = issue.severity === 'error' ? 'red' : 
                       issue.severity === 'warning' ? 'yellow' : 'blue';
          output += chalk[color](`  ${issue.file}:${issue.line} - ${issue.message}\n`);
        });
        if (layerResults.issues.length > 5) {
          output += chalk.gray(`  ... 还有 ${layerResults.issues.length - 5} 个问题\n`);
        }
        output += '\n';
      }
    }

    return output;
  }

  async saveReport(results, outputPath, format) {
    let content;
    
    switch (format) {
      case 'json':
        content = JSON.stringify(results, null, 2);
        break;
      case 'markdown':
        content = this.generateMarkdownReport(results);
        break;
      default:
        content = this.formatConsoleOutput(results);
    }
    
    await fs.writeFile(outputPath, content);
  }

  generateMarkdownReport(results) {
    let md = '# 代码审查报告\n\n';
    md += `生成时间: ${new Date().toLocaleString()}\n\n`;
    
    md += '## 📈 概览\n\n';
    md += `- 总文件数: ${results.summary.totalFiles}\n`;
    md += `- 问题总数: ${results.summary.totalIssues}\n`;
    md += `- ❌ Errors: ${results.summary.errors}\n`;
    md += `- ⚠️ Warnings: ${results.summary.warnings}\n`;
    md += `- ℹ️ Info: ${results.summary.info}\n\n`;

    for (const [layerId, layerResults] of Object.entries(results.layers)) {
      if (layerResults.issues && layerResults.issues.length > 0) {
        md += `## 🔍 ${layerResults.name}\n\n`;
        layerResults.issues.forEach(issue => {
          md += `### ${issue.file}:${issue.line}\n`;
          md += `- **级别**: ${issue.severity}\n`;
          md += `- **问题**: ${issue.message}\n`;
          if (issue.suggestion) {
            md += `- **建议**: ${issue.suggestion}\n`;
          }
          md += '\n';
        });
      }
    }

    return md;
  }
}

module.exports = CodeReviewer;
