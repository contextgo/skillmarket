const fs = require('fs').promises;

class ReportGenerator {
  generateMarkdown(results, options = {}) {
    const { targetPath = '.', scanTime = new Date() } = options;
    
    const stats = this.calculateStats(results);
    
    let report = `# 代码审查报告\n\n`;
    report += `**扫描目标**: ${targetPath}  \n`;
    report += `**扫描时间**: ${scanTime.toLocaleString()}  \n`;
    report += `**文件数**: ${stats.fileCount}  \n`;
    report += `**问题总数**: ${stats.totalIssues} (严重: ${stats.critical}, 高: ${stats.high}, 中: ${stats.medium}, 低: ${stats.low})  \n\n`;
    
    // 概览图表
    report += `## 📊 问题分布\n\n`;
    report += '| 级别 | 数量 | 占比 |\n';
    report += '|------|------|------|\n';
    report += `| 🔴 Critical | ${stats.critical} | ${((stats.critical/stats.totalIssues)*100).toFixed(1)}% |\n`;
    report += `| 🟠 High | ${stats.high} | ${((stats.high/stats.totalIssues)*100).toFixed(1)}% |\n`;
    report += `| 🟡 Medium | ${stats.medium} | ${((stats.medium/stats.totalIssues)*100).toFixed(1)}% |\n`;
    report += `| 🔵 Low | ${stats.low} | ${((stats.low/stats.totalIssues)*100).toFixed(1)}% |\n\n`;
    
    // 按类别分组
    const byCategory = this.groupByCategory(results);
    
    report += `## 📋 详细问题\n\n`;
    
    // Critical issues first
    if (stats.critical > 0) {
      report += `### 🔴 Critical Issues (${stats.critical})\n\n`;
      const critical = results.filter(r => r.severity === 'critical');
      critical.forEach(issue => {
        report += this.formatIssue(issue);
      });
      report += '\n';
    }
    
    // High severity
    if (stats.high > 0) {
      report += `### 🟠 High Severity Issues (${stats.high})\n\n`;
      const high = results.filter(r => r.severity === 'high');
      high.forEach(issue => {
        report += this.formatIssue(issue);
      });
      report += '\n';
    }
    
    // Other issues
    if (stats.medium + stats.low > 0) {
      report += `### 🟡 Other Issues (${stats.medium + stats.low})\n\n`;
      const others = results.filter(r => r.severity === 'medium' || r.severity === 'low');
      others.forEach(issue => {
        report += this.formatIssue(issue);
      });
    }
    
    // Summary
    report += `\n## ✅ 建议行动\n\n`;
    if (stats.critical > 0) {
      report += `1. **立即修复** ${stats.critical} 个严重问题（安全漏洞、密钥泄露）\n`;
    }
    if (stats.high > 0) {
      report += `2. **优先处理** ${stats.high} 个高风险问题\n`;
    }
    report += `3. **持续改进** 代码质量和测试覆盖率\n`;
    
    return report;
  }

  formatConsoleOutput(results) {
    const stats = this.calculateStats(results);
    let output = '';
    
    output += '\n╔════════════════════════════════════════════════════════╗\n';
    output += '║           代码审查报告                                  ║\n';
    output += '╚════════════════════════════════════════════════════════╝\n\n';
    
    output += `📁 文件数: ${stats.fileCount}\n`;
    output += `📝 问题总数: ${stats.totalIssues}\n`;
    output += `   🔴 Critical: ${stats.critical}\n`;
    output += `   🟠 High: ${stats.high}\n`;
    output += `   🟡 Medium: ${stats.medium}\n`;
    output += `   🔵 Low: ${stats.low}\n\n`;
    
    // Group by file
    const byFile = {};
    results.forEach(r => {
      if (!byFile[r.file]) byFile[r.file] = [];
      byFile[r.file].push(r);
    });
    
    for (const [file, issues] of Object.entries(byFile)) {
      output += `\n📄 ${file}\n`;
      output += '─'.repeat(50) + '\n';
      
      issues.forEach(issue => {
        const icon = issue.severity === 'critical' ? '🔴' :
                     issue.severity === 'high' ? '🟠' :
                     issue.severity === 'medium' ? '🟡' : '🔵';
        
        output += `  ${icon} Line ${issue.line}: ${issue.message}\n`;
        if (issue.recommendation) {
          output += `     💡 ${issue.recommendation}\n`;
        }
      });
    }
    
    output += '\n' + '═'.repeat(56) + '\n';
    
    return output;
  }

  formatIssue(issue) {
    let text = `- **${issue.ruleId}** (${issue.severity})\n`;
    text += `  - 文件: \`${issue.file}:${issue.line}\`\n`;
    text += `  - 问题: ${issue.message}\n`;
    if (issue.recommendation) {
      text += `  - 建议: ${issue.recommendation}\n`;
    }
    text += '\n';
    return text;
  }

  calculateStats(results) {
    const stats = {
      totalIssues: results.length,
      critical: results.filter(r => r.severity === 'critical').length,
      high: results.filter(r => r.severity === 'high').length,
      medium: results.filter(r => r.severity === 'medium').length,
      low: results.filter(r => r.severity === 'low').length,
      fileCount: new Set(results.map(r => r.file)).size
    };
    return stats;
  }

  groupByCategory(results) {
    const groups = {};
    results.forEach(r => {
      const cat = r.category || 'other';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(r);
    });
    return groups;
  }

  async saveReport(results, outputPath, format = 'markdown') {
    let content;
    
    switch(format) {
      case 'markdown':
        content = this.generateMarkdown(results);
        break;
      case 'json':
        content = JSON.stringify(results, null, 2);
        break;
      default:
        throw new Error(`不支持的格式: ${format}`);
    }
    
    await fs.writeFile(outputPath, content, 'utf8');
  }
}

module.exports = ReportGenerator;
