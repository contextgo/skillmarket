#!/usr/bin/env python3
"""
增强版浏览器自动化引擎
==========================

在 OpenClaw browser 工具基础上，提供更智能、更高效的浏览器自动化能力。

Usage:
    python browser_auto.py workflow <config>        # 执行复杂工作流
    python browser_auto.py batch <urls>             # 批量处理多个URL
    python browser_auto.py extract <url> <pattern>  # 结构化数据提取
    python browser_auto.py monitor <url> <interval> # 持续监控页面变化
    python browser_auto.py auto-login <url> <config> # 自动登录工作流
"""

import argparse
import json
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse

# ─── 配置 ───────────────────────────────────────────────────────────────

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", Path.home() / ".openclaw" / "workspace"))
BROWSER_CONFIG_FILE = WORKSPACE / "browser_auto_config.json"

# ─── 核心工作流 ─────────────────────────────────────────────────────────

class BrowserAutoEngine:
    """增强版浏览器自动化引擎"""

    def __init__(self):
        self.config = self._load_config()
        self.session_data = {}

    def _load_config(self) -> Dict:
        """加载浏览器配置"""
        if BROWSER_CONFIG_FILE.exists():
            return json.loads(BROWSER_CONFIG_FILE.read_text())
        return {
            "default_profile": "openclaw",
            "headless": True,
            "timeout": 30,
            "retry_count": 3,
            "retry_delay": 2,
            "auto_screenshot": True,
            "auto_wait": 2,
            "login_credentials": {}
        }

    def _save_config(self, config: Dict):
        BROWSER_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        BROWSER_CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2))

    def execute_workflow(self, workflow_config: Dict) -> Dict:
        """执行复杂浏览器工作流"""
        print(f"🌐 执行工作流: {workflow_config.get('name', '未命名')}")
        
        results = {"start_time": datetime.now().isoformat(), "steps": [], "overall_status": "success"}
        
        for i, step in enumerate(workflow_config.get("steps", []), 1):
            print(f"\n📍 步骤 {i}/{len(workflow_config['steps'])}: {step.get('name', step['action'])}")
            
            try:
                step_result = self._execute_step(step, workflow_config)
                results["steps"].append({
                    "step": i,
                    "action": step["action"],
                    "status": "success",
                    "result": step_result,
                    "timestamp": datetime.now().isoformat()
                })
                print(f"   ✅ {step.get('name', step['action'])}")
            except Exception as e:
                results["steps"].append({
                    "step": i,
                    "action": step["action"],
                    "status": "error",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                })
                print(f"   ❌ {step.get('name', step['action'])}: {e}")
                
                if workflow_config.get("stop_on_error", True):
                    results["overall_status"] = "error"
                    break

        results["end_time"] = datetime.now().isoformat()
        results["duration_seconds"] = self._calculate_duration(results["start_time"], results["end_time"])
        
        return results

    def _execute_step(self, step: Dict, workflow_config: Dict) -> Any:
        """执行单个工作流步骤"""
        action = step["action"]
        
        if action == "open":
            return self._open_page(step["url"], step.get("profile", self.config["default_profile"]))
        
        elif action == "snapshot":
            return self._take_snapshot(step.get("full_page", False))
        
        elif action == "click":
            return self._click_element(step["ref"])
        
        elif action == "type":
            return self._type_text(step["ref"], step["text"], step.get("submit", False))
        
        elif action == "extract":
            return self._extract_data(step.get("pattern"), step.get("selector"))
        
        elif action == "wait":
            return self._wait_for_element(step.get("selector"), step.get("timeout", self.config["timeout"]))
        
        elif action == "screenshot":
            return self._take_screenshot(step.get("full_page", False))
        
        else:
            raise ValueError(f"未知操作: {action}")

    def _open_page(self, url: str, profile: str = None) -> Dict:
        """打开页面"""
        print(f"   📂 打开: {url}")
        
        # 使用 OpenClaw browser 工具
        import subprocess
        import json
        
        cmd = ["openclaw", "browser", "navigate", url]
        # Note: profile handling - the browser tool uses different mechanisms
        # For now, let's try without profile for basic functionality
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            return {"status": "success", "url": url, "profile": profile}
        else:
            raise Exception(f"打开页面失败: {result.stderr}")

    def _take_snapshot(self, full_page: bool = False) -> Dict:
        """获取页面快照"""
        print("   📸 获取页面快照")
        
        import subprocess
        import json
        
        cmd = ["openclaw", "browser", "snapshot"]
        if full_page:
            cmd.append("--full-page")
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                return {"status": "success", "raw_output": result.stdout[:200]}
        else:
            raise Exception(f"快照失败: {result.stderr}")

    def _click_element(self, ref: str) -> Dict:
        """点击元素"""
        print(f"   🖱️  点击: {ref}")
        
        import subprocess
        
        cmd = ["openclaw", "browser", "click", ref]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            return {"status": "success", "ref": ref, "action": "click"}
        else:
            raise Exception(f"点击失败: {result.stderr}")

    def _type_text(self, ref: str, text: str, submit: bool = False) -> Dict:
        """输入文字"""
        print(f"   📝 输入: {text[:30]}{'...' if len(text) > 30 else ''}")
        
        import subprocess
        import json
        
        request = {"kind": "type", "ref": ref, "text": text}
        if submit:
            request["submit"] = True
        
        cmd = ["openclaw", "browser", "act", "--request", json.dumps(request)]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            return {"status": "success", "ref": ref, "text": text, "submit": submit}
        else:
            raise Exception(f"输入失败: {result.stderr}")

    def _extract_data(self, pattern: Optional[str] = None, selector: Optional[str] = None) -> Dict:
        """提取结构化数据"""
        print("   🔍 提取数据")
        
        snapshot = self._take_snapshot()
        
        data = {
            "title": "",
            "links": [],
            "forms": [],
            "text_content": ""
        }
        
        # 从 snapshot 提取基本信息
        if isinstance(snapshot, dict) and "accessibilityTree" in snapshot:
            tree = snapshot["accessibilityTree"]
            
            # 提取标题
            for item in tree:
                if item.get("role") == "heading" and item.get("level") == 1:
                    data["title"] = item.get("name", "")
                    break
            
            # 提取链接
            for item in tree:
                if item.get("role") == "link" and item.get("name"):
                    data["links"].append({
                        "text": item["name"],
                        "url": item.get("href", ""),
                        "ref": item.get("ref", "")
                    })
            
            # 提取表单
            for item in tree:
                if item.get("role") == "textbox":
                    data["forms"].append({
                        "label": item.get("name", ""),
                        "ref": item.get("ref", ""),
                        "type": "text"
                    })
            
            # 提取主要文本内容
            text_items = [item.get("name", "") for item in tree 
                         if item.get("name") and len(item.get("name", "")) > 10]
            data["text_content"] = " ".join(text_items[:10])
        
        # 如果指定了 pattern，尝试匹配
        if pattern:
            import re
            matches = re.findall(pattern, data["text_content"], re.IGNORECASE)
            data["pattern_matches"] = matches
        
        return data

    def _wait_for_element(self, selector: str, timeout: int = 30) -> Dict:
        """等待元素出现"""
        print(f"   ⏳ 等待元素: {selector} (最长 {timeout}s)")
        
        import subprocess
        import time
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            snapshot = self._take_snapshot()
            
            # 检查是否出现目标元素
            if isinstance(snapshot, dict) and "accessibilityTree" in snapshot:
                for item in snapshot["accessibilityTree"]:
                    if selector in str(item):
                        return {"status": "found", "element": item, "wait_time": time.time() - start_time}
            
            time.sleep(1)
        
        return {"status": "timeout", "selector": selector, "wait_time": timeout}

    def _take_screenshot(self, full_page: bool = False) -> Dict:
        """截图"""
        print(f"   📸 截图{'（全页）' if full_page else ''}")
        
        import subprocess
        
        cmd = ["openclaw", "browser", "screenshot"]
        if full_page:
            cmd.append("--full-page")
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            return {
                "status": "success",
                "screenshot": result.stdout.strip(),
                "full_page": full_page
            }
        else:
            raise Exception(f"截图失败: {result.stderr}")

    def _calculate_duration(self, start: str, end: str) -> float:
        """计算持续时间（秒）"""
        start_dt = datetime.fromisoformat(start)
        end_dt = datetime.fromisoformat(end)
        return (end_dt - start_dt).total_seconds()


def batch_process_urls(urls: List[str], workflow: Dict) -> List[Dict]:
    """批量处理多个URL"""
    print(f"📦 批量处理 {len(urls)} 个URL")
    
    results = []
    for i, url in enumerate(urls, 1):
        print(f"\n[{i}/{len(urls)}] {url}")
        
        try:
            engine = BrowserAutoEngine()
            result = engine.execute_workflow({
                "name": f"批量处理 {url}",
                "steps": [
                    {"action": "open", "url": url},
                    {"action": "snapshot"},
                    {"action": "extract", "pattern": workflow.get("pattern")}
                ]
            })
            results.append({"url": url, "status": "success", "result": result})
        except Exception as e:
            results.append({"url": url, "status": "error", "error": str(e)})
    
    return results


def cmd_workflow(args):
    """执行工作流"""
    try:
        config = json.loads(args.config)
    except:
        print("❌ 配置必须是有效的 JSON")
        return
    
    engine = BrowserAutoEngine()
    result = engine.execute_workflow(config)
    
    print(f"\n📊 工作流结果")
    print(f"   状态: {result['overall_status']}")
    print(f"   耗时: {result['duration_seconds']:.1f}秒")
    print(f"   步骤: {len(result['steps'])}")
    
    if result['overall_status'] == 'success':
        print("\n✅ 所有步骤完成")
    else:
        print("\n❌ 工作流失败")


def cmd_batch(args):
    """批量处理"""
    urls = args.urls
    if not urls:
        print("请提供 URL 列表")
        return
    
    workflow = {"pattern": args.pattern} if args.pattern else {}
    results = batch_process_urls(urls, workflow)
    
    print(f"\n📊 批量处理结果 ({len(results)} 个URL)")
    success = sum(1 for r in results if r["status"] == "success")
    print(f"   成功: {success}/{len(results)}")
    
    for r in results:
        icon = "✅" if r["status"] == "success" else "❌"
        print(f"   {icon} {r['url']}")


def main():
    parser = argparse.ArgumentParser(description="🌐 增强版浏览器自动化引擎")
    sub = parser.add_subparsers(dest="cmd", required=True)

    workflow = sub.add_parser("workflow", help="执行复杂工作流")
    workflow.add_argument("config", help="工作流配置（JSON）")

    batch = sub.add_parser("batch", help="批量处理多个URL")
    batch.add_argument("urls", nargs="+", help="URL列表")
    batch.add_argument("--pattern", "-p", help="提取模式")

    args = parser.parse_args()

    if args.cmd == "workflow":
        cmd_workflow(args)
    elif args.cmd == "batch":
        cmd_batch(args)


if __name__ == "__main__":
    main()
