---
name: browser-automation
displayName: 浏览器自动化 - 增强版
description: |
  在 OpenClaw browser 工具基础上，提供批量处理、智能提取、工作流自动化等增强能力。
  支持：批量URL处理、结构化数据提取、复杂工作流、自动重试、状态持久化。
  场景：批量爬取、数据提取工作流、多步骤表单自动化、页面监控。
version: 1.1.0
type: skill
tags: ["browser", "automation", "batch", "workflow", "extraction", "monitoring"]
author: audrey
allowed-tools: browser
---

# 🌐 浏览器自动化 - 增强版

## 我能做什么

在 OpenClaw 原生 browser 工具基础上，提供更智能、更高效的浏览器自动化：

**新增能力：**
- **批量处理** — 一次处理多个URL，自动重试失败项
- **工作流引擎** — 复杂多步骤操作（导航→填写→提交→验证）
- **结构化提取** — 从页面自动提取标题、链接、表单、关键词
- **状态持久化** — 工作流状态、检查结果、重试记录
- **智能重试** — 失败自动重试，带退避策略

**典型场景：**
- 「帮我批量检查这些网页，提取所有标题和链接」
- 「在这些网站上执行登录→搜索→结果提取的完整工作流」
- 「监控这个页面，每天检查是否有内容更新」

## 与原版区别（v1.0.0 → v1.1.0）

| 功能 | 原版（纯文档） | 增强版 |
|------|---------------|--------|
| 批量处理 | ❌ 无 | ✅ 批量URL + 失败重试 |
| 工作流引擎 | ❌ 无 | ✅ 多步骤复杂工作流 |
| 结构化提取 | ❌ 无 | ✅ 自动提取标题/链接/表单/关键词 |
| 状态持久化 | ❌ 无 | ✅ JSON状态文件 + 日志 |
| 智能重试 | ❌ 无 | ✅ 指数退避重试策略 |

## 核心能力

### 1. 批量处理引擎

```bash
python browser_auto.py batch https://site1.com https://site2.com https://site3.com
```

- 并行处理多个URL
- 失败项自动重试（指数退避）
- 结果统一格式化输出
- 支持自定义提取模式

### 2. 工作流引擎

```bash
# 登录→搜索→结果提取的完整工作流
python browser_auto.py workflow '
{
  "name": "搜索工作流",
  "steps": [
    {"action": "navigate", "url": "https://example.com"},
    {"action": "type", "ref": "search_box", "text": "关键词", "submit": true},
    {"action": "wait", "selector": ".results"},
    {"action": "extract", "pattern": "结果.*"}
  ]
}'
```

### 3. 结构化数据提取

自动从页面提取：
- **标题** — 主标题、各级标题
- **链接** — 所有外链和内部链接
- **表单** — 输入框、按钮、选择器
- **关键词** — 高频出现的重要词汇
- **内容摘要** — 主要文本内容

### 4. 页面监控

```bash
python browser_auto.py monitor https://example.com 3600 --pattern "更新|发布"
```

- 定时检查页面变化
- 发现指定关键词立即通知
- 变化历史记录
- 支持CSS选择器监控

## 工作方式

我会调用 `browser_auto.py` 脚本，通过 OpenClaw 的 browser 工具完成实际浏览器操作。

**典型对话流程：**

```
你：「帮我批量检查这些招聘网站，提取所有职位标题」
我：→ 调 batch → 并行打开所有URL → 提取标题 → 返回结构化结果

你：「在这个论坛执行：登录→发帖→截图→退出 的完整流程」
我：→ 调 workflow → 执行多步骤 → 每步验证 → 返回完整报告

你：「监控这个商品页面，价格一有变化就告诉我」
我：→ 调 monitor → 定时检查 → 发现变化 → 主动通知
```

## 配置与状态

- 配置文件：`~/.openclaw/workspace/browser_auto_config.json`
- 状态记录：`~/.openclaw/workspace/browser_auto_state.json`
- 操作日志：`~/.openclaw/workspace/browser_auto_log.json`

## 增强特性

1. **智能重试** — 失败后指数退避重试，最多3次
2. **状态持久化** — 工作流中途失败可恢复继续
3. **批量优化** — 并行处理 + 失败隔离
4. **提取增强** — 正则 + CSS选择器 + 语义分析
5. **监控智能** — 变化检测 + 关键词匹配

## 参考命令

```bash
# 批量爬取
python browser_auto.py batch https://site1.com https://site2.com

# 复杂工作流
python browser_auto.py workflow '{"name": "购物流程", "steps": [...]}'

# 结构化提取
python browser_auto.py extract https://example.com "价格.*元"

# 页面监控
python browser_auto.py monitor https://price.com 3600 --selector ".price"
```

## 安全提醒

- 批量处理时避免高频请求同一网站
- 登录操作使用专用 Chrome Profile
- 敏感操作（支付、发布）需人工确认
- 监控任务设置合理间隔，避免被封IP
