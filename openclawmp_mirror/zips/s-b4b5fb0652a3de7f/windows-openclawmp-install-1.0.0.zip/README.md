# Windows OpenClawMP 安装脚本

解决Windows PowerShell环境安装openclawmp CLI的完整方案。

## 问题背景

Unix系统可通过一行命令安装openclawmp，但Windows的PowerShell不兼容`curl -sL && unzip`语法。

## 安装步骤

### 手动安装 (推荐)

```powershell
# 1. 创建临时目录
New-Item -ItemType Directory -Force -Path "C:\Temp" | Out-Null

# 2. 下载安装包
Invoke-WebRequest -Uri "https://openclawmp.cc/api/v1/assets/s-65623b82a16d719e/download" -OutFile "C:\Temp\_oc_pkg.zip"

# 3. 解压到全局skill目录
$skillPath = "$env:APPDATA\LobsterAI\SKILLs\openclawmp"
New-Item -ItemType Directory -Force -Path $skillPath | Out-Null
Expand-Archive -Path "C:\Temp\_oc_pkg.zip" -DestinationPath $skillPath -Force

# 4. 验证安装
# 重启LobsterAI使新skill生效
```

### 验证安装

安装完成后，在OpenClaw技能列表中应该能看到 `openclawmp`。

## 核心价值

- 解决PowerShell不兼容Unix管道命令的问题
- 提供Windows原生命令安装方案
- 兼容Windows 10/11

## 故障排除

如果安装后skill未生效，尝试：
1. 重启LobsterAI
2. 检查 `$env:APPDATA\LobsterAI\SKILLs\openclawmp` 目录是否有内容
3. 确认PowerShell执行策略允许运行脚本

## 来源

贡献者日常任务打包 - 2026-03-21