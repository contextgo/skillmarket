#!/usr/bin/env python3
"""
智能日程管理器
支持日程的增删改查、冲突检测、优先级管理
"""

import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import uuid

class Priority(Enum):
    HIGH = "high"      # 紧急且重要
    MEDIUM = "medium"  # 重要不紧急 或 紧急不重要
    LOW = "low"        # 不紧急不重要

class RepeatType(Enum):
    NONE = "none"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    WORKDAY = "workday"  # 工作日
    WEEKEND = "weekend"  # 周末

@dataclass
class Schedule:
    id: str
    title: str
    start_time: datetime
    end_time: datetime
    priority: Priority
    repeat_type: RepeatType
    description: str
    location: str
    created_at: datetime
    updated_at: datetime
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        # 转换枚举类型为字符串
        data['priority'] = self.priority.value
        data['repeat_type'] = self.repeat_type.value
        # 转换 datetime 为 ISO 格式字符串
        for key in ['start_time', 'end_time', 'created_at', 'updated_at']:
            if isinstance(data[key], datetime):
                data[key] = data[key].isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Schedule':
        # 转换字符串为 datetime
        for key in ['start_time', 'end_time', 'created_at', 'updated_at']:
            if isinstance(data[key], str):
                data[key] = datetime.fromisoformat(data[key])
        # 转换字符串为枚举
        data['priority'] = Priority(data['priority'])
        data['repeat_type'] = RepeatType(data['repeat_type'])
        return cls(**data)

class ScheduleManager:
    def __init__(self, data_dir: str = None):
        if data_dir is None:
            data_dir = os.path.expanduser("~/.stepclaw/workspace/schedule-data")
        self.data_dir = data_dir
        self.data_file = os.path.join(data_dir, "schedules.json")
        os.makedirs(data_dir, exist_ok=True)
        self.schedules: List[Schedule] = []
        self._load_data()
    
    def _load_data(self):
        """从文件加载日程数据"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.schedules = [Schedule.from_dict(s) for s in data]
            except Exception as e:
                print(f"加载数据失败: {e}")
                self.schedules = []
    
    def _save_data(self):
        """保存日程数据到文件"""
        try:
            data = [s.to_dict() for s in self.schedules]
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存数据失败: {e}")
            return False
    
    def add_schedule(self, title: str, start_time: datetime, end_time: datetime,
                     priority: Priority = Priority.MEDIUM,
                     repeat_type: RepeatType = RepeatType.NONE,
                     description: str = "", location: str = "") -> Schedule:
        """添加新日程"""
        schedule = Schedule(
            id=str(uuid.uuid4()),
            title=title,
            start_time=start_time,
            end_time=end_time,
            priority=priority,
            repeat_type=repeat_type,
            description=description,
            location=location,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        self.schedules.append(schedule)
        self._save_data()
        return schedule
    
    def delete_schedule(self, schedule_id: str) -> bool:
        """删除日程"""
        for i, s in enumerate(self.schedules):
            if s.id == schedule_id:
                self.schedules.pop(i)
                self._save_data()
                return True
        return False
    
    def update_schedule(self, schedule_id: str, **kwargs) -> Optional[Schedule]:
        """更新日程"""
        for s in self.schedules:
            if s.id == schedule_id:
                for key, value in kwargs.items():
                    if hasattr(s, key):
                        setattr(s, key, value)
                s.updated_at = datetime.now()
                self._save_data()
                return s
        return None
    
    def get_schedules(self, start: datetime = None, end: datetime = None,
                      priority: Priority = None) -> List[Schedule]:
        """获取日程列表，支持筛选"""
        result = self.schedules
        
        if start:
            result = [s for s in result if s.end_time >= start]
        if end:
            result = [s for s in result if s.start_time <= end]
        if priority:
            result = [s for s in result if s.priority == priority]
        
        # 按开始时间排序
        result.sort(key=lambda x: x.start_time)
        return result
    
    def check_conflicts(self, start_time: datetime, end_time: datetime,
                        exclude_id: str = None) -> List[Schedule]:
        """检查时间冲突"""
        conflicts = []
        for s in self.schedules:
            if exclude_id and s.id == exclude_id:
                continue
            # 检查时间重叠
            if s.start_time < end_time and s.end_time > start_time:
                conflicts.append(s)
        return conflicts
    
    def get_today_schedules(self) -> List[Schedule]:
        """获取今天的日程"""
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        tomorrow = today + timedelta(days=1)
        return self.get_schedules(start=today, end=tomorrow)
    
    def get_week_schedules(self) -> List[Schedule]:
        """获取本周的日程"""
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        # 计算本周一
        monday = today - timedelta(days=today.weekday())
        next_monday = monday + timedelta(days=7)
        return self.get_schedules(start=monday, end=next_monday)
    
    def analyze_time_distribution(self, days: int = 7) -> Dict:
        """分析时间分配"""
        end = datetime.now()
        start = end - timedelta(days=days)
        schedules = self.get_schedules(start=start, end=end)
        
        # 按优先级统计
        priority_stats = {p.value: 0 for p in Priority}
        total_hours = 0
        
        for s in schedules:
            duration = (s.end_time - s.start_time).total_seconds() / 3600
            priority_stats[s.priority.value] += duration
            total_hours += duration
        
        return {
            "total_hours": round(total_hours, 2),
            "priority_distribution": {k: round(v, 2) for k, v in priority_stats.items()},
            "schedule_count": len(schedules)
        }

# CLI 接口
if __name__ == "__main__":
    import sys
    
    manager = ScheduleManager()
    
    if len(sys.argv) < 2:
        print("用法: python schedule_manager.py <command> [args]")
        print("命令: add, list, delete, today, week, analyze")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "today":
        schedules = manager.get_today_schedules()
        print(f"今天共有 {len(schedules)} 个日程:")
        for s in schedules:
            print(f"  [{s.priority.value}] {s.start_time.strftime('%H:%M')}-{s.end_time.strftime('%H:%M')} {s.title}")
    
    elif command == "week":
        schedules = manager.get_week_schedules()
        print(f"本周共有 {len(schedules)} 个日程")
    
    elif command == "analyze":
        days = int(sys.argv[2]) if len(sys.argv) > 2 else 7
        stats = manager.analyze_time_distribution(days)
        print(f"近 {days} 天时间分析:")
        print(f"  总时长: {stats['total_hours']} 小时")
        print(f"  日程数: {stats['schedule_count']}")