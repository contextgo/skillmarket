#!/usr/bin/env python3
"""
日程冲突检测器
检测日程之间的时间冲突
"""

import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class Schedule:
    """日程对象"""
    id: str
    title: str
    start_time: datetime
    end_time: datetime
    description: str = ""
    
    def overlaps_with(self, other: 'Schedule') -> bool:
        """检查是否与另一个日程冲突"""
        return (self.start_time < other.end_time and 
                self.end_time > other.start_time)
    
    def get_overlap_duration(self, other: 'Schedule') -> int:
        """获取冲突时长（分钟）"""
        if not self.overlaps_with(other):
            return 0
        
        overlap_start = max(self.start_time, other.start_time)
        overlap_end = min(self.end_time, other.end_time)
        
        return int((overlap_end - overlap_start).total_seconds() / 60)


class ConflictChecker:
    """日程冲突检测器"""
    
    def __init__(self, schedules: List[Dict] = None):
        self.schedules = []
        if schedules:
            for s in schedules:
                self.add_schedule(s)
    
    def add_schedule(self, schedule_dict: Dict):
        """添加日程"""
        schedule = Schedule(
            id=schedule_dict.get('id', ''),
            title=schedule_dict.get('title', ''),
            start_time=datetime.fromisoformat(schedule_dict['start_time']),
            end_time=datetime.fromisoformat(schedule_dict['end_time']),
            description=schedule_dict.get('description', '')
        )
        self.schedules.append(schedule)
    
    def check_conflicts(self, new_schedule: Dict) -> List[Dict]:
        """
        检查新日程与现有日程的冲突
        
        Returns:
            冲突列表，每个冲突包含冲突日程信息和重叠时长
        """
        new = Schedule(
            id=new_schedule.get('id', 'new'),
            title=new_schedule.get('title', ''),
            start_time=datetime.fromisoformat(new_schedule['start_time']),
            end_time=datetime.fromisoformat(new_schedule['end_time']),
            description=new_schedule.get('description', '')
        )
        
        conflicts = []
        for existing in self.schedules:
            if new.overlaps_with(existing):
                overlap_minutes = new.get_overlap_duration(existing)
                conflicts.append({
                    'conflict_with': {
                        'id': existing.id,
                        'title': existing.title,
                        'start_time': existing.start_time.isoformat(),
                        'end_time': existing.end_time.isoformat(),
                    },
                    'overlap_minutes': overlap_minutes,
                    'suggestion': self._generate_suggestion(new, existing)
                })
        
        return conflicts
    
    def _generate_suggestion(self, new: Schedule, existing: Schedule) -> str:
        """生成冲突解决建议"""
        suggestions = []
        
        # 建议1：提前开始
        buffer_before = existing.start_time - new.end_time
        if buffer_before.total_seconds() > 0:
            minutes_before = int(buffer_before.total_seconds() / 60)
            if minutes_before >= 30:
                suggestions.append(f"可以提前 {minutes_before} 分钟开始")
        
        # 建议2：延后开始
        buffer_after = new.start_time - existing.end_time
        if buffer_after.total_seconds() > 0:
            minutes_after = int(buffer_after.total_seconds() / 60)
            if minutes_after >= 30:
                suggestions.append(f"可以延后 {minutes_after} 分钟开始")
        
        # 建议3：缩短时长
        duration = (new.end_time - new.start_time).total_seconds() / 60
        if duration > 60:
            suggestions.append("可以考虑缩短会议时长")
        
        # 建议4：改期
        suggestions.append("建议改到其他时间段")
        
        return "；".join(suggestions) if suggestions else "建议调整时间"
    
    def find_free_slots(self, date: datetime, duration_minutes: int = 60) -> List[Dict]:
        """
        查找指定日期的空闲时间段
        
        Args:
            date: 目标日期
            duration_minutes: 需要的空闲时长（分钟）
            
        Returns:
            空闲时间段列表
        """
        # 默认工作时间 9:00 - 18:00
        work_start = date.replace(hour=9, minute=0, second=0, microsecond=0)
        work_end = date.replace(hour=18, minute=0, second=0, microsecond=0)
        
        # 获取当天的所有日程
        day_schedules = [
            s for s in self.schedules
            if s.start_time.date() == date.date()
        ]
        
        # 按开始时间排序
        day_schedules.sort(key=lambda x: x.start_time)
        
        free_slots = []
        current_time = work_start
        
        for schedule in day_schedules:
            # 检查当前时间到下一个日程开始之间是否有足够空闲
            gap = schedule.start_time - current_time
            gap_minutes = int(gap.total_seconds() / 60)
            
            if gap_minutes >= duration_minutes:
                free_slots.append({
                    'start': current_time.isoformat(),
                    'end': schedule.start_time.isoformat(),
                    'duration_minutes': gap_minutes
                })
            
            # 移动到当前日程结束时间
            current_time = max(current_time, schedule.end_time)
        
        # 检查最后一个日程之后到下班时间
        gap = work_end - current_time
        gap_minutes = int(gap.total_seconds() / 60)
        
        if gap_minutes >= duration_minutes:
            free_slots.append({
                'start': current_time.isoformat(),
                'end': work_end.isoformat(),
                'duration_minutes': gap_minutes
            })
        
        return free_slots


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: conflict_checker.py '<schedule_json>'")
        print("Example: conflict_checker.py '{\"start_time\":\"...\",\"end_time\":\"...\"}'")
        sys.exit(1)
    
    try:
        new_schedule = json.loads(sys.argv[1])
        
        # 这里可以加载现有日程（从文件或数据库）
        checker = ConflictChecker([])
        
        conflicts = checker.check_conflicts(new_schedule)
        
        result = {
            'has_conflict': len(conflicts) > 0,
            'conflicts': conflicts
        }
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON - {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
