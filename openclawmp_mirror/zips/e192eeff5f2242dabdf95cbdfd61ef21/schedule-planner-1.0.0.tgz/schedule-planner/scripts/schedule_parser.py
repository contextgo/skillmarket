#!/usr/bin/env python3
"""
日程解析器 - 将自然语言转换为结构化日程数据
"""

import re
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

class ScheduleParser:
    """解析自然语言日程描述"""
    
    # 时间关键词映射
    TIME_PATTERNS = {
        '今天': 0,
        '明天': 1,
        '后天': 2,
        '下周': 7,
        '下月': 30,
    }
    
    # 周期关键词
    RECURRING_PATTERNS = {
        '每天': 'daily',
        '每周': 'weekly',
        '每月': 'monthly',
        '工作日': 'weekdays',
        '周末': 'weekends',
    }
    
    def __init__(self):
        self.today = datetime.now()
    
    def parse(self, text: str) -> Dict:
        """
        解析日程描述
        
        Args:
            text: 自然语言描述，如"明天下午3点开会"
            
        Returns:
            结构化日程数据
        """
        result = {
            'title': '',
            'start_time': None,
            'end_time': None,
            'duration': None,
            'recurring': None,
            'priority': 'normal',
            'description': text
        }
        
        # 提取标题
        result['title'] = self._extract_title(text)
        
        # 解析时间
        time_info = self._parse_time(text)
        if time_info:
            result['start_time'] = time_info['start']
            result['end_time'] = time_info['end']
            result['duration'] = time_info['duration']
        
        # 检测周期性
        result['recurring'] = self._detect_recurring(text)
        
        # 检测优先级
        result['priority'] = self._detect_priority(text)
        
        return result
    
    def _extract_title(self, text: str) -> str:
        """提取日程标题"""
        # 移除时间相关词汇
        title = text
        time_words = ['今天', '明天', '后天', '下周', '下月', '上午', '下午', '晚上',
                      '早上', '中午', '凌晨', '点', '分', '明天', '每天', '每周']
        for word in time_words:
            title = title.replace(word, '')
        
        # 提取核心动作
        match = re.search(r'(开会|会议|见面|约会|健身|运动|学习|工作|吃饭|聚餐|约会|面试|报告|截止|提交)', title)
        if match:
            return match.group(1)
        
        return title.strip() or '未命名日程'
    
    def _parse_time(self, text: str) -> Optional[Dict]:
        """解析时间信息"""
        base_date = self.today.date()
        
        # 确定日期
        if '今天' in text:
            base_date = self.today.date()
        elif '明天' in text:
            base_date = (self.today + timedelta(days=1)).date()
        elif '后天' in text:
            base_date = (self.today + timedelta(days=2)).date()
        elif '下周' in text:
            # 下周一
            days_ahead = 7 - self.today.weekday()
            base_date = (self.today + timedelta(days=days_ahead)).date()
        
        # 解析具体时间
        hour, minute = self._extract_hour_minute(text)
        
        if hour is not None:
            start_time = datetime.combine(base_date, datetime.min.time().replace(hour=hour, minute=minute or 0))
            
            # 检测时长
            duration = self._extract_duration(text) or 60  # 默认1小时
            end_time = start_time + timedelta(minutes=duration)
            
            return {
                'start': start_time.isoformat(),
                'end': end_time.isoformat(),
                'duration': duration
            }
        
        return None
    
    def _extract_hour_minute(self, text: str) -> Tuple[Optional[int], Optional[int]]:
        """提取小时和分钟"""
        # 匹配 "3点"、"15:30"、"下午3点" 等格式
        patterns = [
            r'(\d{1,2}):(\d{2})',
            r'(\d{1,2})点(?:半)?',
            r'([一二两三四五六七八九十]+)点',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                hour_str = match.group(1)
                
                # 转换中文数字
                hour = self._chinese_to_number(hour_str)
                if hour is None:
                    try:
                        hour = int(hour_str)
                    except ValueError:
                        continue
                
                # 处理下午/晚上
                if '下午' in text or '晚上' in text:
                    if hour < 12:
                        hour += 12
                elif '上午' in text or '早上' in text:
                    if hour == 12:
                        hour = 0
                
                # 提取分钟
                minute = 0
                if '半' in text and '点半' in text:
                    minute = 30
                elif len(match.groups()) > 1 and match.group(2):
                    try:
                        minute = int(match.group(2))
                    except ValueError:
                        pass
                
                return hour, minute
        
        return None, None
    
    def _chinese_to_number(self, text: str) -> Optional[int]:
        """中文数字转阿拉伯数字"""
        mapping = {
            '一': 1, '二': 2, '两': 2, '三': 3, '四': 4,
            '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
            '十一': 11, '十二': 12
        }
        return mapping.get(text)
    
    def _extract_duration(self, text: str) -> Optional[int]:
        """提取时长（分钟）"""
        patterns = [
            (r'(\d+)小时(?:半)?', lambda x: int(x) * 60 + (30 if '半' in text else 0)),
            (r'(\d+)个半小时', lambda x: int(x) * 60 + 30),
            (r'(\d+)分钟', lambda x: int(x)),
            (r'半(?:个)?小时', lambda x: 30),
            (r'(?:一|1)小时', lambda x: 60),
            (r'(?:两|2)小时', lambda x: 120),
        ]
        
        for pattern, converter in patterns:
            match = re.search(pattern, text)
            if match:
                return converter(match.group(1) if match.groups() else '0')
        
        return None
    
    def _detect_recurring(self, text: str) -> Optional[str]:
        """检测是否为周期性任务"""
        for keyword, pattern in self.RECURRING_PATTERNS.items():
            if keyword in text:
                return pattern
        return None
    
    def _detect_priority(self, text: str) -> str:
        """检测优先级"""
        high_keywords = ['紧急', '重要', '必须', '马上', '立刻', '尽快', 'deadline', '截止']
        low_keywords = ['有空', '随便', '也许', '可能', '考虑']
        
        for keyword in high_keywords:
            if keyword in text:
                return 'high'
        
        for keyword in low_keywords:
            if keyword in text:
                return 'low'
        
        return 'normal'


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: schedule_parser.py '<schedule description>'")
        print("Example: schedule_parser.py '明天下午3点开会，预计1小时'")
        sys.exit(1)
    
    text = sys.argv[1]
    parser = ScheduleParser()
    result = parser.parse(text)
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
