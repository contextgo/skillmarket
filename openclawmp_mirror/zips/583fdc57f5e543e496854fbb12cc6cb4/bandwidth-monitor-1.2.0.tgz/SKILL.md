---
name: bandwidth-monitor
description: Monitor network bandwidth usage on Linux systems. Track real-time and historical data consumption per interface, set threshold alerts, and identify bandwidth-hungry processes. Use when users want to (1) check current bandwidth usage, (2) monitor network traffic over time, (3) set up bandwidth alerts and limits, (4) track historical data consumption daily/monthly, (5) identify which processes consume bandwidth, or (6) export bandwidth data for dashboards.
---

# Bandwidth Monitor（带宽监控）

监控网络带宽使用情况，跟踪长期数据消耗，并在超出阈值时发出告警。专为 Linux 服务器和开发机设计。

## 快速开始

```bash
# Install vnstat
sudo apt install vnstat       # Debian/Ubuntu
sudo yum install vnstat       # RHEL/CentOS

# Enable daemon (starts collecting data immediately)
sudo systemctl enable --now vnstat

# Check usage
vnstat -d                     # Daily summary
vnstat -l                     # Live traffic (Ctrl+C to stop)
vnstat -m                     # Monthly summary
```

## 架构

```
Linux Kernel (network interface counters)
  └── vnstatd (daemon, polls every 30s)
        └── /var/lib/vnstat/ (historical database)
              ├── vnstat CLI queries
              ├── vnstat --json (export)
              └── Custom alert scripts
  └── nethogs (optional, per-process view)
        └── /proc/net/dev + /proc/<pid>/net
```

三个组件：

1. **内核计数器**：每个 Linux 内核都在 `/proc/net/dev` 中跟踪每个接口的字节数/包数。零配置，零开销。
2. **vnstatd**：后台守护进程，每 30 秒读取一次内核计数器并存储数据。数据在重启后持久保留。配置文件位于 `/etc/vnstat.conf`。
3. **nethogs**：可选的按进程监控工具。显示哪些进程正在活跃使用带宽（类似于网络版的 `top`）。

## 实时监控（Real-time Monitoring）

### 实时流量（Live Traffic）

```bash
# Live bandwidth per interface (updates every 2s)
vnstat -l

# Specific interface
vnstat -i eth0 -l

# Compact live view
vnstat -l -ru
```

### 按进程带宽（Per-Process Bandwidth）

```bash
# Install nethogs
sudo apt install nethogs

# Show per-process bandwidth (requires root)
sudo nethogs

# Specific interface
sudo nethogs eth0

# Refresh every 5 seconds
sudo nethogs -d 5
```

### 套接字级监控（Socket-level Monitoring）

```bash
# All TCP/UDP connections with process names
ss -tunap

# Established connections sorted by state
ss -tunap state established

# Specific port
ss -tunap '( sport = :443 or sport = :80 )'
```

## 历史报告（Historical Reporting）

### 每日报告（Daily Report）

```bash
# Today + last 30 days
vnstat -d

# Output:
#      day        rx      |     tx      |    total    |   avg. rate
# ------------------------+-------------+-------------+---------------
#  2026-04-08   2.14 GiB  |  450 MiB   |  2.58 GiB  |  254.61 kbit/s
#  2026-04-07   1.87 GiB  |  380 MiB   |  2.24 GiB  |  221.04 kbit/s
```

### 每小时报告（Hourly Report）

```bash
# Last 24 hours, hourly breakdown
vnstat -h
```

### 每月报告（Monthly Report）

```bash
# This month + last 12 months
vnstat -m
```

### 每周报告（Weekly Report）

```bash
# Last 7 days
vnstat -w
```

### 流量最高的 10 天（Top 10 Days）

```bash
# Top 10 highest-traffic days
vnstat -t
```

### JSON 导出（JSON Export）

```bash
# Export all data as JSON for custom processing
vnstat --json

# Specific interface
vnstat -i eth0 --json

# Parse with python
vnstat --json | python3 -c "
import sys, json
data = json.load(sys.stdin)
for iface in data['interfaces']:
    print(f'Interface: {iface[\"name\"]}')
    print(f'Total RX: {iface[\"traffic\"][\"total\"][\"rx\"]}')
    print(f'Total TX: {iface[\"traffic\"][\"total\"][\"tx\"]}')
"
```

## 多接口支持（Multi-Interface Support）

```bash
# List all monitored interfaces
vnstat --iflist

# Add a new interface
sudo vnstat --add -i docker0

# Check specific interface
vnstat -i wlan0 -d

# Combine multiple interfaces
vnstat -i eth0+wlan0 -d
```

常见需要监控的接口：

| 接口 | 说明 |
|------|------|
| `eth0` | 主以太网 |
| `wlan0` | WiFi |
| `docker0` | Docker 网桥 |
| `veth*` | 虚拟以太网（容器） |
| `br-*` | 网桥接口 |
| `tun0` | VPN 隧道 |

## 阈值告警（Threshold Alerts）

### 简单每日告警脚本（Simple Daily Alert Script）

```bash
#!/bin/bash
# bandwidth-alert.sh - Alert when daily bandwidth exceeds threshold

INTERFACE="eth0"
THRESHOLD_GB=10
LOG_FILE="/var/log/bandwidth-alerts.log"

# Get today's total usage in MB
DAILY_LINE=$(vnstat -i "$INTERFACE" -d --oneline)
TOTAL_MB=$(echo "$DAILY_LINE" | cut -d';' -f11)
TOTAL_GB=$(echo "scale=2; $TOTAL_MB / 1024" | bc)

if (( $(echo "$TOTAL_GB > $THRESHOLD_GB" | bc -l) )); then
    echo "$(date '+%Y-%m-%d %H:%M:%S') ALERT: ${INTERFACE} daily usage ${TOTAL_GB}GB exceeds ${THRESHOLD_GB}GB" >> "$LOG_FILE"
    # Desktop notification (if applicable)
    notify-send "Bandwidth Alert" "${INTERFACE}: ${TOTAL_GB}GB / ${THRESHOLD_GB}GB daily limit"
fi
```

### 月度上限告警（Monthly Cap Alert）

```bash
#!/bin/bash
# monthly-cap-alert.sh - Alert when monthly usage approaches ISP cap

CAP_GB=1000
WARN_PERCENT=80

MONTHLY_LINE=$(vnstat -m --oneline)
TOTAL_MB=$(echo "$MONTHLY_LINE" | cut -d';' -f11)
TOTAL_GB=$(echo "scale=2; $TOTAL_MB / 1024" | bc)
WARN_GB=$(echo "scale=2; $CAP_GB * $WARN_PERCENT / 100" | bc)

if (( $(echo "$TOTAL_GB > $WARN_GB" | bc -l) )); then
    echo "$(date '+%Y-%m-%d') WARNING: Monthly usage ${TOTAL_GB}GB approaching ${CAP_GB}GB cap (${WARN_PERCENT}%)" >> "/var/log/bandwidth-alerts.log"
fi
```

### Cron 集成（Cron Integration）

```bash
# Check bandwidth every hour
0 * * * * /usr/local/bin/bandwidth-alert.sh

# Check monthly cap daily at 9am
0 9 * * * /usr/local/bin/monthly-cap-alert.sh
```

## 仪表盘集成（Dashboard Integration）

### Prometheus 导出器（Prometheus Exporter）

```bash
# Install vnstat_exporter
go install github.com/bt909/vnstat_exporter@latest

# Run exporter (exposes metrics on :8081/metrics)
vnstat_exporter --listen :8081
```

暴露的 Prometheus 指标：
- `vnstat_rx_bytes_total` — 总接收字节数
- `vnstat_tx_bytes_total` — 总发送字节数
- `vnstat_rx_rate_bps` — 当前接收速率
- `vnstat_tx_rate_bps` — 当前发送速率

### Grafana 仪表盘（Grafana Dashboard）

导入仪表盘 ID `19023`，即可使用预构建的 vnstat Grafana 仪表盘，展示每日/每月趋势。

## 关键实现细节（Key Implementation Details）

- **数据库位置**：`/var/lib/vnstat/` — 每个接口一个数据库文件
- **轮询间隔**：默认 30 秒，可在 `/etc/vnstat.conf` 中配置（`PollInterval`）
- **重启持久化**：vnstatd 在关闭时将当前计数器保存到磁盘，启动时恢复
- **接口检测**：启用 `UseExclusivePolling` 后，新接口会被自动检测
- **数据保留**：默认保留 2 年的每日数据，可通过配置中的 `DayRotation` 调整
- **低开销**：vnstatd 占用不到 1MB 内存，CPU 消耗可忽略不计

## 配置（Configuration）

`/etc/vnstat.conf` 中的关键设置：

```ini
# Polling interval in seconds
PollInterval 30

# Which interfaces to monitor (empty = all)
Interface ""

# Data retention in days
DayRotation 30

# Maximum bandwidth for rate estimation
MaxBandwidth 1000

# Database location
DatabaseDir "/var/lib/vnstat"
```

## 故障排查（Troubleshooting）

| 问题 | 解决方案 |
|------|----------|
| **"No data available"** | 启用 vnstat 后等待 5 分钟。检查 `systemctl status vnstat` |
| **接口未列出** | 手动添加：`sudo vnstat --add -i eth0` |
| **守护进程未运行** | 执行 `sudo systemctl start vnstat`，然后检查 `systemctl status vnstat` |
| **权限被拒绝** | vnstat 查询无需特殊权限；实时模式和 nethogs 需要 sudo |
| **重启后数据丢失** | 检查 vnstatd 服务是否已启用：`systemctl is-enabled vnstat` |
| **显示的带宽不正确** | 确保配置中的 `MaxBandwidth` 与实际链路速度匹配 |
| **nethogs 显示 0** | 某些进程使用 Unix 套接字；nethogs 只显示 IP 流量 |

## 文件（Files）

- `/etc/vnstat.conf` — 主配置文件
- `/var/lib/vnstat/` — 数据库目录（每个接口一个文件）
- `/var/log/vnstat.log` — 守护进程日志文件
- `/etc/systemd/system/vnstat.service` — Systemd 服务单元
