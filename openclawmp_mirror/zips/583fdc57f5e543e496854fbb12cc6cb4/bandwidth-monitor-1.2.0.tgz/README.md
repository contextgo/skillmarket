# Bandwidth Monitor（带宽监控）

监控 Linux 系统上的网络带宽使用情况，支持实时跟踪、历史报告、阈值告警和按进程监控。基于 vnstat + nethogs + 标准 Linux 网络工具构建。

## 解决什么问题

如果你运行 Linux 服务器或开发机，需要了解自己消耗了多少带宽，本技能提供了完整的监控方案。与简单的速度测试不同，它可以跟踪数小时、数天乃至数月的累计数据使用量——并在你触及 ISP 数据上限或云服务商带宽限额之前发出告警。

## 核心能力

- **实时带宽跟踪**：按网络接口进行实时流量监控
- **历史使用报告**：按小时、天、周、月进行详细统计
- **阈值告警**：当数据消耗超过设定限额时发出通知
- **按进程监控**：识别哪些进程正在消耗带宽
- **多接口支持**：分别跟踪 eth0、wlan0、docker0、veth*、bridge 等接口
- **JSON 导出**：输出机器可读格式，便于自定义仪表盘和告警系统

## 快速开始

```bash
# Install vnstat (the core dependency)
sudo apt install vnstat      # Debian/Ubuntu
sudo yum install vnstat      # RHEL/CentOS
sudo pacman -S vnstat        # Arch

# Enable the daemon
sudo systemctl enable --now vnstat

# Wait a few minutes for data collection, then check:
vnstat -d                    # Daily summary
vnstat -l                    # Live monitoring
```

## 架构

```
Linux Kernel (network interfaces)
  └── vnstatd (background daemon, collects traffic stats)
        └── vnstat DB (/var/lib/vnstat/)
              ├── vnstat -l (live view)
              ├── vnstat -d (daily report)
              ├── vnstat -m (monthly report)
              └── vnstat --json (machine-readable)
  └── nethogs (per-process bandwidth)
        └── /proc/net/dev (kernel network stats)
```

三个层次：

1. **内核层**：统计每个网络接口上的字节数/包数。零开销，始终运行。
2. **vnstatd**：后台守护进程，每 30 秒轮询一次内核计数器，将历史数据存储在类 SQLite 数据库中。重启后数据不丢失。
3. **nethogs**：可选的按进程监控工具。实时显示每个进程的带宽占用（类似于网络版的 `top`）。
