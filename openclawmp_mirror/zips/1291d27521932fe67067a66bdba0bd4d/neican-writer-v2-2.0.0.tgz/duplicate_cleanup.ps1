# 重复文件清理与归类脚本
param([switch]$WhatIf = $false)

$LogFile = "$env:USERPROFILE\.stepclaw\workspace\duplicate_cleanup_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$duplicates = @()
$deletedCount = 0
$freedSpace = 0

function Log($msg, $color="White") {
    Write-Host $msg -ForegroundColor $color
    "[$(Get-Date -Format 'HH:mm:ss')] $msg" | Out-File $LogFile -Append -Encoding UTF8
}

Log "========== 重复文件清理与归类 ==========" "Cyan"
Log "Mode: $(if($WhatIf){'PREVIEW'}else{'EXECUTE'})" "Yellow"

# 1. 查找重复文件（按文件大小和哈希）
Log "`n[1/3] 扫描重复文件..." "Cyan"
$drives = @('E:\','F:\','G:\','H:\')
$files = @()

foreach($drive in $drives){
    if(Test-Path $drive){
        Log "  Scanning $drive..." "Gray"
        $files += Get-ChildItem -Path $drive -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 1MB } |
            Select-Object FullName, Length, @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}}, 
                         @{N='Hash';E={(Get-FileHash $_.FullName -Algorithm MD5 -ErrorAction SilentlyContinue).Hash}},
                         Extension
    }
}

# 按哈希分组找重复
$grouped = $files | Where-Object { $_.Hash -ne $null } | Group-Object Hash | Where-Object { $_.Count -gt 1 }
Log "  发现 $($grouped.Count) 组重复文件" "Yellow"

foreach($group in $grouped){
    $sorted = $group.Group | Sort-Object FullName
    $keep = $sorted[0]  # 保留第一个
    $remove = $sorted[1..($sorted.Count-1)]  # 删除其余的
    
    Log "`n  重复组 (哈希: $($group.Name.Substring(0,8))...)" "Cyan"
    Log "    保留: $($keep.FullName) ($($keep.SizeMB) MB)" "Green"
    
    foreach($dup in $remove){
        Log "    删除: $($dup.FullName) ($($dup.SizeMB) MB)" "Red"
        if(-not $WhatIf){
            try{
                Remove-Item $dup.FullName -Force -ErrorAction Stop
                $deletedCount++
                $freedSpace += $dup.SizeMB
            }catch{
                Log "    失败: $($_.Exception.Message)" "Red"
            }
        }else{
            $deletedCount++
            $freedSpace += $dup.SizeMB
        }
    }
}

# 2. 删除剩余空文件夹
Log "`n[2/3] 清理剩余空文件夹..." "Cyan"
$emptyCount = 0
foreach($drive in $drives){
    if(Test-Path $drive){
        Get-ChildItem -Path $drive -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } |
        Sort-Object FullName -Descending | ForEach-Object {
            if(-not $WhatIf){ Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
            $emptyCount++
        }
    }
}
Log "  删除空文件夹: $emptyCount 个" "Green"

# 3. 同类文件归类
Log "`n[3/3] 归类文件到 E:\Organized..." "Cyan"

$categories = @{
    "01-Software" = @("*.exe","*.msi","*.zip","*.rar","*.7z","*.iso")
    "02-Documents" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx","*.ppt","*.pptx","*.txt")
    "03-Images" = @("*.jpg","*.jpeg","*.png","*.gif","*.bmp","*.psd","*.ai","*.ico")
    "04-Videos" = @("*.mp3","*.mp4","*.avi","*.mkv","*.wma","*.wav","*.ncm","*.wmv")
    "05-Design" = @("*.pds","*.crf","*.dl","*.dwg","*.skp")
    "06-Backup" = @("*.wim","*.dat","*.db","*.bin","*.wim")
}

$movedCount = 0
$movedSize = 0

foreach($cat in $categories.GetEnumerator()){
    $destFolder = "E:\Organized\$($cat.Key)"
    if(-not (Test-Path $destFolder)){
        New-Item -ItemType Directory -Path $destFolder -Force | Out-Null
    }
    
    foreach($pattern in $cat.Value){
        # 只从E盘根目录和年份文件夹中移动文件（避免移动程序目录中的文件）
        $sourcePaths = @("E:\")
        Get-ChildItem -Path "E:\" -Directory -ErrorAction SilentlyContinue | 
            Where-Object { $_.Name -match '^\d{4}$' } | 
            ForEach-Object { $sourcePaths += $_.FullName }
        
        foreach($src in $sourcePaths){
            Get-ChildItem -Path $src -Filter $pattern -File -ErrorAction SilentlyContinue | ForEach-Object {
                $destPath = Join-Path $destFolder $_.Name
                # 如果目标已存在，重命名
                if(Test-Path $destPath){
                    $destPath = Join-Path $destFolder "$($_.BaseName)_$(Get-Random)$($_.Extension)"
                }
                
                $sizeMB = [math]::Round($_.Length/1MB,2)
                if(-not $WhatIf){
                    try{
                        Move-Item $_.FullName $destPath -Force -ErrorAction Stop
                        Log "  移动: $($_.Name) -> $($cat.Key)" "Green"
                        $movedCount++
                        $movedSize += $sizeMB
                    }catch{
                        Log "  失败: $($_.Name)" "Red"
                    }
                }else{
                    Log "  [预览] 移动: $($_.Name) -> $($cat.Key)" "Gray"
                    $movedCount++
                    $movedSize += $sizeMB
                }
            }
        }
    }
}

# 总结
Log "`n========== 完成 ==========" "Cyan"
Log "重复文件删除: $deletedCount 个" "Green"
Log "释放空间: $([math]::Round($freedSpace,2)) MB" "Green"
Log "空文件夹删除: $emptyCount 个" "Green"
Log "文件归类: $movedCount 个 ($([math]::Round($movedSize,2)) MB)" "Green"
Log "日志: $LogFile" "Gray"
