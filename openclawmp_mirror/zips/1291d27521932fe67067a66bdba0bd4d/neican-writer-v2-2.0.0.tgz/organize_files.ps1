# 电脑文件整理脚本
# 功能：清理无用文件 + 按类别整理

param([switch]$WhatIf = $false)

$LogFile = "$env:USERPROFILE\.stepclaw\workspace\file_cleanup_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$Summary = @{
    DeletedFiles = 0
    DeletedSizeMB = 0
    MovedFiles = 0
    MovedSizeMB = 0
    EmptyFoldersRemoved = 0
}

function Write-Log($Message, $Color = "White") {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] $Message"
    Write-Host $logLine -ForegroundColor $Color
    $logLine | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

function Remove-UselessFiles($Path, $Patterns) {
    foreach ($pattern in $Patterns) {
        $files = Get-ChildItem -Path $Path -Filter $pattern -File -Recurse -ErrorAction SilentlyContinue
        foreach ($file in $files) {
            try {
                $sizeMB = [math]::Round($file.Length / 1MB, 2)
                if (-not $WhatIf) {
                    Remove-Item -Path $file.FullName -Force -ErrorAction Stop
                }
                Write-Log "删除: $($file.FullName) (${sizeMB} MB)" "Green"
                $Summary.DeletedFiles++
                $Summary.DeletedSizeMB += $sizeMB
            }
            catch {
                Write-Log "删除失败: $($file.FullName) - $($_.Exception.Message)" "Red"
            }
        }
    }
}

function Remove-EmptyFolders($Path) {
    $emptyDirs = Get-ChildItem -Path $Path -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { (Get-ChildItem -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } | 
        Sort-Object FullName -Descending
    
    foreach ($dir in $emptyDirs) {
        try {
            if (-not $WhatIf) {
                Remove-Item -Path $dir.FullName -Force -ErrorAction Stop
            }
            Write-Log "删除空文件夹: $($dir.FullName)" "Green"
            $Summary.EmptyFoldersRemoved++
        }
        catch {
            Write-Log "删除空文件夹失败: $($dir.FullName)" "Red"
        }
    }
}

# ==================== 主程序 ====================

Write-Log "========== 文件整理开始 ==========" "Cyan"
Write-Log "模式: $(if ($WhatIf) { '预览模式' } else { '实际执行' })" "Yellow"

# 1. 清理临时文件和缓存
Write-Log "`n[1/4] 清理临时文件和缓存..." "Cyan"
$tempPatterns = @(
    "*.tmp", "*.temp", "*.cache", "*.log", "*.old", "*.bak", "*.backup",
    "Thumbs.db", "*.thumb", "desktop.ini", "~$*", "*.dmp", "*.crash"
)
$drives = @('E:\', 'F:\', 'G:\', 'H:\')
foreach ($drive in $drives) {
    if (Test-Path $drive) {
        Write-Log "  扫描 $drive..." "Gray"
        Remove-UselessFiles -Path $drive -Patterns $tempPatterns
    }
}

# 2. 删除空文件夹
Write-Log "`n[2/4] 删除空文件夹..." "Cyan"
foreach ($drive in $drives) {
    if (Test-Path $drive) {
        Write-Log "  处理 $drive..." "Gray"
        Remove-EmptyFolders -Path $drive
    }
}

# 3. 按类别整理文件（仅在E盘创建分类文件夹示例）
Write-Log "`n[3/4] 创建规范目录结构..." "Cyan"

$categoryFolders = @{
    "01-Software" = @("*.exe", "*.msi", "*.zip", "*.rar", "*.7z", "*.iso")
    "02-Documents" = @("*.pdf", "*.doc", "*.docx", "*.xls", "*.xlsx", "*.ppt", "*.pptx", "*.txt")
    "03-Images" = @("*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp", "*.psd", "*.ai")
    "04-Videos" = @("*.mp3", "*.mp4", "*.avi", "*.mkv", "*.wma", "*.wav", "*.ncm")
    "05-Design" = @("*.pds", "*.crf", "*.dl", "*.dwg")
    "06-Backup" = @("*.wim", "*.dat", "*.db", "*.bin")
    "99-Others" = @()
}

# 在E盘创建分类文件夹
$organizeRoot = "E:\已整理文件"
if (-not $WhatIf) {
    New-Item -ItemType Directory -Path $organizeRoot -Force -ErrorAction SilentlyContinue | Out-Null
    foreach ($folder in $categoryFolders.Keys) {
        New-Item -ItemType Directory -Path "$organizeRoot\$folder" -Force -ErrorAction SilentlyContinue | Out-Null
    }
}
Write-Log "  已在 $organizeRoot 创建分类文件夹" "Green"

# 4. 统计重复文件（大文件）
Write-Log "`n[4/4] 扫描大文件和潜在重复文件..." "Cyan"
$largeFiles = @()
foreach ($drive in $drives) {
    if (Test-Path $drive) {
        $largeFiles += Get-ChildItem -Path $drive -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 100MB } |
            Select-Object @{N='Path';E={$_.FullName}}, @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}}, Extension |
            Sort-Object SizeMB -Descending |
            Select-Object -First 20
    }
}

if ($largeFiles.Count -gt 0) {
    Write-Log "  发现 $($largeFiles.Count) 个大于100MB的文件:" "Yellow"
    $largeFiles | ForEach-Object { Write-Log "    $($_.Path) - $($_.SizeMB) MB" "Gray" }
}

# ==================== 总结 ====================
Write-Log "`n========== 整理完成 ==========" "Cyan"
Write-Log "删除文件数: $($Summary.DeletedFiles)" "Green"
Write-Log "释放空间: $([math]::Round($Summary.DeletedSizeMB, 2)) MB" "Green"
Write-Log "删除空文件夹: $($Summary.EmptyFoldersRemoved)" "Green"
Write-Log "日志保存至: $LogFile" "Gray"

# 生成整理建议
Write-Log "`n========== 整理建议 ==========" "Cyan"
Write-Log "1. E盘: 主要是软件安装文件，建议保留常用软件安装包，删除旧版本" "Yellow"
Write-Log "2. F盘: 微信数据，.fuk文件为微信加密数据谨慎处理" "Yellow"
Write-Log "3. G盘: 大量.bmp设计文件(8.9GB)，建议转换为.jpg节省空间" "Yellow"
Write-Log "4. H盘: 音乐文件(约17GB)，.ncm为网易云加密格式，.dat为缓存可清理" "Yellow"
