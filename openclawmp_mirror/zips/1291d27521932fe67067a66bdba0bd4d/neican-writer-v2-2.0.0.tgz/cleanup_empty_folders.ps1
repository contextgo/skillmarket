# 删除所有盘符中的空文件夹
# 安全模式：只删除完全为空的文件夹

$drives = @('E:\', 'F:\', 'G:\', 'H:\')
$deletedCount = 0
$failedCount = 0
$logFile = "$env:USERPROFILE\.stepclaw\workspace\deleted_folders_log.txt"

"=== 空文件夹删除日志 - $(Get-Date) ===" | Out-File -FilePath $logFile -Encoding UTF8

foreach ($drive in $drives) {
    if (-not (Test-Path $drive)) {
        Write-Host "跳过不存在的盘符: $drive" -ForegroundColor Yellow
        continue
    }
    
    Write-Host "正在扫描盘符: $drive" -ForegroundColor Cyan
    
    # 获取所有空文件夹（从深层开始，避免删除父文件夹后无法访问子文件夹的问题）
    $emptyDirs = Get-ChildItem -Path $drive -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { 
            $files = Get-ChildItem -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            ($files | Measure-Object).Count -eq 0 
        } | 
        Sort-Object FullName -Descending  # 从深层开始删除
    
    Write-Host "  在 $drive 发现 $($emptyDirs.Count) 个空文件夹" -ForegroundColor Yellow
    
    foreach ($dir in $emptyDirs) {
        try {
            # 再次确认文件夹为空
            $contents = Get-ChildItem -Path $dir.FullName -Force -ErrorAction SilentlyContinue
            if (($contents | Measure-Object).Count -eq 0) {
                Remove-Item -Path $dir.FullName -Force -ErrorAction Stop
                $deletedCount++
                "[已删除] $($dir.FullName)" | Out-File -FilePath $logFile -Append -Encoding UTF8
                Write-Host "  ✓ 已删除: $($dir.FullName)" -ForegroundColor Green
            }
        }
        catch {
            $failedCount++
            "[失败] $($dir.FullName) - $($_.Exception.Message)" | Out-File -FilePath $logFile -Append -Encoding UTF8
            Write-Host "  ✗ 失败: $($dir.FullName)" -ForegroundColor Red
        }
    }
}

"`n=== 删除完成 ===" | Out-File -FilePath $logFile -Append -Encoding UTF8
"成功删除: $deletedCount 个" | Out-File -FilePath $logFile -Append -Encoding UTF8
"删除失败: $failedCount 个" | Out-File -FilePath $logFile -Append -Encoding UTF8

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "清理完成！" -ForegroundColor Green
Write-Host "成功删除: $deletedCount 个空文件夹" -ForegroundColor Green
Write-Host "删除失败: $failedCount 个" -ForegroundColor $(if ($failedCount -gt 0) { 'Red' } else { 'Green' })
Write-Host "日志已保存到: $logFile" -ForegroundColor Gray
