﻿# 重复文件查找与删除脚本
$start = Get-Date
Write-Host "========== 重复文件清理 ==========" -ForegroundColor Cyan
Write-Host "开始时间: $start" -ForegroundColor Gray

$drives = @('E:\','F:\','G:\','H:\')
$deletedCount = 0
$freedSpace = 0

# 按文件名+大小查找重复
Write-Host "`n[1/2] 扫描重复文件..." -ForegroundColor Yellow

$allFiles = @()
foreach($d in $drives){
    if(Test-Path $d){
        Write-Host "  扫描 $d..." -ForegroundColor Gray
        $allFiles += Get-ChildItem -Path $d -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 1MB } |
            Select-Object FullName, Name, Length, Directory,
                @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}},
                @{N='Key';E={"$($_.Name)|$($_.Length)"}}
    }
}

# 分组找重复
$dupGroups = $allFiles | Group-Object Key | Where-Object { $_.Count -gt 1 }
Write-Host "  发现 $($dupGroups.Count) 组重复文件" -ForegroundColor Yellow

# 删除重复（保留第一个）
Write-Host "`n[2/2] 删除重复文件..." -ForegroundColor Yellow
foreach($group in $dupGroups){
    $items = $group.Group | Sort-Object FullName
    $keep = $items[0]
    Write-Host "`n  保留: $($keep.FullName) ($($keep.SizeMB) MB)" -ForegroundColor Green
    
    for($i=1; $i -lt $items.Count; $i++){
        $item = $items[$i]
        Write-Host "  删除: $($item.FullName) ($($item.SizeMB) MB)" -ForegroundColor Red
        try {
            Remove-Item $item.FullName -Force -ErrorAction Stop
            $deletedCount++
            $freedSpace += $item.SizeMB
        } catch {
            Write-Host "  失败: $_" -ForegroundColor DarkRed
        }
    }
}

# 完成
$end = Get-Date
$duration = $end - $start
Write-Host "`n========== 完成 ==========" -ForegroundColor Cyan
Write-Host "重复文件删除: $deletedCount 个" -ForegroundColor Green
Write-Host "释放空间: $([math]::Round($freedSpace,2)) MB ($([math]::Round($freedSpace/1024,2)) GB)" -ForegroundColor Green
Write-Host "耗时: $($duration.Minutes)分 $($duration.Seconds)秒" -ForegroundColor Yellow
