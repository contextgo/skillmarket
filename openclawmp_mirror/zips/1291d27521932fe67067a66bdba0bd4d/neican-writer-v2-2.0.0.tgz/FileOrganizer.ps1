# ============================================
# 文件整理脚本 - 删除空文件夹 + 智能分类移动
# 作者: AI Assistant
# 功能: 自动清理空文件夹，按文件类型整理到不同目录
# ============================================

param(
    [string]$TargetPath = "E:\",           # 要整理的根目录
    [string]$OrganizedPath = "E:\Organized",  # 整理后的存放位置
    [switch]$WhatIf = $false,              # 预览模式（不实际执行）
    [switch]$IncludeSubfolders = $true     # 是否包含子文件夹
)

# 配置：文件类型分类映射
$FileCategories = @{
    "01-软件安装包" = @("*.exe", "*.msi", "*.zip", "*.rar", "*.7z", "*.iso", "*.dmg")
    "02-文档资料"   = @("*.pdf", "*.doc", "*.docx", "*.xls", "*.xlsx", "*.ppt", "*.pptx", "*.txt", "*.rtf", "*.csv")
    "03-图片素材"   = @("*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp", "*.psd", "*.ai", "*.svg", "*.ico", "*.webp")
    "04-音视频"     = @("*.mp3", "*.mp4", "*.avi", "*.mkv", "*.mov", "*.wmv", "*.flv", "*.wma", "*.wav", "*.aac", "*.ncm")
    "05-设计文件"   = @("*.psd", "*.ai", "*.sketch", "*.fig", "*.xd", "*.dwg", "*.max", "*.blend")
    "06-代码文件"   = @("*.py", "*.js", "*.html", "*.css", "*.java", "*.cpp", "*.c", "*.h", "*.cs", "*.php", "*.go", "*.rs")
    "07-数据备份"   = @("*.bak", "*.backup", "*.wim", "*.gho", "*.tib", "*.dat", "*.db", "*.sql")
    "08-电子书"     = @("*.epub", "*.mobi", "*.azw3", "*.pdf")
    "99-其他"       = @("*")  # 其他未分类的文件
}

# 排除的目录（不处理这些系统/程序目录）
$ExcludePaths = @(
    "*Program Files*"
    "*ProgramData*"
    "*Windows*"
    "*System32*"
    "*Organized*"
    "*.git*"
    "*node_modules*"
)

# 统计变量
$Stats = @{
    EmptyFoldersRemoved = 0
    FilesMoved = 0
    TotalSizeMoved = 0
    Errors = 0
}

# ============================================
# 函数定义
# ============================================

function Write-Log($Message, $Color = "White", $Level = "INFO") {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] [$Level] $Message"
    Write-Host $logLine -ForegroundColor $Color
    
    # 同时写入日志文件
    $logFile = Join-Path $OrganizedPath "organize_log_$(Get-Date -Format 'yyyyMMdd').txt"
    $logLine | Out-File -FilePath $logFile -Append -Encoding UTF8 -ErrorAction SilentlyContinue
}

function Test-ShouldExclude($Path) {
    foreach ($pattern in $ExcludePaths) {
        if ($Path -like $pattern) { return $true }
    }
    return $false
}

function Get-FileCategory($File) {
    $ext = $File.Extension.ToLower()
    foreach ($category in $FileCategories.GetEnumerator()) {
        if ($category.Key -eq "99-其他") { continue }
        foreach ($pattern in $category.Value) {
            $patternExt = $pattern.Replace("*", "")
            if ($ext -eq $patternExt) {
                return $category.Key
            }
        }
    }
    return "99-其他"
}

function Remove-EmptyFolders($Path) {
    $folders = Get-ChildItem -Path $Path -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { -not (Test-ShouldExclude $_.FullName) } |
        Sort-Object FullName -Descending
    
    foreach ($folder in $folders) {
        try {
            # 检查文件夹是否为空（包括隐藏文件）
            $items = Get-ChildItem -Path $folder.FullName -Force -ErrorAction SilentlyContinue
            if ($items.Count -eq 0) {
                if (-not $WhatIf) {
                    Remove-Item -Path $folder.FullName -Force -ErrorAction Stop
                }
                Write-Log "删除空文件夹: $($folder.FullName)" "Green" "DELETE"
                $Stats.EmptyFoldersRemoved++
            }
        }
        catch {
            Write-Log "删除失败: $($folder.FullName) - $($_.Exception.Message)" "Red" "ERROR"
            $Stats.Errors++
        }
    }
}

function Move-FilesByCategory($Path) {
    # 获取所有文件
    $files = Get-ChildItem -Path $Path -File -Recurse:$IncludeSubfolders -ErrorAction SilentlyContinue | 
        Where-Object { -not (Test-ShouldExclude $_.DirectoryName) }
    
    Write-Log "发现 $($files.Count) 个文件需要整理" "Cyan" "INFO"
    
    foreach ($file in $files) {
        $category = Get-FileCategory $file
        $destFolder = Join-Path $OrganizedPath $category
        
        # 创建目标目录
        if (-not (Test-Path $destFolder)) {
            if (-not $WhatIf) {
                New-Item -ItemType Directory -Path $destFolder -Force | Out-Null
            }
            Write-Log "创建目录: $destFolder" "Gray" "MKDIR"
        }
        
        # 生成目标路径
        $destPath = Join-Path $destFolder $file.Name
        $counter = 1
        while (Test-Path $destPath) {
            $newName = "$($file.BaseName)_$($counter.ToString().PadLeft(3, '0'))$($file.Extension)"
            $destPath = Join-Path $destFolder $newName
            $counter++
        }
        
        # 移动文件
        try {
            $sizeMB = [math]::Round($file.Length / 1MB, 2)
            if (-not $WhatIf) {
                Move-Item -Path $file.FullName -Destination $destPath -Force -ErrorAction Stop
            }
            Write-Log "移动: [$category] $($file.Name) (${sizeMB} MB)" "Green" "MOVE"
            $Stats.FilesMoved++
            $Stats.TotalSizeMoved += $sizeMB
        }
        catch {
            Write-Log "移动失败: $($file.Name) - $($_.Exception.Message)" "Red" "ERROR"
            $Stats.Errors++
        }
    }
}

function Show-Summary() {
    Write-Log "`n========================================" "Cyan" "SUMMARY"
    Write-Log "文件整理完成！" "Green" "SUMMARY"
    Write-Log "========================================" "Cyan" "SUMMARY"
    Write-Log "空文件夹删除: $($Stats.EmptyFoldersRemoved) 个" "White" "SUMMARY"
    Write-Log "文件移动: $($Stats.FilesMoved) 个" "White" "SUMMARY"
    Write-Log "总大小: $([math]::Round($Stats.TotalSizeMoved, 2)) MB ($([math]::Round($Stats.TotalSizeMoved/1024, 2)) GB)" "White" "SUMMARY"
    Write-Log "错误: $($Stats.Errors) 个" $(if($Stats.Errors -gt 0){"Red"}else{"Green"}) "SUMMARY"
    
    if ($WhatIf) {
        Write-Log "`n⚠️  这是预览模式，没有实际执行任何操作" "Yellow" "WARN"
        Write-Log "    要实际执行，请去掉 -WhatIf 参数" "Yellow" "WARN"
    }
    
    Write-Log "`n整理后的文件位置: $OrganizedPath" "Cyan" "INFO"
}

# ============================================
# 主程序
# ============================================

Write-Log "========== 文件整理脚本启动 ==========" "Cyan" "START"
Write-Log "目标目录: $TargetPath" "Gray" "CONFIG"
Write-Log "整理位置: $OrganizedPath" "Gray" "CONFIG"
Write-Log "预览模式: $WhatIf" "Gray" "CONFIG"

# 检查目标路径
if (-not (Test-Path $TargetPath)) {
    Write-Log "错误: 目标路径不存在 - $TargetPath" "Red" "ERROR"
    exit 1
}

# 创建整理根目录
if (-not (Test-Path $OrganizedPath)) {
    New-Item -ItemType Directory -Path $OrganizedPath -Force | Out-Null
    Write-Log "创建整理根目录: $OrganizedPath" "Green" "MKDIR"
}

# 步骤1: 删除空文件夹
Write-Log "`n[步骤 1/2] 删除空文件夹..." "Yellow" "STEP"
Remove-EmptyFolders -Path $TargetPath

# 步骤2: 按类别移动文件
Write-Log "`n[步骤 2/2] 按类别整理文件..." "Yellow" "STEP"
Move-FilesByCategory -Path $TargetPath

# 显示总结
Show-Summary

Write-Log "`n脚本执行完毕！" "Green" "DONE"
