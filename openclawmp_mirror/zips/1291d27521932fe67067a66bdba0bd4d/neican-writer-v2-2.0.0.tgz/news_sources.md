# 📰 文教授 — 新闻信息源清单

> 最后更新：2026-03-22

## 一、中央主要媒体

| 媒体 | 网址 | RSS/抓取 |
|------|------|----------|
| 新华社 | https://www.xinhuanet.com | ✅ |
| 人民日报 | https://www.people.com.cn | ✅ |
| 中央广播电视总台 | https://www.cctv.com | ✅ |
| 求是杂志 | https://www.qstheory.cn | ✅ |
| 光明日报 | https://www.gmw.cn | ✅ |
| 经济日报 | https://www.ce.cn | ✅ |
| 中国日报 | https://www.chinadaily.com.cn | ✅ |
| 解放军新闻传播中心 | https://www.81.cn | ✅ |

## 二、中央重点新闻网站

| 媒体 | 网址 | RSS/抓取 |
|------|------|----------|
| 人民网 | https://www.people.com.cn | ✅ |
| 新华网 | https://www.xinhuanet.com | ✅ |
| 央视网 | https://www.cctv.com | ✅ |
| 中国网 | https://www.china.com.cn | ✅ |
| 国际在线 | https://www.cri.cn | ✅ |
| 中国日报网 | https://www.chinadaily.com.cn | ✅ |
| 央广网 | https://www.cnr.cn | ✅ |
| 中国青年网 | https://www.youth.cn | ✅ |
| 光明网 | https://www.gmw.cn | ✅ |
| 中国经济网 | https://www.ce.cn | ✅ |
| 中国新闻网 | https://www.chinanews.com.cn | ✅ |
| 法治网 | https://www.legaldaily.com.cn | ✅ |
| 中青在线 | https://www.cyol.com | ✅ |
| 未来网 | https://www.k618.cn | ✅ |
| 环球网 | https://www.huanqiu.com | ✅ |
| 求是网 | https://www.qstheory.cn | ✅ |

## 三、行业/专业报刊

| 媒体 | 网址 | RSS/抓取 |
|------|------|----------|
| 工人日报 | https://www.workercn.cn | ✅ |
| 中国妇女报 | https://www.cnwomen.com.cn | ✅ |
| 科技日报 | https://www.stdaily.com | ✅ |
| 人民政协报 | https://www.rmzxb.com.cn | ✅ |

## 四、省级媒体（31省市自治区）

### 北京
| 媒体 | 网址 |
|------|------|
| 北京日报 | https://www.bjd.com.cn |
| 新京报 | https://www.bjnews.com.cn |
| 北京青年报 | https://www.ynet.com |
| 北京时间 | https://www.btime.com |
| 千龙网 | https://www.qianlong.com |
| 新京报网 | https://www.bjnews.com.cn |
| 北青网 | https://www.ynet.com |

### 天津
| 媒体 | 网址 |
|------|------|
| 天津日报 | https://www.tjrb.com.cn |
| 津云新闻 | https://www.津云.com |
| 天津日报客户端 | - |

### 河北
| 媒体 | 网址 |
|------|------|
| 河北日报 | https://www.hebnews.cn |
| 冀时客户端 | - |
| 长城网 | https://www.hebei.com.cn |

### 山西
| 媒体 | 网址 |
|------|------|
| 山西日报 | https://www.sxrb.com |
| 黄河plus | - |
| 山西新闻网 | https://www.sxnews.cn |

### 内蒙古
| 媒体 | 网址 |
|------|------|
| 内蒙古日报 | https://www.northnews.cn |
| 奔腾融媒 | - |
| 正北方网 | https://www.northnews.cn |

### 辽宁
| 媒体 | 网址 |
|------|------|
| 辽宁日报 | https://www.lnd.com.cn |
| 北斗融媒 | - |
| 北国网 | https://www.lnd.com.cn |

### 吉林
| 媒体 | 网址 |
|------|------|
| 吉林日报 | https://www.jlrb.cn |
| 吉祥新闻 | - |
| 中国吉林网 | https://www.cnjiwang.com |

### 黑龙江
| 媒体 | 网址 |
|------|------|
| 黑龙江日报 | https://www.hljnews.cn |
| 极光新闻 | - |
| 东北网 | https://www.dbw.cn |

### 上海
| 媒体 | 网址 |
|------|------|
| 解放日报 | https://www.jfdaily.com |
| 文汇报 | https://www.whb.cn |
| 澎湃新闻 | https://www.thepaper.cn |
| 上观新闻 | https://www.shobserver.com |
| 东方网 | https://www.eastday.com |
| 看看新闻Knews | https://www.kankanews.com |

### 江苏
| 媒体 | 网址 |
|------|------|
| 新华日报 | https://www.xhby.net |
| 扬子晚报 | https://www.yangtse.com |
| 现代快报 | https://www.xdkb.net |
| 荔枝新闻 | https://www.jstv.com |
| 我苏网 | https://www.ourjiangsu.com |
| 中国江苏网 | https://www.jschina.com.cn |
| 新华报业网 | https://www.xhby.net |

### 浙江
| 媒体 | 网址 |
|------|------|
| 浙江日报 | https://www.zjol.com.cn |
| 钱江晚报 | https://www.qjwb.com.cn |
| 中国蓝新闻 | https://www.cztv.com |
| 浙江在线 | https://www.zjol.com.cn |
| 小时新闻 | - |

### 安徽
| 媒体 | 网址 |
|------|------|
| 安徽日报 | https://www.ahnews.com.cn |
| 安徽视讯 | - |
| 中安在线 | https://www.anhuinews.com |

### 福建
| 媒体 | 网址 |
|------|------|
| 福建日报 | https://www.fjdaily.com |
| 海博TV | - |
| 新福建 | - |
| 东南网 | https://www.fjsen.com |

### 江西
| 媒体 | 网址 |
|------|------|
| 江西日报 | https://www.jxnews.com.cn |
| 今视频 | - |
| 中国江西网 | https://www.jxnews.com.cn |

### 山东
| 媒体 | 网址 |
|------|------|
| 大众日报 | https://www.dzwww.com |
| 齐鲁晚报 | https://www.qlwb.com.cn |
| 闪电新闻 | https://www.iqilu.com |
| 大众网 | https://www.dzwww.com |
| 齐鲁网 | https://www.iqilu.com |

### 河南
| 媒体 | 网址 |
|------|------|
| 河南日报 | https://www.henandaily.cn |
| 大河报 | https://www.dahebao.cn |
| 大象新闻 | - |
| 大河网 | https://www.dahe.cn |
| 顶端新闻 | - |

### 湖北
| 媒体 | 网址 |
|------|------|
| 湖北日报 | https://www.hubeidaily.net |
| 楚天都市报 | https://www.ctdsb.net |
| 长江云 | https://www.hbtv.com.cn |
| 荆楚网 | https://www.cnhubei.com |
| 极目新闻 | https://www.ctdsb.net |

### 湖南
| 媒体 | 网址 |
|------|------|
| 湖南日报 | https://www.hnrb.cn |
| 潇湘晨报 | https://www.xxcb.cn |
| 芒果TV | https://www.mgtv.com |
| 红网 | https://www.rednet.cn |
| 华声在线 | https://www.voc.com.cn |

### 广东
| 媒体 | 网址 |
|------|------|
| 南方日报 | https://www.southcn.com |
| 广州日报 | https://www.gzdaily.cn |
| 南方都市报 | https://www.oeeee.com |
| 南方+ | https://www.southcn.com |
| 粤TV | - |
| 触电新闻 | - |
| N视频 | - |

### 广西
| 媒体 | 网址 |
|------|------|
| 广西日报 | https://www.gxnews.com.cn |
| 南国早报 | https://www.ngzb.com.cn |
| 广西视听 | - |
| 广西新闻网 | https://www.gxnews.com.cn |

### 海南
| 媒体 | 网址 |
|------|------|
| 海南日报 | https://www.hinews.cn |
| 视听海南 | - |
| 南海网 | https://www.hinews.cn |

### 重庆
| 媒体 | 网址 |
|------|------|
| 重庆日报 | https://www.cqrb.cn |
| 华龙网 | https://www.cqnews.net |
| 第1眼新闻 | - |
| 重庆日报客户端 | - |

### 四川
| 媒体 | 网址 |
|------|------|
| 四川日报 | https://www.scdaily.cn |
| 华西都市报 | https://www.huaxi100.com |
| 四川观察 | - |
| 川观新闻 | https://www.cbgc.scol.com.cn |
| 封面新闻 | https://www.thecover.cn |

### 贵州
| 媒体 | 网址 |
|------|------|
| 贵州日报 | https://www.gzrb.cn |
| 动静新闻 | - |
| 多彩贵州网 | https://www.gog.cn |

### 云南
| 媒体 | 网址 |
|------|------|
| 云南日报 | https://www.yndaily.com |
| 七彩云端 | - |
| 云南网 | https://www.yunnan.cn |

### 西藏
| 媒体 | 网址 |
|------|------|
| 西藏日报 | https://www.xzxw.com |
| 珠峰云 | - |
| 中国西藏新闻网 | https://www.xzxw.com |

### 陕西
| 媒体 | 网址 |
|------|------|
| 陕西日报 | https://www.sxdaily.com.cn |
| 起点新闻 | - |
| 群众新闻网 | https://www.sxdaily.com.cn |

### 甘肃
| 媒体 | 网址 |
|------|------|
| 甘肃日报 | https://www.gansudaily.com.cn |
| 视听甘肃 | - |
| 每日甘肃网 | https://www.gansudaily.com.cn |

### 青海
| 媒体 | 网址 |
|------|------|
| 青海日报 | https://www.qhnews.com |
| 三江源 | - |
| 青海新闻网 | https://www.qhnews.com |

### 宁夏
| 媒体 | 网址 |
|------|------|
| 宁夏日报 | https://www.nxnews.net |
| 黄河云视 | - |
| 宁夏新闻网 | https://www.nxnews.net |

### 新疆
| 媒体 | 网址 |
|------|------|
| 新疆日报 | https://www.xjdaily.com |
| 丝路视听 | - |
| 新疆日报网 | https://www.xjdaily.com |

## 五、民主党派中央官网

| 党派 | 官网 | 重点栏目 |
|------|------|----------|
| 中国国民党革命委员会（民革） | https://www.minge.gov.cn | 参政议政、社情民意 |
| 中国民主同盟（民盟） | https://www.mmzy.org.cn | 参政议政、建言献策 |
| 中国民主建国会（民建） | https://www.cndca.org.cn | 参政议政、调研报告 |
| 中国民主促进会（民进） | https://www.mj.org.cn | 参政议政、社情民意 |
| 中国农工民主党（农工党） | https://www.ngd.org.cn | 参政议政、建言献策 |
| 中国致公党（致公党） | https://www.zg.org.cn | 参政议政、海外联络 |
| 九三学社 | https://www.93.gov.cn | 参政议政、科技建言 |
| 台湾民主自治同盟（台盟） | https://www.taimeng.org.cn | 参政议政、涉台建言 |

## 六、全国及省级政协

### 全国政协
| 单位 | 官网 | 重点栏目 |
|------|------|----------|
| 全国政协 | https://www.cppcc.gov.cn | 提案工作、建言资政、协商议政 |
| 人民政协报 | https://www.rmzxb.com.cn | 建言、议政、专题调研 |
| 人民政协网 | https://www.rmzxb.com.cn | 委员建言、提案追踪 |

### 省级政协
| 省份 | 政协官网 |
|------|----------|
| 北京市政协 | http://www.bjzx.gov.cn |
| 天津市政协 | http://www.tjszx.gov.cn |
| 河北省政协 | http://www.hebzx.gov.cn |
| 山西省政协 | http://www.sxzx.gov.cn |
| 内蒙古自治区政协 | http://www.nmgzx.gov.cn |
| 辽宁省政协 | http://www.lnzx.gov.cn |
| 吉林省政协 | http://www.jlzx.gov.cn |
| 黑龙江省政协 | http://www.hljzx.gov.cn |
| 上海市政协 | http://www.shszx.gov.cn |
| 江苏省政协 | http://www.jszx.gov.cn |
| 浙江省政协 | http://www.zjzx.gov.cn |
| 安徽省政协 | http://www.ahzx.gov.cn |
| 福建省政协 | http://www.fjzx.gov.cn |
| 江西省政协 | http://www.jxzx.gov.cn |
| 山东省政协 | http://www.sdzx.gov.cn |
| 河南省政协 | http://www.hnzx.gov.cn |
| 湖北省政协 | http://www.hbzx.gov.cn |
| 湖南省政协 | http://www.hnzx.gov.cn |
| 广东省政协 | http://www.gdzx.gov.cn |
| 广西壮族自治区政协 | http://www.gxzx.gov.cn |
| 海南省政协 | http://www.hnzx.gov.cn |
| 重庆市政协 | http://www.cqzx.gov.cn |
| 四川省政协 | http://www.sczx.gov.cn |
| 贵州省政协 | http://www.gzzx.gov.cn |
| 云南省政协 | http://www.ynzx.gov.cn |
| 西藏自治区政协 | http://www.xzzx.gov.cn |
| 陕西省政协 | http://www.sxzx.gov.cn |
| 甘肃省政协 | http://www.gszx.gov.cn |
| 青海省政协 | http://www.qhzx.gov.cn |
| 宁夏回族自治区政协 | http://www.nxzx.gov.cn |
| 新疆维吾尔自治区政协 | http://www.xjzx.gov.cn |

## 七、商业/市场化媒体

| 媒体 | 网址 |
|------|------|
| 界面新闻 | https://www.jiemian.com |

## 五、国际通讯社

| 媒体 | 网址 | 语言 |
|------|------|------|
| 路透社 | https://www.reuters.com | EN |
| 美联社 | https://apnews.com | EN |
| 法新社 | https://www.france24.com | EN/FR |
| 合众国际社 | https://www.upi.com | EN |
| 塔斯社 | https://tass.com | EN/RU |

## 六、国际主流报刊

| 媒体 | 网址 | 类型 |
|------|------|------|
| 纽约时报 | https://www.nytimes.com | 综合 |
| 华尔街日报 | https://www.wsj.com | 财经 |
| 金融时报 | https://www.ft.com | 财经 |
| 华盛顿邮报 | https://www.washingtonpost.com | 综合 |
| 泰晤士报 | https://www.thetimes.co.uk | 综合 |
| 卫报 | https://www.theguardian.com | 综合 |
| 南华早报 | https://www.scmp.com | 亚太 |
| 时代周刊 | https://time.com | 综合 |
| 经济学人 | https://www.economist.com | 财经 |
| 福布斯 | https://www.forbes.com | 商业 |
| 财富 | https://fortune.com | 商业 |

## 七、国际广播/电视

| 媒体 | 网址 | 类型 |
|------|------|------|
| BBC News | https://www.bbc.com/news | 综合 |
| CNN | https://www.cnn.com | 综合 |
| 半岛电视台 | https://www.aljazeera.com | 综合 |
| 美国之音 | https://www.voanews.com | 综合 |
| 德国之声 | https://www.dw.com | 综合 |
| 法国国际广播电台 | https://www.rfi.fr/en | 综合 |
| NHK | https://www3.nhk.or.jp/nhkworld | 综合 |

## 八、财经/科技专业

| 媒体 | 网址 | 类型 |
|------|------|------|
| 彭博社 | https://www.bloomberg.com | 财经 |
| Axios | https://www.axios.com | 科技/政策 |

## 九、国务院各部委官网

| 部委 | 官网 | 重点栏目 |
|------|------|----------|
| 国务院办公厅 | https://www.gov.cn | 政策文件、国务院公报 |
| 国家发展和改革委员会 | https://www.ndrc.gov.cn | 政策发布、发展规划、价格监测 |
| 工业和信息化部 | https://www.miit.gov.cn | 产业政策、运行监测、技术创新 |
| 财政部 | https://www.mof.gov.cn | 财政政策、预算决算、税收政策 |
| 人力资源和社会保障部 | https://www.mohrss.gov.cn | 就业政策、社会保障、劳动关系 |
| 自然资源部 | https://www.mnr.gov.cn | 国土规划、矿产资源、海洋管理 |
| 生态环境部 | https://www.mee.gov.cn | 环境政策、污染防治、生态保护 |
| 住房和城乡建设部 | https://www.mohurd.gov.cn | 住房政策、城市建设、村镇建设 |
| 交通运输部 | https://www.mot.gov.cn | 交通规划、运输管理、基础设施 |
| 水利部 | https://www.mwr.gov.cn | 水资源管理、防汛抗旱、水利建设 |
| 农业农村部 | https://www.moa.gov.cn | 农业政策、乡村振兴、粮食安全 |
| 商务部 | https://www.mofcom.gov.cn | 商贸流通、外资外贸、市场运行 |
| 文化和旅游部 | https://www.mct.gov.cn | 文化产业、旅游市场、公共文化 |
| 国家卫生健康委员会 | https://www.nhc.gov.cn | 医疗卫生、公共卫生、健康政策 |
| 应急管理部 | https://www.mem.gov.cn | 安全生产、防灾减灾、应急救援 |
| 中国人民银行 | http://www.pbc.gov.cn | 货币政策、金融稳定、金融市场 |
| 审计署 | https://www.audit.gov.cn | 审计结果、政策落实、整改公告 |
| 国务院国有资产监督管理委员会 | http://www.sasac.gov.cn | 国企改革、央企动态、国资监管 |
| 海关总署 | http://www.customs.gov.cn | 进出口数据、贸易统计、关税政策 |
| 国家税务总局 | https://www.chinatax.gov.cn | 税收政策、征管改革、税收优惠 |
| 国家市场监督管理总局 | https://www.samr.gov.cn | 市场监管、反垄断、食品药品安全 |
| 国家广播电视总局 | http://www.nrta.gov.cn | 传媒政策、内容监管、产业发展 |
| 国家体育总局 | https://www.sport.gov.cn | 体育政策、群众体育、竞技体育 |
| 国家统计局 | https://www.stats.gov.cn | 统计数据、统计公报、数据解读 |
| 国家医疗保障局 | https://www.nhsa.gov.cn | 医保政策、药品集采、基金监管 |
| 国家能源局 | http://www.nea.gov.cn | 能源规划、电力监管、新能源政策 |
| 国家数据局 | - | 数据要素、数字治理、数据安全 |
| 国家国防科技工业局 | - | 国防科技、军工产业、军民融合 |
| 国家移民管理局 | https://www.nia.gov.cn | 出入境管理、边防检查、移民政策 |
| 国家林业和草原局 | http://www.forestry.gov.cn | 林业生态、草原保护、自然保护地 |
| 国家知识产权局 | https://www.cnipa.gov.cn | 专利审查、商标管理、知识产权保护 |
| 国家信访局 | https://www.gjxfj.gov.cn | 信访工作、社情民意、矛盾化解 |
| 国家粮食和物资储备局 | http://www.lswz.gov.cn | 粮食安全、物资储备、应急管理 |
| 国家烟草专卖局 | http://www.tobacco.gov.cn | 烟草监管、专卖管理、产业发展 |
| 国家矿山安全监察局 | - | 矿山安全、监察执法、事故预防 |
| 国家外汇管理局 | https://www.safe.gov.cn | 外汇管理、国际收支、汇率政策 |
| 国家药品监督管理局 | https://www.nmpa.gov.cn | 药品监管、医疗器械、化妆品监管 |
| 国家中医药管理局 | http://www.satcm.gov.cn | 中医药政策、传承创新、产业发展 |
| 国家疾病预防控制局 | - | 疾病预防、公共卫生、疫情防控 |
| 国家档案局 | - | 档案管理、档案开放、档案安全 |
| 国家保密局 | - | 保密管理、保密技术、保密检查 |
| 国家密码管理局 | - | 密码管理、密码技术、密码安全 |

## 十、国家级智库/研究机构

| 机构 | 官网/平台 | 重点领域 |
|------|-----------|----------|
| 国务院发展研究中心 | http://www.drc.gov.cn | 宏观经济、产业政策、区域发展 |
| 中国社会科学院 | http://www.cass.cn | 哲学社会科学全领域 |
| 中国科学院 | https://www.cas.cn | 自然科学、高新技术 |
| 中国工程院 | https://www.cae.cn | 工程技术、产业咨询 |
| 中央党校（国家行政学院） | http://www.ccps.gov.cn | 党建理论、公共管理 |
| 国家发展和改革委员会宏观经济研究院 | - | 宏观经济、发展战略 |
| 中国宏观经济研究院 | - | 经济预测、政策研究 |
| 中国国际经济交流中心 | http://www.cciee.org.cn | 国际经济、对外开放 |
| 中国（海南）改革发展研究院 | http://www.chinareform.org.cn | 改革开放、制度创新 |
| 中国财政科学研究院 | http://www.chineseafs.org | 财政税收、公共政策 |
| 工业和信息化部赛迪研究院 | http://www.ccidgroup.com | 信息产业、智能制造 |
| 商务部国际贸易经济合作研究院 | http://www.caitec.org.cn | 国际贸易、对外投资 |
| 生态环境部环境规划院 | http://www.caep.org.cn | 环境规划、污染防治 |
| 交通运输部科学研究院 | http://www.motcats.com.cn | 交通规划、运输经济 |
| 中国科学技术发展战略研究院 | - | 科技政策、创新战略 |
| 中国人口与发展研究中心 | - | 人口政策、老龄化 |
| 中国劳动和社会保障科学研究院 | - | 就业社保、劳动关系 |
| 中国城市规划设计研究院 | - | 城市规划、区域发展 |
| 中国农村发展研究中心 | - | 三农问题、乡村振兴 |
| 清华大学国情研究院 | - | 国情分析、公共政策 |
| 北京大学国家发展研究院 | https://www.nsd.pku.edu.cn | 经济发展、体制改革 |
| 中国人民大学国家发展与战略研究院 | - | 国家战略、社会治理 |
| 复旦大学中国研究院 | - | 中国道路、中国模式 |
| 上海交通大学安泰经济与管理学院 | - | 产业经济、企业管理 |
| 浙江大学公共政策研究院 | - | 公共政策、政府治理 |
| 武汉大学中国中部发展研究院 | - | 区域发展、中部崛起 |
| 中山大学粤港澳发展研究院 | - | 大湾区、区域合作 |
| 四川大学中国西部边疆安全与发展协同创新中心 | - | 边疆安全、民族问题 |
| 中国社科院世界经济与政治研究所 | - | 国际经济、全球治理 |
| 中国社科院工业经济研究所 | - | 产业政策、企业改革 |
| 中国社科院农村发展研究所 | - | 农业农村、乡村振兴 |
| 中国社科院人口与劳动经济研究所 | - | 人口政策、劳动就业 |
| 中国社科院城市与竞争力研究中心 | - | 城市发展、房地产 |
| 中国社科院生态文明研究所 | - | 生态文明、绿色发展 |
| 中国社科院边疆研究所 | - | 边疆治理、民族宗教 |
| 中国现代国际关系研究院 | - | 国际关系、国家安全 |
| 中国国际问题研究院 | - | 外交政策、国际安全 |

## 十一、行业协会/商会

| 协会 | 官网 | 重点领域 |
|------|------|----------|
| 中国钢铁工业协会 | http://www.chinaisa.org.cn | 钢铁行业、产能调控 |
| 中国汽车工业协会 | http://www.caam.org.cn | 汽车产业、新能源汽车 |
| 中国石油和化学工业联合会 | http://www.cpcia.org.cn | 石油化工、能源化工 |
| 中国电力企业联合会 | http://www.cec.org.cn | 电力行业、能源转型 |
| 中国煤炭工业协会 | http://www.coalchina.org.cn | 煤炭行业、清洁利用 |
| 中国有色金属工业协会 | http://www.chinania.org.cn | 有色金属、稀有金属 |
| 中国建筑材料联合会 | http://www.cbma.org.cn | 建材行业、绿色建筑 |
| 中国机械工业联合会 | http://www.cmif.org.cn | 机械制造、装备制造 |
| 中国电子信息行业联合会 | - | 电子信息、数字经济 |
| 中国纺织工业联合会 | http://www.cntac.org.cn | 纺织服装、产业升级 |
| 中国轻工业联合会 | http://www.clii.com.cn | 轻工行业、消费品 |
| 中国食品工业协会 | http://www.cnfia.cn | 食品工业、食品安全 |
| 中国医药企业管理协会 | - | 医药产业、药品监管 |
| 中国物流与采购联合会 | http://www.chinawuliu.com.cn | 物流行业、供应链 |
| 中国房地产业协会 | http://www.realestate.gov.cn | 房地产、住房保障 |
| 中国银行业协会 | http://www.china-cba.net | 银行业、金融监管 |
| 中国证券业协会 | http://www.sac.net.cn | 证券行业、资本市场 |
| 中国保险行业协会 | http://www.iachina.cn | 保险业、风险管理 |
| 中国国际贸易促进委员会 | http://www.ccpit.org | 对外贸易、投资促进 |
| 中国企业联合会 | http://www.cec-ceda.org.cn | 企业管理、企业家 |
| 中国企业家协会 | http://www.cec-ceda.org.cn | 企业家、企业创新 |
| 中国中小企业协会 | http://www.ca-sme.org | 中小企业、创业创新 |
| 中国民营经济研究会 | - | 民营经济、民营企业 |
| 中国互联网协会 | http://www.isc.org.cn | 互联网、数字经济 |
| 中国通信企业协会 | http://www.tace.org.cn | 通信行业、5G/6G |
| 中国软件行业协会 | http://www.csia.org.cn | 软件产业、信息技术 |
| 中国半导体行业协会 | - | 半导体、集成电路 |
| 中国人工智能学会 | http://www.caai.cn | 人工智能、智能产业 |
| 中国可再生能源学会 | http://www.cres.org.cn | 可再生能源、新能源 |
| 中国氢能联盟 | - | 氢能产业、燃料电池 |
| 中国电动汽车百人会 | - | 电动汽车、智能交通 |
| 中国光伏行业协会 | http://www.chinapv.org.cn | 光伏产业、新能源 |
| 中国风电协会 | - | 风电产业、清洁能源 |
| 中国核能行业协会 | http://www.china-nea.cn | 核能产业、核电安全 |
| 中国水利发电工程学会 | - | 水电、清洁能源 |
| 中国环境保护产业协会 | http://www.caepi.org.cn | 环保产业、污染治理 |
| 中国循环经济协会 | - | 循环经济、资源利用 |
| 中国安全生产协会 | - | 安全生产、应急管理 |
| 中国消防协会 | - | 消防安全、应急救援 |
| 中国地震学会 | - | 地震监测、防灾减灾 |
| 中国气象学会 | - | 气象服务、气候预测 |
| 中国测绘学会 | - | 测绘地理、空间信息 |
| 中国城市规划学会 | - | 城市规划、城市设计 |
| 中国建筑学会 | http://www.chinaasc.org | 建筑设计、建筑产业 |
| 中国土木工程学会 | - | 土木工程、基础设施 |
| 中国公路学会 | - | 公路交通、智能交通 |
| 中国铁道学会 | - | 铁路交通、高铁技术 |
| 中国航空学会 | - | 航空工业、航空运输 |
| 中国航海学会 | - | 航海运输、海洋经济 |
| 中国港口协会 | - | 港口物流、航运经济 |
| 中国船舶工业行业协会 | - | 船舶制造、海洋工程 |
| 中国航天科技集团 | - | 航天科技、卫星应用 |
| 中国兵器工业集团 | - | 兵器工业、军民融合 |
| 中国航空工业集团 | - | 航空工业、航空制造 |
| 中国船舶集团 | - | 船舶工业、海洋装备 |
| 中国中车集团 | - | 轨道交通、高铁装备 |
| 国家电网公司 | http://www.sgcc.com.cn | 电力供应、电网建设 |
| 南方电网公司 | http://www.csg.cn | 电力供应、区域电网 |
| 中国石油天然气集团 | http://www.cnpc.com.cn | 油气勘探、能源供应 |
| 中国石油化工集团 | http://www.sinopec.com | 石油化工、能源化工 |
| 中国海洋石油集团 | http://www.cnooc.com.cn | 海洋油气、能源开发 |
| 国家能源投资集团 | http://www.ceic.com | 煤炭电力、新能源 |
| 中国华能集团 | http://www.chng.com.cn | 电力生产、清洁能源 |
| 中国大唐集团 | http://www.china-cdt.com | 电力生产、能源供应 |
| 中国华电集团 | http://www.chd.com.cn | 电力生产、新能源 |
| 国家电力投资集团 | http://www.spic.com.cn | 电力投资、核电新能源 |
| 中国长江三峡集团 | http://www.ctg.com.cn | 水电开发、清洁能源 |
| 国家开发投资集团 | http://www.sdic.com.cn | 投资运营、战略性新兴产业 |
| 中国华润集团 | http://www.crc.com.cn | 多元化经营、民生服务 |

## 十二、学术期刊/数据库

| 平台/期刊 | 网址 | 类型 |
|-----------|------|------|
| 中国知网（CNKI） | https://www.cnki.net | 学术论文、期刊文献 |
| 万方数据 | https://www.wanfangdata.com.cn | 学术论文、专利标准 |
| 维普网 | http://www.cqvip.com | 期刊论文、文献检索 |
| 国家哲学社会科学文献中心 | https://www.ncpssd.org | 社科文献、免费下载 |
| 中国社会科学网 | http://www.cssn.cn | 社科研究、学术动态 |
| 科学网 | https://www.sciencenet.cn | 科技新闻、学术资讯 |
| 中国科学报 | https://www.sciencenet.cn/dz/ | 科技新闻、科研动态 |
| 经济研究 | - | 经济学顶级期刊 |
| 管理世界 | - | 管理学顶级期刊 |
| 中国工业经济 | - | 产业经济权威期刊 |
| 世界经济 | - | 国际经济研究 |
| 金融研究 | - | 金融学研究 |
| 中国农村经济 | - | 三农问题研究 |
| 中国人口科学 | - | 人口问题研究 |
| 社会学研究 | - | 社会学研究 |
| 政治学研究 | - | 政治学研究 |
| 法学研究 | - | 法学研究 |
| 中国法学 | - | 法学研究 |
| 历史研究 | - | 历史学研究 |
| 求是 | http://www.qstheory.cn/qs/ | 中央理论刊物 |
| 红旗文稿 | http://www.qstheory.cn/hongqi/ | 理论宣传 |
| 中共党史研究 | - | 党史研究 |
| 党的文献 | - | 党史文献 |
| 中国行政管理 | - | 行政管理研究 |
| 公共管理学报 | - | 公共管理研究 |
| 城市规划 | - | 城市规划研究 |
| 中国软科学 | - | 软科学研究 |
| 科研管理 | - | 科技管理研究 |
| 科学学研究 | - | 科学学研究 |
| 自然辩证法研究 | - | 科技哲学 |
| 中国科技论坛 | - | 科技政策 |
| 中国科学院院刊 | - | 院士观点、科技前沿 |
| 中国工程院院刊（Engineering） | - | 工程技术 |
| 中国工程科学 | - | 工程科技 |
| 新华文摘 | - | 综合性学术文摘 |
| 人大复印报刊资料 | - | 学术文摘、专题研究 |

## 十三、地方重要媒体（补充）

### 计划单列市/副省级城市
| 城市 | 媒体 |
|------|------|
| 深圳 | 深圳特区报、深圳商报、晶报、深圳新闻网 |
| 厦门 | 厦门日报、厦门晚报、海西晨报 |
| 宁波 | 宁波日报、宁波晚报、东南商报 |
| 青岛 | 青岛日报、青岛晚报、半岛都市报 |
| 大连 | 大连日报、大连晚报、半岛晨报 |
| 沈阳 | 沈阳日报、沈阳晚报、辽沈晚报 |
| 长春 | 长春日报、长春晚报、城市晚报 |
| 哈尔滨 | 哈尔滨日报、新晚报、生活报 |
| 南京 | 南京日报、金陵晚报、扬子晚报 |
| 杭州 | 杭州日报、都市快报、钱江晚报 |
| 济南 | 济南日报、济南时报、舜网 |
| 武汉 | 长江日报、武汉晚报、楚天都市报 |
| 广州 | 广州日报、羊城晚报、新快报 |
| 成都 | 成都日报、成都商报、华西都市报 |
| 西安 | 西安日报、西安晚报、华商报 |

### 重要省会城市
| 城市 | 媒体 |
|------|------|
| 石家庄 | 石家庄日报、燕赵晚报、燕赵都市报 |
| 太原 | 太原日报、太原晚报、山西晚报 |
| 呼和浩特 | 呼和浩特日报、呼和浩特晚报、北方新报 |
| 合肥 | 合肥日报、合肥晚报、新安晚报 |
| 福州 | 福州日报、福州晚报、海峡都市报 |
| 南昌 | 南昌日报、南昌晚报、江南都市报 |
| 郑州 | 郑州日报、郑州晚报、大河报 |
| 长沙 | 长沙晚报、潇湘晨报、三湘都市报 |
| 南宁 | 南宁日报、南宁晚报、南国早报 |
| 海口 | 海口日报、海口晚报、南国都市报 |
| 贵阳 | 贵阳日报、贵阳晚报、贵州都市报 |
| 昆明 | 昆明日报、昆明晚报、春城晚报 |
| 拉萨 | 西藏日报、西藏商报、拉萨晚报 |
| 兰州 | 兰州日报、兰州晚报、西部商报 |
| 西宁 | 西宁晚报、西海都市报 |
| 银川 | 银川日报、银川晚报、新消息报 |
| 乌鲁木齐 | 新疆日报、乌鲁木齐晚报、都市消费晨报 |

## 十四、专业垂直媒体

### 财经金融
| 媒体 | 网址 |
|------|------|
| 财新网 | https://www.caixin.com |
| 第一财经 | https://www.yicai.com |
| 21世纪经济报道 | https://www.21jingji.com |
| 每日经济新闻 | https://www.nbd.com.cn |
| 经济观察报 | https://www.eeo.com.cn |
| 财联社 | https://www.cls.cn |
| 华尔街见闻 | https://wallstreetcn.com |
| 雪球 | https://xueqiu.com |
| 东方财富网 | https://www.eastmoney.com |
| 和讯网 | https://www.hexun.com |
| 证券时报 | https://www.stcn.com |
| 上海证券报 | https://www.cnstock.com |
| 中国证券报 | https://www.cs.com.cn |
| 证券日报 | http://www.zqrb.cn |
| 期货日报 | http://www.qhrb.com.cn |
| 保险报 | http://www.insurance.cn |
| 银行家 | - |
| 中国金融 | - |

### 科技互联网
| 媒体 | 网址 |
|------|------|
| 36氪 | https://36kr.com |
| 虎嗅网 | https://www.huxiu.com |
| 钛媒体 | https://www.tmtpost.com |
| 雷锋网 | https://www.leiphone.com |
| 品玩 | https://www.pingwest.com |
| 极客公园 | https://www.geekpark.net |
| 机器之心 | https://www.jiqizhixin.com |
| 量子位 | https://www.qbitai.com |
| 智东西 | https://www.zhidx.com |
| IT之家 | https://www.ithome.com |
|  TechWeb | http://www.techweb.com.cn |
|  DoNews | https://www.donews.com |
|  动点科技 | https://cn.technode.com |
|  亿欧网 | https://www.iyiou.com |
|  投资界 | https://www.pedaily.cn |
|  创业邦 | https://www.cyzone.cn |
|  铅笔道 | https://www.pencilnews.cn |

### 能源环保
| 媒体 | 网址 |
|------|------|
| 中国能源报 | http://www.cnenergy.org |
| 中国电力报 | http://www.cpnn.com.cn |
| 中国煤炭报 | http://www.ccoalnews.com |
| 中国石油报 | http://www.zgsyb.com |
| 中国石化报 | http://www.sinopecnews.com.cn |
| 中国海洋石油报 | - |
| 中国核电 | - |
| 中国新能源网 | http://www.china-nengyuan.com |
| 国际能源网 | http://www.in-en.com |
| 北极星电力网 | http://www.bjx.com.cn |
| 北极星储能网 | http://chuneng.bjx.com.cn |
| 北极星氢能网 | http://h2.bjx.com.cn |
| 高工氢电 | - |
| 能源杂志 | - |
| 中国环境报 | https://www.cenews.com.cn |
| 中国绿色时报 | http://www.greentimes.com |
| 环保网 | - |

### 房地产/城建
| 媒体 | 网址 |
|------|------|
| 中国房地产报 | http://www.zgfdcb.com |
| 中国建设报 | http://www.chinajsb.cn |
| 建筑时报 | http://www.jzsbs.com |
| 中国建材报 | - |
| 乐居网 | https://www.leju.com |
| 房天下 | https://www.fang.com |
| 链家研究院 | - |
| 贝壳研究院 | - |
| 克而瑞 | - |
| 中指研究院 | - |

### 医疗健康
| 媒体 | 网址 |
|------|------|
| 健康报 | http://www.jkb.com.cn |
| 中国医药报 | http://www.cnpharm.com |
| 医药经济报 | - |
| 米内网 | http://www.menet.com.cn |
| 动脉网 | https://www.vbdata.cn |
| 丁香园 | https://www.dxy.cn |
| 医学界 | https://www.yxj.org.cn |
| 健康界 | https://www.cn-healthcare.com |
| 生物探索 | https://www.biodiscover.com |
| 基因谷 | - |
| 医疗器械创新网 | - |

### 教育/文化/旅游
| 媒体 | 网址 |
|------|------|
| 中国教育报 | http://www.jyb.cn |
| 中国教师报 | http://www.teachers.com.cn |
| 中国教育新闻网 | http://www.jyb.cn |
| 多知网 | http://www.duozhi.com |
| 芥末堆 | https://www.jiemodui.com |
| 中国文化报 | http://www.ncc.org.cn |
| 中国艺术报 | http://www.cflac.org.cn |
| 中国旅游报 | http://www.ctnews.com.cn |
| 执惠 | https://www.tripvivid.com |
| 品橙旅游 | https://www.pinchain.com |
| 劲旅网 | http://www.ctcnn.com |

### 农业/食品
| 媒体 | 网址 |
|------|------|
| 农民日报 | http://www.farmer.com.cn |
| 中国农村杂志 | - |
| 中国食品报 | http://www.cnfood.cn |
| 中国食品安全报 | http://www.cfsn.cn |
| 糖酒快讯 | - |
| 酒业家 | - |
| 茶叶周刊 | - |

### 汽车/交通
| 媒体 | 网址 |
|------|------|
| 中国汽车报 | http://www.cnautonews.com |
| 汽车之家 | https://www.autohome.com.cn |
| 易车网 | https://www.yiche.com |
| 懂车帝 | - |
| 盖世汽车 | https://www.gasgoo.com |
| 高工智能汽车 | - |
| 电车资源 | - |
| 中国交通报 | http://www.zgjtb.com |
| 中国水运报 | http://www.zgsyb.com |
| 中国民航报 | http://www.caacnews.com.cn |
| 中国铁道建筑报 | - |

### 法律/社会
| 媒体 | 网址 |
|------|------|
| 检察日报 | https://www.jcrb.com |
| 人民法院报 | https://rmfyb.chinacourt.org |
| 人民公安报 | https://www.cpd.com.cn |
| 中国纪检监察报 | http://www.jjjcb.com |
| 民主与法制时报 | - |
| 法律与生活 | - |
| 方圆 | - |
| 中国社会报 | http://www.shb.cn |
| 公益时报 | http://www.gongyishibao.com |
| 慈善公益报 | - |

## 十五、国际智库/研究机构

| 机构 | 国家/地区 | 重点领域 |
|------|-----------|----------|
| 布鲁金斯学会 | 美国 | 经济政策、国际关系 |
| 卡内基国际和平基金会 | 美国 | 国际安全、核不扩散 |
| 兰德公司 | 美国 | 国防安全、公共政策 |
| 彼得森国际经济研究所 | 美国 | 国际经济、贸易政策 |
| 美国企业研究所 | 美国 | 经济政策、社会政策 |
| 传统基金会 | 美国 | 保守主义政策研究 |
| 战略与国际研究中心 | 美国 | 国际安全、地缘政治 |
| 新美国安全中心 | 美国 | 国家安全、国防政策 |
| 外交关系协会 | 美国 | 外交政策、国际关系 |
| 大西洋理事会 | 美国 | 跨大西洋关系、安全 |
| 美国进步中心 | 美国 | 进步主义政策 |
| 伍德罗·威尔逊中心 | 美国 | 公共政策、国际事务 |
| 胡佛研究所 | 美国 | 经济政策、政治制度 |
| 曼哈顿政策研究所 | 美国 | 城市政策、住房 |
| 查塔姆研究所 | 英国 | 国际关系、全球治理 |
| 国际战略研究所 | 英国 | 军事安全、国防 |
| 欧洲改革中心 | 英国 | 欧洲一体化、脱欧 |
| 皇家国际事务研究所 | 英国 | 国际关系、经济 |
| 德国国际政治与安全研究所 | 德国 | 安全政策、欧洲 |
| 德国经济研究所 | 德国 | 经济政策、劳动力 |
| 德国全球与区域研究所 | 德国 | 区域研究、发展 |
| 法国国际关系研究所 | 法国 | 国际关系、欧盟 |
| 法国国际和战略事务研究所 | 法国 | 战略研究、安全 |
| 日本国际问题研究所 | 日本 | 亚太安全、国际关系 |
| 日本防卫研究所 | 日本 | 防卫政策、安全 |
| 韩国对外经济政策研究院 | 韩国 | 对外经济、贸易 |
| 韩国开发研究院 | 韩国 | 经济政策、发展 |
| 新加坡国立大学东亚研究所 | 新加坡 | 东亚研究、中国 |
| 新加坡政策研究所 | 新加坡 | 公共政策、社会 |
| 澳大利亚洛伊研究所 | 澳大利亚 | 亚太安全、外交 |
| 澳大利亚战略政策研究所 | 澳大利亚 | 国防安全、战略 |
| 俄罗斯科学院世界经济与国际关系研究所 | 俄罗斯 | 国际经济、安全 |
| 莫斯科卡内基中心 | 俄罗斯 | 俄罗斯政策、转型 |
| 印度观察家研究基金会 | 印度 | 印度外交、安全 |
| 巴西瓦加斯基金会 | 巴西 | 经济政策、发展 |
| 南非人类科学研究理事会 | 南非 | 发展研究、社会 |
| 联合国开发计划署 | 美国 | 发展研究、人类发展 |
| 世界银行 | 美国 | 发展经济、减贫 |
| 国际货币基金组织 | 美国 | 宏观经济、金融 |
| 世界贸易组织 | 瑞士 | 贸易政策、规则 |
| 经济合作与发展组织 | 法国 | 经济政策、发展 |
| 亚洲开发银行 | 菲律宾 | 亚太发展、基础设施 |
| 亚洲基础设施投资银行 | 中国 | 基础设施、投资 |
| 金砖国家新开发银行 | 中国 | 金砖国家发展 |

## 十六、国际组织/多边机构

| 组织 | 官网 | 重点领域 |
|------|------|----------|
| 联合国 | https://www.un.org | 全球治理、和平发展 |
| 联合国安理会 | - | 国际安全、维和 |
| 联合国大会 | - | 多边外交、全球议题 |
| 联合国经社理事会 | - | 经济社会发展 |
| 联合国贸发会议 | https://unctad.org | 贸易发展、投资 |
| 联合国环境规划署 | https://www.unep.org | 环境保护、气候 |
| 联合国开发计划署 | https://www.undp.org | 人类发展、减贫 |
| 联合国人口基金 | https://www.unfpa.org | 人口、生殖健康 |
| 联合国儿童基金会 | https://www.unicef.org | 儿童权益、发展 |
| 联合国教科文组织 | https://www.unesco.org | 教育、科学、文化 |
| 世界卫生组织 | https://www.who.int | 公共卫生、健康 |
| 国际劳工组织 | https://www.ilo.org | 劳动就业、权益 |
| 世界粮食计划署 | https://www.wfp.org | 粮食安全、援助 |
| 国际货币基金组织 | https://www.imf.org | 宏观经济、金融稳定 |
| 世界银行集团 | https://www.worldbank.org | 发展融资、减贫 |
| 世界贸易组织 | https://www.wto.org | 多边贸易、规则 |
| 国际能源署 | https://www.iea.org | 能源政策、安全 |
| 石油输出国组织 | https://www.opec.org | 石油政策、市场 |
| 国际可再生能源署 | https://www.irena.org | 可再生能源 |
| 国际原子能机构 | https://www.iaea.org | 核能、核安全 |
| 世界气象组织 | https://www.wmo.int | 气象、气候 |
| 国际海事组织 | https://www.imo.org | 航运、海洋 |
| 国际民航组织 | https://www.icao.int | 航空运输 |
| 世界知识产权组织 | https://www.wipo.int | 知识产权 |
| 国际电信联盟 | https://www.itu.int | 信息通信 |
| 世界标准组织 | https://www.iso.org | 国际标准 |
| 亚太经合组织 | https://www.apec.org | 亚太经济合作 |
| 二十国集团 | https://g20.org | 全球经济治理 |
| 金砖国家 | - | 新兴市场合作 |
| 上海合作组织 | http://chn.sectsco.org | 区域安全、合作 |
| 东盟 | https://asean.org | 东南亚合作 |
| 欧盟 | https://european-union.europa.eu | 欧洲一体化 |
| 非盟 | https://au.int | 非洲团结、发展 |
| 阿盟 | https://www.lasportal.org | 阿拉伯国家合作 |
| 北约 | https://www.nato.int | 集体安全、防卫 |
| 美洲国家组织 | https://www.oas.org | 美洲合作 |
| 非洲开发银行 | https://www.afdb.org | 非洲发展 |
| 泛美开发银行 | https://www.iadb.org | 拉美发展 |
| 欧洲投资银行 | https://www.eib.org | 欧洲投资 |
| 欧洲复兴开发银行 | https://www.ebrd.com | 转型经济 |

## 十七、港澳台媒体

### 香港
| 媒体 | 网址 | 类型 |
|------|------|------|
| 南华早报 | https://www.scmp.com | 英文主流 |
| 大公文汇 | http://www.takungpao.com | 爱国爱港 |
| 香港商报 | http://www.hkcd.com | 财经 |
| 香港经济日报 | https://www.hket.com | 财经 |
| 明报 | https://www.mingpao.com | 综合 |
| 信报 | https://www.hkej.com | 财经 |
| 东方日报 | https://orientaldaily.on.cc | 综合 |
| 星岛日报 | https://www.singtao.ca | 综合 |
| 文汇报（香港） | http://www.wenweipo.com | 爱国爱港 |
| 紫荆杂志 | - | 政论 |
| 中国评论通讯社 | http://www.crntt.com | 两岸关系 |

### 澳门
| 媒体 | 网址 |
|------|------|
| 澳门日报 | http://www.macaodaily.com |
| 华侨报 | http://www.vakiodaily.com |
| 市民日报 | - |
| 新华澳报 | - |

### 台湾
| 媒体 | 网址 | 类型 |
|------|------|------|
| 中国时报 | https://www.chinatimes.com | 综合 |
| 联合报 | https://udn.com | 综合 |
| 自由时报 | https://www.ltn.com.tw | 综合 |
| 中央社 | https://www.cna.com.tw | 通讯社 |
| 经济日报（台湾） | https://money.udn.com | 财经 |
| 工商时报 | https://www.chinatimes.com/newspapers/工商時報 | 财经 |
| 天下杂志 | https://www.cw.com.tw | 政经 |
| 远见杂志 | https://www.gvm.com.tw | 政经 |
| 新新闻 | - | 新闻周刊 |

## 十八、自媒体/智库平台

| 平台 | 网址 | 特点 |
|------|------|------|
| 学习强国 | https://www.xuexi.cn | 权威理论学习 |
| 人民日报客户端 | - | 主流媒体 |
| 新华社客户端 | - | 权威新闻 |
| 央视新闻客户端 | - | 视频新闻 |
| 求是网 | http://www.qstheory.cn | 理论宣传 |
| 中国军网 | http://www.81.cn | 军事新闻 |
| 钧正平工作室 | - | 军事评论 |
| 长安街知事 | - | 时政解读 |
| 政知见 | - | 时政分析 |
| 侠客岛 | - | 时事评论 |
| 补壹刀 | - | 国际评论 |
| 玉渊谭天 | - | 财经时政 |
| 陶然笔记 | - | 经济分析 |
| 牛弹琴 | - | 国际时评 |
| 胡锡进观察 | - | 时事评论 |
| 局座召忠 | - | 军事科普 |
| 金灿荣频道 | - | 国际关系 |
| 张维为频道 | - | 中国道路 |
| 陈平眉山论剑 | - | 经济金融 |
| 温铁军讲堂 | - | 三农问题 |

---

## 采集策略

### 关注领域
- 国内政策动态 / 民生热点 / 社会治理
- 经济运行 / 产业政策 / 科技创新
- 国际关系 / 地缘政治 / 全球治理
- 舆情风向 / 苗头性问题 / 趋势研判

### 采集频率
- 国内主流媒体：每日 2-3 次
- 部委官网/政策文件：每日 1 次
- 国际媒体：每日 1-2 次
- 智库报告：每周汇总
- 深度报道/评论：每周汇总

### 输出格式
- 每日简报：重点新闻 + 趋势研判
- 专题内参：深度分析 + 政策建议
- 舆情预警：苗头性问题 + 风险提示
- 政策解读：文件分析 + 影响评估

---

## 信息源分类速查

| 需求类型 | 推荐来源 |
|----------|----------|
| 宏观经济数据 | 国家统计局、央行、发改委、财政部官网 |
| 产业政策 | 工信部、各部委官网、行业协会 |
| 地方动态 | 省级党报、地方发改委、统计局 |
| 国际局势 | 新华社国际部、央视国际、路透社、BBC |
| 社情民意 | 人民政协报、民主党派官网、地方政协 |
| 专家观点 | 国家级智库、高校智库、社科院 |
| 行业数据 | 行业协会、专业垂直媒体 |
| 学术支撑 | 知网、万方、国家哲学社会科学文献中心 |
| 国际比较 | 国际智库、世界银行、IMF、OECD |
| 政策解读 | 学习强国、求是网、人民日报评论员文章 |

### 关注领域
- 国内政策动态 / 民生热点 / 社会治理
- 经济运行 / 产业政策 / 科技创新
- 国际关系 / 地缘政治 / 全球治理
- 舆情风向 / 苗头性问题 / 趋势研判

### 采集频率
- 国内主流媒体：每日 2-3 次
- 国际媒体：每日 1-2 次
- 深度报道/评论：每周汇总

### 输出格式
- 每日简报：重点新闻 + 趋势研判
- 专题内参：深度分析 + 政策建议
- 舆情预警：苗头性问题 + 风险提示
