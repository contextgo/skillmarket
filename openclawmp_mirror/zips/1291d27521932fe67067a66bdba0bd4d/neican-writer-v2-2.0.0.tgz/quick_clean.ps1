﻿# 快速文件整理脚本
$Log = "$env:USERPROFILE\.stepclaw\workspace\quick_clean_$(Get-Date -Format 'HHmmss').log"
$start = Get-Date

function Write-Log($m, $c="White") {
    Write-Host $m -ForegroundColor $c
    $m | Out-File $Log -Append -Encoding UTF8
}

Write-Log "========== 快速文件整理 ==========" "Cyan"
Write-Log "开始时间: $start" "Gray"

# 1. 快速查找同名同大小文件（疑似重复）
Write-Log "`n[1/4] 查找同名同大小文件..." "Cyan"
$drives = @('E:\','F:\','G:\','H:\')
$dupCount = 0
$dupSize = 0

foreach($d in $drives){
    if(Test-Path $d){
        # 只找大于10MB的文件
        $files = Get-ChildItem -Path $d -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 10MB } |
            Group-Object Name, Length | Where-Object { $_.Count -gt 1 }
        
        foreach($g in $files){
            $items = $g.Group | Sort-Object FullName
            Write-Log "`n  重复: $($items[0].Name)" "Yellow"
            for($i=1; $i -lt $items.Count; $i++){
                $sizeMB = [math]::Round($items[$i].Length/1MB,2)
                try{
                    Remove-Item $items[$i].FullName -Force -ErrorAction Stop
                    Write-Log "    已删除: $($items[$i].FullName) (${sizeMB} MB)" "Green"
                    $dupCount++
                    $dupSize += $sizeMB
                }catch{
                    Write-Log "    删除失败: $($items[$i].FullName)" "Red"
                }
            }
        }
    }
}

# 2. 删除空文件夹
Write-Log "`n[2/4] 删除空文件夹..." "Cyan"
$emptyCount = 0
foreach($d in $drives){
    if(Test-Path $d){
        do{
            $empties = Get-ChildItem -Path $d -Directory -Recurse -ErrorAction SilentlyContinue | 
                Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 }
            $batchCount = 0
            foreach($e in $empties){
                try{
                    Remove-Item $e.FullName -Force -ErrorAction Stop
                    $batchCount++
                }catch{}
            }
            $emptyCount += $batchCount
        }while($batchCount -gt 0)
    }
}
Write-Log "  删除空文件夹: $emptyCount 个" "Green"

# 3. 归类E盘文件
Write-Log "`n[3/4] 归类E盘文件..." "Cyan"
$cats = @{
    "Software" = @("*.exe","*.msi","*.zip","*.rar","*.7z","*.iso")
    "Documents" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx","*.ppt","*.pptx","*.txt")
    "Images" = @("*.jpg","*.jpeg","*.png","*.gif","*.bmp","*.psd","*.ico")
    "Videos" = @("*.mp3","*.mp4","*.avi","*.mkv","*.wma","*.wav","*.ncm")
}

$moved = 0
foreach($c in $cats.GetEnumerator()){
    $dest = "E:\Organized\$($c.Key)"
    if(-not (Test-Path $dest)){ New-Item -ItemType Directory -Path $dest -Force | Out-Null }
    
    foreach($p in $c.Value){
        Get-ChildItem -Path "E:\" -Filter $p -File -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { $_.DirectoryName -notlike "*Organized*" -and $_.DirectoryName -notlike "*Program*" } | 
        ForEach-Object {
            $target = Join-Path $dest $_.Name
            if(Test-Path $target){ 
                $target = Join-Path $dest "$($_.BaseName)_$([guid]::NewGuid().ToString().Substring(0,4))$($_.Extension)"
            }
            try{
                Move-Item $_.FullName $target -Force
                $moved++
            }catch{
                Write-Log "  移动失败: $($_.Name)" "Red"
            }
        }
    }
}
Write-Log "  归类文件: $moved 个" "Green"

# 4. 统计
Write-Log "`n[4/4] 统计结果..." "Cyan"
Get-Volume | Where-Object { $_.DriveLetter -ne $null } | 
    Select-Object DriveLetter, @{N='UsedGB';E={[math]::Round(($_.Size-$_.SizeRemaining)/1GB,2)}}, @{N='FreeGB';E={[math]::Round($_.SizeRemaining/1GB,2)}} |
    Format-Table | Out-String | Write-Log

$end = Get-Date
$duration = $end - $start
Write-Log "`n========== 完成 ==========" "Cyan"
Write-Log "重复文件删除: $dupCount 个 ($([math]::Round($dupSize,2)) MB)" "Green"
Write-Log "空文件夹删除: $emptyCount 个" "Green"
Write-Log "文件归类: $moved 个" "Green"
Write-Log "耗时: $($duration.Minutes)分 $($duration.Seconds)秒" "Yellow"
Write-Log "日志: $Log" "Gray"
