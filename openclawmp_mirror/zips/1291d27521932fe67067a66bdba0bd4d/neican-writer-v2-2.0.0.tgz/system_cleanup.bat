@echo off
chcp 65001 >nul
echo ==========================================
echo      系统全面清理工具
echo ==========================================
echo.

:: 1. 清理系统临时文件
echo [1/6] 清理系统临时文件...
rd /s /q "%temp%" 2>nul
rd /s /q "C:\Windows\Temp" 2>nul
rd /s /q "C:\Windows\Prefetch" 2>nul
md "%temp%" 2>nul
echo      完成
echo.

:: 2. 清理浏览器缓存
echo [2/6] 清理浏览器缓存...
rd /s /q "%localappdata%\Google\Chrome\User Data\Default\Cache" 2>nul
rd /s /q "%localappdata%\Microsoft\Edge\User Data\Default\Cache" 2>nul
echo      完成
echo.

:: 3. 运行磁盘清理
echo [3/6] 运行磁盘清理...
cleanmgr /sagerun:1 2>nul
echo      完成
echo.

:: 4. 删除空文件夹 (E, F, G, H盘)
echo [4/6] 扫描并删除空文件夹...
powershell -Command "Get-ChildItem -Path 'E:\','F:\','G:\','H:\' -Directory -Recurse -ErrorAction SilentlyContinue | Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue"
echo      完成
echo.

:: 5. 整理E盘文件
echo [5/6] 整理E盘文件分类...
if not exist "E:\Organized" mkdir "E:\Organized"
if not exist "E:\Organized\Software" mkdir "E:\Organized\Software"
if not exist "E:\Organized\Documents" mkdir "E:\Organized\Documents"
if not exist "E:\Organized\Images" mkdir "E:\Organized\Images"
if not exist "E:\Organized\Videos" mkdir "E:\Organized\Videos"
if not exist "E:\Organized\Backup" mkdir "E:\Organized\Backup"
if not exist "E:\Organized\Others" mkdir "E:\Organized\Others"

:: 移动文件到对应分类 (仅移动根目录和年份文件夹中的文件)
powershell -Command "Get-ChildItem -Path 'E:\' -Filter '*.exe','*.msi','*.zip','*.rar','*.iso' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -notlike '*Organized*' -and $_.DirectoryName -notlike '*Program*' } | Move-Item -Destination 'E:\Organized\Software' -Force -ErrorAction SilentlyContinue"
powershell -Command "Get-ChildItem -Path 'E:\' -Filter '*.pdf','*.doc','*.docx','*.xls','*.xlsx' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -notlike '*Organized*' } | Move-Item -Destination 'E:\Organized\Documents' -Force -ErrorAction SilentlyContinue"
powershell -Command "Get-ChildItem -Path 'E:\' -Filter '*.jpg','*.jpeg','*.png','*.gif','*.bmp' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -notlike '*Organized*' } | Move-Item -Destination 'E:\Organized\Images' -Force -ErrorAction SilentlyContinue"
powershell -Command "Get-ChildItem -Path 'E:\' -Filter '*.mp3','*.mp4','*.avi','*.wma' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -notlike '*Organized*' } | Move-Item -Destination 'E:\Organized\Videos' -Force -ErrorAction SilentlyContinue"
echo      完成
echo.

:: 6. 系统优化
echo [6/6] 系统优化...
:: 释放内存
powershell -Command "[GC]::Collect()"
:: 刷新DNS
ipconfig /flushdns >nul
:: 重置Winsock
netsh winsock reset >nul 2>&1
echo      完成
echo.

echo ==========================================
echo      清理完成！
echo ==========================================
echo.
echo 已执行以下操作：
echo   - 清理系统临时文件
echo   - 清理浏览器缓存
echo   - 删除空文件夹
echo   - 整理E盘文件分类
echo   - 系统优化
echo.
pause
