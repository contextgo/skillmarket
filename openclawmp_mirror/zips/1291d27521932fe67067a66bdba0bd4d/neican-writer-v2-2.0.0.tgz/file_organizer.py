#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件整理脚本 - Python版本
功能: 删除空文件夹 + 智能分类移动
作者: AI Assistant
"""

import os
import shutil
import sys
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# ============================================
# 配置
# ============================================

# 文件类型分类映射
FILE_CATEGORIES = {
    "01-软件安装包": [".exe", ".msi", ".zip", ".rar", ".7z", ".iso", ".dmg"],
    "02-文档资料": [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".csv"],
    "03-图片素材": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".psd", ".ai", ".svg", ".ico", ".webp"],
    "04-音视频": [".mp3", ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".wma", ".wav", ".aac", ".ncm"],
    "05-设计文件": [".psd", ".ai", ".sketch", ".fig", ".xd", ".dwg", ".max", ".blend"],
    "06-代码文件": [".py", ".js", ".html", ".css", ".java", ".cpp", ".c", ".h", ".cs", ".php", ".go", ".rs"],
    "07-数据备份": [".bak", ".backup", ".wim", ".gho", ".tib", ".dat", ".db", ".sql"],
    "08-电子书": [".epub", ".mobi", ".azw3", ".pdf"],
    "99-其他": []  # 其他未分类的文件
}

# 排除的目录（不处理这些系统/程序目录）
EXCLUDE_PATHS = [
    "program files", "programdata", "windows", "system32",
    "organized", ".git", "node_modules", "__pycache__", ".venv"
]

# 统计变量
stats = {
    "empty_folders_removed": 0,
    "files_moved": 0,
    "total_size_moved": 0,
    "errors": 0
}

# ============================================
# 工具函数
# ============================================

def log(message, color="white", level="INFO"):
    """打印并记录日志"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{timestamp}] [{level}] {message}"
    
    # 颜色映射
    colors = {
        "white": "\033[37m",
        "green": "\033[32m",
        "red": "\033[31m",
        "yellow": "\033[33m",
        "cyan": "\033[36m",
        "gray": "\033[90m"
    }
    reset = "\033[0m"
    
    color_code = colors.get(color, colors["white"])
    print(f"{color_code}{log_line}{reset}")
    
    # 写入日志文件
    log_file = Path(organized_path) / f"organize_log_{datetime.now().strftime('%Y%m%d')}.txt"
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_line + "\n")
    except:
        pass

def should_exclude(path):
    """检查路径是否应该被排除"""
    path_lower = str(path).lower()
    for pattern in EXCLUDE_PATHS:
        if pattern in path_lower:
            return True
    return False

def get_file_category(file_path):
    """获取文件所属分类"""
    ext = file_path.suffix.lower()
    for category, extensions in FILE_CATEGORIES.items():
        if category == "99-其他":
            continue
        if ext in extensions:
            return category
    return "99-其他"

def format_size(size_bytes):
    """格式化文件大小"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

# ============================================
# 核心功能
# ============================================

def remove_empty_folders(path, what_if=False):
    """删除空文件夹"""
    log("[步骤 1/2] 删除空文件夹...", "yellow", "STEP")
    
    # 获取所有文件夹（从深层开始）
    folders = []
    for root, dirs, files in os.walk(str(path), topdown=False):
        for dir_name in dirs:
            folder_path = Path(root) / dir_name
            if not should_exclude(folder_path):
                folders.append(folder_path)
    
    # 添加根目录下的直接子文件夹
    for item in path.iterdir():
        if item.is_dir() and not should_exclude(item):
            folders.append(item)
    
    # 去重并排序（深层优先）
    folders = sorted(set(folders), key=lambda x: len(str(x)), reverse=True)
    
    for folder in folders:
        try:
            # 检查是否为空
            contents = list(folder.iterdir())
            if len(contents) == 0:
                if not what_if:
                    folder.rmdir()
                log(f"删除空文件夹: {folder}", "green", "DELETE")
                stats["empty_folders_removed"] += 1
        except Exception as e:
            log(f"删除失败: {folder} - {e}", "red", "ERROR")
            stats["errors"] += 1

def move_files_by_category(path, organized_path, what_if=False, include_subfolders=True):
    """按类别移动文件"""
    log("[步骤 2/2] 按类别整理文件...", "yellow", "STEP")
    
    # 收集所有文件
    files = []
    if include_subfolders:
        for root, dirs, filenames in os.walk(str(path)):
            # 排除指定目录
            dirs[:] = [d for d in dirs if not should_exclude(Path(root) / d)]
            
            for filename in filenames:
                file_path = Path(root) / filename
                if not should_exclude(file_path.parent):
                    files.append(file_path)
    else:
        files = [f for f in path.iterdir() if f.is_file() and not should_exclude(f)]
    
    log(f"发现 {len(files)} 个文件需要整理", "cyan", "INFO")
    
    # 创建分类目录
    organized_root = Path(organized_path)
    organized_root.mkdir(parents=True, exist_ok=True)
    
    for category in FILE_CATEGORIES.keys():
        category_path = organized_root / category
        if not what_if:
            category_path.mkdir(exist_ok=True)
        else:
            log(f"创建目录: {category_path}", "gray", "MKDIR")
    
    # 移动文件
    for file_path in files:
        try:
            category = get_file_category(file_path)
            dest_folder = organized_root / category
            
            # 处理重名
            dest_path = dest_folder / file_path.name
            counter = 1
            while dest_path.exists():
                new_name = f"{file_path.stem}_{counter:03d}{file_path.suffix}"
                dest_path = dest_folder / new_name
                counter += 1
            
            # 移动文件
            size = file_path.stat().st_size
            if not what_if:
                shutil.move(str(file_path), str(dest_path))
            
            log(f"移动: [{category}] {file_path.name} ({format_size(size)})", "green", "MOVE")
            stats["files_moved"] += 1
            stats["total_size_moved"] += size
            
        except Exception as e:
            log(f"移动失败: {file_path.name} - {e}", "red", "ERROR")
            stats["errors"] += 1

def show_summary(what_if=False):
    """显示总结"""
    log("\n========================================", "cyan", "SUMMARY")
    log("文件整理完成！", "green", "SUMMARY")
    log("========================================", "cyan", "SUMMARY")
    log(f"空文件夹删除: {stats['empty_folders_removed']} 个", "white", "SUMMARY")
    log(f"文件移动: {stats['files_moved']} 个", "white", "SUMMARY")
    log(f"总大小: {format_size(stats['total_size_moved'])}", "white", "SUMMARY")
    
    error_color = "red" if stats["errors"] > 0 else "green"
    log(f"错误: {stats['errors']} 个", error_color, "SUMMARY")
    
    if what_if:
        log("\n⚠️  这是预览模式，没有实际执行任何操作", "yellow", "WARN")
        log("    要实际执行，请去掉 --what-if 参数", "yellow", "WARN")
    
    log(f"\n整理后的文件位置: {organized_path}", "cyan", "INFO")

# ============================================
# 主程序
# ============================================

def main():
    """主函数"""
    import argparse
    
    # 命令行参数
    parser = argparse.ArgumentParser(description='文件整理脚本 - 删除空文件夹 + 智能分类')
    parser.add_argument('--target', '-t', default='E:\\', help='要整理的根目录 (默认: E:\\)')
    parser.add_argument('--output', '-o', default='E:\\Organized', help='整理后的存放位置 (默认: E:\\Organized)')
    parser.add_argument('--what-if', '-w', action='store_true', help='预览模式（不实际执行）')
    parser.add_argument('--no-subfolders', action='store_true', help='不包含子文件夹')
    
    args = parser.parse_args()
    
    global target_path, organized_path
    target_path = Path(args.target)
    organized_path = Path(args.output)
    what_if = args.what_if
    include_subfolders = not args.no_subfolders
    
    # 启动
    log("========== 文件整理脚本启动 (Python) ==========", "cyan", "START")
    log(f"目标目录: {target_path}", "gray", "CONFIG")
    log(f"整理位置: {organized_path}", "gray", "CONFIG")
    log(f"预览模式: {what_if}", "gray", "CONFIG")
    
    # 检查目标路径
    if not target_path.exists():
        log(f"错误: 目标路径不存在 - {target_path}", "red", "ERROR")
        sys.exit(1)
    
    # 创建整理根目录
    organized_path.mkdir(parents=True, exist_ok=True)
    log(f"创建整理根目录: {organized_path}", "green", "MKDIR")
    
    # 执行整理
    remove_empty_folders(target_path, what_if)
    move_files_by_category(target_path, organized_path, what_if, include_subfolders)
    
    # 显示总结
    show_summary(what_if)
    
    log("\n脚本执行完毕！", "green", "DONE")

if __name__ == "__main__":
    main()
