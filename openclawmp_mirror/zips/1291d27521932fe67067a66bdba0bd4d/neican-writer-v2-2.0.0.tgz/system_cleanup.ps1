# 系统全面清理脚本
$startTime = Get-Date
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "      系统全面清理工具" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# 1. 清理系统临时文件
Write-Host "[1/6] 清理系统临时文件..." -ForegroundColor Yellow
$tempPaths = @(
    $env:TEMP,
    "C:\Windows\Temp",
    "C:\Windows\Prefetch"
)
$cleanedSize = 0
foreach($path in $tempPaths){
    if(Test-Path $path){
        Get-ChildItem -Path $path -Recurse -Force -ErrorAction SilentlyContinue | 
        Where-Object { -not $_.PSIsContainer } | 
        ForEach-Object {
            $cleanedSize += $_.Length
            try { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}
Write-Host "      完成 (清理 $([math]::Round($cleanedSize/1MB,2)) MB)" -ForegroundColor Green
Write-Host ""

# 2. 清理浏览器缓存
Write-Host "[2/6] 清理浏览器缓存..." -ForegroundColor Yellow
$browserCaches = @(
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache",
    "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache",
    "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles"
)
foreach($cache in $browserCaches){
    if(Test-Path $cache){
        try { Remove-Item "$cache\*" -Recurse -Force -ErrorAction SilentlyContinue } catch {}
    }
}
Write-Host "      完成" -ForegroundColor Green
Write-Host ""

# 3. 删除空文件夹
Write-Host "[3/6] 扫描并删除空文件夹..." -ForegroundColor Yellow
$drives = @('E:\','F:\','G:\','H:\')
$emptyCount = 0
foreach($drive in $drives){
    if(Test-Path $drive){
        # 循环删除直到没有空文件夹
        do {
            $empties = Get-ChildItem -Path $drive -Directory -Recurse -ErrorAction SilentlyContinue | 
                Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 }
            $batchCount = 0
            foreach($empty in $empties){
                try {
                    Remove-Item $empty.FullName -Force -ErrorAction Stop
                    $batchCount++
                } catch {}
            }
            $emptyCount += $batchCount
        } while($batchCount -gt 0)
    }
}
Write-Host "      完成 (删除 $emptyCount 个空文件夹)" -ForegroundColor Green
Write-Host ""

# 4. 创建规范目录结构
Write-Host "[4/6] 创建规范目录结构..." -ForegroundColor Yellow
$folders = @("Software","Documents","Images","Videos","Backup","Others")
$organizeRoot = "E:\Organized"
if(-not (Test-Path $organizeRoot)){
    New-Item -ItemType Directory -Path $organizeRoot -Force | Out-Null
}
foreach($folder in $folders){
    $path = Join-Path $organizeRoot $folder
    if(-not (Test-Path $path)){
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
}
Write-Host "      完成 (已创建 E:\Organized 分类目录)" -ForegroundColor Green
Write-Host ""

# 5. 整理E盘文件
Write-Host "[5/6] 整理E盘文件..." -ForegroundColor Yellow
$movedCount = 0

# 定义文件类型映射
$fileTypes = @{
    "Software" = @("*.exe","*.msi","*.zip","*.rar","*.7z","*.iso")
    "Documents" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx","*.ppt","*.pptx","*.txt")
    "Images" = @("*.jpg","*.jpeg","*.png","*.gif","*.bmp","*.psd","*.ico")
    "Videos" = @("*.mp3","*.mp4","*.avi","*.mkv","*.wma","*.wav","*.wmv")
}

foreach($type in $fileTypes.GetEnumerator()){
    $destFolder = Join-Path $organizeRoot $type.Key
    foreach($pattern in $type.Value){
        # 只从年份文件夹和根目录移动
        $sourceFolders = @("E:\")
        Get-ChildItem -Path "E:\" -Directory -ErrorAction SilentlyContinue | 
            Where-Object { $_.Name -match '^\d{4}$' } | 
            ForEach-Object { $sourceFolders += $_.FullName }
        
        foreach($src in $sourceFolders){
            Get-ChildItem -Path $src -Filter $pattern -File -ErrorAction SilentlyContinue | 
            Where-Object { $_.DirectoryName -notlike "*Organized*" } | 
            ForEach-Object {
                $destPath = Join-Path $destFolder $_.Name
                if(Test-Path $destPath){
                    $destPath = Join-Path $destFolder "$($_.BaseName)_$([guid]::NewGuid().ToString().Substring(0,4))$($_.Extension)"
                }
                try {
                    Move-Item $_.FullName $destPath -Force -ErrorAction Stop
                    $movedCount++
                } catch {}
            }
        }
    }
}
Write-Host "      完成 (移动 $movedCount 个文件)" -ForegroundColor Green
Write-Host ""

# 6. 系统优化
Write-Host "[6/6] 系统优化..." -ForegroundColor Yellow
# 释放内存
[GC]::Collect()
[GC]::WaitForPendingFinalizers()
# 刷新DNS
ipconfig /flushdns | Out-Null
# 显示磁盘信息
Write-Host "      磁盘空间状态:" -ForegroundColor Gray
Get-Volume | Where-Object { $_.DriveLetter -ne $null } | 
    Select-Object DriveLetter, 
        @{N='Used(GB)';E={[math]::Round(($_.Size-$_.SizeRemaining)/1GB,2)}}, 
        @{N='Free(GB)';E={[math]::Round($_.SizeRemaining/1GB,2)}},
        @{N='Total(GB)';E={[math]::Round($_.Size/1GB,2)}} |
    Format-Table | Out-String | Write-Host -ForegroundColor Gray

Write-Host "      完成" -ForegroundColor Green
Write-Host ""

# 完成总结
$endTime = Get-Date
$duration = $endTime - $startTime
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "      清理完成！" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "执行结果:" -ForegroundColor Yellow
Write-Host "  - 清理临时文件: $([math]::Round($cleanedSize/1MB,2)) MB" -ForegroundColor White
Write-Host "  - 删除空文件夹: $emptyCount 个" -ForegroundColor White
Write-Host "  - 整理文件: $movedCount 个" -ForegroundColor White
Write-Host "  - 耗时: $($duration.Minutes)分 $($duration.Seconds)秒" -ForegroundColor White
Write-Host ""
Write-Host "已创建分类目录:" -ForegroundColor Yellow
Write-Host "  E:\Organized\Software   - 软件安装包" -ForegroundColor Gray
Write-Host "  E:\Organized\Documents  - 文档资料" -ForegroundColor Gray
Write-Host "  E:\Organized\Images     - 图片素材" -ForegroundColor Gray
Write-Host "  E:\Organized\Videos     - 音视频" -ForegroundColor Gray
Write-Host "  E:\Organized\Backup     - 备份文件" -ForegroundColor Gray
Write-Host "  E:\Organized\Others     - 其他文件" -ForegroundColor Gray
Write-Host ""
