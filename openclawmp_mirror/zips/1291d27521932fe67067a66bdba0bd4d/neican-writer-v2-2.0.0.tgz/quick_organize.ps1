# 快速电脑整理脚本 - 删除空文件夹 + 文件归类
$start = Get-Date
Write-Host "========== 电脑快速整理 ==========" -ForegroundColor Cyan
Write-Host "开始时间: $start" -ForegroundColor Gray

# 1. 删除所有空文件夹
Write-Host "`n[1/3] 删除空文件夹..." -ForegroundColor Yellow
$drives = @('E:\','F:\','G:\','H:\')
$totalEmpty = 0

foreach($drive in $drives){
    if(Test-Path $drive){
        Write-Host "  扫描 $drive..." -ForegroundColor Gray
        # 使用简单快速的方法
        $cmd = "cmd /c for /f 'delims=' %d in ('dir /s /b /ad '$drive' 2^>nul ^| sort /r') do @rd '%d' 2>nul"
        Invoke-Expression $cmd | Out-Null
    }
}
# 统计
foreach($drive in $drives){
    if(Test-Path $drive){
        $empties = Get-ChildItem -Path $drive -Directory -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { (Get-ChildItem $_.FullName -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 }
        $totalEmpty += $empties.Count
    }
}
Write-Host "  完成 (剩余空文件夹: $totalEmpty)" -ForegroundColor Green

# 2. 创建分类目录
Write-Host "`n[2/3] 创建分类目录..." -ForegroundColor Yellow
$baseDir = "E:\已整理"
$categories = @(
    "01-软件安装包",
    "02-文档资料", 
    "03-图片素材",
    "04-音视频",
    "05-设计文件",
    "06-备份数据",
    "99-其他"
)
if(-not (Test-Path $baseDir)){
    New-Item -ItemType Directory -Path $baseDir -Force | Out-Null
}
foreach($cat in $categories){
    $path = Join-Path $baseDir $cat
    if(-not (Test-Path $path)){
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
}
Write-Host "  完成 (已创建 $baseDir)" -ForegroundColor Green

# 3. 移动E盘松散文件到分类目录
Write-Host "`n[3/3] 整理E盘文件..." -ForegroundColor Yellow
$moved = 0

# 定义文件类型
$typeMap = @{
    "$baseDir\01-软件安装包" = @("*.exe","*.msi","*.zip","*.rar","*.7z","*.iso")
    "$baseDir\02-文档资料" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx","*.ppt","*.pptx","*.txt")
    "$baseDir\03-图片素材" = @("*.jpg","*.jpeg","*.png","*.gif","*.bmp","*.psd","*.ico")
    "$baseDir\04-音视频" = @("*.mp3","*.mp4","*.avi","*.mkv","*.wma","*.wav","*.wmv")
    "$baseDir\05-设计文件" = @("*.pds","*.dwg","*.skp")
}

# 从E盘根目录和年份文件夹移动文件
$sourceDirs = @("E:\")
Get-ChildItem -Path "E:\" -Directory -ErrorAction SilentlyContinue | 
    Where-Object { $_.Name -match '^\d{4}$' } | 
    ForEach-Object { $sourceDirs += $_.FullName }

foreach($dest in $typeMap.GetEnumerator()){
    foreach($pattern in $dest.Value){
        foreach($src in $sourceDirs){
            Get-ChildItem -Path $src -Filter $pattern -File -ErrorAction SilentlyContinue | 
            Where-Object { $_.DirectoryName -notlike "*已整理*" -and $_.DirectoryName -notlike "*Program*" } | 
            ForEach-Object {
                $target = Join-Path $dest.Key $_.Name
                if(Test-Path $target){
                    $target = Join-Path $dest.Key "$($_.BaseName)_$(Get-Random -Maximum 9999)$($_.Extension)"
                }
                try {
                    Move-Item $_.FullName $target -Force -ErrorAction Stop
                    $moved++
                } catch {}
            }
        }
    }
}
Write-Host "  完成 (移动 $moved 个文件)" -ForegroundColor Green

# 完成
$end = Get-Date
$duration = $end - $start
Write-Host "`n========== 完成 ==========" -ForegroundColor Cyan
Write-Host "空文件夹: 已清理" -ForegroundColor Green
Write-Host "文件归类: $moved 个" -ForegroundColor Green
Write-Host "耗时: $($duration.TotalSeconds.ToString('F1')) 秒" -ForegroundColor Yellow
Write-Host "`n分类目录:" -ForegroundColor Yellow
$categories | ForEach-Object { Write-Host "  $baseDir\$_" -ForegroundColor Gray }
