﻿# H盘音乐文件整理脚本
$start = Get-Date
Write-Host "========== H盘音乐文件整理 ==========" -ForegroundColor Cyan
Write-Host "开始时间: $start" -ForegroundColor Gray

# 创建音乐专用目录
$musicDir = "E:\Organized\Music"
if(-not (Test-Path $musicDir)){
    New-Item -ItemType Directory -Path $musicDir -Force | Out-Null
    Write-Host "  创建目录: $musicDir" -ForegroundColor Green
}

# 音乐文件类型
$musicTypes = @("*.mp3","*.wma","*.wav","*.ncm","*.flac","*.aac","*.ogg","*.m4a")

# 扫描H盘音乐文件
Write-Host "`n[1/2] 扫描H盘音乐文件..." -ForegroundColor Yellow
$musicFiles = @()
foreach($type in $musicTypes){
    $musicFiles += Get-ChildItem -Path "H:\" -Filter $type -File -Recurse -ErrorAction SilentlyContinue
}
Write-Host "  发现 $($musicFiles.Count) 个音乐文件" -ForegroundColor Yellow

# 显示文件分布
$byExt = $musicFiles | Group-Object Extension | Select-Object Name, Count | Sort-Object Count -Descending
Write-Host "`n  文件类型分布:" -ForegroundColor Gray
$byExt | ForEach-Object { Write-Host "    $($_.Name): $($_.Count) 个" -ForegroundColor Gray }

# 移动音乐文件
Write-Host "`n[2/2] 移动音乐文件到 $musicDir..." -ForegroundColor Yellow
$moved = 0
$totalSize = 0

foreach($file in $musicFiles){
    $sizeMB = [math]::Round($file.Length/1MB,2)
    $target = Join-Path $musicDir $file.Name
    
    # 如果目标已存在，重命名
    if(Test-Path $target){
        $target = Join-Path $musicDir "$($file.BaseName)_$(Get-Random -Maximum 9999)$($file.Extension)"
    }
    
    try {
        Move-Item $file.FullName $target -Force -ErrorAction Stop
        Write-Host "  移动: $($file.Name) (${sizeMB} MB)" -ForegroundColor Green
        $moved++
        $totalSize += $sizeMB
    } catch {
        Write-Host "  失败: $($file.Name)" -ForegroundColor Red
    }
}

# 完成
$end = Get-Date
$duration = $end - $start
Write-Host "`n========== 完成 ==========" -ForegroundColor Cyan
Write-Host "音乐文件移动: $moved 个" -ForegroundColor Green
Write-Host "总大小: $([math]::Round($totalSize,2)) MB ($([math]::Round($totalSize/1024,2)) GB)" -ForegroundColor Green
Write-Host "目标位置: $musicDir" -ForegroundColor Yellow
Write-Host "耗时: $($duration.Minutes)分 $($duration.Seconds)秒" -ForegroundColor Gray

# 显示结果
Write-Host "`n整理后音乐文件列表 (前20个):" -ForegroundColor Yellow
Get-ChildItem -Path $musicDir -File | Select-Object -First 20 Name, @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize
