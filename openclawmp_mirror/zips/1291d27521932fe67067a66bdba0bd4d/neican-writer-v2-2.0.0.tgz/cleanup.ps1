﻿# File Cleanup Script
param([switch]$WhatIf = $false)
$LogFile = "$env:USERPROFILE\.stepclaw\workspace\cleanup_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$deletedFiles = 0
$deletedSize = 0
$emptyFolders = 0

function Log($msg, $color="White") {
    Write-Host $msg -ForegroundColor $color
    "[$(Get-Date -Format 'HH:mm:ss')] $msg" | Out-File $LogFile -Append -Encoding UTF8
}

Log "========== FILE CLEANUP START ==========" "Cyan"
Log "Mode: $(if($WhatIf){'PREVIEW'}else{'EXECUTE'})" "Yellow"

# Clean temp files
Log "`n[1/4] Cleaning temp files..." "Cyan"
$patterns = @("*.tmp","*.temp","*.cache","Thumbs.db","*.thumb","desktop.ini","~$*","*.dmp","*.old","*.bak")
$drives = @('E:\','F:\','G:\','H:\')

foreach($drive in $drives){
    if(Test-Path $drive){
        Log "  Scanning $drive..." "Gray"
        foreach($pat in $patterns){
            Get-ChildItem -Path $drive -Filter $pat -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $sz = [math]::Round($_.Length/1MB,2)
                if(-not $WhatIf){ Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
                Log "  Deleted: $($_.Name) (${sz}MB)" "Green"
                $deletedFiles++
                $deletedSize += $sz
            }
        }
    }
}

# Remove empty folders
Log "`n[2/4] Removing empty folders..." "Cyan"
foreach($drive in $drives){
    if(Test-Path $drive){
        Get-ChildItem -Path $drive -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } |
        Sort-Object FullName -Descending | ForEach-Object {
            if(-not $WhatIf){ Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
            Log "  Removed: $($_.FullName)" "Green"
            $emptyFolders++
        }
    }
}

# Create organized folders
Log "`n[3/4] Creating organized folder structure..." "Cyan"
$folders = @("01-Software","02-Documents","03-Images","04-Videos","05-Design","06-Backup","99-Others")
$root = "E:\Organized"
if(-not $WhatIf){
    New-Item -ItemType Directory -Path $root -Force -ErrorAction SilentlyContinue | Out-Null
    foreach($f in $folders){ New-Item -ItemType Directory -Path "$root\$f" -Force -ErrorAction SilentlyContinue | Out-Null }
}
Log "  Created: $root" "Green"

# Find large files
Log "`n[4/4] Scanning large files (>100MB)..." "Cyan"
$large = @()
foreach($drive in $drives){
    if(Test-Path $drive){
        $large += Get-ChildItem -Path $drive -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 100MB } |
            Select-Object @{N='Path';E={$_.FullName}},@{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}} |
            Sort-Object SizeMB -Descending | Select-Object -First 10
    }
}
$large | ForEach-Object { Log "  $($_.Path) - $($_.SizeMB) MB" "Gray" }

# Summary
Log "`n========== CLEANUP COMPLETE ==========" "Cyan"
Log "Files deleted: $deletedFiles" "Green"
Log "Space freed: $([math]::Round($deletedSize,2)) MB" "Green"
Log "Empty folders removed: $emptyFolders" "Green"
Log "Log saved: $LogFile" "Gray"
