﻿# Quick PC Cleanup
$start = Get-Date
Write-Host "========== PC Cleanup ==========" -ForegroundColor Cyan

# Delete empty folders
Write-Host "`n[1/2] Removing empty folders..." -ForegroundColor Yellow
$drives = @('E:\','F:\','G:\','H:\')
$emptyCount = 0
foreach($d in $drives){
    if(Test-Path $d){
        Get-ChildItem -Path $d -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { (Get-ChildItem $_.FullName -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } |
        ForEach-Object { 
            try { Remove-Item $_.FullName -Force; $emptyCount++ } catch {} 
        }
    }
}
Write-Host "  Removed: $emptyCount empty folders" -ForegroundColor Green

# Create organized folders
Write-Host "`n[2/2] Creating organized folders..." -ForegroundColor Yellow
$base = "E:\Organized"
$folders = @("Software","Documents","Images","Videos","Backup","Others")
if(-not (Test-Path $base)){ New-Item -ItemType Directory -Path $base -Force | Out-Null }
foreach($f in $folders){ 
    $p = Join-Path $base $f
    if(-not (Test-Path $p)){ New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

# Move files
$moved = 0
$types = @{
    "Software" = @("*.exe","*.msi","*.zip","*.rar","*.iso")
    "Documents" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx")
    "Images" = @("*.jpg","*.png","*.gif","*.bmp")
    "Videos" = @("*.mp3","*.mp4","*.avi","*.wma")
}
foreach($t in $types.GetEnumerator()){
    $dest = Join-Path $base $t.Key
    foreach($pat in $t.Value){
        Get-ChildItem -Path "E:\" -Filter $pat -File -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { $_.DirectoryName -notlike "*Organized*" } | 
        ForEach-Object {
            try { Move-Item $_.FullName $dest -Force; $moved++ } catch {}
        }
    }
}
Write-Host "  Moved: $moved files" -ForegroundColor Green

# Summary
$end = Get-Date
Write-Host "`n========== Done ==========" -ForegroundColor Cyan
Write-Host "Empty folders: $emptyCount" -ForegroundColor Green
Write-Host "Files moved: $moved" -ForegroundColor Green
Write-Host "Time: $([math]::Round(($end-$start).TotalSeconds,1)) seconds" -ForegroundColor Yellow
