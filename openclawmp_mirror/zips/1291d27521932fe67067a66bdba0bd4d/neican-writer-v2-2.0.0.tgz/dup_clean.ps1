﻿# Duplicate File Cleanup Script
param([switch]$WhatIf = $false)

$LogFile = "$env:USERPROFILE\.stepclaw\workspace\dup_clean_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$deleted = 0
$freed = 0
$empties = 0

function Log($m, $c="White") {
    Write-Host $m -ForegroundColor $c
    "[$(Get-Date -Format 'HH:mm:ss')] $m" | Out-File $LogFile -Append -Encoding UTF8
}

Log "========== DUPLICATE FILE CLEANUP ==========" "Cyan"

# Find duplicates by hash
Log "`n[1/3] Finding duplicate files..." "Cyan"
$drives = @('E:\','F:\','G:\','H:\')
$allFiles = @()

foreach($d in $drives){
    if(Test-Path $d){
        Log "  Scanning $d..." "Gray"
        $allFiles += Get-ChildItem -Path $d -File -Recurse -ErrorAction SilentlyContinue | 
            Where-Object { $_.Length -gt 10MB } |
            Select-Object FullName, Length, Directory, 
                @{N='Hash';E={(Get-FileHash $_.FullName -Algorithm MD5 -ErrorAction SilentlyContinue).Hash}},
                @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}}
    }
}

# Group by hash
$dupGroups = $allFiles | Where-Object { $_.Hash -ne $null } | Group-Object Hash | Where-Object { $_.Count -gt 1 }
Log "  Found $($dupGroups.Count) duplicate groups" "Yellow"

foreach($g in $dupGroups){
    $items = $g.Group | Sort-Object FullName
    Log "`n  Duplicate: $($items[0].FullName.Split('\')[-1])" "Cyan"
    Log "    Keep: $($items[0].FullName)" "Green"
    
    for($i=1; $i -lt $items.Count; $i++){
        Log "    Delete: $($items[$i].FullName) ($($items[$i].SizeMB) MB)" "Red"
        if(-not $WhatIf){
            try{
                Remove-Item $items[$i].FullName -Force
                $deleted++
                $freed += $items[$i].SizeMB
            }catch{
                Log "    Error: $_" "Red"
            }
        }else{
            $deleted++
            $freed += $items[$i].SizeMB
        }
    }
}

# Remove empty folders
Log "`n[2/3] Removing empty folders..." "Cyan"
foreach($d in $drives){
    if(Test-Path $d){
        Get-ChildItem -Path $d -Directory -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0 } |
        Sort-Object FullName -Descending | ForEach-Object {
            if(-not $WhatIf){ Remove-Item $_.FullName -Force }
            $empties++
        }
    }
}
Log "  Empty folders removed: $empties" "Green"

# Organize files
Log "`n[3/3] Organizing files to E:\Organized..." "Cyan"
$cats = @{
    "Software" = @("*.exe","*.msi","*.zip","*.rar","*.7z","*.iso")
    "Documents" = @("*.pdf","*.doc","*.docx","*.xls","*.xlsx","*.ppt","*.pptx")
    "Images" = @("*.jpg","*.jpeg","*.png","*.gif","*.bmp","*.psd")
    "Videos" = @("*.mp3","*.mp4","*.avi","*.mkv","*.wma","*.wav","*.ncm")
}

$moved = 0
foreach($c in $cats.GetEnumerator()){
    $dest = "E:\Organized\$($c.Key)"
    if(-not (Test-Path $dest)){ New-Item -ItemType Directory -Path $dest -Force | Out-Null }
    
    foreach($p in $c.Value){
        Get-ChildItem -Path "E:\" -Filter $p -File -Recurse -ErrorAction SilentlyContinue | 
        Where-Object { $_.DirectoryName -notlike "*Organized*" } | ForEach-Object {
            $target = Join-Path $dest $_.Name
            if(Test-Path $target){ $target = Join-Path $dest "$($_.BaseName)_$(Get-Random)$($_.Extension)" }
            if(-not $WhatIf){
                try{
                    Move-Item $_.FullName $target -Force
                    Log "  Moved: $($_.Name) -> $($c.Key)" "Green"
                    $moved++
                }catch{
                    Log "  Failed: $($_.Name)" "Red"
                }
            }else{
                Log "  [Preview] Move: $($_.Name) -> $($c.Key)" "Gray"
                $moved++
            }
        }
    }
}

Log "`n========== SUMMARY ==========" "Cyan"
Log "Duplicates deleted: $deleted" "Green"
Log "Space freed: $([math]::Round($freed,2)) MB" "Green"
Log "Empty folders: $empties" "Green"
Log "Files organized: $moved" "Green"
Log "Log: $LogFile" "Gray"
