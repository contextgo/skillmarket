const WebSocket = require('ws');
const fs = require('fs');

require('dotenv').config({ path: __dirname + '/.env' });

const APP_ID = process.env.QIAOQIAO_APP_ID;
const APP_SECRET = process.env.QIAOQIAO_APP_SECRET;
const AGENT_ID = APP_ID;
const WS_URL = 'wss://ws.qiaoqiao.social/agent-direct-ws';

const LOG_FILE = '/tmp/qiaoqiao-ws.log';
const NOTIFY_FILE = '/tmp/qiaoqiao-new-message';

let ws;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let heartbeatInterval;

// 结构化日志
function log(event, data = {}) {
  const logEntry = {
    ts: new Date().toISOString(),
    level: 'INFO',
    event,
    agentId: AGENT_ID,
    ...data
  };
  const logLine = JSON.stringify(logEntry);
  console.log(logLine);
  fs.appendFileSync(LOG_FILE, logLine + '\n');
}

function logError(event, error, data = {}) {
  const logEntry = {
    ts: new Date().toISOString(),
    level: 'ERROR',
    event,
    agentId: AGENT_ID,
    error: (error && error.message) || String(error || 'Unknown error'),
    ...data
  };
  const logLine = JSON.stringify(logEntry);
  console.log(logLine);
  fs.appendFileSync(LOG_FILE, logLine + '\n');
}

// 收到消息后只通知，不自动回复
function handleNewMessage(msg) {
  const requestId = msg.requestId;
  const text = msg.data?.text || '';
  const senderId = msg.data?.senderInfo?.userId || '';
  
  log('dm_received', { requestId, text, senderId, kind: msg.data?.kind });
  
  // 写入通知文件，通知主人手动回复
  const notifyData = { 
    text, 
    senderId, 
    requestId, 
    timestamp: new Date().toISOString() 
  };
  fs.writeFileSync(NOTIFY_FILE, JSON.stringify(notifyData, null, 2));
  
  // 输出醒目的日志提示手动回复
  console.log(`\n═══════════════════════════════════════`);
  console.log(`💬 新消息: ${text}`);
  console.log(`👤 发送者: ${senderId}`);
  console.log(`⚠️  请手动回复！（不要自动回复）`);
  console.log(`═══════════════════════════════════════\n`);
}

function connect() {
  log('ws_connecting');
  
  ws = new WebSocket(WS_URL);

  ws.on('open', () => {
    log('ws_connected');
    reconnectAttempts = 0;
    
    const registerMsg = {
      type: 'agent_direct_register',
      appId: APP_ID,
      appSecret: APP_SECRET,
      agentId: AGENT_ID
    };
    ws.send(JSON.stringify(registerMsg));
  });

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      handleMessage(msg);
    } catch (e) {
      logError('parse_failed', e);
    }
  });

  ws.on('close', () => {
    log('ws_closed_reconnect_scheduled');
    clearInterval(heartbeatInterval);
    scheduleReconnect();
  });

  ws.on('error', (err) => {
    logError('ws_error', err);
  });
}

function handleMessage(msg) {
  switch (msg.type) {
    case 'agent_direct_register_ack':
      if (msg.success) {
        log('ws_register_ok', { agentId: msg.agentId });
        startHeartbeat();
      }
      break;
      
    case 'qiaoqiao_message':
      handleNewMessage(msg);
      break;
      
    case 'agent_direct_dm':
      handleNewMessage(msg);
      break;
      
    case 'heartbeat_ack':
      // 心跳忽略
      break;
  }
}

function startHeartbeat() {
  heartbeatInterval = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'heartbeat' }));
      log('heartbeat_sent');
    }
  }, 30000);
}

function scheduleReconnect() {
  if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
    logError('max_reconnect_attempts_reached');
    return;
  }
  
  const delay = Math.min(30000, 5000 * Math.pow(2, reconnectAttempts));
  reconnectAttempts++;
  log('reconnect_scheduled', { delayMs: delay, attempt: reconnectAttempts });
  
  setTimeout(connect, delay);
}

// 定期打点
setInterval(() => {
  log('runner_metrics', { 
    wsState: ws ? ws.readyState : 'disconnected',
    uptime: process.uptime()
  });
}, 60000);

connect();
log('runner_started');