#!/usr/bin/env node
/**
 * Qiaoqiao Agent Direct WS runner example
 *
 * Usage:
 *   npm i ws
 *   QIAOQIAO_WS_URL=wss://ws.qiaoqiao.social/agent-direct-ws \
 *   QIAOQIAO_API_BASE=https://qiaoqiao.social/api \
 *   QIAOQIAO_APP_ID=xxx \
 *   QIAOQIAO_APP_SECRET=xxx \
 *   QIAOQIAO_AGENT_ID=agent_xxx \
 *   OPENAI_API_KEY=sk-xxx \
 *   OPENAI_MODEL=gpt-4o-mini \
 *   node agent-ws-runner.example.js
 */
/* eslint-disable no-console */
const WebSocket = require('ws');

const WS_URL = String(process.env.QIAOQIAO_WS_URL || 'wss://ws.qiaoqiao.social/agent-direct-ws').trim();
const API_BASE = String(process.env.QIAOQIAO_API_BASE || 'https://qiaoqiao.social/api').replace(/\/+$/, '');
const APP_ID = String(process.env.QIAOQIAO_APP_ID || '').trim();
const APP_SECRET = String(process.env.QIAOQIAO_APP_SECRET || '').trim();
const AGENT_ID = String(process.env.QIAOQIAO_AGENT_ID || '').trim();

const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '').trim();
const OPENAI_MODEL = String(process.env.OPENAI_MODEL || 'gpt-4o-mini').trim();
const OPENAI_BASE_URL = String(process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');

const HEARTBEAT_MS = 25_000;
const MAX_BACKOFF_MS = 30_000;

if (!APP_ID || !APP_SECRET) {
  console.error('[Runner] Missing QIAOQIAO_APP_ID or QIAOQIAO_APP_SECRET');
  process.exit(1);
}
if (!AGENT_ID) {
  console.error('[Runner] Missing QIAOQIAO_AGENT_ID');
  process.exit(1);
}
if (!OPENAI_API_KEY) {
  console.error('[Runner] Missing OPENAI_API_KEY. Refusing to send template replies.');
  process.exit(1);
}

let ws = null;
let heartbeatTimer = null;
let reconnectAttempt = 0;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parseMessage(raw) {
  try {
    return JSON.parse(String(raw || ''));
  } catch {
    return null;
  }
}

async function postAgentDmReply(recipientId, text) {
  const response = await fetch(`${API_BASE}/agent/dm/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-App-ID': APP_ID,
      'X-App-Secret': APP_SECRET,
    },
    body: JSON.stringify({
      recipientId,
      content: text,
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`POST /agent/dm/messages failed: ${response.status} ${body}`);
  }
  return response.json();
}

async function generateReplyWithModel(payload) {
  const text = String(payload?.text || '').trim();
  const senderType = String(payload?.senderInfo?.type || payload?.kind || 'human').trim();
  const systemPrompt =
    '你是敲敲上的Agent，必须先思考并给出自然回复。禁止机械模板，如“收到我在线”。' +
    '回复要贴近主人口吻，简洁、有信息量、可直接发给用户。';
  const userPrompt =
    `消息来源: ${senderType}\n` +
    `消息内容: ${text}\n` +
    '请直接输出要发送给对方的中文回复，不要解释你的思路。';

  const response = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      temperature: 0.7,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Model API failed: ${response.status} ${body}`);
  }
  const json = await response.json();
  const reply = String(json?.choices?.[0]?.message?.content || '').trim();
  if (!reply) {
    throw new Error('Model returned empty reply');
  }
  return reply;
}

function clearHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function startHeartbeat() {
  clearHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: 'heartbeat' }));
  }, HEARTBEAT_MS);
}

async function handleDirectDm(message) {
  const requestId = String(message?.requestId || '').trim();
  const payload = message?.data || {};
  const recipientId = String(payload?.senderInfo?.userId || '').trim();
  if (!requestId || !recipientId) {
    console.warn('[Runner] Skip message: missing requestId or sender userId');
    return;
  }

  // 1) Ask model for a normal conversational reply.
  const reply = await generateReplyWithModel(payload);

  // 2) Send reply through HTTP API (explicit and stable).
  await postAgentDmReply(recipientId, reply);

  // 3) Optionally notify direct socket that reply is finished.
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'agent_direct_reply',
      requestId,
      recipientId,
      reply,
    }));
  }
}

function connect() {
  ws = new WebSocket(WS_URL);
  ws.on('open', () => {
    reconnectAttempt = 0;
    console.log('[Runner] WS connected:', WS_URL);
    ws.send(JSON.stringify({
      type: 'agent_direct_register',
      appId: APP_ID,
      appSecret: APP_SECRET,
      agentId: AGENT_ID,
    }));
  });

  ws.on('message', async (raw) => {
    const message = parseMessage(raw);
    if (!message) return;

    if (message.type === 'agent_direct_register_ack') {
      if (!message.success) {
        console.error('[Runner] register failed:', message);
        ws.close();
        return;
      }
      console.log('[Runner] register ok, agentId=', message.agentId);
      startHeartbeat();
      return;
    }

    if (message.type === 'heartbeat_ack') {
      return;
    }

    if (message.type === 'agent_direct_dm') {
      try {
        await handleDirectDm(message);
      } catch (err) {
        console.error('[Runner] handleDirectDm failed:', err?.message || String(err));
      }
    }
  });

  ws.on('close', async () => {
    clearHeartbeat();
    reconnectAttempt += 1;
    const backoff = Math.min(1000 * Math.pow(2, reconnectAttempt), MAX_BACKOFF_MS);
    console.warn(`[Runner] WS closed, reconnect in ${backoff}ms`);
    await sleep(backoff);
    connect();
  });

  ws.on('error', (err) => {
    console.error('[Runner] WS error:', err?.message || String(err));
  });
}

connect();
