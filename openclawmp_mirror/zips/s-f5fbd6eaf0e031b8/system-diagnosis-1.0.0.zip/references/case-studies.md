# System Diagnosis 诊断案例库

## 案例1: IAT槽为0导致CALL失效

### 触发条件
32-bit CALL [mem32] 读取到 0 / 0xFFFFFFFF / 0xCCCCCCCC / 0xCDCDCDCD 等哨兵值

### 诊断信号
- `exec_call.c` 内 `is_uninitialized_thunk32()` 命中
- 运行日志出现 "keeping IAT=0"/"Invalid INT/IAT pointers"

### 根因
Import/IAT 修复未能解析导入（导出缺失、VirtualDLL 无有效头、resolver 返回NULL、或 delay-load 未触发）

### 修复方案
1. 先确认为"导出缺失"还是"解析失败"：对照 `vdll_export_tables.runtime.json` 是否存在该 DLL!API
2. 若"已实现但未导出"：只能做接线（模式A），不得补实现
3. 若"真实缺口"：登记到 gap C 类

### 验真信号
以最小样本触发一次导入，确保该 IAT 槽不再为0，且 runtime export-index 对应条目为 REAL

---

## 案例2: VirtualDLL缺少有效头导致导出表无效

### 触发条件
VirtualDLL 在 VA 范围内存在，但导出解析认为"Invalid DOS signature"

### 诊断信号
`pe_loader/mnq_virtual_dll_export.c` 的 `mnq_vdll_ensure_minimal_headers()` 防线触发

### 根因
虚拟 DLL backing memory 只有占位数据，无有效 PE 头/导出目录，导致 resolver 失败

### 修复方案
VirtualDLL 必须确保最小 DOS/NT 头与导出目录存在，导出表必须能被 runtime dump 出来并包含目标符号

### 验真信号
运行时生成 `vdll_export_tables.runtime.json`，检查对应 DLL 存在且包含 exports 列表；导入后 IAT 不为0

---

## 案例3: Stub遮挡真实实现

### 触发条件
同名导出先注册为 stub，后续接线/真实实现不生效或被重复注册逻辑跳过

### 诊断信号
- runtime export-index 显示 `impl_type=="SUCCESS_STUB"` 但扫描/对账显示已存在 handler/FNID/dispatch
- `vdll_register/register_win32_stubs.c::func_db_set()` 的覆盖日志（override/reject）可定位覆盖顺序

### 根因
注册顺序/去重逻辑/重复 add 导致 REAL 未能覆盖 stub，或工具脚本误判

### 修复方案
以 "SUCCESS_STUB→REAL 允许覆盖" 为裁决，在导出层把 stub 改为 `is_fnid+fnid`（接线），不要在业务侧补逻辑

### 验真信号
同一 API 在 before/after 的 export-index 中从 SUCCESS_STUB 变为 REAL（数字闭环）

---

## 案例4: 入口识别路径过多导致漂移

### 触发条件
新增兼容性需求时，倾向继续在 `exec_call.c` 添加分支

### 诊断信号
`exec_call.c` 同时包含 legacy syscall、host stub、sim func、FNID trampoline、ULS fallback 等大量逻辑分支

### 根因
把"迁移策略问题"当成"执行器实现问题"

### 修复方案
任何新增入口识别必须先落入三种迁移模式（A/B/C）并提供审计点；程序特征补丁必须归档到 `game_profiles/*`，不得继续写 RIP 魔数拦截进 exec_main/exec_call

### 验真信号
新增兼容性条目时，audit 产物能反映为导出接线/模式变化，而不是 exec_call 分支数增加

---

## 案例5: Win32启动阶段TEB/PEB/FS初始化链路依赖隐式化

### 触发条件
某些PE的import table为空/跳过IAT修复，导致错过FS初始化

### 诊断信号
HL2/CRT对 FS:[0x18]/FS:[0x30] 的访问触发越界/随机指针

### 根因
TEB/PEB/FS初始化在import修复流程中触发，若某个PE跳过IAT修复则可能错过

### 修复方案
把"TEB/PEB/FS初始化"提升为boot phase的强制步骤（与import是否存在解耦），并在status/audit里显式标记

### 验真信号
所有PE启动时FS base正确建立，TLS访问不越界

---

## 案例6: UCRT stdio init自旋热点

### 触发条件
slice热点落在`UCRTBASE.DLL+0x0006f54a`，触发`BRG-SPINLOOP-YIELD-01`

### 诊断信号
`blocked_user_idle` / `host_yield`，阻断窗口链推进

### 根因
UCRT早期初始化阶段的自旋等待

### 修复方案（BOOTSTRAP-only）
- **id**: `BRG-UCRT-STDIO-SPINBREAK-01`
- **gate**: hello2-only + `MNQ_CRT_BRINGUP=1 && window_created==0` + RIP落点匹配
- **action**: ret-resync（带callsite证明）或in-function的`jne taken`
- **budget**: 默认4次
- **退场**: `window_created==1`后自动失效

### 验真信号
推进到下一个blocker（优先WinChain），避免卡死在helper尾部循环

---

## 诊断检查清单

### 启动前检查
- [ ] 环境变量/配置正确
- [ ] 依赖文件存在
- [ ] 权限足够

### 运行时检查
- [ ] 日志级别设置正确
- [ ] 审计产物生成正常
- [ ] 第一缺口可识别

### 问题发生后检查
- [ ] 触发条件已记录
- [ ] 诊断信号已收集
- [ ] 证据线完整
- [ ] 吸引子类型已识别
- [ ] 修复方案已评估
- [ ] 回滚方式已准备
