#!/usr/bin/env python3
"""
系统诊断工具 - 证据线生成器
生成标准化的诊断记录格式
"""
import json
import datetime
import sys

class DiagnosisRecorder:
    """诊断记录器"""
    
    def __init__(self, problem_id=None):
        self.problem_id = problem_id or self._generate_id()
        self.records = []
        
    def _generate_id(self):
        """生成问题ID"""
        now = datetime.datetime.now()
        return now.strftime("%Y%m%d") + "-" + str(now.hour * 100 + now.minute)
    
    def record_trigger(self, operation, input_data, environment):
        """记录触发条件"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "TRIGGER",
            "operation": operation,
            "input": input_data,
            "environment": environment
        }
        self.records.append(record)
        return self
    
    def record_signal(self, level, signal_type, details, related_id=None):
        """记录诊断信号"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "level": level,  # ERROR/WARNING/INFO
            "type": "SIGNAL",
            "signal_type": signal_type,
            "details": details,
            "related_id": related_id
        }
        self.records.append(record)
        return self
    
    def identify_first_halt(self, location, layer, description):
        """标识第一缺口"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "FIRST_HALT",
            "location": location,
            "layer": layer,  # A/B/C
            "description": description
        }
        self.records.append(record)
        return self
    
    def analyze_attractor(self, attractor_type, trigger_conditions, stable_state):
        """分析吸引子"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "ATTRACTOR",
            "attractor_type": attractor_type,  # high_survival/failure_branch/cleanup_reflow
            "trigger_conditions": trigger_conditions,
            "stable_state": stable_state
        }
        self.records.append(record)
        return self
    
    def propose_fix(self, minimal_fix, impact_scope):
        """提出修复方案"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "FIX_PROPOSAL",
            "minimal_fix": minimal_fix,
            "impact_scope": impact_scope
        }
        self.records.append(record)
        return self
    
    def define_verification(self, method, success_criteria):
        """定义验真信号"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "VERIFICATION",
            "method": method,
            "success_criteria": success_criteria
        }
        self.records.append(record)
        return self
    
    def prepare_rollback(self, backup_point, rollback_command):
        """准备回滚方式"""
        record = {
            "timestamp": datetime.datetime.now().isoformat(),
            "type": "ROLLBACK",
            "backup_point": backup_point,
            "rollback_command": rollback_command
        }
        self.records.append(record)
        return self
    
    def export(self, format='json'):
        """导出记录"""
        if format == 'json':
            return json.dumps({
                "problem_id": self.problem_id,
                "records": self.records,
                "summary": self._generate_summary()
            }, indent=2, ensure_ascii=False)
        elif format == 'markdown':
            return self._export_markdown()
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _generate_summary(self):
        """生成摘要"""
        types = [r['type'] for r in self.records]
        return {
            "total_records": len(self.records),
            "has_trigger": "TRIGGER" in types,
            "has_first_halt": "FIRST_HALT" in types,
            "has_attractor": "ATTRACTOR" in types,
            "has_fix": "FIX_PROPOSAL" in types,
            "status": "complete" if "VERIFICATION" in types else "incomplete"
        }
    
    def _export_markdown(self):
        """导出为Markdown格式"""
        lines = [f"# 诊断记录 [{self.problem_id}]\n"]
        
        for record in self.records:
            ts = record['timestamp']
            rtype = record['type']
            
            if rtype == 'TRIGGER':
                lines.append(f"## 触发条件\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 操作: {record['operation']}")
                lines.append(f"- 输入: {record['input']}")
                lines.append(f"- 环境: {record['environment']}\n")
            
            elif rtype == 'SIGNAL':
                lines.append(f"## 诊断信号 [{record['level']}]\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 类型: {record['signal_type']}")
                lines.append(f"- 详情: {record['details']}\n")
            
            elif rtype == 'FIRST_HALT':
                lines.append(f"## 第一缺口\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 位置: {record['location']}")
                lines.append(f"- 层级: {record['layer']}")
                lines.append(f"- 描述: {record['description']}\n")
            
            elif rtype == 'ATTRACTOR':
                lines.append(f"## 吸引子分析 [{record['attractor_type']}]\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 触发条件: {record['trigger_conditions']}")
                lines.append(f"- 稳定状态: {record['stable_state']}\n")
            
            elif rtype == 'FIX_PROPOSAL':
                lines.append(f"## 修复方案\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 最小修复: {record['minimal_fix']}")
                lines.append(f"- 影响范围: {record['impact_scope']}\n")
            
            elif rtype == 'VERIFICATION':
                lines.append(f"## 验真信号\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 验证方法: {record['method']}")
                lines.append(f"- 成功标准: {record['success_criteria']}\n")
            
            elif rtype == 'ROLLBACK':
                lines.append(f"## 回滚方式\n")
                lines.append(f"- 时间: {ts}")
                lines.append(f"- 备份点: {record['backup_point']}")
                lines.append(f"- 回滚命令: {record['rollback_command']}\n")
        
        return '\n'.join(lines)


def main():
    """命令行入口"""
    if len(sys.argv) < 2:
        print("Usage: python diagnosis_tool.py <command> [args]")
        print("Commands: create, export, analyze")
        return
    
    command = sys.argv[1]
    
    if command == 'create':
        # 创建示例诊断记录
        recorder = DiagnosisRecorder("20260323-001")
        recorder.record_trigger(
            operation="启动程序",
            input_data="--mode=debug",
            environment="macOS 15.3, OpenClaw 2026.3.12"
        )
        recorder.record_signal(
            level="ERROR",
            signal_type="连接失败",
            details="无法连接到API服务器"
        )
        recorder.identify_first_halt(
            location="api_client.c:156",
            layer="A",
            description="DNS解析失败，导致连接超时"
        )
        print(recorder.export('markdown'))
    
    elif command == 'export':
        # 从stdin读取JSON并导出
        data = json.load(sys.stdin)
        recorder = DiagnosisRecorder(data['problem_id'])
        recorder.records = data['records']
        print(recorder.export('markdown'))
    
    else:
        print(f"Unknown command: {command}")

if __name__ == '__main__':
    main()
