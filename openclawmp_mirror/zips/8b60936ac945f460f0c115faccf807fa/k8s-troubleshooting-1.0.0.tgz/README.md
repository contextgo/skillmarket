# Kubernetes 故障排查手册

## 快速诊断
kubectl get pods -A | grep -v Running
kubectl describe pod <name>
kubectl logs <pod> --previous

## Top 10 问题
1. CrashLoopBackOff -> logs --previous + readinessProbe
2. OOMKilled -> 增加 memory limit
3. ImagePullBackOff -> 检查 imagePullSecrets
4. Pending -> 扩容或降 requests
5. ContainerCreating -> ConfigMap/PVC 绑定
6. DNS 失败 -> 检查 CoreDNS、networkPolicy
7. Service 不通 -> Endpoints + iptables
8. 节点 NotReady -> kubelet 状态
9. 存储挂载失败 -> PVC/PV 状态
10. 资源配额超限 -> ResourceQuota 查看

## 网络排查
nslookup kubernetes.default（DNS）
curl service:port/health（Service 连通）
kubectl get networkpolicies -A（策略）
