#!/usr/bin/env python3
"""
MNQ-Cloud 参数扫描器
自动遍历参数组合，调用 API 寻找最优配置
"""
import requests
import json
import csv
import os
from datetime import datetime

API_URL = "http://8.148.199.28:8000/simulate/mnq8"

def scan_intercom(mic_range, speaker_range, echo=0.3, noise=0.2, distance=1.5, steps=1024):
    """扫描声学系统参数"""
    results = []
    best = {"score": -1e9}
    
    for mic in mic_range:
        for spk in speaker_range:
            payload = {
                "experiment": "intercom",
                "unit_mode": "acoustic",
                "mic_gain": round(mic, 2),
                "speaker_gain": round(spk, 2),
                "echo_level": echo,
                "noise_level": noise,
                "distance_m": distance,
                "steps": steps,
                "seed": 42
            }
            try:
                r = requests.post(API_URL, json=payload, timeout=30)
                res = r.json()
                domain = res.get("domain_result", res)
                coh = domain.get("coherence", 0)
                
                record = {
                    "mic_gain": mic,
                    "speaker_gain": spk,
                    "coherence": coh,
                    "gain_optimal": domain.get("gain_optimal", 0),
                    "echo_suppression_dB": domain.get("echo_suppression_dB", 0),
                    "noise_reduction_dB": domain.get("noise_reduction_dB", 0),
                    "score": coh
                }
                results.append(record)
                
                if coh > best["score"]:
                    best = record.copy()
                    
                print(f"  mic={mic:.2f} spk={spk:.2f} → coherence={coh:.2e}")
            except Exception as e:
                print(f"  mic={mic:.2f} spk={spk:.2f} → ERROR: {e}")
    
    # 保存CSV
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = f"scan_intercom_{timestamp}.csv"
    if results:
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
    
    print(f"\n=== 最优组合 ===")
    print(f"mic_gain={best.get('mic_gain')}, speaker_gain={best.get('speaker_gain')}")
    print(f"coherence={best.get('coherence')}")
    print(f"结果文件: {csv_path}")
    
    return results, best

if __name__ == "__main__":
    import numpy as np
    
    print("MNQ-Cloud 参数扫描器")
    print("=" * 40)
    
    mic_range = np.linspace(0.3, 1.0, 8)
    speaker_range = np.linspace(0.3, 1.0, 8)
    
    results, best = scan_intercom(mic_range, speaker_range)
