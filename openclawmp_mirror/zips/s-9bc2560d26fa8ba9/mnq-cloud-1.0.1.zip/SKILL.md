---
name: mnq-cloud
description: >
  MNQ-Cloud 信息波仿真平台 API 技能。通过统一 HTTP 接口调用五域（原子/介观/宏观宇宙/声学/光显）能量-相干计算引擎，实现跨尺度仿真模拟。
  触发场景：(1) 调用 MNQ API 进行能量仿真模拟；(2) 声学系统降噪/回声抑制优化；(3) 分子/原子级能量共振模拟；(4) 宇宙/黑洞尺度能量演化；(5) LED灯牌可视化驱动；(6) 参数扫描寻找最优组合；(7) 将任意领域问题映射为能流计算。
  触发词：MNQ、能量弦、仿真、模拟、降噪、回声抑制、相干度、能流计算、mnq-cloud、simulate。
---

# MNQ-Cloud 信息波仿真平台

## 概述

MNQ-Cloud 是基于「信息波机制」的多领域仿真平台。通过统一 API 接口调用不同领域的仿真模块，实现从原子到宇宙的能量-相干计算。

- **API 地址**：`http://8.148.199.28:8000/simulate/mnq8`
- **健康检查**：`http://8.148.199.28:8000/health`
- **请求方式**：POST JSON
- **无需认证**：不需要 token 或 API Key

## 五域总览

| 领域 | experiment | unit_mode | 典型应用 |
|------|-----------|-----------|---------|
| 原子层 | `proton` | `atomic` | 药物能量共振、分子相干模拟 |
| 介观层 | `quantum` | `meso` | 水文、天气、地震能量演化 |
| 宏观宇宙 | `cosmos` | `macro` | 黑洞、行星能量守恒演化 |
| 声学系统 | `intercom` | `acoustic` | 对讲系统降噪、啸叫抑制 |
| 光显层 | `led` | `acoustic` | LED灯牌可视化反馈 |

## 调用方法

### 1. 先检查服务器状态

```bash
curl -s http://8.148.199.28:8000/health
```

期望返回：`{"status":"ok","engine":"MNQ8-Core"}`

如果不通，告知用户服务器可能离线。

### 2. 调用仿真接口

使用 exec 工具执行 curl 命令：

```bash
curl -s -X POST "http://8.148.199.28:8000/simulate/mnq8" \
  -H "Content-Type: application/json" \
  -d '{ JSON参数 }'
```

## 各领域参数与示例

### 声学系统（intercom）— 对讲机降噪

**参数：**

| 参数 | 类型 | 说明 | 范围 |
|------|------|------|------|
| `experiment` | string | 固定 `"intercom"` | |
| `unit_mode` | string | 固定 `"acoustic"` | |
| `mic_gain` | float | 麦克风增益 | 0-1 |
| `speaker_gain` | float | 喇叭增益 | 0-1 |
| `echo_level` | float | 回声水平 | 0-1 |
| `noise_level` | float | 噪声水平 | 0-1 |
| `distance_m` | float | 距离（米） | >0 |
| `steps` | int | 迭代步数 | 256-4096 |
| `seed` | int | 随机种子 | 任意整数 |

**示例：**
```json
{
  "experiment": "intercom",
  "unit_mode": "acoustic",
  "mic_gain": 0.8,
  "speaker_gain": 0.7,
  "echo_level": 0.3,
  "noise_level": 0.2,
  "distance_m": 1.5,
  "steps": 1024,
  "seed": 42
}
```

**返回字段解读：**
- `coherence` — 相干度，越高系统越稳定
- `gain_optimal` — 自动计算的最佳音量
- `echo_suppression_dB` — 回声抑制量（dB）
- `noise_reduction_dB` — 噪声降低量（dB）
- `horizon_length_m` — 作用尺度长度
- `horizon_time_s` — 作用时间尺度

### 原子层（proton）— 分子能量模拟

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `experiment` | string | 固定 `"proton"` |
| `unit_mode` | string | 固定 `"atomic"` |
| `steps` | int | 迭代步数 |
| `epsilon` | float | 精度控制（如 1e-7）|
| `seed` | int | 随机种子 |

**示例：**
```json
{
  "experiment": "proton",
  "unit_mode": "atomic",
  "steps": 2048,
  "epsilon": 1e-7,
  "seed": 42
}
```

**返回字段：**
- `mean_energy_J` — 平均能量（焦耳）
- `proton_radius_m` — 质子半径（米）
- `coherence` — 相干度
- `tau_converge_s` — 收敛时间

### 宏观宇宙（cosmos）— 恒星/黑洞模拟

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `experiment` | string | 固定 `"cosmos"` |
| `unit_mode` | string | 固定 `"macro"` |
| `mass_M` | float | 质量（kg），如太阳质量 1.988e30 |
| `steps` | int | 迭代步数 |
| `epsilon` | float | 精度控制 |
| `seed` | int | 随机种子 |

**示例：**
```json
{
  "experiment": "cosmos",
  "unit_mode": "macro",
  "mass_M": 1.988e30,
  "steps": 4096,
  "epsilon": 1e-7,
  "seed": 42
}
```

**返回字段：**
- `mean_energy_J` — 平均能量
- `horizon_radius_m` — 视界半径（米）
- `horizon_time_s` — 视界时间
- `mass_equiv_kg` — 等效质量
- `coherence` — 相干度

### LED灯牌（led）— 可视化反馈

**参数：** 需要先调用 intercom 获取结果，再传入

| 参数 | 类型 | 说明 |
|------|------|------|
| `experiment` | string | 固定 `"led"` |
| `unit_mode` | string | 固定 `"acoustic"` |
| `gain_optimal` | float | 来自 intercom 结果 |
| `coherence` | float | 来自 intercom 结果 |
| `echo_suppression_dB` | float | 来自 intercom 结果 |
| `noise_reduction_dB` | float | 来自 intercom 结果 |

**返回字段：**
- `led_r/g/b` — RGB颜色值（0-1）
- `brightness` — 亮度
- `pwm_duty` — PWM占空比
- `status` — 状态

### 介观层（quantum）— 水文/气象/地震

**⚠️ 当前状态：适配器缺失（adapter_quantum.py 未部署），调用会报错**

**参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `experiment` | string | 固定 `"quantum"` |
| `unit_mode` | string | 固定 `"meso"` |
| `E_scale` | float | 能量缩放 |
| `coherence` | float | 初始相干度 |
| `steps` | int | 迭代步数 |

如遇报错 `Adapter not found`，告知用户介观层模块暂未上线。

## 泛化映射规则

当用户问题不直接对应五域时，按以下步骤判断是否可映射：

### 映射条件（需满足至少3项）

1. **C1** — 能否定义能量函数或目标势场？
2. **C2** — 变量可否离散为有限格点？
3. **C3** — 结果可否通过稳态/收敛判断？
4. **C4** — 可否接受近似解？
5. **C5** — 变量间是否存在耦合？

### 映射方法

将问题字段映射为 MNQ 参数：
- **Ω（能量强度）** → 归一化到 0-1
- **φ（相位）** → 映射为 0-2π
- **η（自调节能力）** → 反馈增益
- **κ（耦合系数）** → 变量间关联强度
- **ε_unlock（重置阈值）** → 失衡触发条件

使用通用调用模板：
```json
{
  "experiment": "quantum",
  "unit_mode": "meso",
  "Eta": 0.3,
  "Kappa": 0.6,
  "EpsUnlock": 0.05,
  "steps": 1024
}
```

## 参数扫描

当需要寻找最优参数组合时，用循环调用 API 实现网格搜索。
详细扫描脚本参见 [scripts/param_scanner.py](scripts/param_scanner.py)

## 结果解读

| 指标 | 含义 | 理想趋势 |
|------|------|---------|
| `coherence` | 相干度，系统稳定性 | 越高越好 |
| `gain_optimal` | 最优增益/强度 | 接近 0.5 |
| `horizon_length_m` | 作用尺度长度 | 与系统设定接近 |
| `tau_converge_s` | 收敛步数 | 越小越好 |
| `brightness/pwm_duty` | 光输出 | 表示信号强度 |

## 三尺度单位锚定

| 尺度 | unit_mode | 能量 α (J) | 长度 β (m) | 时间 γ (s) |
|------|-----------|-----------|-----------|-----------|
| 原子层 | atomic | 2.18e-18 | 5.29e-11 | 1.77e-19 |
| 介观层 | meso | 1.0e-20 | 1.0e-10 | 1.0e-15 |
| 宏观宇宙 | macro | 3.25e+28 | 6.957e+08 | 86400 |

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 连接超时 | 服务器离线 | 先检查 /health |
| `Adapter not found` | 适配器未部署 | 通知管理员（联系 17681941080）|
| coherence 极低 | 信号过强或噪声太高 | 降低 mic_gain / noise_level |
| 返回为空 | 参数拼写错误 | 检查 experiment 和 unit_mode |
