<p align="center">
  <h1 align="center">✈️ FlyAI 技能</h1>
  <p align="center">
    <strong>由 Fliggy 提供的旅行搜索功能，直接集成于 Claude Code、OpenClaw 和其他兼容技能的代理中。</strong>
  </p>
  <p align="center">
    使用自然语言搜索航班、酒店、景点、音乐会等，无需打开浏览器标签或切换应用，只需提问即可。
  </p>
  <p align="center">
    <a href="https://open.fly.ai/">主页</a> ·
    <a href="#quick-start">快速开始</a> ·
    <a href="#commands">命令</a> ·
    <a href="#examples">示例</a>
  </p>
</p>

---

## 为什么选择 FlyAI？

你正在与你的 AI 编码代理进行深入对话——计划旅行、研究场所、比较选项。FlyAI 允许你在不离开终端的情况下实时搜索旅行库存。它将 [Claude Code](https://docs.anthropic.com/en/docs/claude-code)、[OpenClaw](https://github.com/nicepkg/openclaw) 和其他兼容技能的代理连接到 [Fliggy](https://www.fliggy.com/) 的庞大旅行平台（隶属于阿里巴巴集团），几秒钟内即可获得结构化、可预订的结果。

- **自然语言输入，结构化数据输出**——用普通英语或中文提问，获得可以管道、过滤或渲染的 JSON
- **四个专业搜索命令**——广泛发现或深入比较，任你选择
- **可预订结果**——每个结果都包含直接预订链接
- **零配置即可开始**——开箱即用，可选 API 密钥以获得增强结果

## 快速开始

### 第一步 — 安装技能

**OpenClaw：**

```bash
# 通过 clawhub（推荐）
clawhub install flyai

# 或通过 npx
npx skills add alibaba-flyai/flyai-skill
```

**Claude Code：**

在 Claude Code 中运行以下命令：

```
/plugin marketplace add alibaba-flyai/flyai-skill
/plugin install flyai@alibaba-flyai-flyai-skill
```

或者直接复制技能目录：

```bash
cp -r /path/to/flyai-skill ~/.claude/skills/flyai
```

### 第二步 — 安装 CLI

```bash
npm i -g @fly-ai/flyai-cli
```

### 第三步 — 验证

```bash
flyai fliggy-fast-search --query "东京的旅游景点"
```

你应该看到结构化的 JSON 输出。你已经准备好使用了。

### 第四步 — 配置（可选）

技能无需任何 API 密钥即可工作。为了获得增强结果，请设置一个：

```bash
flyai config set FLYAI_API_KEY "你的密钥"
```

## 命令

FlyAI 提供了四个命令，每个都针对不同的搜索模式进行了优化：

| 命令 | 目的 | 必需参数 |
|------|------|----------|
| `fliggy-fast-search` | 在所有旅行类别中进行自然语言元搜索 | `--query` |
| `search-flight` | 具有深度过滤的结构化航班搜索 | `--origin` |
| `search-hotels` | 根据目的地进行结构化酒店搜索 | `--dest-name` |
| `search-poi` | 根据城市搜索景点和 POI | `--city-name` |

### `fliggy-fast-search` — 广泛发现

一个查询，所有类别。酒店、航班、票务、旅游、邮轮、签证、SIM 卡——它搜索一切。

**OpenClaw：**

```
/flyai fliggy-fast-search --query "杭州3日游"
/flyai fliggy-fast-search --query "法国签证"
/flyai fliggy-fast-search --query "上海邮轮"
```

**Claude Code：**

```
/flyai fliggy-fast-search --query "杭州3日游"
/flyai fliggy-fast-search --query "法国签证"
/flyai fliggy-fast-search --query "上海邮轮"
```

**CLI：**

```bash
flyai fliggy-fast-search --query "杭州3日游"
```

### `search-flight` — 航班比较

具有排序、舱位等级、价格上限和时间过滤的结构化航班搜索。

**OpenClaw / Claude Code：**

```
/flyai search-flight --origin "北京" --destination "上海" --dep-date 2026-04-15
```

**CLI：**

```bash
# 基本的单程搜索
flyai search-flight --origin "北京" --destination "上海" --dep-date 2026-04-15

# 往返，仅限直飞，按价格排序（低到高）
flyai search-flight \
  --origin "上海" --destination "东京" \
  --dep-date 2026-04-20 --back-date 2026-04-25 \
  --journey-type 1 --sort-type 3
```

<details>
<summary><strong>所有航班搜索选项</strong></summary>

| 标志 | 描述 |
|------|------|
| `--origin` | 出发城市或机场 **（必需）** |
| `--destination` | 到达城市或机场 |
| `--dep-date` | 出发日期 (`YYYY-MM-DD`) |
| `--dep-date-start` / `--dep-date-end` | 出发日期范围 |
| `--back-date` | 返回日期 |
| `--back-date-start` / `--back-date-end` | 返回日期范围 |
| `--journey-type` | `1` = 直飞，`2` = 中转 |
| `--seat-class-name` | 舱位等级名称 |
| `--transport-no` | 航班号 |
| `--transfer-city` | 中转城市 |
| `--dep-hour-start` / `--dep-hour-end` | 出发时间范围 |
| `--arr-hour-start` / `--arr-hour-end` | 到达时间范围 |
| `--total-duration-hour` | 最大飞行时长（小时） |
| `--max-price` | 价格上限 |
| `--sort-type` | `1` 价格降序 · `2` 推荐 · `3` 价格升序 · `4` 时长升序 · `5` 时长降序 · `6` 提前出发 · `7` 晚出发 · `8` 直飞优先 |

</details>

### `search-hotels` — 酒店比较

根据目的地进行搜索，具有星级、床型、价格范围和附近 POI 的过滤器。

**OpenClaw / Claude Code：**

```
/flyai search-hotels --dest-name "杭州" --poi-name "西湖" --check-in-date 2026-04-10 --check-out-date 2026-04-12
```

**CLI：**

```bash
# 杭州西湖附近的酒店
flyai search-hotels \
  --dest-name "杭州" --poi-name "西湖" \
  --check-in-date 2026-04-10 --check-out-date 2026-04-12

# 三四星级酒店在三亚，每晚不超过800元，按评分排序
flyai search-hotels \
  --dest-name "三亚" --hotel-stars "4,5" \
  --sort rate_desc --max-price 800
```

<details>
<summary><strong>所有酒店搜索选项</strong></summary>

| 标志 | 描述 |
|------|------|
| `--dest-name` | 目的地（国家/省/市/区） **（必需）** |
| `--key-words` | 搜索关键词 |
| `--poi-name` | 附近景点名称 |
| `--hotel-types` | `酒店`（hotel）· `民宿`（homestay）· `客栈`（inn） |
| `--sort` | `distance_asc` · `rate_desc` · `price_asc` · `price_desc` · `no_rank` |
| `--check-in-date` | 入住日期 (`YYYY-MM-DD`) |
| `--check-out-date` | 退房日期 (`YYYY-MM-DD`) |
| `--hotel-stars` | 星级，用逗号分隔（`1`–`5`） |
| `--hotel-bed-types` | `大床房`（king）· `双床房`（twin）· `多床房`（multi） |
| `--max-price` | 每晚最高价格（人民币） |

</details>

### `search-poi` — 景点与活动

根据城市、类别或等级查找景点——从AAAAA级景点到当地冲浪学校。

**OpenClaw / Claude Code：**

```
/flyai search-poi --city-name "西安" --category "历史古迹"
```

**CLI：**

```bash
# 西安的历史景点
flyai search-poi --city-name "西安" --category "历史古迹"

# 北京的顶级景点
flyai search-poi --city-name "北京" --poi-level 5

# 杭州的西湖和园林
flyai search-poi --city-name "杭州" --keyword "西湖" --category "山湖田园"
```

<details>
<summary><strong>所有 POI 搜索选项</strong></summary>

| 标志 | 描述 |
|------|------|
| `--city-name` | 城市名称 **（必需）** |
| `--keyword` | 景点名称关键词 |
| `--poi-level` | 景点等级 (`1`–`5`) |
| `--category` | 单个类别，从以下选择：自然风光 · 山湖田园 · 森林丛林 · 峡谷瀑布 · 沙滩海岛 · 沙漠草原 · 人文古迹 · 古镇古村 · 历史古迹 · 园林花园 · 宗教场所 · 主题乐园 · 水上乐园 · 影视基地 · 动物园 · 植物园 · 海洋馆 · 体育场馆 · 演出赛事 · 剧院剧场 · 博物馆 · 纪念馆 · 展览馆 · 地标建筑 · 市集 · 文创街区 · 城市观光 · 滑雪 · 漂流 · 冲浪 · 潜水 · 露营 · 温泉 |

</details>

## 示例

### OpenClaw

在 OpenClaw 中自然输入——FlyAI 在旅行查询上自动激活：

> 找出北京到上海下周五的直飞航班，价格低于600元

> 比较上海外滩附近的5星级酒店，本周末入住

> 成都有哪些顶级景点？我对自然和历史感兴趣

或者直接使用斜杠命令：

```
/flyai search-flight --origin "北京" --destination "上海" --dep-date 2026-04-25 --max-price 600
```

### Claude Code

在 Claude Code 中自然提问或使用 `/flyai` 斜杠命令：

> 我计划去日本5天——搜索签证信息、从上海出发的航班和东京的酒店

> 找出杭州正在发生的音乐会和现场活动

```
/flyai fliggy-fast-search --query "从上海出发的5天日本之旅"
/flyai search-hotels --dest-name "东京" --check-in-date 2026-05-01 --check-out-date 2026-05-06
```

## 工作原理

```
你向你的代理提问 ──→ FlyAI 技能激活 ──→ flyai-cli 运行 ──→ Fliggy MCP API
                                                                         │
你看到丰富的结果 ←── 代理格式化 Markdown ←── JSON 响应 ←──────┘
```

- **运行时**：Node.js
- **输出**：单行 JSON 到 `stdout`，错误/提示到 `stderr`
- **上下文隔离**：每个命令在其自己的执行上下文中运行
- **模式匹配**：基于意图的激活，优先级为 90——代理自动将旅行查询路由到 FlyAI

## 覆盖的旅行场景

FlyAI 不只是针对航班和酒店。它涵盖了整个旅行生命周期：

| 类别 | 示例 |
|------|------|
| **交通** | 航班、机场接送、租车、包车 |
| **住宿** | 酒店、民宿、客栈、酒店+航班套餐 |
| **体验** | 景点门票、一日游、导游游、定制之旅 |
| **活动** | 音乐会、体育赛事、表演艺术、动漫活动 |
| **服务** | 签证、旅行保险、SIM 卡、WiFi 租赁 |
| **旅行** | 邮轮、周末度假、蜜月、家庭度假、研学旅行 |

## 许可证

[MIT](LICENSE) — 版权所有 © 2026 alibaba-flyai