---
name: btc-halving-cycle-quantitative-model
description: "Quantitative model for Bitcoin halving cycle price projections based on stock-to-flow, demand dynamics, and historical pattern matching"
version: 1.0.0
---

# BTC Halving Cycle Quantitative Model

A data-driven framework for projecting Bitcoin price trajectories around halving events, combining stock-to-flow analysis, on-chain demand metrics, and macro overlays.

## Core Model Components

### 1. Stock-to-Flow (S2F) Base Model

```
S2F_Ratio = Total_Supply / Annual_New_Supply
Implied_Price = e^(3.21 × ln(S2F) + 1.48)  [PlanB model]

Post-2024 Halving: S2F ≈ 112
Post-2028 Halving: S2F ≈ 224
```

### 2. Demand-Supply Equilibrium

```
Equilibrium_Price = (Daily_Institutional_Demand × 365) / Post_Halving_Annual_Supply
```

Key demand drivers:
- Spot ETF inflows (dominant post-2024)
- Corporate treasury allocations (MicroStrategy, Tesla pattern)
- Miner selling pressure (hash rate adjusted)
- Retail participation (on-chain active addresses)

### 3. Cycle Phase Classification

| Phase | Timing (from halving) | Price Pattern | Duration |
|-------|----------------------|---------------|----------|
| Accumulation | 0-6 months | Sideways/gradual rise | 180 days |
| Bull Run | 6-14 months | Exponential growth | 240 days |
| Blow-off Top | 14-18 months | Parabolic spike | 120 days |
| Bear Market | 18-48 months | Drawdown 65-80% | 900 days |

### 4. Macro Overlay Adjustments

```
Adjusted_Target = Base_Target × Macro_Multiplier

Macro_Multiplier factors:
- Fed rate cycle: +0.3 if cutting, -0.2 if hiking
- USD strength: -0.15 per 5% DXY rise from baseline
- Geopolitical risk: +0.1 per 20pt VIX rise
- Risk appetite: +0.2 if S&P > 200-day MA, -0.2 if below
- War premium: Variable (-0.1 to +0.3 depending on crypto correlation)
```

## 2024 Halving Cycle Projection

### Baseline (no macro adjustment)
```
Halving: April 2024 (Block 840,000)
New supply: 3.125 BTC/block → 450 BTC/day

Phase 1 (Apr-Oct 2024): $60K-80K (accumulation)
Phase 2 (Oct 2024-Mar 2025): $80K-150K (ETF-driven bull)
Phase 3 (Apr-Jul 2025): $150K-250K (retail FOMO peak)
Phase 4 (Jul 2025-Mar 2027): Correction to $75K-100K
```

### With Macro Adjustment (Current Environment)
```
War premium: -$15K to -$30K (Iran conflict suppressing risk appetite)
ETF momentum: +$20K to +$40K (institutional adoption accelerating)
Net adjustment: -$10K to +$10K (largely offsetting)
```

### Key Observations from 2026 Data
- BTC crashed from $74K to $66K on Iran conflict (validates war premium model)
- Strategy (MicroStrategy) accumulated $776M+ in dips (institutional floor)
- BTC outperformed S&P/Nasdaq during war recovery (safe-haven narrative shift)
- ETF flows remained stable despite geopolitical stress

## Cycle Comparison

| Metric | 2020 Cycle | 2024 Cycle (projected) |
|--------|-----------|----------------------|
| Pre-halving ATH | $14K | $74K |
| Peak target (base) | $100K | $250K |
| Peak timing | ~18 months | ~14 months |
| Drawdown from peak | 65% | 60-70% |
| Recovery time | 18 months | 12-15 months |
| New ATH after bear | 12 months | 6-9 months |

## Risk Factors

1. **Regulatory**: CFTC/prediction market crackdown could spill to crypto
2. **Supply shock**: Satoshi wallet movement (1M+ BTC)
3. **Protocol risk**: Quantum computing threat (long-term)
4. **Geopolitical**: War escalation causing prolonged risk-off
5. **Technological**: Competing L2 chains reducing BTC dominance

## Integration with Polymarket

Use this model to estimate:
- "BTC > $100K by Dec 2025" probability
- "BTC > $250K by Jul 2025" probability  
- "BTC crashes > 50% in 2026" probability

## Version

1.0.0 - Calibrated on 2012, 2016, 2020 halving cycles + 2024-2026 live data
