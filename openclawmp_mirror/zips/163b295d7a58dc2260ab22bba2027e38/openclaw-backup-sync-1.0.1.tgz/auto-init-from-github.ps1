# OpenClaw 自动初始化脚本
# 从 GitHub 仓库链接自动恢复配置
# 用法: 发送 "https://github.com/bayi-95/my-claw" 给 OpenClaw

param(
    [Parameter(Mandatory=$true)]
    [string]$RepoUrl
)

$ErrorActionPreference = "Stop"

Write-Host "🦞 OpenClaw 自动初始化" -ForegroundColor Cyan
Write-Host "======================" -ForegroundColor Cyan

# 解析仓库 URL
if ($RepoUrl -match "github\.com/([^/]+)/([^/]+?)(?:\.git|/|$)") {
    $owner = $matches[1]
    $repo = $matches[2] -replace '\.git$', ''
    $gitUrl = "git@github.com:$owner/$repo.git"
    $httpsUrl = "https://github.com/$owner/$repo.git"
} else {
    Write-Error "无效的 GitHub 仓库链接: $RepoUrl"
    exit 1
}

Write-Host "`n📦 仓库: $owner/$repo" -ForegroundColor Yellow

# 配置路径
$backupDir = Join-Path $env:USERPROFILE ".stepclaw-backup"
$stepclawDir = Join-Path $env:USERPROFILE ".stepclaw"
$workspaceDir = Join-Path $stepclawDir "workspace"

# 检查是否已存在备份目录
if (Test-Path $backupDir) {
    Write-Host "`n⚠️  检测到已存在的备份目录" -ForegroundColor Yellow
    $confirm = Read-Host "是否覆盖并重新初始化? (y/N)"
    if ($confirm -ne 'y' -and $confirm -ne 'Y') {
        Write-Host "已取消" -ForegroundColor Red
        exit 0
    }
    Remove-Item $backupDir -Recurse -Force
}

# 1. 克隆仓库
Write-Host "`n📥 正在克隆仓库..." -ForegroundColor Yellow
try {
    git clone $gitUrl $backupDir 2>$null
} catch {
    # 如果 SSH 失败，尝试 HTTPS
    Write-Host "SSH 克隆失败，尝试 HTTPS..." -ForegroundColor Yellow
    git clone $httpsUrl $backupDir
}

if (-not (Test-Path $backupDir)) {
    Write-Error "克隆失败，请检查网络连接或仓库权限"
    exit 1
}

Write-Host "✅ 仓库克隆成功" -ForegroundColor Green

# 2. 检查仓库结构（支持新旧两种结构）
$installScript = Join-Path $backupDir "scripts\install.ps1"
$installScriptRoot = Join-Path $backupDir "install.ps1"

if (Test-Path $installScript) {
    # 新结构：scripts/install.ps1
    Write-Host "`n🔧 正在运行安装脚本 (scripts/install.ps1)..." -ForegroundColor Yellow
    & $installScript
} elseif (Test-Path $installScriptRoot) {
    # 旧结构：根目录 install.ps1
    Write-Host "`n🔧 正在运行安装脚本 (install.ps1)..." -ForegroundColor Yellow
    & $installScriptRoot
} else {
    Write-Error "未找到安装脚本，仓库结构可能不正确。期望找到 scripts/install.ps1 或 install.ps1"
    exit 1
}

# 4. 检查是否需要配置敏感信息
$configPath = Join-Path $stepclawDir "openclaw.json"
if (Test-Path $configPath) {
    $content = Get-Content $configPath -Raw
    $needsConfig = $false
    
    if ($content -match "YOUR_FEISHU_APP_SECRET") {
        Write-Host "`n❌ 需要配置: channels.feishu.appSecret" -ForegroundColor Red
        $needsConfig = $true
    }
    if ($content -match "YOUR_GATEWAY_TOKEN") {
        Write-Host "❌ 需要配置: gateway.auth.token" -ForegroundColor Red
        $needsConfig = $true
    }
    if ($content -match "YOUR_API_KEY") {
        Write-Host "❌ 需要配置: models.providers.stepfun.apiKey" -ForegroundColor Red
        $needsConfig = $true
    }
    
    if ($needsConfig) {
        Write-Host "`n⚠️  检测到需要配置的敏感信息" -ForegroundColor Yellow
        Write-Host "请编辑以下文件填入真实值:" -ForegroundColor White
        Write-Host "  $configPath" -ForegroundColor Cyan
        
        # 尝试打开编辑器
        $openEditor = Read-Host "`n是否现在打开配置文件? (y/N)"
        if ($openEditor -eq 'y' -or $openEditor -eq 'Y') {
            notepad $configPath
        }
    } else {
        Write-Host "`n✅ 所有配置已完成" -ForegroundColor Green
    }
}

# 5. 创建快捷命令
$profilePath = $PROFILE
if (-not (Test-Path $profilePath)) {
    New-Item -ItemType File -Path $profilePath -Force | Out-Null
}

$syncFunction = @"

# OpenClaw 同步快捷命令
function claw-sync {
    & "$stepclawDir\sync.ps1"
}

# OpenClaw 备份快捷命令  
function claw-backup {
    & "$stepclawDir\sync.ps1"
}

# OpenClaw 状态检查
function claw-status {
    cd "$backupDir"
    git status
}
"@

# 检查是否已添加
if (-not (Select-String -Path $profilePath -Pattern "claw-sync" -Quiet)) {
    $syncFunction | Add-Content $profilePath
    Write-Host "`n✅ 快捷命令已添加到 PowerShell 配置" -ForegroundColor Green
    Write-Host "   使用 'claw-sync' 快速同步配置" -ForegroundColor White
}

# 6. 完成提示
Write-Host "`n🎉 初始化完成!" -ForegroundColor Cyan
Write-Host "`n常用命令:" -ForegroundColor Yellow
Write-Host "  claw-sync     - 同步配置到 GitHub" -ForegroundColor White
Write-Host "  claw-status   - 查看同步状态" -ForegroundColor White
Write-Host "`n配置文件位置:" -ForegroundColor Yellow
Write-Host "  $configPath" -ForegroundColor Cyan
Write-Host "`n下次同步:" -ForegroundColor Yellow
Write-Host "  自动同步: 每6小时" -ForegroundColor White
Write-Host "  手动同步: 运行 'claw-sync' 或 ~/.stepclaw/sync.ps1" -ForegroundColor White
