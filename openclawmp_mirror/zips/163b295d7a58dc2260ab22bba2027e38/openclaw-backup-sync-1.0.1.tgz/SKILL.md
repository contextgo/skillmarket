---
name: openclaw-backup-sync
description: '多设备 OpenClaw 配置备份与同步方案，支持 Windows/Mac/Linux 全平台'
version: 1.0.1
---

# OpenClaw 多设备配置同步方案

## 描述

一个完整的多设备 OpenClaw 配置备份与同步解决方案，支持 Windows/Mac/Linux 全平台，包含自动备份、智能初始化、冲突解决等功能。

## 使用场景

- 多设备间同步 OpenClaw 配置
- 新设备快速恢复配置
- 配置版本管理与回滚
- 团队协作共享配置

## 包含内容

1. **备份脚本** - 将本地配置备份到 GitHub 私有仓库
2. **恢复脚本** - 从 GitHub 恢复配置到新设备
3. **智能初始化** - 自动检测并配置新设备
4. **定时同步** - 每6小时自动备份

## 安装方法

```bash
# 通过水产市场安装
openclawmp install experience/@bayi-95/openclaw-backup-sync
```

## 快速开始

1. 创建 GitHub 私有仓库
2. 运行备份脚本初始化
3. 在其他设备发送仓库链接即可恢复

## 安全提示

⚠️ 此方案设计为**私有仓库**使用，包含敏感信息，请勿使用公共仓库。

## 版本

v1.0.0

## 作者

bayi-95
