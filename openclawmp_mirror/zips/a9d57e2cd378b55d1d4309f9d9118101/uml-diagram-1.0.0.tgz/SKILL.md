---
name: uml-diagram
description: UML图表生成助手。用于生成类图、时序图、用例图、流程图的PlantUML/Mermaid代码。当需要画UML图、架构图、流程图时触发。
---

# UML图表生成助手

## PlantUML基础

### 类图(Class Diagram)
```plantuml
@startuml
' 类图示例

class User {
  - id: Long
  - name: String
  - email: String
  + create()
  + update()
  + delete()
}

class Order {
  - id: Long
  - orderNo: String
  - amount: Decimal
  + calculate()
  + submit()
}

User "1" -- "0..*" Order : places
Order "1" -- "0..*" OrderItem : contains
OrderItem -- Product : references

@enduml
```

### 时序图(Sequence Diagram)
```plantuml
@startuml
' 时序图示例

actor User
participant "前端" as Frontend
participant "后端" as Backend
participant "数据库" as DB

User -> Frontend: 提交订单
Frontend -> Backend: 创建订单请求
Backend -> DB: 插入订单数据
DB --> Backend: 返回订单ID
Backend -> DB: 查询商品库存
DB --> Backend: 返回库存
alt 库存充足
    Backend -> DB: 扣减库存
    DB --> Backend: 成功
    Backend --> Frontend: 订单创建成功
    Frontend --> User: 显示成功
else 库存不足
    Backend --> Frontend: 库存不足
    Frontend --> User: 显示提示
end

@enduml
```

### 用例图(Use Case Diagram)
```plantuml
@startuml
' 用例图示例

left to right direction

actor "用户" as User
actor "管理员" as Admin

rectangle 商城系统 {
  usecase "浏览商品" as UC1
  usecase "搜索商品" as UC2
  usecase "加入购物车" as UC3
  usecase "下单购买" as UC4
  usecase "支付订单" as UC5
  usecase "管理商品" as UC6
  usecase "管理订单" as UC7
}

User --> UC1
User --> UC2
User --> UC3
User --> UC4
User --> UC5

Admin --> UC6
Admin --> UC7

UC1 <.. UC3 : extends
UC3 <.. UC4 : includes
UC4 <.. UC5 : includes

@enduml
```

### 活动图(Activity Diagram)
```plantuml
@startuml
' 活动图示例

start
:用户登录;
:输入用户名密码;

if (验证成功?) then (是)
  :显示首页;
  :加载用户数据;
  :加载商品列表;
else (否)
  :显示错误提示;
  :返回登录页;
  stop
endif

:用户浏览商品;
if (找到想要的商品?) then (是)
  :加入购物车;
else (否)
  :继续浏览;
endif

if (继续购物?) then (是)
  :返回浏览;
else (否)
  :结算购物车;
  :提交订单;
  :支付订单;
  :生成订单;
endif

:显示订单结果;
stop

@enduml
```

### 状态图(State Diagram)
```plantuml
@startuml
' 状态图示例

[*] --> 待支付

待支付 --> 待发货 : 支付成功
待支付 --> 已取消 : 用户取消

待发货 --> 已发货 : 商家发货
待发货 --> 已取消 : 商家取消

已发货 --> 待收货 : 确认收货
已发货 --> 待收货 : 超时自动确认

待收货 --> 已完成 : 确认完成
待收货 --> 已完成 : 系统超时

已取消 --> [*]
已完成 --> [*]

@enduml
```

### 组件图(Component Diagram)
```plantuml
@startuml
' 组件图示例

package "前端层" {
  [Web UI] as Web
  [Mobile App] as Mobile
}

package "服务层" {
  [用户服务] as UserService
  [订单服务] as OrderService
  [支付服务] as PayService
  [商品服务] as ProductService
}

package "数据层" {
  database "MySQL" as DB1
  database "Redis" as DB2
  database "MongoDB" as DB3
}

Web --> UserService
Mobile --> UserService
UserService --> DB1
UserService --> DB2
OrderService --> DB1
OrderService --> DB3
PayService --> DB2
ProductService --> DB3

@enduml
```

## Mermaid图表

### 流程图
```mermaid
graph TD
    A[开始] --> B{判断条件}
    B -->|是| C[处理1]
    B -->|否| D[处理2]
    C --> E[结束]
    D --> E
```

### 甘特图
```mermaid
gantt
    title 项目计划
    dateFormat  YYYY-MM-DD
    section 设计
    需求分析       :a1, 2024-01-01, 7d
    系统设计       :a2, after a1, 5d
    section 开发
    编码开发       :b1, after a2, 15d
    单元测试       :b2, after b1, 5d
    section 测试
    集成测试       :c1, after b2, 7d
    系统测试       :c2, after c1, 5d
```

### 饼图
```mermaid
pie title 项目资源分配
    "开发" : 45
    "测试" : 20
    "运维" : 15
    "管理" : 20
```

## 常用符号

### 类图关系
| 符号 | 说明 |
|------|------|
| `--` | 关联 |
| `*--` | 组合(强拥有) |
| `o--` | 聚合(弱拥有) |
| `-->` | 依赖 |
| `..>` | 实现 |
| `|>` | 继承 |

### 基数
| 符号 | 说明 |
|------|------|
| `1` | 正好1个 |
| `0..*` | 零或多个 |
| `1..*` | 一个或多个 |
| `0..1` | 零或一个 |

### 可见性
| 符号 | 说明 |
|------|------|
| `-` | private |
| `+` | public |
| `#` | protected |
| `~` | package |
