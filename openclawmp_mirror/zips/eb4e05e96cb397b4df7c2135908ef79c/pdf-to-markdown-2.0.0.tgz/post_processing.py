#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown 后处理清理工具

清理转录后MD文件中的垃圾内容（网站UI、临时链接、水印等）。

使用:
    python3 post_processing.py --config website --input ./folder/
    python3 post_processing.py --config custom --patterns "^垃圾$" --input ./folder/
    python3 post_processing.py --config all --input ./folder/ --verify
"""

import argparse
import re
import sys
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass


@dataclass
class CleanupConfig:
    """清理配置"""
    name: str
    description: str
    line_patterns: List[str]  # 整行匹配删除
    url_patterns: List[str] = None  # URL匹配删除
    verify_patterns: List[str] = None  # 验证用模式

    def __post_init__(self):
        self.url_patterns = self.url_patterns or []
        self.verify_patterns = self.verify_patterns or []


# ============================================
# 内置清理配置（通用）
# ============================================

# 网站PDF转录垃圾
WEBSITE_CONFIG = CleanupConfig(
    name="网站PDF清理",
    description="清理网站保存PDF产生的UI元素",
    line_patterns=[
        r'^\d{1,5}$',  # 孤立数字（点赞数等）
        r'^Copyright\s*©',
        r'^京ICP备',
        r'^京公网安备',
        r'^打开APP$',
        r'^登录.*注册$',
        r'^最新评论$',
        r'^大家都在看$',
        r'^相关推荐$',
    ],
    url_patterns=[
        r'https?://[^\s]+\.com/[^\s]*\?[^\s]*type=',
    ],
    verify_patterns=[r'打开APP', r'最新评论'],
)

# 公众号临时链接
WECHAT_CONFIG = CleanupConfig(
    name="公众号链接清理",
    description="清理公众号临时预览链接",
    line_patterns=[
        r'^此为临时链接.*$',
        r'^喜欢作者$',
        r'^上一篇$',
        r'^下一篇$',
    ],
    url_patterns=[
        r'mp\.weixin\.qq\.com/s\?.*tempkey=',
    ],
    verify_patterns=[r'临时链接', r'tempkey='],
)

# 转录水印（通用模板，用户可自定义）
WATERMARK_CONFIG = CleanupConfig(
    name="转录水印清理",
    description="清理转录产生的水印（可自定义）",
    line_patterns=[
        r'^\d{2}:\d{2}$',  # 时间戳
        r'^\[\d{2}:\d{2}\]$',
        r'^\d{2}\s+\d{2}$',  # 视频时间码
    ],
    verify_patterns=[],
)

CONFIG_MAP = {
    'website': WEBSITE_CONFIG,
    'wechat': WECHAT_CONFIG,
    'watermark': WATERMARK_CONFIG,
}


# ============================================
# 清理引擎
# ============================================

class Cleaner:
    def __init__(self, configs: List[CleanupConfig], dry_run: bool = False):
        self.configs = configs
        self.dry_run = dry_run
        self.stats = {'files': 0, 'modified': 0, 'lines_removed': 0}

    def _compile_patterns(self):
        line_patterns = []
        url_patterns = []
        for c in self.configs:
            line_patterns.extend(re.compile(p) for p in c.line_patterns)
            url_patterns.extend(re.compile(p) for p in c.url_patterns)
        return line_patterns, url_patterns

    def should_skip(self, line: str, line_pats, url_pats) -> bool:
        s = line.strip()
        for p in line_pats:
            if p.match(s):
                return True
        for p in url_pats:
            if p.search(s):
                return True
        return False

    def clean_file(self, path: Path) -> bool:
        with open(path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        line_pats, url_pats = self._compile_patterns()
        cleaned = []
        removed = 0

        for line in lines:
            if self.should_skip(line, line_pats, url_pats):
                removed += 1
            else:
                cleaned.append(line)

        self.stats['files'] += 1
        self.stats['lines_removed'] += removed

        if removed > 0:
            self.stats['modified'] += 1
            if not self.dry_run:
                with open(path, 'w', encoding='utf-8') as f:
                    f.writelines(cleaned)
            return True
        return False

    def clean_dir(self, input_dir: Path):
        files = list(input_dir.glob("*.md"))
        print(f"\n清理: {input_dir} ({len(files)} 文件)")
        print(f"配置: {', '.join(c.name for c in self.configs)}")
        print(f"模拟: {'是' if self.dry_run else '否'}\n")

        for i, f in enumerate(files, 1):
            mod = self.clean_file(f)
            print(f"[{i}/{len(files)}] {f.name}: {'修改' if mod else '无变化'}")

        print(f"\n统计: {self.stats['modified']}/{self.stats['files']} 文件修改, "
              f"{self.stats['lines_removed']} 行删除")

    def verify(self, input_dir: Path) -> bool:
        print("\n验证清理效果...")
        all_clean = True
        patterns = []
        for c in self.configs:
            patterns.extend(c.verify_patterns)

        for pattern in patterns:
            compiled = re.compile(pattern)
            matches = []
            for f in input_dir.glob("*.md"):
                if compiled.search(f.read_text(encoding='utf-8')):
                    matches.append(f.name)
            if matches:
                all_clean = False
                print(f"[警告] '{pattern}' 残留: {matches[:3]}...")
            else:
                print(f"[通过] '{pattern}'")

        print("验证通过!" if all_clean else "存在残留")
        return all_clean


def main():
    parser = argparse.ArgumentParser(description="Markdown清理工具")
    parser.add_argument('--config', '-c', choices=['website', 'wechat', 'watermark', 'all', 'custom'],
                        default='all', help='清理配置')
    parser.add_argument('--input', '-i', required=True, help='输入目录')
    parser.add_argument('--patterns', '-p', nargs='+', help='自定义模式（config=custom时）')
    parser.add_argument('--verify', '-v', action='store_true', help='验证效果')
    parser.add_argument('--dry-run', '-n', action='store_true', help='模拟运行')
    args = parser.parse_args()

    if args.config == 'all':
        configs = list(CONFIG_MAP.values())
    elif args.config == 'custom':
        if not args.patterns:
            print("错误: custom需要--patterns")
            sys.exit(1)
        configs = [CleanupConfig("自定义", "用户模式", args.patterns)]
    else:
        configs = [CONFIG_MAP[args.config]]

    input_dir = Path(args.input)
    if not input_dir.exists():
        print(f"错误: 目录不存在: {input_dir}")
        sys.exit(1)

    cleaner = Cleaner(configs, args.dry_run)
    cleaner.clean_dir(input_dir)

    if args.verify:
        cleaner.verify(input_dir)


if __name__ == "__main__":
    main()
