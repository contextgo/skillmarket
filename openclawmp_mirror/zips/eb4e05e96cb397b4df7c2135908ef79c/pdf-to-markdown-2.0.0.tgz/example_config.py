#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF to Markdown 转换配置示例

本文件展示常见场景的配置方案，复制所需配置到 template.py 使用。
"""

# ============================================
# 示例 1: 扫描版PDF - 整体转换
# ============================================
"""
场景：扫描版电子书，不需要拆分
"""
EXAMPLE_1 = {
    "PDF_PATH": "/path/to/scanned_book.pdf",
    "OUTPUT_DIR": "./output_md",
    "USE_OCR": True,
    "SECTIONS": [],  # 空 = 不拆分
    "PAGE_OFFSET": 0,
    "OCR_DPI": 150,
}

# ============================================
# 示例 2: 扫描版PDF - 按章节拆分
# ============================================
"""
场景：教科书，有明确章节结构
      书中第1页对应PDF第10页
"""
EXAMPLE_2 = {
    "PDF_PATH": "/path/to/textbook.pdf",
    "OUTPUT_DIR": "./textbook_chapters",
    "USE_OCR": True,
    "PAGE_OFFSET": 9,  # PDF第10页 = 书中第1页，10-1=9
    "OCR_DPI": 200,
    "SECTIONS": [
        (1, "第一章 绪论", 1, 15),
        (2, "第二章 理论基础", 16, 45),
        (3, "第三章 方法论", 46, 78),
    ],
}

# ============================================
# 示例 3: 文字版PDF - 直接提取
# ============================================
"""
场景：数字原生PDF，可直接复制文字
"""
EXAMPLE_3 = {
    "PDF_PATH": "/path/to/digital_report.pdf",
    "OUTPUT_DIR": "./report_md",
    "USE_OCR": False,  # 关键：文字版不需要OCR
    "SECTIONS": [],
    "PAGE_OFFSET": 0,
}

# ============================================
# 示例 4: 古籍/低质量扫描 - 高精度OCR
# ============================================
"""
场景：印刷质量差，需要高精度OCR
"""
EXAMPLE_4 = {
    "PDF_PATH": "/path/to/ancient_book.pdf",
    "OUTPUT_DIR": "./ancient_md",
    "USE_OCR": True,
    "OCR_DPI": 300,  # 高质量，但速度慢
    "OCR_LANGUAGES": ["zh-Hant", "zh-Hans"],  # 优先繁体
    "SECTIONS": [
        (1, "卷一", 1, 20),
        (2, "卷二", 21, 42),
    ],
    "PAGE_OFFSET": 5,
}

# ============================================
# 示例 5: 英文技术书籍
# ============================================
EXAMPLE_5 = {
    "PDF_PATH": "/path/to/programming_book.pdf",
    "OUTPUT_DIR": "./book_md",
    "USE_OCR": True,
    "OCR_LANGUAGES": ["en"],  # 仅英文
    "OCR_DPI": 150,
    "PAGE_OFFSET": 12,
    "SECTIONS": [
        (1, "Chapter 1 Introduction", 1, 25),
        (2, "Chapter 2 Getting Started", 26, 55),
    ],
}

# ============================================
# 配置检查清单
# ============================================
"""
运行前确保：

✓ PDF_PATH 路径正确
✓ OUTPUT_DIR 是期望的输出目录
✓ USE_OCR 根据PDF类型设置（扫描=True，文字=False）
✓ PAGE_OFFSET 计算正确
✓ SECTIONS 使用"书中页码"而非PDF页码
✓ OCR_DPI 根据质量需求调整
"""

# ============================================
# 中文引号注意事项
# ============================================
"""
⚠️ 标题包含中文引号时，用单引号包裹：

错误：(1, "坚持"一国两制"方针", 1, 10)
正确：(1, '坚持"一国两制"方针', 1, 10)
"""

# ============================================
# PAGE_OFFSET 验证代码
# ============================================
"""
验证偏移量是否正确：

import fitz

doc = fitz.open(PDF_PATH)
book_page = 3  # 想验证的书中页码
pdf_page = book_page + PAGE_OFFSET - 1
text = doc[pdf_page].get_text()[:100]
print(f"书中第{book_page}页内容: {text}")
doc.close()
"""

# ============================================
# 快速开始模板
# ============================================
"""
最简配置：

PDF_PATH = "/path/to/your.pdf"
OUTPUT_DIR = "./output"
USE_OCR = True
SECTIONS = []
PAGE_OFFSET = 0
OCR_DPI = 150
OCR_LANGUAGES = ["zh-Hans", "zh-Hant", "en"]
"""
