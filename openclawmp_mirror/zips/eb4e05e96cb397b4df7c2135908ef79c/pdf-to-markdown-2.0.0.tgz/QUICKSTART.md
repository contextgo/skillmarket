# PDF to Markdown 快速开始

## 安装

```bash
pip install pymupdf
```

## 3步转换

### 1. 复制模板
```bash
cp template.py my_convert.py
```

### 2. 编辑配置
```python
PDF_PATH = "/path/to/your.pdf"
OUTPUT_DIR = "./output_md"
USE_OCR = True  # 扫描版True，文字版False
```

### 3. 运行
```bash
python3 my_convert.py
```

## 按章节拆分

```python
SECTIONS = [
    (1, "第一章", 1, 20),   # (序号, 标题, 起始页, 结束页)
    (2, "第二章", 21, 40),
]
PAGE_OFFSET = 12  # PDF页码 - 书中页码
```

## 后处理清理

```bash
python3 post_processing.py --config all --input ./output_md/
```

## 更多信息

- **README.md** - 详细功能说明
- **example_config.py** - 配置示例
- **instructions.md** - 完整工作流程
