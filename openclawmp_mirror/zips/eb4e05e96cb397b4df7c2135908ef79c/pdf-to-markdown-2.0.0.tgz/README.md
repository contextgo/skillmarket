# PDF to Markdown 转换工具

将PDF文档（扫描版/文字版）转换为Markdown格式。

## 功能

- OCR识别扫描版PDF（macOS Vision框架）
- 直接提取文字版PDF
- 按章节拆分为多个文件
- 自动生成目录索引
- 后处理清理垃圾内容

## 安装

```bash
pip install pymupdf
```

**系统要求**：macOS（OCR使用Vision框架）

## 快速开始

```bash
# 1. 复制模板
cp template.py my_convert.py

# 2. 编辑配置
# PDF_PATH = "/path/to/your.pdf"
# OUTPUT_DIR = "./output_md"
# USE_OCR = True

# 3. 运行
python3 my_convert.py
```

## 配置说明

| 参数 | 说明 | 示例 |
|-----|------|------|
| `PDF_PATH` | PDF文件路径 | `"/path/to/book.pdf"` |
| `OUTPUT_DIR` | 输出目录 | `"./output_md"` |
| `USE_OCR` | 是否OCR（扫描版=True） | `True` |
| `PAGE_OFFSET` | 页码偏移量 | `12` |
| `OCR_DPI` | OCR分辨率 | `150` |

### 按章节拆分

```python
SECTIONS = [
    (1, "第一章", 1, 20),   # (序号, 标题, 起始页, 结束页)
    (2, "第二章", 21, 40),
]
PAGE_OFFSET = 12  # PDF页码 - 书中页码
```

## 后处理清理

清理转录后的垃圾内容：

```bash
# 使用内置规则
python3 post_processing.py --config all --input ./output_md/

# 自定义规则
python3 post_processing.py --config custom --patterns "^垃圾$" --input ./folder/

# 验证效果
python3 post_processing.py --config all --input ./folder/ --verify
```

内置配置：`website`（网站UI）、`wechat`（公众号链接）、`watermark`（水印）

## 文件说明

| 文件 | 用途 |
|-----|------|
| `template.py` | 转换脚本模板 |
| `post_processing.py` | 后处理清理工具 |
| `example_config.py` | 配置示例 |
| `instructions.md` | 完整工作流程 |
| `QUICKSTART.md` | 快速开始指南 |
| `OPTIMIZE_FOR_AI.md` | AI友好格式优化（扩展） |

## 性能参考

| PDF类型 | 方式 | 速度 |
|--------|-----|------|
| 扫描版 | OCR 150 DPI | ~2.5页/秒 |
| 文字版 | 直接提取 | ~3000页/秒 |

## 许可

MIT License

---

*版本: 2.0*
