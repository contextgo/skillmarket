#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF to Markdown 转换脚本模板
使用说明：根据你的PDF修改配置部分，然后运行脚本
"""

import sys
sys.path.insert(0, '/Users/xixiangyu/Library/Python/3.9/lib/python/site-packages')

import fitz  # pymupdf
import Quartz
from Quartz import CGImageSourceCreateWithURL, CGImageSourceCreateImageAtIndex
from Foundation import NSURL
import Vision
import os
import re
import time

# ========== 配置部分 - 请根据你的PDF修改 ==========
PDF_PATH = "YOUR_PDF_PATH.pdf"  # PDF文件路径
OUTPUT_DIR = "OUTPUT_DIRECTORY"  # 输出目录
USE_OCR = True  # True=扫描版PDF需要OCR, False=文本PDF直接提取

# 章节配置（如不需要拆分，保持为空列表）
# 格式: (序号, 标题, 书中起始页, 书中结束页)
SECTIONS = [
    # 示例：
    # (1, "第一章 标题", 1, 10),
    # (2, "第二章 标题", 11, 20),
]

# 页码偏移量：PDF实际页码 = 书中页码 + PAGE_OFFSET
# 例如：书中第1页对应PDF第13页，则偏移量为12
PAGE_OFFSET = 0

# OCR分辨率（DPI）：越高质量越好但速度越慢，推荐150-300
OCR_DPI = 150

# OCR语言设置
OCR_LANGUAGES = ["zh-Hans", "zh-Hant", "en"]  # 简体中文、繁体中文、英文
# ================================================

def ocr_image(image_path):
    """使用macOS Vision框架进行OCR"""
    url = NSURL.fileURLWithPath_(image_path)
    image_source = CGImageSourceCreateWithURL(url, None)
    if not image_source:
        return ""
    cg_image = CGImageSourceCreateImageAtIndex(image_source, 0, None)
    if not cg_image:
        return ""

    request = Vision.VNRecognizeTextRequest.alloc().init()
    request.setRecognitionLanguages_(OCR_LANGUAGES)
    request.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)

    handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(cg_image, None)
    success, error = handler.performRequests_error_([request], None)

    if not success:
        return ""

    results = request.results()
    if not results:
        return ""

    text_lines = []
    for observation in results:
        text = observation.topCandidates_(1)[0].string()
        text_lines.append(text)

    return "\n".join(text_lines)

def ocr_page(doc, page_num):
    """OCR单个页面"""
    page = doc[page_num]
    pix = page.get_pixmap(dpi=OCR_DPI)
    img_path = f"/tmp/ocr_page_{page_num}.png"
    pix.save(img_path)
    text = ocr_image(img_path)
    os.remove(img_path)
    return text

def extract_text_page(doc, page_num):
    """直接提取文本页面（非扫描版PDF）"""
    page = doc[page_num]
    return page.get_text()

def clean_text(text):
    """清理文本"""
    # 移除常见扫描软件水印
    text = re.sub(r'[&＆營灣口鹽發煲愛罂罌曖]*\s*扫描[全金]能王\s*创建', '', text)
    # 移除多余空行
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

def sanitize_filename(title):
    """清理文件名中的非法字符"""
    # 包含系统非法字符和中文标点符号
    invalid_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|',
                     '、', '"', '"', '，', '《', '》', '【', '】', '（', '）']
    result = title
    for char in invalid_chars:
        result = result.replace(char, '_')
    return result

def process_section(doc, section_info, progress_callback=None):
    """处理单个章节"""
    idx, title, start_page, end_page = section_info

    # 转换为PDF页码（0索引）
    pdf_start = start_page + PAGE_OFFSET - 1
    pdf_end = end_page + PAGE_OFFSET - 1

    content_parts = []

    for page_num in range(pdf_start, pdf_end + 1):
        if page_num >= doc.page_count:
            break

        if USE_OCR:
            text = ocr_page(doc, page_num)
        else:
            text = extract_text_page(doc, page_num)

        text = clean_text(text)
        content_parts.append(text)

        if progress_callback:
            progress_callback(page_num, pdf_start, pdf_end)

    # 合并内容
    full_content = "\n\n".join(content_parts)

    # 创建Markdown格式
    md_content = f"# {title}\n\n{full_content}\n"

    return md_content

def convert_whole_pdf(doc, output_path):
    """转换整个PDF为一个Markdown文件"""
    print(f"正在转换PDF（共{doc.page_count}页）...")

    content_parts = []
    for page_num in range(doc.page_count):
        print(f"处理进度: {page_num + 1}/{doc.page_count}", end='\r')

        if USE_OCR:
            text = ocr_page(doc, page_num)
        else:
            text = extract_text_page(doc, page_num)

        text = clean_text(text)
        if text:
            content_parts.append(text)

    full_content = "\n\n".join(content_parts)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(full_content)

    print(f"\n转换完成！输出文件: {output_path}")

def convert_by_sections(doc):
    """按章节转换PDF"""
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    total_sections = len(SECTIONS)
    for i, section in enumerate(SECTIONS):
        idx, title, start_page, end_page = section
        page_count = end_page - start_page + 1

        print(f"\n[{i+1}/{total_sections}] 处理: {title}")
        print(f"    页码范围: {start_page}-{end_page} ({page_count}页)")

        start_time = time.time()

        def progress(current, start, end):
            total = end - start + 1
            done = current - start + 1
            print(f"    进度: {done}/{total} 页", end='\r')

        # 处理章节
        md_content = process_section(doc, section, progress)

        # 保存文件
        safe_title = sanitize_filename(title)
        filename = f"{idx:02d}_{safe_title}.md"
        filepath = os.path.join(OUTPUT_DIR, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md_content)

        elapsed = time.time() - start_time
        print(f"    完成! 耗时: {elapsed:.1f}秒")

    # 创建目录索引
    create_index()

def create_index():
    """创建目录索引文件"""
    index_path = os.path.join(OUTPUT_DIR, "00_目录索引.md")
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write("# 目录索引\n\n")
        f.write("## 章节列表\n\n")
        for idx, title, start_page, end_page in SECTIONS:
            safe_title = sanitize_filename(title)
            filename = f"{idx:02d}_{safe_title}.md"
            f.write(f"{idx}. [{title}]({filename}) (页码: {start_page}-{end_page})\n")
        f.write(f"\n---\n\n生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

def main():
    """主函数"""
    print("=" * 70)
    print("PDF to Markdown 转换器")
    print("=" * 70)

    # 检查配置
    if PDF_PATH == "YOUR_PDF_PATH.pdf":
        print("\n错误：请先配置PDF_PATH!")
        print("请编辑脚本顶部的配置部分")
        return

    if not os.path.exists(PDF_PATH):
        print(f"\n错误：PDF文件不存在: {PDF_PATH}")
        return

    print(f"\n配置信息:")
    print(f"  PDF文件: {PDF_PATH}")
    print(f"  输出目录: {OUTPUT_DIR}")
    print(f"  OCR模式: {'开启' if USE_OCR else '关闭'}")
    print(f"  OCR分辨率: {OCR_DPI} DPI")
    print(f"  拆分模式: {'按章节' if SECTIONS else '整体转换'}")

    print(f"\n正在打开PDF文件...")
    doc = fitz.open(PDF_PATH)
    print(f"PDF总页数: {doc.page_count}")

    if SECTIONS:
        # 按章节转换
        print(f"章节数量: {len(SECTIONS)}")
        convert_by_sections(doc)
        print(f"\n输出目录: {OUTPUT_DIR}")
    else:
        # 整体转换
        output_file = OUTPUT_DIR if OUTPUT_DIR.endswith('.md') else os.path.join(OUTPUT_DIR, "output.md")
        os.makedirs(os.path.dirname(output_file) or '.', exist_ok=True)
        convert_whole_pdf(doc, output_file)

    doc.close()

    print("\n" + "=" * 70)
    print("转换完成!")
    print("=" * 70)

if __name__ == "__main__":
    main()
