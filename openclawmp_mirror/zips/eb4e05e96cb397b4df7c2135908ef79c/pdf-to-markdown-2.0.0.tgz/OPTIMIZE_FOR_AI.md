# 大型文本库优化为AI友好格式

> 本文档描述如何将大型文本库（如多卷本书籍、会议记录集、讲话汇编等）优化为便于AI检索和分析的格式。

---

## 适用场景

当你有以下需求时，可以使用本方法论：

1. **对比分析** - 比较不同时期同一主题的表述差异
2. **概念追踪** - 追溯某个提法的首次出现和演变轨迹
3. **趋势发现** - 从时间维度发现政策/观点变化趋势
4. **精确检索** - 快速定位到具体某篇文章的某段内容

---

## 常见问题

大型文本库通常存在以下问题：

| 问题 | 表现 | 影响 |
|-----|------|-----|
| **文章粒度不一致** | 有的按篇组织，有的按主题章节混合多篇 | 难以定位到具体某一篇 |
| **缺少结构化元数据** | 日期、场合、关键词散落在正文中 | AI无法快速筛选 |
| **主题分类过粗** | 只有几个大类 | 难以精确定位 |
| **无时间维度** | 无法按时间排序查看 | 无法追踪演变 |

---

## 优化步骤

### 第一步：统一文章粒度

**目标**：每篇独立文章一个MD文件

**方法**：
1. 识别文章边界特征（日期、场合说明、标题格式）
2. 编写拆分脚本，将混合章节文件拆分为独立文章
3. 统一命名规则

**推荐命名格式**：
```
V{卷}_{序号}_{YYYY-MM-DD}_{标题}.md
```

**文章边界识别要点**：

对于中文讲话/报告类文档，**场合说明**是最可靠的文章边界标识：

```python
# 场合说明模式 - 匹配 "* 这是习近平在xxx讲话" 格式
OCCASION_PATTERN = r'^[*※]?\s*这是.+?(.+?(?:讲话|报告|演讲|文章|贺电|贺信|批示|指示).+?)(?:。|$)'

# 日期格式
DATE_PATTERN = r'（(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日）'
```

**拆分算法**：
1. 找到所有场合说明的位置
2. 从场合说明向前查找日期行（可能需要搜索100-200行）
3. 从日期行向前查找标题（通常在日期前1-5行）
4. 确定文章范围（从标题到下一篇文章开始）

### 第二步：创建结构化元数据索引

**文件**：`metadata_index.json`（**AI检索的主入口**）

**结构示例**：
```json
{
  "generated_at": "2026-01-26T10:00:00",
  "description": "文本库元数据索引",
  "statistics": {
    "total_articles": 341,
    "date_range": "2012-11-16 ~ 2024-12-11",
    "by_year": {"2012": 10, "2013": 28, "...": "..."},
    "by_volume": {"1": 79, "2": 73, "3": 67, "4": 64, "5": 58}
  },
  "articles": [
    {
      "id": "V1_001",
      "title": "文章标题",
      "date": "2012-11-15",
      "year": 2012,
      "volume": 1,
      "type": "讲话",
      "occasion": "场合说明",
      "file": "V1_001_2012-11-15_文章标题.md",
      "char_count": 3500
    }
  ]
}
```

### 第三步：创建概念索引

**文件**：`concepts_index.md` + `concepts_index.json`

**核心概念列表**（根据研究领域定制）：

```python
CONCEPTS = {
    "经济政策": [
        "高质量发展", "新质生产力", "新发展格局", "双循环",
        "共同富裕", "两个毫不动摇", "供给侧结构性改革",
        "民营经济", "民营企业", "实体经济", "数字经济"
    ],
    "科技创新": [
        "科技自立自强", "自主创新", "卡脖子", "关键核心技术",
        "人工智能", "新能源", "创新驱动", "数字中国"
    ],
    # ... 其他类别
}
```

**每个概念记录**：
- 相关文章数量和提及次数
- **首次出现**：时间、场合、原文摘录
- 主要相关文章列表

**概念索引Markdown格式**：
```markdown
### 高质量发展

- **相关文章**: 45篇
- **提及次数**: 328次
- **首次出现**: 2017-10-18 《十九大报告》
  > ...推动经济发展质量变革、效率变革、动力变革，提高全要素生产率...

**主要相关文章**:
- [文章标题1](文件名.md) (2017-10-18, 提及15次)
- [文章标题2](文件名.md) (2018-03-05, 提及8次)
```

### 第四步：创建时间线索引

**文件**：`timeline_index.md`

**内容组织**：
- 按年份、月份组织所有文章
- 标注各年度主要事件/会议
- 便于查看某段时期的政策重点

**格式示例**：
```markdown
## 年度统计

| 年份 | 篇数 | 主要事件/会议 |
|-----|-----|-------------|
| 2012 | 10篇 | 十八大召开 |
| 2013 | 28篇 | 提出"中国梦" |
| ... | ... | ... |

## 2024年 (25篇)

### 12月 (3篇)
- [2024-12-11] [文章标题](文件名.md) - 场合说明
```

### 第五步：更新总目录索引

**文件**：`00_总目录索引.md`

**内容**：
- 快速导航（链接到各索引文件）
- 统计概览（表格形式）
- 按卷/来源分类的完整文章列表

---

## 使用方式

当拿到一篇新文章需要对比分析时：

```
1. 主题检索
   └── 查 concepts_index.json
       └── 获取相关历史文章列表

2. 时间定位
   └── 查 timeline_index.md
       └── 找到特定时间段的文章

3. 精确对比
   └── 打开具体文章文件
       └── 对比表述差异

4. 概念追踪
   └── 从概念索引获取首次出现时间和演变轨迹
```

**示例查询**：

| 查询需求 | 操作步骤 |
|---------|---------|
| 找出所有关于"新质生产力"的讲话 | 读取 concepts_index.json → 返回相关文章列表 |
| 比较2018年和2024年关于民营经济的表述 | 通过 timeline_index.md 定位时间段 → 对比具体文章 |
| "高质量发展"概念是什么时候提出的？ | 从 concepts_index.md 获取首次出现时间 |

---

## 脚本模板

### 文章拆分脚本框架

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""文章拆分工具"""

import re
import json
from pathlib import Path
from datetime import datetime

# 配置
INPUT_DIR = "原始MD文件目录"
OUTPUT_DIR = "输出目录"

# 模式匹配
DATE_PATTERN = r'（(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日）'
OCCASION_PATTERN = r'^[*※]?\s*这是.+?(.+?(?:讲话|报告|演讲).+?)(?:。|$)'

def find_articles_by_occasion(content):
    """使用场合说明识别文章边界"""
    lines = content.split('\n')
    articles = []

    # 找到所有场合说明的行
    occasion_lines = []
    for i, line in enumerate(lines):
        if re.search(OCCASION_PATTERN, line):
            occasion_lines.append(i)

    # 对每个场合说明，向前查找标题和日期
    for idx, occasion_line in enumerate(occasion_lines):
        # 向前搜索日期（最多200行）
        date = None
        for i in range(occasion_line - 1, max(occasion_line - 200, -1), -1):
            match = re.search(DATE_PATTERN, lines[i])
            if match:
                year, month, day = match.groups()
                date = f"{year}-{int(month):02d}-{int(day):02d}"
                date_line = i
                break

        if not date:
            continue

        # 在日期行之前找标题
        title = None
        for i in range(date_line - 1, max(date_line - 10, -1), -1):
            line = lines[i].strip()
            if line and len(line) > 3:
                title = line
                title_line = i
                break

        if title:
            articles.append({
                'title': title,
                'date': date,
                'start_line': title_line,
                'end_line': occasion_lines[idx + 1] if idx + 1 < len(occasion_lines) else len(lines)
            })

    return articles

def main():
    # 实现拆分逻辑
    pass

if __name__ == '__main__':
    main()
```

### 概念索引生成脚本框架

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""概念索引生成工具"""

import json
import re
from pathlib import Path

# 概念列表
CONCEPTS = {
    "类别1": ["概念A", "概念B"],
    "类别2": ["概念C", "概念D"],
}

def search_concept_in_file(filepath, concept):
    """在文件中搜索概念"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    count = len(re.findall(re.escape(concept), content))
    if count == 0:
        return None

    # 提取摘录
    excerpts = []
    for match in re.finditer(re.escape(concept), content):
        start = max(0, match.start() - 30)
        end = min(len(content), match.end() + 50)
        excerpt = content[start:end].replace('\n', ' ').strip()
        excerpts.append(excerpt)

    return {'count': count, 'excerpts': excerpts[:3]}

def build_concepts_index(metadata_path, articles_dir):
    """构建概念索引"""
    with open(metadata_path, 'r', encoding='utf-8') as f:
        metadata = json.load(f)

    concepts_data = {}
    for category, concepts in CONCEPTS.items():
        concepts_data[category] = {}
        for concept in concepts:
            concept_articles = []
            for article in metadata['articles']:
                filepath = Path(articles_dir) / article['file']
                result = search_concept_in_file(filepath, concept)
                if result:
                    concept_articles.append({
                        'title': article['title'],
                        'date': article['date'],
                        'file': article['file'],
                        'count': result['count'],
                        'excerpts': result['excerpts']
                    })

            if concept_articles:
                concept_articles.sort(key=lambda x: x['date'] or '9999')
                concepts_data[category][concept] = {
                    'total_articles': len(concept_articles),
                    'total_mentions': sum(a['count'] for a in concept_articles),
                    'first_mention': concept_articles[0],
                    'articles': concept_articles
                }

    return concepts_data

def main():
    pass

if __name__ == '__main__':
    main()
```

---

## 输出文件清单

完成优化后的文件结构：

```
优化后的目录/
├── 00_总目录索引.md           # 快速导航
├── metadata_index.json        # 结构化元数据（AI检索入口）
├── concepts_index.md          # 概念索引（人类阅读版）
├── concepts_index.json        # 概念索引（AI检索版）
├── timeline_index.md          # 时间线索引
├── V1_001_2012-11-15_标题.md  # 独立文章
├── V1_002_2012-11-17_标题.md
├── ...
```

---

## 实际案例

### 《习近平谈治国理政》全五卷优化

**原始状态**：
- 155个MD文件，约361万字符
- 第一卷：每篇文章独立文件（较好）
- 第二至五卷：按主题章节组织，多篇讲话混在一起

**优化结果**：
- 341篇独立文章
- 时间跨度：2012-11-16 ~ 2024-12-11
- 按卷分布：V1=79篇, V2=73篇, V3=67篇, V4=64篇, V5=58篇

**生成的索引**：
- `metadata_index.json` - 结构化元数据
- `concepts_index.md/json` - 50个核心概念索引
- `timeline_index.md` - 按年月组织的时间线
- `00_总目录索引.md` - 快速导航

**关键脚本**：
- `split_articles_v2.py` - 文章拆分
- `build_concepts_index.py` - 概念索引生成
- `build_timeline_index.py` - 时间线索引生成
- `build_main_index.py` - 总目录索引生成

---

## 注意事项

1. **场合说明符号**：不同来源可能使用不同符号（`*` 或 `※`），正则需要同时支持

2. **日期与场合的距离**：正文内容可能很长，日期到场合说明之间可能跨越100+行，搜索范围要足够大

3. **OCR杂质清理**：需要清理页码、书名页眉等扫描产生的杂质
   ```python
   NOISE_PATTERNS = [
       r'^\d+$',  # 单独的页码
       r'^书名\s*第[一二三四五]卷\s*$',  # 书名页眉
   ]
   ```

4. **文件命名安全**：清理文件名中的特殊字符
   ```python
   safe = re.sub(r'[<>:"/\\|?*，。、""''！？]', '', title)
   ```

5. **保留原目录**：建议输出到新目录，保留原始文件不动

---

*文档版本: 1.0*
*创建日期: 2026-01-26*
