---
name: dbt-data-transform
description: "dbt data transformation guide - SQL-based ELT, data modeling, and analytics engineering"
version: 1.0.0
tags: ["dbt", "data-engineering", "sql", "elt", "analytics"]
---

# dbt Data Transformation Guide

dbt (data build tool) enables analytics engineers to transform data using SQL, with version control, testing, and documentation.

## Core Concepts

- **Models**: SELECT statements that transform data
- **Sources**: Define raw data tables
- **Tests**: Assertions about data quality
- **Macros**: Reusable SQL snippets
- **Seeds**: Static CSV data

## Project Structure

```
models/
├── staging/
│   ├── stg_customers.sql
│   └── stg_orders.sql
├── intermediate/
│   └── int_order_items.sql
├── marts/
│   ├── dim_customers.sql
│   └── fct_orders.sql
└── schema.yml
```

## Model Example

```sql
-- models/marts/fct_orders.sql
with orders as (
    select * from {{ ref('stg_orders') }}
),
customers as (
    select * from {{ ref('stg_customers') }}
)
select
    o.order_id,
    o.order_date,
    c.customer_name,
    o.amount,
    o.status
from orders o
join customers c on o.customer_id = c.customer_id
```

## Tests (schema.yml)

```yaml
version: 2
models:
  - name: fct_orders
    columns:
      - name: order_id
        tests:
          - unique
          - not_null
      - name: amount
        tests:
          - not_null
          - dbt_utils.accepted_range:
              min_value: 0
```

## Best Practices

- Follow naming conventions: `stg_`, `int_`, `fct_`, `dim_`
- Use sources for raw data references
- Write tests for all primary keys and not-null columns
- Use `dbt docs generate` for documentation
- Use `ref()` and `source()` functions for dependencies
