---
name: proactive-agent-wal
description: 进阶版主动Agent系统，基于WAL协议实现持久化任务记忆，支持自主Cron调度、自评自省、优先级队列管理、自动恢复和记忆压缩整合，让Agent真正实现自主进化与持续运行。
---

# 主动进化 Agent — WAL 协议版

本技能定义了一套完整的 Agent 自主运行协议，核心基于 WAL（Write-Ahead Log）持久化记忆系统，让 Agent 具备持久任务记忆、自主定时调度、自评自省、优先级管理和自动恢复能力。Agent 将能够在无人干预的情况下持续工作、积累经验、优化策略。

---

## 目录

1. [系统架构概述](#1-系统架构概述)
2. [WAL 协议核心规范](#2-wal-协议核心规范)
3. [Working Buffer 工作缓冲区](#3-working-buffer-工作缓冲区)
4. [优先级任务队列](#4-优先级任务队列)
5. [Proactive Cron 自主调度](#5-proactive-cron-自主调度)
6. [自评自省机制](#6-自评自省机制)
7. [目标分解与进度追踪](#7-目标分解与进度追踪)
8. [自动恢复与重试策略](#8-自动恢复与重试策略)
9. [记忆压缩与整合](#9-记忆压缩与整合)
10. [完整工作流示例](#10-完整工作流示例)
11. [文件结构规范](#11-文件结构规范)
12. [异常场景处理](#12-异常场景处理)

---

## 1. 系统架构概述

### 1.1 核心概念

```
┌─────────────────────────────────────────────────────────┐
│                   主动进化 Agent 系统                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐    ┌──────────────┐    ┌───────────┐ │
│  │  WAL Log     │◄──►│  Working     │◄──►│  Priority │ │
│  │  (持久记忆)   │    │  Buffer      │    │  Queue    │ │
│  │              │    │  (活跃任务)   │    │  (待执行)  │ │
│  └──────┬───────┘    └──────┬───────┘    └─────┬─────┘ │
│         │                   │                   │       │
│         ▼                   ▼                   ▼       │
│  ┌──────────────┐    ┌──────────────┐    ┌───────────┐ │
│  │  Memory      │    │  Self-Eval   │    │  Cron     │ │
│  │  Compactor   │    │  Engine      │    │  Scheduler│ │
│  │  (记忆压缩)   │    │  (自评引擎)   │    │  (定时器)  │ │
│  └──────────────┘    └──────────────┘    └───────────┘ │
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │              Goal Tracker (目标追踪器)               ││
│  └─────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

### 1.2 生命周期

Agent 的运行遵循以下循环：

1. **启动检查** → 读取 WAL 和 Buffer 恢复状态
2. **Cron 触发** → 检查是否有定时任务到期
3. **队列处理** → 从优先级队列取任务执行
4. **日志记录** → 将操作结果写入 WAL
5. **自评自省** → 定期评估任务完成质量和策略效果
6. **记忆整合** → 压缩旧日志，保留关键洞察
7. **状态持久化** → 确保 Buffer 和 WAL 一致

---

## 2. WAL 协议核心规范

### 2.1 WAL 文件格式

WAL（Write-Ahead Log）是 Agent 的持久化记忆核心。所有关键操作在执行前先写入 WAL，确保操作可追溯、可恢复。

```json
{
    "version": "wal-1.0",
    "agent_id": "agent-001",
    "created_at": "2024-01-15T00:00:00Z",
    "entries": [
        {
            "seq": 1,
            "timestamp": "2024-01-15T09:30:00Z",
            "level": "info",
            "category": "task_start",
            "task_id": "task-20240115-001",
            "description": "开始执行：分析Q1销售数据",
            "context": {
                "goal_id": "goal-quarterly-report",
                "priority": "high",
                "deadline": "2024-01-16T18:00:00Z"
            },
            "checkpoint": {
                "status": "started",
                "progress": 0
            }
        },
        {
            "seq": 2,
            "timestamp": "2024-01-15T09:35:00Z",
            "level": "info",
            "category": "task_progress",
            "task_id": "task-20240115-001",
            "description": "已完成数据收集，共获取 1,247 条销售记录",
            "context": {
                "data_source": "sales_db",
                "records_count": 1247,
                "time_range": "2024-01-01 to 2024-03-31"
            },
            "checkpoint": {
                "status": "in_progress",
                "progress": 30,
                "phase": "data_collection"
            }
        },
        {
            "seq": 3,
            "timestamp": "2024-01-15T10:00:00Z",
            "level": "warn",
            "category": "task_anomaly",
            "task_id": "task-20240115-001",
            "description": "发现异常数据：华东区域2月销售额偏差超过30%",
            "context": {
                "anomaly_type": "data_deviation",
                "region": "east_china",
                "expected": 850000,
                "actual": 595000,
                "deviation_pct": 30
            },
            "checkpoint": {
                "status": "anomaly_detected",
                "requires_review": true
            }
        },
        {
            "seq": 4,
            "timestamp": "2024-01-15T11:00:00Z",
            "level": "info",
            "category": "task_complete",
            "task_id": "task-20240115-001",
            "description": "Q1销售分析报告生成完成",
            "context": {
                "output_file": "/reports/Q1_sales_analysis.md",
                "key_findings": [
                    "整体销售额同比增长12%",
                    "华东区域存在显著异常需关注",
                    "新产品线贡献了23%的新增营收"
                ],
                "quality_score": 0.92
            },
            "checkpoint": {
                "status": "completed",
                "progress": 100
            }
        }
    ]
}
```

### 2.2 WAL 日志级别

| 级别 | 使用场景 | 说明 |
|------|----------|------|
| `trace` | 详细调试信息 | 函数级别的详细日志，仅在深度调试时使用 |
| `debug` | 调试信息 | 变量值、中间计算结果、API 调用详情 |
| `info` | 常规操作 | 任务开始、进度更新、常规完成 |
| `warn` | 异常警告 | 数据偏差、性能下降、需要人工关注 |
| `error` | 错误 | 操作失败、API 错误、数据丢失 |
| `critical` | 严重故障 | 系统不可用、数据损坏、安全事件 |
| `decision` | 关键决策 | Agent 做出的重要策略选择，需可追溯 |
| `learning` | 经验记录 | 从任务中总结的经验和教训 |

### 2.3 WAL 日志分类

| 分类 | 标识 | 说明 |
|------|------|------|
| 任务管理 | `task_start`, `task_progress`, `task_complete`, `task_fail` | 任务生命周期 |
| 目标管理 | `goal_created`, `goal_updated`, `goal_achieved` | 目标追踪 |
| 自评自省 | `self_eval`, `self_critique`, `strategy_adjustment` | 反思机制 |
| Cron 调度 | `cron_registered`, `cron_triggered`, `cron_skipped` | 定时任务 |
| 记忆管理 | `memory_compacted`, `memory_consolidated`, `memory_pruned` | 记忆操作 |
| 异常处理 | `anomaly_detected`, `recovery_started`, `recovery_completed` | 错误恢复 |
| 外部交互 | `api_call`, `user_interaction`, `tool_execution` | 外部交互 |
| 系统事件 | `system_startup`, `system_checkpoint`, `system_shutdown` | 系统级别 |

### 2.4 WAL 写入规范

Agent 在执行任何关键操作时，必须遵循以下 WAL 写入协议：

```
协议规则：
1. 先写 WAL，后执行操作（Write-Ahead 原则）
2. WAL 条目必须包含唯一的 seq 序列号（递增）
3. 每条 WAL 必须包含 timestamp、level、category
4. 检查点信息（checkpoint）必须在关键操作前后记录
5. 任务状态变更必须通过 WAL 记录，不允许直接修改 Buffer
```

### 2.5 WAL 日志轮转与归档

```json
{
    "wal_rotation_policy": {
        "max_entries_per_file": 5000,
        "max_file_size_mb": 10,
        "retention_days": 90,
        "archive_compression": "gzip",
        "archive_format": "wal-{date}-{seq}.json.gz",
        "active_file": "wal-active.json",
        "archive_directory": "archive/wal/"
    }
}
```

---

## 3. Working Buffer 工作缓冲区

### 3.1 Buffer 结构定义

Working Buffer 是 Agent 维护的活跃任务状态快照，每次系统启动时从 WAL 恢复。

```json
{
    "version": "buffer-1.0",
    "agent_id": "agent-001",
    "last_checkpoint_seq": 4,
    "last_sync_time": "2024-01-15T11:00:00Z",
    "active_tasks": [
        {
            "task_id": "task-20240115-001",
            "title": "分析Q1销售数据",
            "status": "completed",
            "priority": "high",
            "created_at": "2024-01-15T09:30:00Z",
            "completed_at": "2024-01-15T11:00:00Z",
            "progress": 100,
            "quality_score": 0.92,
            "goal_id": "goal-quarterly-report",
            "output_files": ["/reports/Q1_sales_analysis.md"],
            "learnings": [
                "华东区域数据需要额外验证源",
                "新产品线数据收集需要调整字段映射"
            ]
        }
    ],
    "pending_tasks": [
        {
            "task_id": "task-20240115-002",
            "title": "联系供应商确认Q2供货计划",
            "status": "pending",
            "priority": "medium",
            "created_at": "2024-01-15T11:05:00Z",
            "deadline": "2024-01-17T12:00:00Z",
            "dependencies": ["task-20240115-001"],
            "estimated_duration": "2h",
            "retry_count": 0,
            "max_retries": 3
        }
    ],
    "goals": [
        {
            "goal_id": "goal-quarterly-report",
            "title": "完成Q1季度报告",
            "description": "汇总销售、运营、财务数据，生成完整Q1报告",
            "status": "in_progress",
            "progress": 60,
            "sub_tasks": ["task-20240115-001", "task-20240115-002", "task-20240115-003"],
            "deadline": "2024-01-20T18:00:00Z",
            "created_at": "2024-01-10T08:00:00Z"
        }
    ],
    "metrics": {
        "total_tasks_completed": 47,
        "total_tasks_failed": 3,
        "average_quality_score": 0.87,
        "tasks_completed_today": 5,
        "uptime_hours": 72.5
    },
    "agent_state": {
        "current_focus": "报告生成",
        "energy_level": "high",
        "context_window": "处理季度报告相关工作",
        "last_self_eval": "2024-01-15T08:00:00Z"
    }
}
```

### 3.2 Buffer 同步协议

```
Buffer 同步规则：
1. 系统启动时：从 WAL 重建 Buffer（回放所有未完成任务的日志）
2. 任务状态变更时：先写 WAL entry，然后更新 Buffer
3. 定时检查点：每 30 分钟或在重大操作后创建 Buffer 快照
4. 异常恢复：基于 WAL 中的 checkpoint 信息恢复 Buffer
5. 一致性校验：Buffer 中的 last_checkpoint_seq 必须与 WAL 中最大 seq 一致
```

### 3.3 Buffer 恢复流程

```
系统启动
    │
    ▼
读取 Buffer 快照 ──┐
    │              │
    ▼              │
读取 WAL 日志 ────┤
    │              │
    ▼              │
对比 last_seq     │
    │              │
    ├── 一致 ──► 直接使用 Buffer
    │
    └── 不一致 ──► 从差异 seq 开始回放 WAL
                          │
                          ▼
                     重建 Buffer
                          │
                          ▼
                     写入新 Buffer 快照
```

---

## 4. 优先级任务队列

### 4.1 优先级定义

```json
{
    "priority_levels": {
        "critical": {
            "level": 0,
            "description": "紧急且重要，需要立即处理",
            "color": "red",
            "max_age_hours": 2,
            "escalation_threshold_hours": 1,
            "examples": [
                "系统故障告警",
                "客户紧急请求",
                "数据安全事件",
                "关键截止时间已到"
            ]
        },
        "high": {
            "level": 1,
            "description": "重要但不紧急，当天必须完成",
            "color": "orange",
            "max_age_hours": 24,
            "escalation_threshold_hours": 12,
            "examples": [
                "带截止日期的任务",
                "影响他人工作的依赖任务",
                "用户明确要求的任务"
            ]
        },
        "medium": {
            "level": 2,
            "description": "正常优先级，按计划执行",
            "color": "yellow",
            "max_age_hours": 72,
            "escalation_threshold_hours": 48,
            "examples": [
                "定期报告生成",
                "日常数据维护",
                "常规优化改进"
            ]
        },
        "low": {
            "level": 3,
            "description": "低优先级，有空闲时处理",
            "color": "green",
            "max_age_hours": 168,
            "escalation_threshold_hours": 120,
            "examples": [
                "文档整理",
                "学习新材料",
                "非紧急的代码重构"
            ]
        },
        "deferred": {
            "level": 4,
            "description": "已推迟的任务，等待合适时机",
            "color": "gray",
            "max_age_hours": 720,
            "escalation_threshold_hours": 0,
            "examples": [
                "长期规划",
                "参考材料收集",
                "可选的优化项"
            ]
        }
    }
}
```

### 4.2 队列排序算法

任务出队时按以下综合分数排序：

```
score = priority_weight * (1 / age_penalty) * dependency_bonus * deadline_urgency

其中：
- priority_weight:  critical=100, high=75, medium=50, low=25, deferred=10
- age_penalty: max(1, age_hours / max_age_hours)  # 越老越紧急
- dependency_bonus: 被其他高优先级任务依赖时 * 1.5
- deadline_urgency: distance_to_deadline / total_allowed_time (越近越紧急)
```

### 4.3 任务入队示例

```json
{
    "task": {
        "task_id": "task-20240115-005",
        "title": "修复支付模块超时问题",
        "priority": "critical",
        "source": "user_request",
        "context": {
            "affected_module": "payment-service",
            "error_rate": "12%",
            "impact_users": "约 2000 人/小时",
            "root_cause": "第三方支付 API 响应超时"
        },
        "estimated_effort": "3h",
        "deadline": "2024-01-15T14:00:00Z",
        "tags": ["bugfix", "production", "payment"]
    },
    "queue_insertion": {
        "inserted_at": "2024-01-15T10:30:00Z",
        "queue_position": 1,
        "score": 98.5,
        "reason": "critical优先级 + 影响大量用户 + 即将到达截止时间"
    }
}
```

---

## 5. Proactive Cron 自主调度

### 5.1 Cron 任务注册

```json
{
    "cron_tasks": [
        {
            "cron_id": "cron-daily-digest",
            "title": "每日工作摘要",
            "schedule": "0 20 * * *",
            "timezone": "Asia/Shanghai",
            "description": "每天 20:00 生成当日工作摘要并发送给用户",
            "action": {
                "type": "composite",
                "steps": [
                    "查询今日完成的任务列表",
                    "统计各项指标（完成数、质量分、耗时）",
                    "生成摘要报告（Markdown 格式）",
                    "通过邮件发送给用户"
                ]
            },
            "enabled": true,
            "last_run": "2024-01-14T20:00:00Z",
            "next_run": "2024-01-15T20:00:00Z",
            "run_count": 45,
            "failure_count": 1,
            "max_consecutive_failures": 3,
            "cooldown_on_failure": "24h"
        },
        {
            "cron_id": "cron-hourly-health-check",
            "title": "每小时健康检查",
            "schedule": "0 * * * *",
            "timezone": "Asia/Shanghai",
            "description": "每小时检查系统状态和待处理任务",
            "action": {
                "type": "check",
                "checks": [
                    {
                        "name": "stale_tasks_check",
                        "description": "检查是否有超过预期时间的任务",
                        "condition": "any_task.age_hours > task.max_age_hours",
                        "action_on_fail": "escalate_to_user"
                    },
                    {
                        "name": "deadline_approaching",
                        "description": "检查即将到期的任务",
                        "condition": "any_task.deadline - now < 4h AND status != completed",
                        "action_on_fail": "increase_priority"
                    },
                    {
                        "name": "buffer_wal_sync",
                        "description": "检查 Buffer 和 WAL 是否同步",
                        "condition": "buffer.last_checkpoint_seq != wal.max_seq",
                        "action_on_fail": "replay_wal"
                    }
                ]
            },
            "enabled": true,
            "last_run": "2024-01-15T10:00:00Z",
            "next_run": "2024-01-15T11:00:00Z"
        },
        {
            "cron_id": "cron-weekly-review",
            "title": "每周工作回顾",
            "schedule": "0 9 * * 1",
            "timezone": "Asia/Shanghai",
            "description": "每周一 9:00 回顾上周工作，总结经验教训",
            "action": {
                "type": "review",
                "steps": [
                    "汇总本周完成的任务和成果",
                    "分析失败任务的原因",
                    "评估各类型任务的质量趋势",
                    "提出下周改进策略",
                    "更新 Agent 经验库"
                ]
            },
            "enabled": true,
            "last_run": "2024-01-08T09:00:00Z",
            "next_run": "2024-01-15T09:00:00Z"
        },
        {
            "cron_id": "cron-memory-compaction",
            "title": "记忆压缩",
            "schedule": "0 3 * * 0",
            "timezone": "Asia/Shanghai",
            "description": "每周日凌晨3点执行记忆压缩",
            "action": {
                "type": "maintenance",
                "steps": [
                    "将30天前的完成任务的详细日志压缩为摘要",
                    "保留所有 critical 和 learning 级别的日志",
                    "清理重复或无效的日志条目",
                    "更新知识库和经验索引"
                ]
            },
            "enabled": true,
            "last_run": "2024-01-07T03:00:00Z",
            "next_run": "2024-01-14T03:00:00Z"
        }
    ]
}
```

### 5.2 Cron 调度算法

```
调度流程：
1. 每分钟检查一次是否有 Cron 任务需要执行
2. 根据 cron 表达式和 timezone 计算下次执行时间
3. 检查前置条件：
   - 任务是否启用
   - 连续失败次数是否超过阈值
   - 是否在冷却期
   - 系统资源是否充足
4. 满足条件则触发执行，写入 WAL 记录
5. 执行结果更新到 cron_tasks 配置中
```

### 5.3 Cron 表达式速查

```
┌───────────── 分钟 (0-59)
│ ┌───────────── 小时 (0-23)
│ │ ┌───────────── 日 (1-31)
│ │ │ ┌───────────── 月 (1-12)
│ │ │ │ ┌───────────── 星期 (0-6, 0=周日)
│ │ │ │ │
* * * * *

常用示例：
0 */2 * * *    每2小时
0 9 * * 1-5    工作日每天9点
0 20 * * *     每天20点
0 0 1 * *      每月1号零点
0 3 * * 0      每周日凌晨3点
*/30 * * * *   每30分钟
0 9,12,18 * * * 每天9点、12点、18点
0 9-17 * * 1-5 工作日9点到17点每小时
```

---

## 6. 自评自省机制

### 6.1 自评框架

Agent 在完成每个任务后以及每周定期执行自评。自评使用以下框架：

```json
{
    "self_evaluation": {
        "eval_id": "eval-20240115-001",
        "task_id": "task-20240115-001",
        "evaluated_at": "2024-01-15T11:05:00Z",
        "dimensions": {
            "completeness": {
                "score": 0.95,
                "evidence": "报告涵盖了所有要求的分析维度：总体趋势、区域对比、产品线分析",
                "gaps": ["缺少竞品对比维度"]
            },
            "accuracy": {
                "score": 0.90,
                "evidence": "数据源可信，计算逻辑正确，但华东区域异常数据未完全验证",
                "issues": ["华东区域偏差可能由数据录入错误导致，需进一步确认"]
            },
            "timeliness": {
                "score": 1.0,
                "evidence": "任务在预估时间内完成（1.5h，预估2h）"
            },
            "usefulness": {
                "score": 0.88,
                "evidence": "报告提供了可操作的建议，但缺少具体的执行计划",
                "improvement": "下次报告应包含建议的优先级排序和实施步骤"
            },
            "communication": {
                "score": 0.92,
                "evidence": "报告结构清晰，图表直观，语言简洁"
            }
        },
        "overall_score": 0.93,
        "strengths": [
            "高效完成数据收集和分析",
            "主动发现数据异常并提出预警",
            "报告结构组织合理"
        ],
        "improvements": [
            "应包含竞品对比分析",
            "数据异常需深入验证而非仅标记",
            "建议部分应更具体可操作"
        ],
        "action_items": [
            {
                "action": "在后续报告中增加竞品对比模板",
                "priority": "medium",
                "deadline": "2024-01-20"
            },
            {
                "action": "建立数据异常验证的标准流程",
                "priority": "high",
                "deadline": "2024-01-17"
            }
        ],
        "strategy_adjustment": {
            "adjusted": true,
            "description": "增加数据验证步骤到标准分析流程中",
            "before": "数据收集 → 分析 → 报告",
            "after": "数据收集 → 数据验证 → 异常排查 → 分析 → 报告 → 验证"
        }
    }
}
```

### 6.2 自评维度说明

| 维度 | 权重 | 评估标准 |
|------|------|----------|
| `completeness` | 25% | 任务要求是否全部满足，是否有遗漏 |
| `accuracy` | 25% | 结果是否准确，数据是否可靠 |
| `timeliness` | 15% | 是否在预期时间内完成 |
| `usefulness` | 20% | 输出是否有实际价值，能否指导决策 |
| `communication` | 15% | 结果表达是否清晰、结构化、易于理解 |

### 6.3 自省策略调整

Agent 基于自评结果，持续调整工作策略：

```
自省触发条件：
1. 单任务评分 < 0.7 → 立即分析原因，记录教训
2. 连续3个任务评分下降 → 暂停新任务，全面复盘
3. 某维度连续低分 → 针对该维度专项改进
4. 新类型任务首次完成 → 额外评估，建立模板
5. 周评时发现趋势性下降 → 调整工作方法

策略调整记录格式：
{
    "adjustment_id": "adj-xxx",
    "trigger": "连续3个分析任务 accuracy < 0.85",
    "root_cause": "数据源未经二次验证直接使用",
    "solution": "增加数据交叉验证步骤",
    "expected_impact": "accuracy 提升 5-10%",
    "validation_method": "在接下来的5个分析任务中跟踪 accuracy 分数",
    "status": "implementing"
}
```

---

## 7. 目标分解与进度追踪

### 7.1 目标定义

```json
{
    "goal": {
        "goal_id": "goal-product-launch",
        "title": "完成新产品上线准备",
        "description": "协调各团队完成新产品 2.0 的上线准备，包括文档、测试、部署、通知",
        "status": "in_progress",
        "progress": 45,
        "created_at": "2024-01-10T08:00:00Z",
        "deadline": "2024-01-25T18:00:00Z",
        "milestones": [
            {
                "milestone_id": "ms-1",
                "title": "技术文档完成",
                "status": "completed",
                "completed_at": "2024-01-12T16:00:00Z"
            },
            {
                "milestone_id": "ms-2",
                "title": "功能测试通过",
                "status": "in_progress",
                "target_date": "2024-01-18T18:00:00Z",
                "progress": 70
            },
            {
                "milestone_id": "ms-3",
                "title": "部署环境就绪",
                "status": "pending",
                "target_date": "2024-01-22T12:00:00Z"
            },
            {
                "milestone_id": "ms-4",
                "title": "发布通知发出",
                "status": "pending",
                "target_date": "2024-01-25T10:00:00Z"
            }
        ],
        "dependencies": [],
        "risk_factors": [
            {
                "risk": "第三方 API 不兼容",
                "probability": "medium",
                "impact": "high",
                "mitigation": "已安排1月20日前完成兼容性测试"
            }
        ]
    }
}
```

### 7.2 目标分解规则

```
目标分解原则：
1. 每个目标最多分解为 5-8 个子任务
2. 子任务应可独立完成且可量化
3. 子任务之间明确依赖关系
4. 每个子任务有明确的验收标准
5. 子任务的预估总时间 ≤ 目标剩余时间 * 0.8（留出缓冲）

分解模板：
目标
├── 调研阶段 (1-2 个任务)
│   ├── 信息收集
│   └── 可行性分析
├── 规划阶段 (1-2 个任务)
│   ├── 方案设计
│   └── 资源评估
├── 执行阶段 (2-3 个任务)
│   ├── 核心开发/实施
│   ├── 测试验证
│   └── 文档编写
└── 收尾阶段 (1 个任务)
    └── 验收交付
```

### 7.3 进度追踪

Agent 使用以下方式追踪目标进度：

```
进度计算：
- 整体进度 = Σ(子任务进度 * 子任务权重) / 100
- 权重按预估工时分配
- 里程碑完成自动更新进度
- 阻塞任务不计算在内（但发出警告）

进度报告频率：
- Daily: 简要进度条和待办事项
- Weekly: 详细进度报告 + 风险分析 + 下周计划
- Milestone: 里程碑达成时生成总结报告
```

---

## 8. 自动恢复与重试策略

### 8.1 失败分类与处理

```json
{
    "failure_handling": {
        "categories": {
            "transient_failure": {
                "description": "暂时性故障，重试可能成功",
                "examples": ["网络超时", "API 限流", "服务暂时不可用", "资源竞争"],
                "strategy": {
                    "max_retries": 3,
                    "backoff": "exponential",
                    "initial_delay": "5s",
                    "max_delay": "5m",
                    "jitter": true,
                    "auto_retry": true,
                    "escalate_after": "max_retries_exceeded"
                }
            },
            "data_failure": {
                "description": "数据问题导致的失败",
                "examples": ["数据格式错误", "数据缺失", "数据不一致", "权限不足"],
                "strategy": {
                    "max_retries": 1,
                    "backoff": "fixed",
                    "delay": "30s",
                    "auto_retry": false,
                    "requires_manual_intervention": false,
                    "fallback_action": "使用备用数据源或跳过该步骤"
                }
            },
            "logic_failure": {
                "description": "逻辑或方案问题导致的失败",
                "examples": ["算法错误", "方案不合理", "需求理解偏差"],
                "strategy": {
                    "max_retries": 0,
                    "auto_retry": false,
                    "requires_analysis": true,
                    "action": "分析根因 → 调整方案 → 重新执行"
                }
            },
            "external_failure": {
                "description": "外部系统或依赖导致的失败",
                "examples": ["第三方服务宕机", "API 密钥过期", "依赖版本不兼容"],
                "strategy": {
                    "max_retries": 2,
                    "backoff": "exponential",
                    "initial_delay": "60s",
                    "max_delay": "30m",
                    "auto_retry": false,
                    "escalate_after": "2nd_retry_failed",
                    "fallback_action": "通知用户，等待外部恢复"
                }
            },
            "resource_failure": {
                "description": "资源不足导致的失败",
                "examples": ["磁盘空间不足", "内存溢出", "并发连接过多"],
                "strategy": {
                    "max_retries": 1,
                    "delay": "5m",
                    "auto_retry": false,
                    "action": "尝试释放资源后重试，否则通知用户"
                }
            }
        }
    }
}
```

### 8.2 重试执行记录

```json
{
    "retry_record": {
        "task_id": "task-20240115-003",
        "original_error": "API rate limit exceeded (HTTP 429)",
        "failure_category": "transient_failure",
        "retries": [
            {
                "attempt": 1,
                "timestamp": "2024-01-15T14:00:00Z",
                "delay_before": "5s",
                "result": "failed",
                "error": "API rate limit still exceeded"
            },
            {
                "attempt": 2,
                "timestamp": "2024-01-15T14:00:15sZ",
                "delay_before": "15s",
                "result": "failed",
                "error": "API rate limit still exceeded"
            },
            {
                "attempt": 3,
                "timestamp": "2024-01-15T14:01:00Z",
                "delay_before": "45s",
                "result": "success",
                "execution_time": "2.3s"
            }
        ],
        "total_recovery_time": "65s",
        "lesson_learned": "该 API 在高峰时段限流严重，建议在非高峰期调用或添加更长的退避时间"
    }
}
```

### 8.3 检查点恢复

```
检查点恢复流程：
1. 检测到任务失败
2. 查找 WAL 中该任务最近的 checkpoint
3. 从 checkpoint 恢复状态
4. 分析失败原因
5. 确定恢复策略：
   a. 从检查点重试（幂等操作）
   b. 从上一个步骤重试（非幂等操作）
   c. 跳过失败步骤（有降级方案时）
   d. 重新开始（无有效检查点时）
6. 记录恢复过程到 WAL
```

---

## 9. 记忆压缩与整合

### 9.1 压缩策略

```json
{
    "memory_compression": {
        "rules": [
            {
                "rule_name": "completed_task_compaction",
                "condition": "task.status == 'completed' AND age > 30 days",
                "action": "compress",
                "keep_fields": ["task_id", "title", "completed_at", "quality_score", "learnings"],
                "archive": {
                    "format": "summary",
                    "retention": "1 year"
                }
            },
            {
                "rule_name": "progress_log_compaction",
                "condition": "category == 'task_progress' AND age > 7 days AND task.status == 'completed'",
                "action": "remove",
                "keep_last_n_per_task": 3
            },
            {
                "rule_name": "learning_extraction",
                "condition": "level == 'learning' OR level == 'decision'",
                "action": "extract_and_index",
                "destination": "knowledge_base/learnings/"
            },
            {
                "rule_name": "error_log_cleanup",
                "condition": "level == 'error' AND age > 90 days AND NOT referenced_by_any_learning",
                "action": "remove"
            },
            {
                "rule_name": "cron_log_cleanup",
                "condition": "category == 'cron_triggered' AND cron_run_result == 'success' AND age > 14 days",
                "action": "remove"
            }
        ],
        "compaction_schedule": "0 3 * * 0",
        "compression_ratio_target": "0.3"
    }
}
```

### 9.2 知识提取格式

```json
{
    "extracted_knowledge": {
        "knowledge_id": "kn-20240115-001",
        "type": "lesson_learned",
        "source_tasks": ["task-20240115-001", "task-20240110-005"],
        "created_at": "2024-01-15T03:00:00Z",
        "title": "销售数据分析必须进行区域数据交叉验证",
        "description": "在多次分析中发现，区域级销售数据常因录入错误导致偏差。建议在分析流程中增加交叉验证步骤。",
        "context": "适用于所有涉及区域销售数据分析的任务",
        "applicable_scenarios": ["sales_analysis", "regional_report", "quarterly_review"],
        "confidence": 0.9,
        "times_applied": 0,
        "times_confirmed": 0,
        "last_applied": null,
        "tags": ["data_quality", "sales", "validation", "best_practice"]
    }
}
```

### 9.3 记忆整合规则

```
整合原则：
1. 保留所有 critical 和 learning 级别的日志（永不删除）
2. 保留所有 self_evaluation 记录（用于趋势分析）
3. 保留所有 strategy_adjustment 记录（用于策略演进）
4. 压缩已完成任务的多条 progress 日志为一条摘要
5. 移除重复或冗余的日志条目
6. 错误日志在相关学习被提取后可以清理
7. Cron 成功日志保留 14 天后清理
8. 所有清理操作必须写入新的 WAL 条目（保留审计记录）
```

---

## 10. 完整工作流示例

### 10.1 典型日工作流

```
09:00  系统启动 → 恢复 Buffer → 检查 Cron 任务
09:01  cron-daily-review 触发（每周一）
       → 读取上周 WAL → 生成周报 → 发送邮件
09:15  处理优先级队列
       → 取 critical 任务：修复支付超时
       → WAL: task_start
       → 执行修复（分析代码 → 定位问题 → 修改代码 → 测试）
       → WAL: task_progress (进度 50%)
       → WAL: task_complete (进度 100%)
       → 触发自评 → score: 0.95
10:00  cron-health-check 触发
       → 检查 stale tasks → 无异常
       → 检查 deadlines → 发现1个任务将在2h到期
       → 自动提升优先级
10:05  处理下一个 high 优先级任务
       → WAL: task_start
       → 执行中遇到 API 限流
       → WAL: task_anomaly (transient_failure)
       → 自动重试（指数退避）→ 成功
       → WAL: task_complete
11:00  cron-health-check 触发
       → 检查通过，继续工作
...
20:00  cron-daily-digest 触发
       → 汇总今日任务 → 生成摘要 → 发送邮件
20:05  Buffer 检查点 → 持久化
```

### 10.2 任务执行流程（代码示例）

```json
{
    "task_execution_flow": {
        "step_1_receive": {
            "action": "从优先级队列取出下一个任务",
            "wal_entry": {
                "level": "info",
                "category": "task_start",
                "description": "开始执行任务: {{task.title}}"
            },
            "buffer_update": {
                "move_task_from": "pending_tasks",
                "move_task_to": "active_tasks",
                "set_status": "in_progress",
                "set_progress": 0
            }
        },
        "step_2_plan": {
            "action": "分析任务要求，制定执行计划",
            "wal_entry": {
                "level": "debug",
                "category": "task_progress",
                "description": "执行计划: {{plan}}"
            },
            "buffer_update": {
                "set_plan": "{{plan}}",
                "set_estimated_steps": "{{N}}"
            }
        },
        "step_3_execute": {
            "action": "按计划逐步执行",
            "for_each_step": {
                "before": "WAL: task_progress (记录步骤开始)",
                "execute": "执行步骤操作",
                "after": {
                    "success": "WAL: task_progress (记录进度百分比)",
                    "failure": "WAL: task_fail → 进入恢复流程"
                }
            }
        },
        "step_4_evaluate": {
            "action": "任务完成后执行自评",
            "wal_entry": {
                "level": "info",
                "category": "self_eval",
                "description": "任务自评完成，综合得分: {{score}}"
            },
            "outputs": [
                "quality_score",
                "strengths",
                "improvements",
                "action_items",
                "strategy_adjustments"
            ]
        },
        "step_5_finalize": {
            "action": "标记完成，更新目标进度",
            "wal_entry": {
                "level": "info",
                "category": "task_complete",
                "description": "任务完成: {{task.title}}，质量评分: {{score}}"
            },
            "buffer_update": {
                "set_status": "completed",
                "set_completed_at": "now",
                "set_quality_score": "{{score}}",
                "set_learnings": "{{extracted_learnings}}",
                "move_task_to": "completed_tasks"
            },
            "goal_update": {
                "recalculate_progress": true,
                "check_milestones": true
            }
        }
    }
}
```

---

## 11. 文件结构规范

Agent 应按以下目录结构组织数据文件：

```
~/.agent-wal/
├── wal-active.json              # 活跃的 WAL 日志
├── buffer.json                  # Working Buffer 快照
├── priority-queue.json          # 优先级队列
├── cron-tasks.json              # Cron 任务配置
├── goals/
│   ├── goal-quarterly-report.json
│   └── goal-product-launch.json
├── archive/
│   ├── wal/                     # 归档的 WAL 日志
│   │   ├── wal-2024-W01.json.gz
│   │   └── wal-2024-W02.json.gz
│   ├── tasks/                   # 归档的已完成任务
│   │   └── completed/
│   └── evaluations/             # 归档的自评记录
│       └── eval-2024-W01.json.gz
├── knowledge-base/
│   ├── learnings/               # 提取的经验教训
│   │   ├── kn-data-validation.json
│   │   └── kn-api-rate-limit.json
│   ├── strategies/              # 策略调整记录
│   │   └── strategy-evolution.json
│   └── templates/               # 任务模板
│       ├── analysis-template.json
│       └── report-template.json
├── metrics/
│   ├── daily-metrics.json       # 每日指标
│   └── weekly-metrics.json      # 每周指标
└── config/
    ├── agent-config.json        # Agent 配置
    └── credentials.json         # 凭证（加密存储）
```

---

## 12. 异常场景处理

### 12.1 WAL 损坏恢复

```
场景：WAL 文件损坏或格式错误

恢复步骤：
1. 尝试解析 WAL 文件，定位损坏位置
2. 使用最后一个有效的 checkpoint 恢复 Buffer
3. 将损坏部分隔离到 separate 文件
4. 从 Buffer 重建后续状态
5. 标记丢失的时间段
6. WAL 记录恢复操作
7. 通知用户可能丢失的数据
```

### 12.2 Buffer 一致性修复

```
场景：Buffer 和 WAL 不同步

修复步骤：
1. 对比 Buffer.last_checkpoint_seq 与 WAL 最大 seq
2. 差异条目逐条回放到 Buffer
3. 如果存在冲突（同一任务的矛盾状态）：
   a. 以 WAL 的最新条目为准
   b. 记录冲突到 audit log
4. 验证修复后的 Buffer 完整性
5. 写入新的 Buffer 快照
```

### 12.3 任务僵尸处理

```
场景：任务长期处于 in_progress 状态（可能因崩溃中断）

检测规则：
- in_progress 状态超过 24h（或任务预估时间的 3 倍）
- 最近 2h 无 WAL progress 记录

处理步骤：
1. 标记为 stale
2. 分析 WAL 找到最后一个 checkpoint
3. 评估恢复成本：
   a. 成本低 → 自动恢复继续
   b. 成本高 → 标记为 failed，记录原因
4. 通知用户
```

### 12.4 Cron 任务雪崩

```
场景：多个 Cron 任务同时触发，系统资源不足

预防措施：
1. Cron 任务之间设置最小间隔（默认 5 分钟）
2. 系统资源不足时跳过低优先级 Cron
3. 限制同时运行的 Cron 任务数量（默认 2 个）
4. 长 Cron 任务设置超时时间
5. Cron 执行队列化，按优先级串行执行
```

### 12.5 记忆溢出

```
场景：WAL 文件或记忆数据超过存储限制

处理策略：
1. 紧急压缩：触发即时压缩（跳过非关键日志）
2. 分级清理：
   - Level 1: 清理 cron 成功日志和 debug 日志
   - Level 2: 压缩 completed task 详细日志
   - Level 3: 归档 30 天前的所有非关键数据
3. 如果仍然不足：
   - 向用户报告存储状况
   - 建议导出归档数据到外部存储
```
