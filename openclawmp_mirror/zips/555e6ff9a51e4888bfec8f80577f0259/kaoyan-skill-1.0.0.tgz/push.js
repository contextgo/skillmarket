#!/usr/bin/env node
/**
 * 考研人 Skill - 每日推送脚本
 * 根据用户配置，在指定时间推送真题、考点、词汇、政治、数学等知识
 * 并附带人性化关怀内容
 */

const fs = require('fs');
const path = require('path');

// 配置文件路径
const CONFIG_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'kaoyan-user-config.json')
  : path.join(process.env.HOME, '.stepclaw', 'kaoyan-user-config.json');

const KNOWLEDGE_BASE = path.join(__dirname, 'knowledge');

// 加载用户配置
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = fs.readFileSync(CONFIG_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('加载配置失败:', e.message);
  }
  return null;
}

// 加载JSON知识库
function loadKnowledge(subject, file) {
  const filePath = path.join(KNOWLEDGE_BASE, subject, file);
  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  }
  return null;
}

// 从数组中随机选取一个元素
function randomPick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// 根据当前日期和星期确定今日推送科目
function getTodaySubject(config) {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0=周日, 1=周一...
  const subjects = config.subjects || ['政治', '英语一', '数学一'];

  // 周一:政治, 周二:英语, 周三:数学, 周四:专业课, 周五:综合, 周六/日:自由
  const schedule = {
    1: subjects[0] || '政治',
    2: subjects[1] || '英语一',
    3: subjects[2] || '数学一',
    4: subjects[3] || '408',
    5: '综合复习',
    6: '自由选做',
    0: '周总结'
  };

  return schedule[dayOfWeek] || '综合复习';
}

// 生成早安激励消息
function generateMorningMessage(config) {
  const encouragement = loadKnowledge('encouragement', 'morning.json');
  const quote = encouragement ? randomPick(encouragement.messages) : { text: "早安，考研人！" };

  const examDate = new Date(config.examDate || '2025-12-20');
  const now = new Date();
  const daysLeft = Math.floor((examDate - now) / (1000 * 60 * 60 * 24));

  const msg = `
🌅 早安，考研人！今天是距离${config.targetSchool || '考研'}还有 ${daysLeft} 天的日子。

✨ 今日激励：
"${quote.text}"

📋 今日学习建议：
- 上午：专注难点科目，保持高效
- 下午：真题练习，查漏补缺
- 晚上：复盘总结，梳理知识框架

💪 记住：坚持本身就是一种胜利。你在进步，每一天！
`.trim();

  return msg;
}

// 生成每日一题
function generateDailyQuestion(config) {
  const subject = getTodaySubject(config);
  let question = null;

  // 根据科目选择题库
  if (subject === '政治') {
    const ma = loadKnowledge('subjects/政治', '马原.json');
    if (ma && ma.questions) question = randomPick(ma.questions);
  } else if (subject === '英语一' || subject === '英语二') {
    const words = loadKnowledge('subjects/英语', '核心词汇3000.json');
    if (words && words.words) {
      const w = randomPick(words.words);
      return `📖 【每日一词】${w.word} (${w.pronunciation})\n意思：${w.meaning}\n例句：${w.example}`;
    }
  } else if (subject === '数学一' || subject === '数学二' || subject === '数学三') {
    const math = loadKnowledge('subjects/数学一', '高数.json');
    if (math && math.questions) question = randomPick(math.questions);
  } else {
    // 专业课或其他
    const major = config.major || '408';
    const prof = loadKnowledge('subjects/专业课', `${major}.json`);
    if (prof && prof.questions) question = randomPick(prof.questions);
  }

  if (!question) {
    return `📝 今日科目：${subject}\n（题库正在完善中，请稍后再试）`;
  }

  return `
📝 【每日一题】| ${subject}

${question.question}

💡 考点：${question.tags ? question.tags.join('、') : '核心知识点'}

⏱️ 建议思考：2-3分钟

---
🔍 参考答案：
✅ 答案：${question.answer}

📚 解析：
${question.explanation}

📌 难度：${question.difficulty === 'easy' ? '基础' : question.difficulty === 'medium' ? '中等' : '难题'}
`.trim();
}

// 生成晚间考点总结
function generateEveningSummary(config) {
  const dayOfWeek = new Date().getDay();
  if (dayOfWeek === 0) {
    // 周日生成周总结
    return generateWeeklySummary(config);
  }

  // 根据科目生成考点总结
  const subject = getTodaySubject(config);
  let summary = "";

  if (subject === '政治') {
    summary = `
📖 【考点精粹】| 马原核心概念

🔑 今日主题：矛盾观

📌 核心要点：
1. 矛盾同一性：相互依存、相互转化
2. 矛盾斗争性：相互排斥、相互对立
3. 矛盾的普遍性：事事有矛盾，时时有矛盾
4. 矛盾的特殊性：具体问题具体分析
5. 主要矛盾与次要矛盾、矛盾主要方面与次要方面

💡 记忆口诀：
"矛盾双方同存异，普遍特殊要分清，
主要矛盾抓重点，具体分析是灵魂。"

📝 真题提示：
2024年考研政治单选题第3题（矛盾特殊性）

📚 建议：结合真题理解，完成今天对应的练习题。
`;
  } else if (subject.includes('数学')) {
    summary = `
📖 【考点精粹】| 高等数学

🔑 今日主题：中值定理

📌 核心定理：
1. 罗尔定理：f(a)=f(b) → ∃ξ∈(a,b), f'(ξ)=0
2. 拉格朗日中值定理：f(x)在[a,b]连续，(a,b)可导 → ∃ξ, f'(ξ)=(f(b)-f(a))/(b-a)
3. 柯西中值定理：条件扩展，用于证明极限和不等式
4. 泰勒公式：用多项式逼近函数，带余项

💡 应用场景：
- 证明方程根的存在性
- 估计函数值误差
- 不等式证明

📝 真题链接：
近5年至少出现2道中值定理证明大题

📚 建议：掌握每个定理的条件和结论，多做证明题训练。
`;
  } else {
    summary = `
📖 【今晚回顾】| ${subject}

✨ 今日所学内容已结束，建议：
1. 快速回顾今天做错的题目
2. 整理笔记中的关键词
3. 记忆今天遇到的生词或公式

🌙 早点休息，明天继续！
`;
  }

  return summary.trim();
}

// 生成周总结
function generateWeeklySummary(config) {
  // 这里可以读取本周完成情况（从日志文件或数据库）
  // 现在先用模板
  return `
🌞 本周学习总结（第${Math.floor(new Date().getDate()/7)+1}周）

📊 本周完成情况：
- 已完成题目：7题
- 英语词汇：70个
- 政治考点：5个
- 数学例题：5道

📈 进度评估：
你已完成本周计划的 85%，超越了 60% 的考生！

💌 本周鼓励：
"不是因为看到了希望才坚持，
而是因为坚持了才看到希望。"

🎯 下周预告：
- 数学：开始真题模拟
- 英语：作文模板整理
- 政治：马原大框架梳理

新的一周，继续保持！💪
`.trim();
}

// 主推送函数：根据时间参数返回对应消息
function generatePushMessage(timeSlot) {
  const config = loadConfig();
  if (!config) {
    return "⚠️ 检测到未配置考研信息。请发送配置消息，例如：\n「我是计算机专业，考408，还有230天」\n进行初始化。";
  }

  switch (timeSlot) {
    case 'morning':
      return generateMorningMessage(config);
    case 'afternoon':
      return generateDailyQuestion(config);
    case 'evening':
      return generateEveningSummary(config);
    default:
      return generateDailyQuestion(config);
  }
}

// 如果直接运行脚本，输出测试消息
if (require.main === module) {
  const timeSlot = process.argv[2] || 'afternoon';
  console.log(generatePushMessage(timeSlot));
}

module.exports = {
  generatePushMessage,
  loadConfig,
  getTodaySubject
};
