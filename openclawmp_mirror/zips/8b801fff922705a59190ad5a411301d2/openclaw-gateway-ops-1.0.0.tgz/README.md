# OpenClaw 网关快修手册

5 分钟定位并修复 OpenClaw 网关常见故障：端口占用、鉴权失败、服务异常、模型连通。

## 安装

```bash
openclawmp install skill/@your-id/openclaw-gateway-ops
```

## 核心价值

- 故障排查顺序固定，减少漏项
- 先可回滚动作，降低误操作风险
- 输出格式统一，便于复盘
