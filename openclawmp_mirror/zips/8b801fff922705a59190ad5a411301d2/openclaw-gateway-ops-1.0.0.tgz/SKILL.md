---
name: openclaw-gateway-ops
description: "Fix common OpenClaw gateway failures in minutes: port conflicts, auth mismatch, service issues, and model connectivity."
version: 1.0.0
type: skill
displayName: "OpenClaw Gateway Quick Fix"
tags: "openclaw, gateway, ops, diagnostics"
---

# OpenClaw 网关快修手册

用于快速恢复 OpenClaw 网关可用性，优先处理最常见故障：服务未启动、端口冲突、鉴权不匹配、模型连通异常。

## 适用场景

- `openclaw gateway status` 报错或显示不可用
- Agent 无法回复消息
- 刚改完模型/网关配置后出现异常
- 定时任务开始集中失败

## 执行原则

1. 先读后写：先确认状态，再改配置。
2. 先可回滚动作：优先重启/前台运行，不先改大配置。
3. 记录变更：每次修改后立即验证并保留关键输出。

## 标准流程（5 分钟）

### 1) 快速体检（只读）

```bash
openclaw gateway status
openclaw health
openclaw status
```

若这里已全部正常，直接结束。

### 2) 判断运行模式并恢复

#### A. 服务模式可用

```bash
openclaw gateway restart
openclaw gateway status
```

#### B. 服务模式不可用（常见于无 user systemd 环境）

```bash
openclaw gateway run --force
```

说明：`--force` 会先释放目标端口，再前台拉起网关。

### 3) 鉴权与配置核对

```bash
openclaw config get gateway.auth.mode --json
openclaw config get gateway.bind --json
openclaw config get models --json
```

重点检查：

- `gateway.auth.mode` 是否符合当前客户端连接方式
- `gateway.bind` 是否符合预期（loopback / lan）
- 模型 provider 的 `baseUrl`、`auth`、`model id` 是否完整

### 4) 常见故障分支

#### 端口冲突

现象：启动时报端口占用。

```bash
openclaw gateway run --force
```

#### 鉴权失败

现象：客户端提示 token/password/trusted-proxy 不匹配。

动作：核对 `gateway.auth.mode` 与客户端参数一致，再重连。

#### 模型不可达

现象：网关在线但调用模型失败。

动作：

1. 检查 `models.providers.*.baseUrl`
2. 确认对应 key 已加载
3. 执行一次最小请求验证（例如让 agent 回“ok”）

### 5) 恢复后验收

- `openclaw gateway status` 正常
- 当前聊天可收到回复
- 最近一次关键任务可执行（如一次简短工具调用）

## 回滚建议

- 配置改坏：从 `openclaw.json.bak` 恢复
- 临时前台恢复后，按环境再决定是否切回服务模式

## 输出模板

执行结束后按以下格式汇报：

- 结论：已恢复 / 未恢复
- 依据：关键命令输出
- 风险：剩余风险点
- 下一步：可执行命令
