---
name: crypto-market-regime-detection
description: "Detect market regime shifts (trending/mean-reverting/volatile/compressed) using multi-timeframe analysis for crypto trading decisions"
version: 1.0.0
tags: ["crypto", "trading", "market-analysis", "regime-detection"]
---

# Crypto Market Regime Detection

A skill for identifying the current market regime to adapt trading strategy accordingly. Different regimes require fundamentally different approaches.

## Regime Types

### 1. Trending Market (Trend Following)
- **Characteristics**: Higher highs, higher lows (uptrend) or lower highs, lower lows (downtrend)
- **Indicators**: ADX > 25, consistent price above/below 20/50 EMA, low drawdowns
- **Strategy**: Trend following, breakout entries, trailing stops
- **Risk**: Trend reversal catching

### 2. Mean-Reverting Market (Range Trading)
- **Characteristics**: Price oscillates between support and resistance
- **Indicators**: ADX < 20, RSI oscillates 30-70, Bollinger Bands squeeze
- **Strategy**: Sell resistance, buy support, fade extremes
- **Risk**: Range breakout

### 3. High Volatility / Choppy (Reduce Exposure)
- **Characteristics**: Large daily swings, whipsaws, no clear direction
- **Indicators**: VIX-equivalent elevated, wide Bollinger Bands, ADX rising but price not trending
- **Strategy**: Reduce position size, wider stops, or sit out
- **Risk**: Being chopped to pieces

### 4. Compressed / Low Volatility (Pre-Breakout)
- **Characteristics**: Narrow price range, declining volume, Bollinger Band squeeze
- **Indicators**: ATR at multi-week lows, volume declining, tight consolidation
- **Strategy**: Wait for breakout, set alerts at key levels
- **Risk**: False breakout

## Detection Framework

### Step 1: Calculate Regime Score

For each timeframe (4H, 1D, 1W):

- trend_score = (ADX > 25 ? ADX/50 : 0) * directional_bias
- volatility_score = ATR_percentile / 100
- range_score = 1 - (price_range / moving_avg_range)
- regime = argmax(trend_score, volatility_score, range_score)

### Step 2: Multi-Timeframe Confirmation

| 4H Regime | 1D Regime | 1W Regime | Combined | Action |
|-----------|-----------|-----------|----------|--------|
| Trending | Trending | Trending | Strong Trend | Full trend following |
| Trending | Range | Range | Weak Trend | Reduced trend following |
| Range | Range | Compressed | Pre-Breakout | Wait for breakout |
| Volatile | Volatile | Any | High Volatility | Reduce exposure |
| Compressed | Range | Range | Consolidation | Set alerts, wait |

### Step 3: Regime Transition Detection

Watch for transitions using:
- ADX crossing 20/25 thresholds
- Bollinger Band width expanding after squeeze
- Volume spike on range breakout
- EMA crossover on higher timeframe

## Quick Reference

- ADX < 20 + Squeeze = COMPRESSION, set alerts
- ADX < 20 + Wide BB = RANGE, fade extremes
- ADX > 25 + Aligned EMAs = TREND, follow with trailing stops
- ADX > 25 + Choppy price = VOLATILE, sit out
