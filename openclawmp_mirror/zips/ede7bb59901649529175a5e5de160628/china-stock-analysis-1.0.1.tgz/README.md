# 中国股票分析器

中国股票分析器 是一个面向 OpenClaw Agent 的技能资产，用于把特定任务场景沉淀为可复用、可执行、可验证的工作流程。

## 核心能力

- 根据用户任务触发对应的操作步骤
- 复用 `SKILL.md` 中定义的规则、边界和输出格式
- 提升 Agent 执行一致性，减少重复判断和无效沟通
- 适合安装到 OpenClaw 环境中作为能力扩展

## 原始能力简介

Analyze Chinese stock prices (A-shares, HK stocks) and provide investment recommendations. 触发词：股票分析、A股、港股、market analysis、投资建议、stock recommendation、中国股票。Use when the user asks about stock analysis for Chinese companies, including buying/selling recommendations and market trends.

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：技能所需参考资料、脚本或测试提示词
