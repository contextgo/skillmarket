#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Break Inertia - Word Report Generator
Generate thinking breakthrough plan based on four-step framework
"""

import sys
import json
from datetime import datetime
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
except ImportError:
    print("[ERROR] Please install: pip install python-docx")
    sys.exit(1)


def create_cover(doc, scenario, date_str):
    """Create cover page"""
    # Empty lines
    for _ in range(6):
        doc.add_paragraph()
    
    # Main title
    title_para = doc.add_paragraph()
    title_run = title_para.add_run("打破惯性思维方案")
    title_run.font.size = Pt(28)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(128, 0, 128)  # Purple
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Empty lines
    for _ in range(2):
        doc.add_paragraph()
    
    # Subtitle
    subtitle_para = doc.add_paragraph()
    subtitle_run = subtitle_para.add_run("觉察-质疑-重构-验证 四步链条")
    subtitle_run.font.size = Pt(16)
    subtitle_run.font.color.rgb = RGBColor(102, 102, 102)
    subtitle_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Scenario
    if scenario:
        scenario_para = doc.add_paragraph()
        scenario_run = scenario_para.add_run(f"场景：{scenario}")
        scenario_run.font.size = Pt(14)
        scenario_run.font.color.rgb = RGBColor(51, 51, 51)
        scenario_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Empty lines
    for _ in range(4):
        doc.add_paragraph()
    
    # Date
    date_para = doc.add_paragraph()
    date_run = date_para.add_run(date_str)
    date_run.font.size = Pt(12)
    date_run.font.color.rgb = RGBColor(128, 128, 128)
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Page break
    doc.add_page_break()


def add_heading_custom(doc, text, level=1):
    """Add custom heading"""
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        if level == 1:
            run.font.color.rgb = RGBColor(128, 0, 128)  # Purple
            run.font.size = Pt(18)
        elif level == 2:
            run.font.color.rgb = RGBColor(153, 50, 204)  # Medium purple
            run.font.size = Pt(14)
        else:
            run.font.color.rgb = RGBColor(51, 51, 51)
    return heading


def create_inertia_table(doc, awareness_data):
    """Create inertia type assessment table"""
    add_heading_custom(doc, "惯性类型识别", level=2)
    
    # Create table
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    
    # Header
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = '惯性类型'
    hdr_cells[1].text = '特征'
    hdr_cells[2].text = '是否存在'
    
    # Set header style
    for cell in hdr_cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Add data rows
    inertia_types = [
        ("经验惯性", "以前都是这么干的", awareness_data.get('experience_inertia', '否')),
        ("权威惯性", "领导/专家说的应该没错", awareness_data.get('authority_inertia', '否')),
        ("从众惯性", "大家都这么做", awareness_data.get('conformity_inertia', '否')),
        ("情绪惯性", "我讨厌这个，所以不做", awareness_data.get('emotion_inertia', '否')),
    ]
    
    for type_name, feature, exists in inertia_types:
        row_cells = table.add_row().cells
        row_cells[0].text = type_name
        row_cells[1].text = feature
        row_cells[2].text = exists
    
    doc.add_paragraph()


def create_counterexample_section(doc, question_data):
    """Create counterexample analysis section"""
    add_heading_custom(doc, "反例搜索", level=2)
    
    counterexamples = question_data.get('counterexamples', [])
    if counterexamples:
        for i, example in enumerate(counterexamples, 1):
            para = doc.add_paragraph()
            label = para.add_run(f"反例{i}：")
            label.font.bold = True
            para.add_run(example)
            para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def create_environment_scan(doc, question_data):
    """Create environment scan section"""
    add_heading_custom(doc, "环境扫描", level=2)
    
    env_scan = question_data.get('environment_scan', {})
    if env_scan:
        dimensions = [
            ("技术变化", env_scan.get('technology', '')),
            ("规则变化", env_scan.get('regulation', '')),
            ("资源变化", env_scan.get('resources', '')),
            ("市场变化", env_scan.get('market', '')),
        ]
        
        for label, content in dimensions:
            if content:
                para = doc.add_paragraph()
                label_run = para.add_run(f"{label}：")
                label_run.font.bold = True
                para.add_run(content)
                para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def create_reconstruction_section(doc, reconstruction_data):
    """Create reconstruction section"""
    add_heading_custom(doc, "重构方案", level=2)
    
    # First principles
    first_principles = reconstruction_data.get('first_principles', {})
    if first_principles:
        add_heading_custom(doc, "第一性原理", level=3)
        essence = first_principles.get('essence', '')
        if essence:
            para = doc.add_paragraph()
            label = para.add_run("本质：")
            label.font.bold = True
            para.add_run(essence)
            para.paragraph_format.line_spacing = 1.5
    
    # Reverse thinking
    reverse = reconstruction_data.get('reverse_thinking', {})
    if reverse:
        add_heading_custom(doc, "逆向思维", level=3)
        fail_path = reverse.get('fail_path', '')
        if fail_path:
            para = doc.add_paragraph()
            label = para.add_run("失败路径：")
            label.font.bold = True
            para.add_run(fail_path)
            para.paragraph_format.line_spacing = 1.5
    
    # Multiple perspectives
    perspectives = reconstruction_data.get('perspectives', {})
    if perspectives:
        add_heading_custom(doc, "多元视角", level=3)
        for key, value in perspectives.items():
            if value:
                para = doc.add_paragraph()
                label = para.add_run(f"{key}：")
                label.font.bold = True
                para.add_run(value)
                para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def create_verification_section(doc, verification_data):
    """Create verification section"""
    add_heading_custom(doc, "验证计划", level=2)
    
    # Test design
    test_design = verification_data.get('test_design', {})
    if test_design:
        add_heading_custom(doc, "测试设计", level=3)
        for key, value in test_design.items():
            if value:
                para = doc.add_paragraph()
                label = para.add_run(f"{key}：")
                label.font.bold = True
                para.add_run(str(value))
                para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def create_checklist_section(doc):
    """Create quick thinking checklist"""
    add_heading_custom(doc, "快速思考清单", level=2)
    
    checklist = [
        "1. \"这是我的真实想法，还是大脑的自动导航？\"（觉察）",
        "2. \"除了这个理由，还有什么其他可能性？\"（质疑）",
        "3. \"抛开所有已知，这件事的核心是什么？\"（重构）",
        "4. \"我能不能先试一小步，看看会发生什么？\"（验证）"
    ]
    
    for item in checklist:
        para = doc.add_paragraph(item)
        para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def generate_report(data, output_path):
    """Generate complete thinking breakthrough plan"""
    doc = Document()
    
    # Set default font
    style = doc.styles['Normal']
    style.font.name = 'Microsoft YaHei'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    style.font.size = Pt(11)
    
    # Extract data
    scenario = data.get('scenario', '')
    date_str = data.get('date', datetime.now().strftime('%Y年%m月%d日'))
    
    # 1. Cover
    create_cover(doc, scenario, date_str)
    
    # 2. Awareness
    add_heading_custom(doc, "第一步：觉察", level=1)
    doc.add_paragraph()
    
    awareness = data.get('awareness', {})
    if awareness:
        create_inertia_table(doc, awareness)
        
        # Auto reaction
        auto_reaction = awareness.get('auto_reaction', {})
        if auto_reaction:
            add_heading_custom(doc, "自动反应捕捉", level=3)
            for key, value in auto_reaction.items():
                para = doc.add_paragraph()
                label = para.add_run(f"{key}：")
                label.font.bold = True
                para.add_run(str(value))
                para.paragraph_format.line_spacing = 1.5
    
    # Page break
    doc.add_page_break()
    
    # 3. Question
    add_heading_custom(doc, "第二步：质疑", level=1)
    doc.add_paragraph()
    
    question = data.get('question', {})
    if question:
        create_counterexample_section(doc, question)
        create_environment_scan(doc, question)
        
        # Zero assumption
        zero = question.get('zero_assumption', '')
        if zero:
            add_heading_custom(doc, "归零假设", level=3)
            para = doc.add_paragraph(zero)
            para.paragraph_format.line_spacing = 1.5
    
    # Page break
    doc.add_page_break()
    
    # 4. Reconstruction
    add_heading_custom(doc, "第三步：重构", level=1)
    doc.add_paragraph()
    
    reconstruction = data.get('reconstruction', {})
    if reconstruction:
        create_reconstruction_section(doc, reconstruction)
    
    # Page break
    doc.add_page_break()
    
    # 5. Verification
    add_heading_custom(doc, "第四步：验证", level=1)
    doc.add_paragraph()
    
    verification = data.get('verification', {})
    if verification:
        create_verification_section(doc, verification)
    
    # Page break
    doc.add_page_break()
    
    # 6. Action manual
    add_heading_custom(doc, "行动手册", level=1)
    doc.add_paragraph()
    
    create_checklist_section(doc)
    
    # Tools
    add_heading_custom(doc, "常用工具", level=2)
    
    tools = [
        ("惯性识别表", "识别经验/权威/从众/情绪惯性"),
        ("反例搜索框架", "寻找时间/空间/人物/维度反例"),
        ("环境扫描清单", "扫描技术/规则/资源/市场变化"),
        ("第一性原理模板", "逐层追问到本质"),
        ("多元视角切换", "竞争对手/客户/旁观者/未来自己"),
        ("低成本测试设计", "小步试错验证新思维")
    ]
    
    for name, desc in tools:
        para = doc.add_paragraph(style='List Bullet')
        label = para.add_run(f"{name}")
        label.font.bold = True
        para.add_run(f" - {desc}")
    
    # Save document
    doc.save(output_path)
    print(f"[OK] Thinking breakthrough plan generated: {output_path}")


def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python generate_report.py <json_file> [output_path]")
        print("Example: python generate_report.py data.json breakthrough_plan.docx")
        sys.exit(1)
    
    json_file = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "打破惯性思维方案.docx"
    
    # Read JSON data
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Generate report
    generate_report(data, output_path)


if __name__ == '__main__':
    main()
