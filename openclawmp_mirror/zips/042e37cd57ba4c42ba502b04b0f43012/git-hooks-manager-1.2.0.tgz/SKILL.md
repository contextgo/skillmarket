---
name: git-hooks-manager
description: 使用 pre-commit 框架在多个仓库中自动化配置 Git hooks。支持代码检查（linting）、格式化、密钥检测和代码质量强制规范，提供针对不同语言的配置模板。适用于以下场景：(1) 在仓库中设置 pre-commit hooks；(2) 为特定语言配置代码质量检查；(3) 添加密钥检测以防止凭证泄露；(4) 在多个项目中标准化 hooks；(5) 将 hooks 集成到 CI/CD 流水线中；(6) 排查 hook 相关问题。
---

# Git Hooks Manager

使用 pre-commit 框架在多个仓库中自动化配置 Git hooks，支持代码检查（linting）、格式化、密钥检测和代码质量强制规范。

## 快速开始

```bash
# Install pre-commit (requires Python 3.8+)
pip install pre-commit

# Create .pre-commit-config.yaml in your repo root
# (see language profiles below)

# Install the hooks
cd your-repo
pre-commit install

# Run against all files (recommended first-time check)
pre-commit run --all-files
```

## 架构

```
.git/hooks/pre-commit (thin wrapper, auto-installed)
  └── pre-commit framework (Python, manages hook lifecycle)
        └── .pre-commit-config.yaml (project configuration)
              ├── Repo: ruff-pre-commit (cached in ~/.cache/pre-commit)
              │     └── Hooks: ruff (lint), ruff-format (format)
              ├── Repo: pre-commit-hooks
              │     └── Hooks: trailing-whitespace, check-yaml, ...
              └── Repo: detect-secrets
                    └── Hooks: detect-secrets (secret scanning)
```

分为三层：

1. **Git hooks**：`.git/hooks/pre-commit` 是一个轻量包装器。Git 在每次执行 `git commit` 前调用它。
2. **pre-commit 框架**：读取配置文件，将 hook 仓库下载到隔离环境中，并按顺序运行每个 hook。
3. **Hook 仓库**：包含 hook 定义的 Git 仓库。仅下载一次，缓存在 `~/.cache/pre-commit/` 中。每个仓库拥有独立的依赖项。

## 语言配置模板

### Python 项目

```yaml
# .pre-commit-config.yaml
repos:
  # Ruff: fast Python linter + formatter (replaces flake8 + black + isort)
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.0
    hooks:
      - id: ruff           # Lint
        args: [--fix]      # Auto-fix issues
      - id: ruff-format    # Format

  # General file checks
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.6.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-toml
      - id: check-json
      - id: check-added-large-files
        args: ['--maxkb=500']
      - id: check-merge-conflict
      - id: debug-statements  # Catches pdb/ipdb breakpoints

  # Secret detection
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
```

### JavaScript / TypeScript 项目

```yaml
repos:
  # Prettier: code formatter
  - repo: https://github.com/pre-commit/mirrors-prettier
    rev: v4.0.0-alpha.8
    hooks:
      - id: prettier
        types_or: [javascript, jsx, ts, tsx, css, json, markdown]

  # ESLint: linting
  - repo: https://github.com/pre-commit/mirrors-eslint
    rev: v9.0.0
    hooks:
      - id: eslint
        types_or: [javascript, jsx, ts, tsx]
        args: ['--fix']

  # General checks
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.6.0
    hooks:
      - id: trailing-whitespace
      - id: check-json
      - id: check-merge-conflict
      - id: no-commit-to-branch
        args: ['--branch', 'main']
```

### Go 项目

```yaml
repos:
  - repo: https://github.com/dnephin/pre-commit-golang
    rev: v0.5.1
    hooks:
      - id: go-fmt
      - id: go-vet
      - id: go-imports
      - id: go-build
      - id: go-unit-tests
      - id: go-build-tags

  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.6.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
```

### Rust 项目

```yaml
repos:
  - repo: https://github.com/doublify/pre-commit-rust
    rev: v1.0
    hooks:
      - id: fmt
      - id: cargo-check
      - id: clippy
        args: ['--all-targets', '--', '-D', 'warnings']
```

### 多语言 / Monorepo 项目

```yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.6.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-added-large-files
      - id: check-merge-conflict
      - id: detect-private-key  # Catches RSA/EC private keys

  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets

  # Add language-specific hooks with file filtering
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.0
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
```

## 密钥检测

### 设置步骤

```bash
# Install detect-secrets
pip install detect-secrets

# Scan repo and create baseline (first time)
detect-secrets scan > .secrets.baseline

# Audit baseline (review and confirm real secrets)
detect-secrets audit .secrets.baseline
```

### 工作原理

1. **基线文件**（`.secrets.baseline`）：记录已知密钥及其位置。提交到仓库中。
2. **提交时**：`detect-secrets` 扫描暂存文件。如果发现新的潜在密钥，则阻止提交。
3. **误报处理**：通过 `detect-secrets audit` 添加到基线中。确认后，不会阻止后续提交。

### 检测范围

| 类型 | 示例 |
|------|------|
| API 密钥 | `sk_live_...`, `AKIA...` |
| 认证令牌 | `Bearer ...`, `ghp_...` |
| 数据库连接地址 | `postgres://user:pass@host/db` |
| 私钥 | `-----BEGIN RSA PRIVATE KEY-----` |
| 配置文件中的密码 | YAML/JSON 中的 `password: "..."` |

## 自定义 Hooks

### 本地脚本 Hook

```yaml
repos:
  - repo: local
    hooks:
      # Run a custom validation script
      - id: validate-api-spec
        name: Validate API Specification
        entry: ./scripts/validate-openapi.sh
        language: script
        files: 'openapi\.ya?ml$'

      # Run a Python script
      - id: check-translations
        name: Check Translation Completeness
        entry: python3 scripts/check_translations.py
        language: python
        files: 'locale/.*\.po$'

      # Enforce branch naming convention
      - id: check-branch-name
        name: Check Branch Name
        entry: bash -c 'echo $BRANCH_NAME | grep -qE "^(feature|fix|hotfix)/"'
        language: system
        always_run: true
        stages: [pre-push]
```

### 项目级 Python Hook

```yaml
repos:
  - repo: local
    hooks:
      - id: mypy
        name: Type Check (mypy)
        entry: mypy
        language: system
        types: [python]
        args: ['--strict']
```

## 常用命令

```bash
# Install hooks (pre-commit only, default)
pre-commit install

# Install all hook types (pre-commit + pre-push + more)
pre-commit install --install-hooks

# Install pre-push hooks specifically
pre-commit install --hook-type pre-push

# Run all hooks manually (against all files)
pre-commit run --all-files

# Run a specific hook
pre-commit run ruff --all-files

# Run only on staged files (simulates actual commit)
pre-commit run

# Update all hooks to latest versions
pre-commit autoupdate

# Clean cached hook environments
pre-commit clean

# List all configured hooks
pre-commit run --hook-stage manual --verbose 2>&1 | head -20

# Uninstall hooks
pre-commit uninstall
```

## CI/CD 集成

### GitHub Actions

```yaml
# .github/workflows/pre-commit.yml
name: Pre-commit
on: [push, pull_request]
jobs:
  pre-commit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install pre-commit
      - run: pre-commit run --all-files
```

或者使用官方 Action：

```yaml
- name: Run pre-commit
  uses: pre-commit/action@v3.0.1
```

### GitLab CI

```yaml
# .gitlab-ci.yml
pre-commit:
  stage: test
  image: python:3.12
  before_script:
    - pip install pre-commit
  script:
    - pre-commit run --all-files
  cache:
    paths:
      - ~/.cache/pre-commit
```

### CircleCI

```yaml
# .circleci/config.yml
jobs:
  pre-commit:
    docker:
      - image: cimg/python:3.12
    steps:
      - checkout
      - run: pip install pre-commit
      - run: pre-commit run --all-files
```

## 关键实现细节

- **Hook 隔离**：每个 hook 仓库在 `~/.cache/pre-commit/` 中拥有独立的虚拟环境，不会污染项目依赖。
- **仅检查暂存文件**：默认情况下，hooks 仅对即将提交的文件（`git diff --cached`）运行，而非整个仓库。
- **快速失败**：第一个 hook 失败即停止整个提交。修复后重新提交即可。
- **部分暂存**：可使用 `pre-commit run --files <path>` 测试指定文件。
- **缓存机制**：Hook 环境会被缓存。首次运行时下载依赖，后续运行速度很快。
- **配置文件提交到仓库**：`.pre-commit-config.yaml` 被纳入版本控制，团队中所有人自动使用相同的 hooks。

## 故障排查

| 问题 | 解决方案 |
|------|----------|
| **Hook 失败但代码看起来没问题** | 使用 `--verbose` 运行：`pre-commit run ruff --all-files --verbose` |
| **Hook 运行缓慢** | 跳过指定 hook：`SKIP=ruff git commit` |
| **Hooks 没有运行** | 检查 `.git/hooks/pre-commit` 是否存在。重新运行 `pre-commit install` |
| **"No such file or directory" 错误** | 清理缓存：`pre-commit clean` 然后重新运行 |
| **Hook 版本冲突** | 运行 `pre-commit autoupdate` 获取最新版本 |
| **因密钥检测无法提交** | 如果是误报：运行 `detect-secrets scan --update .secrets.baseline` 然后 `detect-secrets audit .secrets.baseline` |
| **新团队成员的 hooks 不生效** | 需要执行：`pip install pre-commit && pre-commit install` |
| **大型仓库中 pre-commit 太慢** | 使用 `files:` 模式限制范围，例如 `files: 'src/.*\.py$'` |

## 相关文件

- `.pre-commit-config.yaml` — 主配置文件（提交到仓库）
- `.secrets.baseline` — 密钥检测基线文件（提交到仓库）
- `.git/hooks/pre-commit` — 已安装的 hook 包装器（不提交到仓库）
- `~/.cache/pre-commit/` — 缓存的 hook 环境（仅本地）
