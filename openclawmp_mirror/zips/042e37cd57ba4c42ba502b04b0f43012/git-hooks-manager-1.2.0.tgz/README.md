# Git Hooks Manager

使用 pre-commit 框架在多个仓库中自动化配置 Git hooks。支持代码检查（linting）、格式化、密钥检测和代码质量强制规范，提供针对不同语言的配置模板，并可集成到 CI/CD 流水线中。

## 它解决了什么问题

每位开发者都曾经历过提交包含行尾空格、调试打印语句，甚至更糟的情况——API 密钥和密码的代码。Git hooks 从源头防止这些问题：它们在代码进入仓库之前运行检查。但手动在每个仓库中配置 hooks 既繁琐又不一致。本技能使用成熟的 pre-commit 框架，通过一个 `.pre-commit-config.yaml` 文件即可自动化管理所有 hooks。

## 核心能力

- **一条命令完成设置**：`pre-commit install` 即可在任何仓库中激活所有 hooks
- **多语言配置模板**：预置 Python、JavaScript/TypeScript、Go、Rust、Java 等语言的配置
- **密钥检测**：防止意外提交 API 密钥、密码和令牌
- **自定义 hooks**：可添加项目专属的验证脚本
- **CI/CD 集成**：可在 GitHub Actions、GitLab CI 或任何 CI 系统中运行相同的检查
- **自动更新**：使用 `pre-commit autoupdate` 保持所有 hook 版本最新

## 快速开始

```bash
# Install pre-commit
pip install pre-commit

# Create config file (choose a profile below)
# Then install hooks
cd your-repo
pre-commit install

# Run against all files (first-time check)
pre-commit run --all-files
```

## 架构

```
.git/hooks/pre-commit (installed by pre-commit install)
  └── pre-commit framework (Python)
        └── .pre-commit-config.yaml (your configuration)
              ├── Hook repo 1 (e.g., ruff for Python linting)
              │     └── hook: ruff, ruff-format
              ├── Hook repo 2 (e.g., pre-commit-hooks for general checks)
              │     └── hook: trailing-whitespace, check-yaml, ...
              └── Hook repo 3 (e.g., detect-secrets for security)
                    └── hook: detect-secrets
```

分为三层：

1. **Git hooks**：`.git/hooks/pre-commit` 是由框架安装的轻量包装器。Git 在每次提交前调用它。
2. **pre-commit 框架**：Python 工具，负责读取配置、下载 hook 仓库、为每个 hook 管理虚拟环境，并按顺序运行它们。
3. **Hook 仓库**：包含 hook 定义的 Git 仓库。每个仓库指定自己的依赖项。本地缓存在 `~/.cache/pre-commit` 中。
