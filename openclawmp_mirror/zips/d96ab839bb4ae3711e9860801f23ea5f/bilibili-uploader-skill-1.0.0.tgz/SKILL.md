---
name: bilibili-uploader-skill
displayName: B站视频上传技能
description: B站官方账号视频上传与内容管理技能。支持视频上传（WBI签名认证）、元数据管理、数据追踪。适用于AI品牌B站运营自动化。
version: 1.0.0
tags: bilibili, video, upload, china, social-media
category: social-media
---

# B站视频上传与内容管理技能

## 概览

本技能提供完整的B站官方账号运营自动化能力，包括：

- 📤 **视频上传**：支持大文件分片、断点续传、WBI签名认证
- 📝 **元数据管理**：标题、描述、标签、封面、分区（tid）、定时发布
- 📊 **数据分析**：播放量、弹幕、评论、分享、粉丝增长
- 🎯 **内容策略**：集成AI内容生成（标题优化、标签推荐、描述模板）
- 📅 **排期管理**：定时发布、系列视频、合集管理

适用于AI品牌的B站官方号从0到1的自动化运营。

---

## 核心能力

### 1. 视频上传

上传视频到B站，支持完整元数据配置：

```python
uploader.upload_video(
    video_path="intro.mp4",
    title="AI产品发布会完整回顾",
    description="详细介绍我们的最新AI产品...\\n\\n#AI #产品发布",
    tags=["AI", "人工智能", "产品介绍"],
    cover_path="cover.jpg",
    tid=138,  # 知识/技能分区
    is_original=True  # 原创声明
)
```

**技术特点：**
- ✅ WBI签名认证（官方API，稳定性高）
- ✅ 自动重试和错误处理
- ✅ 分片上传，支持大于100MB视频
- ✅ 上传进度反馈

---

### 2. 内容管理

除了上传，还可管理已有内容：

```python
# 获取视频统计数据
stats = uploader.get_video_stats("BV1xx411c79H")
print(f"播放: {stats['view']}, 点赞: {stats['like']}")

# 批量操作（待扩展）
# - 更新视频信息
# - 移动视频到合集
# - 定时发布队列
```

---

### 3. 数据追踪

集成 `china-growth-ops` 的跨平台数据能力，支持：
- 视频播放量、互动率趋势
- 粉丝增长与留存分析
- 竞品对比（需配合其他技能）

---

## 快速开始

### 前置条件

1. **B站账号**：已通过实名认证的官方账号
2. **获取Cookie**：
   - 登录 https://www.bilibili.com
   - 按 F12 → Network → 刷新页面
   - 点击任意请求 → Request Headers → 复制 Cookie 字段
   - 至少包含：`SESSDATA` 和 `bili_jct`
3. **环境变量配置**：
   ```bash
   export BILIBILI_COOKIE="SESSDATA=xxx; bili_jct=xxx; ..."
   ```
   或创建 `.env` 文件（同目录）：
   ```env
   BILIBILI_COOKIE=SESSDATA=xxx; bili_jct=xxx
   ```

### 安装依赖

技能需要以下Python包：
```bash
pip install -r requirements.txt
playwright install chromium  # 如果需要浏览器自动化
```

### 测试连接

```bash
python3 video_uploader.py --test
```

输出示例：
```
[+] Bilibili API connection OK
[+] Logged in as: AI品牌官方号
```

---

## 使用示例

### 示例1：上传第一个视频

```bash
python3 video_uploader.py \
  --video product_intro.mp4 \
  --title "我们的AI产品到底强在哪里？" \
  --desc "完整介绍我们的最新AI产品功能和优势\\n\\n🔗 官网：https://example.com" \
  --tags AI 人工智能 产品介绍 \
  --cover cover.jpg \
  --tid 138
```

### 示例2：获取视频数据

```python
from bilibili_uploader_skill.video_uploader import BilibiliUploader
uploader = BilibiliUploader()
stats = uploader.get_video_stats("BV1xx411c79H")
print(json.dumps(stats, indent=2, ensure_ascii=False))
```

### 示例3：定时发布（高级）

```python
# 待实现 - 使用B站定时发布API
# 或配合 crontab 在指定时间运行脚本
```

---

## 分区（TID）参考

| TID | 分区名称 | 适用场景 |
|-----|---------|---------|
| 138 | 知识/技能 | AI教程、产品功能讲解 |
| 160 | 生活娱乐 | 创意短片、趣味科普 |
| 201 | 科学科普 | 硬核技术、原理分析 |
| 124 | 财经商业 | 商业案例、行业分析 |
| 138 | 野生技能 | 实际应用、竞品对比 |

---

## 常见问题

### Q: 上传失败，返回 "errno: -3"
**A:** Cookie已失效，需重新获取。B站Cookie有效期约1-2周。

### Q: 视频超过100MB无法上传
**A:** 当前演示版本仅支持单文件上传。完整版需实现分片上传逻辑（参考 `bilibili_api.py` 中的 `get_upload_urls` 返回的多个URL）。

### Q: 封面上传失败
**A:** 封面功能待完善，可暂不传递 `--cover` 参数，后续手动上传。

### Q: 如何批量上传？
**A:** 当前为单文件脚本。建议外层用Shell/Python循环调用，或扩展为批量模式（todo）。

---

## 技术备注

- **WBI签名**：B站Web API认证机制，每天自动刷新，本技能内置缓存24小时
- **CSRF防护**：从Cookie提取 `bili_jct` 作为CSRF token
- **错误码**：参考 `bilibili_api.py` 中的 `_request` 方法
- **扩展性**：架构预留了合集管理、定时发布等接口

---

## 参考文件

- `references/api_docs.md` - B站API接口详细说明（待补充）
- `references/wbi_signing.md` - WBI签名算法解析
- `references/upload_requirements.md` - 上传规范（格式、尺寸、时长限制）

---

## 安全说明

- Cookie仅存储在环境变量中，不会写入代码或配置文件
- 所有请求使用HTTPS
- 本技能只操作你自己有权限的账号

---

## 许可证

MIT License
