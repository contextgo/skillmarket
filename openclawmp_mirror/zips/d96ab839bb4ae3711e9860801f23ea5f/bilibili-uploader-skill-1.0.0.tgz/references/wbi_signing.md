# WBI Signing Algorithm

## What is WBI?

WBI (Web Bilibili Interface) is B站's signature mechanism for authenticating API requests. It replaces the older `appkey`/`sign` system.

## How It Works

1. **Fetch Keys**: Call `/x/web-interface/nav` to get `img_key` and `sub_key` from `wbi_img` URLs
2. **Mix Keys**: Concatenate `img_key + sub_key` → `mix_key`
3. **Sign Parameters**:
   - Sort query params alphabetically by key
   - Concatenate as `key1=value1&key2=value2...`
   - Append `mix_key` (as UTF-8 bytes)
   - MD5 hash → `w_rid` signature
4. **Include Timestamp**: Add `wts` param (current Unix timestamp)

## Why Cache Keys?

WBI keys rotate daily but have grace period. Caching for 24h avoids extra requests.

## Implementation in This Skill

See `bilibili_api.py::_wbi_sign()` for full implementation.

---

## Debugging WBI Errors

- **Signature mismatch**: Check param sorting and encoding (must be URL-encoded)
- **Key expired**: Re-fetch keys from `/nav` (1-day cache built-in)
- **403 Forbidden**: Ensure Cookie is valid and not blocked

---

## References

- Original: https://github.com/Jacobzwj/bilibili-hot-monitor (WBI implementation)
- Discussion: https://github.com/SocialSisterYi/bilibili-API-collect
