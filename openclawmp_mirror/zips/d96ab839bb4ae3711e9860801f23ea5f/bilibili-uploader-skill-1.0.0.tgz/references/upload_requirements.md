# Bilibili Upload Requirements

## Video Format

| Format | Status | Notes |
|--------|--------|-------|
| MP4 (H.264) | ✅ Recommended | Most compatible |
| FLV | ✅ | B站原生格式 |
| WebM | ⚠️ | Some browsers |
| AVI | ⚠️ | May fail, convert first |
| MOV | ⚠️ | May fail |

**Recommended encoding**:
- Video: H.264
- Audio: AAC
- Resolution: 1080p (1920x1080) max
- Bitrate: < 6000 kbps

## File Size

- **Single upload (no chunk)**: < 100MB (demo limitation)
- **Chunked upload**: < 4GB (official limit)
- **Note**: 4GB limit may require VIP or special permissions

## Metadata Limits

| Field | Limit | Notes |
|-------|-------|-------|
| Title | 80 characters | 中文30字左右 |
| Description | 2000 characters | Supports @ mentions, links |
| Tags | 12 tags total | Comma-separated |
| Cover image | < 5MB | JPG/PNG, 推荐1146x717 |
| TID (分区) | Fixed list | See TID reference |

## Content Policies

- No copyright infringement (declaration required)
- No political/sensitive content
- No excessive watermarks
- Original content preferred

## Upload Process

1. `POST /x/vu/upload` → get URLs
2. `PUT` video chunks to CDN URLs
3. `POST /x/vu/submit` with metadata
4. Wait for transcoding (usually 5-30 min)

---

## Common Upload Failures

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| errno=-3 | Cookie expired | Re-login |
| errno=62002 | Title banned words | Check sensitive terms |
| errno=-400 | Missing param | Verify required fields |
| Timeout | Large file, no chunk | Implement chunked upload |
