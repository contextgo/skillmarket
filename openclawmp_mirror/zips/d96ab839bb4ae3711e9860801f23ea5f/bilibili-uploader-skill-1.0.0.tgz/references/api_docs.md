# Bilibili API Reference

## Endpoints Used

### GET /x/web-interface/nav
- **Purpose**: Fetch WBI keys and user nav info
- **Response**: `{ data: { wbi_img: {...}, uname: "...", ... } }`
- **Auth**: Optional (public endpoint)

### POST /x/vu/upload
- **Purpose**: Get pre-signed upload URLs for video file
- **Body**:
  ```json
  {
    "filesize": 12345678,
    "filename": "video.mp4",
    "csrf": "bili_jct_token"
  }
  ```
- **Response**:
  ```json
  {
    "data": {
      "urls": ["https://upos-cdn-upolink...", ...],  // Chunk URLs
      "complete": "https://api.bilibili.com/x/vu/submit",
      "upload_id": "unique_id"
    }
  }
  ```

### POST /x/vu/submit
- **Purpose**: Complete upload and submit video metadata
- **Body**:
  ```json
  {
    "upload_id": "...",
    "filename": "video.mp4",
    "title": "Video Title",
    "desc": "Description",
    "tag": "tag1,tag2,tag3",
    "tid": 138,
    "copyright": 1,  // 1=original, 2=repost
    "csrf": "bili_jct"
  }
  ```
- **Response**:
  ```json
  {
    "data": {
      "bvid": "BV1xx411c79H",
      "aid": 12345678
    }
  }
  ```

### GET /x/web-interface/view
- **Purpose**: Get video metadata
- **Params**: `bvid=BV1xx411c79H`
- **Response**: Full video info including `stat` (view/like/coin/etc)

---

## Rate Limits

- Upload API: 5 requests/minute per IP
- Metadata API: 30 requests/minute per user
- WBI Key cache: 24 hours (refresh automatically)

---

## Error Codes

| Code | Message | Meaning |
|------|---------|---------|
| 0 | success | OK |
| -3 | no login | Cookie invalid |
| -400 | bad request | Missing params |
| 62002 | repeat word | Title contains banned words |
| 62004 | invalid cover | Cover format error |
