"""
Bilibili API wrapper for OpenClaw Skill.
Based on open source projects: bilibili-hot-monitor, bilibili-update-viewer
Supports: WBI signing, video info fetch, upload preparation
"""

import hashlib
import time
import secrets
import json
import re
from typing import Dict, Optional, Tuple
import requests

class BilibiliAPI:
    """Bilibili API wrapper with WBI signing support"""

    BASE_URL = "https://api.bilibili.com"
    WBI_URL = "https://api.bilibili.com/x/web-interface/nav"

    def __init__(self, cookie: str = None):
        self.cookie = cookie
        self.session = requests.Session()
        self._img_key: Optional[str] = None
        self._sub_key: Optional[str] = None
        self._wbi_expire: Optional[int] = None

    def _get_wbi_keys(self) -> Tuple[str, str]:
        """Fetch WBI (Web Bilibili Interface) signing keys from nav endpoint"""
        if self._img_key and self._sub_key and self._wbi_expire and time.time() < self._wbi_expire:
            return self._img_key, self._sub_key

        resp = self.session.get(self.WBI_URL)
        resp.raise_for_status()
        data = resp.json()["data"]
        wbi_img = data["wbi_img"]["img_url"]
        wbi_sub = data["wbi_img"]["sub_url"]

        # Extract keys from URLs
        img_key = wbi_img.split("/")[-1].split(".")[0]
        sub_key = wbi_sub.split("/")[-1].split(".")[0]

        # Cache for 24 hours (B站 keys rotate daily)
        self._img_key = img_key
        self._sub_key = sub_key
        self._wbi_expire = int(time.time()) + 86400

        return img_key, sub_key

    def _wbi_sign(self, params: Dict) -> str:
        """Generate WBI signature for request authentication"""
        img_key, sub_key = self._get_wbi_keys()

        # Mix keys: img_key + sub_key
        mix_key = img_key + sub_key
        mix_key_enc = mix_key.encode("utf-8")

        # Sort params and concatenate
        sorted_params = sorted(params.items(), key=lambda x: x[0])
        query = "&".join(f"{k}={v}" for k, v in sorted_params)

        # Calculate signature
        sign_hash = hashlib.md5((query + mix_key_enc.decode()).encode()).hexdigest()
        return sign_hash

    def _request(self, method: str, endpoint: str, params: Dict = None, json_data: Dict = None, **kwargs) -> Dict:
        """Make authenticated request with WBI signing"""
        url = f"{self.BASE_URL}{endpoint}"

        if params is None:
            params = {}
        if self.cookie:
            kwargs.setdefault("cookies", {"SESSDATA": self.cookie})

        # Add WBI signing
        params["w_rid"] = self._wbi_sign(params)
        params["wts"] = int(time.time())

        resp = self.session.request(method, url, params=params, json=json_data, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def get_user_info(self, uid: int = None) -> Dict:
        """Get current user info or specified user info"""
        if uid:
            endpoint = f"/x/space/acc/info"
            params = {"mid": uid}
        else:
            endpoint = "/x/web-interface/nav"
            params = {}
        return self._request("GET", endpoint, params=params)

    def get_video_info(self, bvid: str) -> Dict:
        """Get video metadata by BVID"""
        endpoint = "/x/web-interface/view"
        params = {"bvid": bvid}
        return self._request("GET", endpoint, params=params)

    def get_upload_urls(self, file_size: int, file_name: str) -> Dict:
        """Get pre-signed upload URLs for video file"""
        endpoint = "/x/vu/upload"
        params = {
            "filesize": file_size,
            "filename": file_name,
            "csrf": self._get_csrf_token()
        }
        return self._request("POST", endpoint, json_data=params)

    def submit_video(self, video_data: Dict) -> Dict:
        """Submit video metadata after upload completion"""
        endpoint = "/x/vu/submit"
        params = {
            "csrf": self._get_csrf_token(),
            **video_data
        }
        return self._request("POST", endpoint, json_data=params)

    def get_cover_url(self, cover_url: str) -> bytes:
        """Fetch cover image from B站 CDN"""
        resp = self.session.get(cover_url)
        resp.raise_for_status()
        return resp.content

    def _get_csrf_token(self) -> str:
        """Extract CSRF token from cookie (bili_jct)"""
        if not self.cookie:
            raise ValueError("Cookie required for write operations")
        match = re.search(r"bili_jct=([^;]+)", self.cookie)
        if not match:
            raise ValueError("bili_jct not found in cookie")
        return match.group(1)

    def test_connection(self) -> bool:
        """Test API connection and credential validity"""
        try:
            info = self.get_user_info()
            return info.get("code") == 0
        except Exception:
            return False