#!/usr/bin/env python3
"""
Bilibili video uploader skill for OpenClaw.
Uploads videos to Bilibili official accounts with full metadata support.
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import Dict, List, Optional
from dotenv import load_dotenv

from bilibili_api import BilibiliAPI

# Load environment variables
load_dotenv()

class BilibiliUploader:
    """Skill for uploading videos to Bilibili"""

    def __init__(self):
        self.cookie = os.getenv("BILIBILI_COOKIE")
        if not self.cookie:
            raise ValueError(
                "BILIBILI_COOKIE environment variable is required.\n"
                "Get it from: login bilibili.com → F12 → Network → Request Headers → Cookie"
            )
        self.api = BilibiliAPI(cookie=self.cookie)

    def upload_video(
        self,
        video_path: str,
        title: str,
        description: str = "",
        tags: List[str] = None,
        cover_path: str = None,
        tid: int = 138,  # Default: 知识/技能 (customizable)
        slogan: str = "",
        dynamic: str = "",
        is_original: bool = True,
        **kwargs
    ) -> Dict:
        """
        Upload a video to Bilibili with full metadata.

        Args:
            video_path: Path to video file (mp4, flv, etc.)
            title: Video title (max 80 chars)
            description: Video description (supports @ mentions, links)
            tags: List of tags (max 12)
            cover_path: Path to cover image (optional, will use video frame if None)
            tid: Topic ID (分区) - 138=知识技能, 160=生活娱乐, etc.
            slogan: Copyright slogan
            dynamic: Dynamic text for sharing
            is_original: Mark as original content

        Returns:
            Dict with bvid, aid, upload info
        """
        video_path = Path(video_path)
        if not video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        file_size = video_path.stat().st_size
        file_name = video_path.name

        print(f"[+] Starting upload: {file_name} ({file_size} bytes)")
        print(f"[+] Title: {title}")
        print(f"[] Getting upload URLs...")

        # Step 1: Get pre-signed upload URLs
        upload_info = self.api.get_upload_urls(file_size, file_name)
        if upload_info.get("code") != 0:
            raise RuntimeError(f"Failed to get upload URLs: {upload_info}")

        upload_urls = upload_info["data"]["urls"]
        complete_url = upload_info["data"]["complete"]
        upload_id = upload_info["data"]["upload_id"]

        print(f"[+] Upload ID: {upload_id}")
        print(f"[+] Pre-signed URLs: {len(upload_urls)} parts")

        # Step 2: Upload video file (simplified - single part)
        # In production, implement chunked upload with retry logic
        print(f"[] Uploading video to Bilibili CDN...")
        headers = {
            "Content-Type": "video/mp4"
        }
        with open(video_path, "rb") as f:
            # For demo: upload entire file in one request (assumes < 100MB)
            # Real implementation should split into chunks based on upload_urls
            if len(upload_urls) > 0:
                upload_url = upload_urls[0]
                resp = self.api.session.put(upload_url, data=f, headers=headers)
                resp.raise_for_status()
            else:
                raise ValueError("No upload URLs returned")

        print(f"[+] Video uploaded, completing upload...")

        # Step 3: Complete upload
        complete_data = {
            "upload_id": upload_id,
            "filename": file_name,
            "title": title[:80],
            "desc": description,
            "tag": ",".join(tags) if tags else "",
            "tid": tid,
            "slogan": slogan,
            "dynamic": dynamic,
            "cover": "",  # Will upload cover separately via /x/vu/cover/up
            "mission_id": kwargs.get("mission_id", 0),
        }

        if is_original:
            complete_data["copyright"] = 1
        else:
            complete_data["copyright"] = 2  # Repost

        # Add CSRF
        complete_data["csrf"] = self.api._get_csrf_token()

        resp = self.api.session.post(complete_url, json=complete_data)
        resp.raise_for_status()
        result = resp.json()

        if result.get("code") != 0:
            raise RuntimeError(f"Upload failed: {result}")

        bvid = result["data"]["bvid"]
        aid = result["data"]["aid"]
        print(f"[+] Upload successful! BVID: {bvid}, AID: {aid}")

        # Step 4: Upload cover if provided
        if cover_path:
            self._upload_cover(cover_path, bvid)

        return {
            "bvid": bvid,
            "aid": aid,
            "title": title,
            "url": f"https://www.bilibili.com/video/{bvid}",
            "upload_info": result["data"]
        }

    def _upload_cover(self, cover_path: str, bvid: str):
        """Upload cover image for the video"""
        cover_path = Path(cover_path)
        if not cover_path.exists():
            print(f"[!] Cover not found: {cover_path}")
            return

        print(f"[+] Uploading cover: {cover_path.name}")

        # B站 cover upload endpoint
        # Implementation: POST to /x/vu/cover/up with file + bvid
        # This is a simplified placeholder
        # Full implementation requires B站 cover upload API details
        print(f"[*] Cover upload not fully implemented yet")
        pass

    def get_video_stats(self, bvid: str) -> Dict:
        """Get basic stats for a video"""
        info = self.api.get_video_info(bvid)
        if info.get("code") != 0:
            raise ValueError(f"Video not found: {bvid}")

        v = info["data"]
        return {
            "bvid": v["bvid"],
            "title": v["title"],
            "view": v["stat"]["view"],
            "like": v["stat"]["like"],
            "coin": v["stat"]["coin"],
            "favorite": v["stat"]["favorite"],
            "share": v["stat"]["share"],
            "reply": v["stat"]["reply"],
            "danmaku": v["stat"]["danmaku"],
            "duration": v["duration"]
        }

    def test_connection(self) -> bool:
        """Test API connection and credential"""
        return self.api.test_connection()


def main():
    parser = argparse.ArgumentParser(description="Bilibili video uploader skill")
    parser.add_argument("--video", required=True, help="Video file path")
    parser.add_argument("--title", required=True, help="Video title")
    parser.add_argument("--desc", default="", help="Video description")
    parser.add_argument("--tags", nargs="*", default=[], help="Tags")
    parser.add_argument("--cover", help="Cover image path")
    parser.add_argument("--tid", type=int, default=138, help="Topic ID (分区)")
    parser.add_argument("--test", action="store_true", help="Test connection only")

    args = parser.parse_args()

    try:
        uploader = BilibiliUploader()

        if args.test:
            if uploader.test_connection():
                print("[+] Bilibili API connection OK")
                user_info = uploader.api.get_user_info()
                print(f"[+] Logged in as: {user_info['data'].get('uname', 'Unknown')}")
                return 0
            else:
                print("[-] Connection failed")
                return 1

        result = uploader.upload_video(
            video_path=args.video,
            title=args.title,
            description=args.desc,
            tags=args.tags,
            cover_path=args.cover,
            tid=args.tid
        )

        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    except Exception as e:
        print(f"[!] Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())