/**
 * GitHub PR分析助手
 * 分析Pull Request代码变更，识别风险
 */

const https = require('https');
const http = require('http');

/**
 * 获取GitHub PR信息
 */
async function fetchPR(owner, repo, prNumber, token) {
  const headers = {
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'OpenClaw-Skill'
  };
  if (token) {
    headers['Authorization'] = `token ${token}`;
  }

  return new Promise((resolve, reject) => {
    const url = `https://api.github.com/repos/${owner}/${repo}/pulls/${prNumber}`;
    https.get(url, { headers }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`解析PR信息失败: ${data}`));
        }
      });
    }).on('error', reject);
  });
}

/**
 * 获取PR的文件变更
 */
async function fetchPRFiles(owner, repo, prNumber, token) {
  const headers = {
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'OpenClaw-Skill'
  };
  if (token) {
    headers['Authorization'] = `token ${token}`;
  }

  return new Promise((resolve, reject) => {
    const url = `https://api.github.com/repos/${owner}/${repo}/pulls/${prNumber}/files`;
    https.get(url, { headers }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`解析文件列表失败: ${data}`));
        }
      });
    }).on('error', reject);
  });
}

/**
 * 分析单个文件变更
 */
function analyzeFileChange(file) {
  const { filename, status, additions, deletions, patch } = file;
  
  const ext = filename.split('.').pop();
  const basename = filename.split('/').pop();
  const dir = filename.split('/').slice(0, -1).join('/');
  
  // 判断变更类型和风险
  let risk = 'low';
  let riskReason = '';
  let focus = '';
  
  // 高风险：安全/认证/配置/基础设施
  if (filename.includes('security') || filename.includes('auth') || 
      filename.includes('credential') || filename.includes('.env') ||
      filename.includes('Dockerfile') || filename.includes('docker-compose')) {
    risk = 'high';
    riskReason = '涉及安全或基础设施配置';
    focus = '安全审查';
  }
  // 核心业务逻辑
  else if (['c', 'cpp', 'h', 'py', 'js', 'ts'].includes(ext) && 
           (status === 'modified' || status === 'added')) {
    risk = 'medium';
    riskReason = '核心代码变更';
    focus = '逻辑审查+测试';
  }
  // 数据库/数据相关
  else if (filename.includes('schema') || filename.includes('migration') ||
           filename.includes('database') || filename.includes('sql')) {
    risk = 'high';
    riskReason = '数据库/数据变更';
    focus = '数据一致性检查';
  }
  // API变更
  else if (filename.includes('api') || filename.includes('route') ||
           filename.includes('endpoint') || filename.includes('swagger')) {
    risk = 'medium';
    riskReason = 'API接口变更';
    focus = 'API兼容性检查';
  }
  // 配置变更
  else if (ext === 'json' || ext === 'yaml' || ext === 'yml' || ext === 'toml') {
    risk = 'medium';
    riskReason = '配置文件变更';
    focus = '参数验证';
  }
  // 测试文件
  else if (filename.includes('test') || filename.includes('spec') || ext === 'md') {
    risk = 'low';
    riskReason = '文档/测试文件';
    focus = '';
  }
  
  return {
    filename,
    status,
    additions,
    deletions,
    dir,
    ext,
    risk,
    riskReason,
    focus,
    hasTests: filename.includes('test') || filename.includes('spec'),
    hasPatch: !!patch
  };
}

/**
 * 生成PR分析报告
 */
async function analyzePR(prUrl, token = '') {
  // 解析PR URL
  const match = prUrl.match(/github\.com\/([^\/]+)\/([^\/]+)\/pull\/(\d+)/);
  if (!match) {
    throw new Error('无效的PR URL格式，请使用: https://github.com/owner/repo/pull/NUMBER');
  }
  
  const [, owner, repo, prNumber] = match;
  console.log(`📡 正在获取PR #${prNumber}...`);
  
  const [pr, files] = await Promise.all([
    fetchPR(owner, repo, prNumber, token),
    fetchPRFiles(owner, repo, prNumber, token)
  ]);
  
  // 分析每个文件
  const analyzedFiles = files.map(analyzeFileChange);
  
  // 统计
  const stats = {
    total: files.length,
    added: files.reduce((s, f) => s + f.additions, 0),
    deleted: files.reduce((s, f) => s + f.deletions, 0),
    highRisk: analyzedFiles.filter(f => f.risk === 'high').length,
    mediumRisk: analyzedFiles.filter(f => f.risk === 'medium').length,
    lowRisk: analyzedFiles.filter(f => f.risk === 'low').length,
    withTests: analyzedFiles.filter(f => f.hasTests).length
  };
  
  // 分类输出
  const highRisk = analyzedFiles.filter(f => f.risk === 'high');
  const mediumRisk = analyzedFiles.filter(f => f.risk === 'medium');
  const lowRisk = analyzedFiles.filter(f => f.risk === 'low');
  
  // 生成报告
  let report = `PR分析报告 #${pr.number}\n`;
  report += `${'━'.repeat(50)}\n`;
  report += `标题：${pr.title}\n`;
  report += `作者：@${pr.user.login}\n`;
  report += `分支：${pr.head.ref} → ${pr.base.ref}\n\n`;
  
  report += `变更统计：\n`;
  report += `  📝 新增：+${stats.added}行\n`;
  report += `  📝 修改：${stats.total - analyzedFiles.filter(f=>f.status==='removed').length}个文件\n`;
  report += `  📝 删除：-${stats.deleted}行\n`;
  report += `  📁 涉及文件：${stats.total}个\n`;
  report += `  🧪 含测试：${stats.withTests}个\n\n`;
  
  const overallRisk = stats.highRisk > 0 ? '🔴 高风险' : 
                      stats.mediumRisk > 0 ? '🟡 中风险' : '🟢 低风险';
  report += `综合风险评估：${overallRisk}\n`;
  report += `${'━'.repeat(50)}\n\n`;
  
  if (highRisk.length > 0) {
    report += `🔴 高风险变更（${highRisk.length}项）：\n`;
    highRisk.forEach(f => {
      report += `  - ${f.filename}\n`;
      report += `    → ${f.riskReason} | ${f.focus}\n`;
      report += `    → 变更：+${f.additions} -${f.deletions}\n`;
    });
    report += '\n';
  }
  
  if (mediumRisk.length > 0) {
    report += `🟡 中等风险（${mediumRisk.length}项）：\n`;
    mediumRisk.forEach(f => {
      report += `  - ${f.filename}\n`;
      report += `    → ${f.riskReason} | ${f.focus}\n`;
      report += `    → 变更：+${f.additions} -${f.deletions}\n`;
    });
    report += '\n';
  }
  
  if (lowRisk.length > 0) {
    report += `🟢 低风险（${lowRisk.length}项）：\n`;
    lowRisk.slice(0, 5).forEach(f => {
      report += `  - ${f.filename} (${f.status})\n`;
    });
    if (lowRisk.length > 5) {
      report += `  ... 还有${lowRisk.length - 5}个低风险文件\n`;
    }
    report += '\n';
  }
  
  // 审查建议
  report += `审查建议：\n`;
  if (stats.withTests === 0) {
    report += `  ⚠️ 未包含测试文件，建议补充单元测试\n`;
  }
  if (stats.highRisk > 0) {
    report += `  ✅ 高风险变更需重点审查，建议安排资深工程师Review\n`;
  }
  if (stats.mediumRisk > 0) {
    report += `  ✅ 逻辑变更建议附上测试数据对比\n`;
  }
  if (pr.body && pr.body.length > 0) {
    report += `  ✅ PR描述已有，建议检查是否与实际变更一致\n`;
  } else {
    report += `  ⚠️ PR缺少描述，建议补充变更说明\n`;
  }
  
  return { report, stats, pr, analyzedFiles };
}

// CLI
const args = process.argv.slice(2);
if (args.length > 0) {
  const prUrl = args[0];
  const token = args[1] || '';
  
  analyzePR(prUrl, token).then(({ report }) => {
    console.log(report);
  }).catch(e => {
    console.error('❌ 分析失败:', e.message);
  });
}

module.exports = { analyzePR, analyzeFileChange };
