# Web Application Security Checklist

## OWASP Top 10 (2025)

### A01: Broken Access Control
- [ ] Implement RBAC/ABAC
- [ ] Deny by default
- [ ] Validate object-level access
- [ ] Disable directory listing
- [ ] Log access control failures

### A02: Cryptographic Failures
- [ ] TLS 1.2+ everywhere
- [ ] Encrypt data at rest (AES-256)
- [ ] Hash passwords (bcrypt/argon2)
- [ ] Never store sensitive data in logs
- [ ] Use secure key management

### A03: Injection
- [ ] Parameterized queries (no SQL concat)
- [ ] Input validation (whitelist)
- [ ] Output encoding (context-aware)
- [ ] Use ORM/parameterized APIs
- [ ] CSP headers for XSS prevention

### A04: Insecure Design
- [ ] Threat modeling
- [ ] Rate limiting
- [ ] Input validation at all layers
- [ ] Secure defaults

### A05: Security Misconfiguration
- [ ] Remove default credentials
- [ ] Disable unnecessary features
- [ ] Error messages don't leak internals
- [ ] Security headers configured
- [ ] HTTPS redirect

## Additional Checks
- [ ] CORS properly configured
- [ ] CSRF tokens on state-changing ops
- [ ] Content Security Policy header
- [ ] Subresource Integrity for CDN
- [ ] Security.txt and vulnerability disclosure
- [ ] Regular dependency audits (npm audit)