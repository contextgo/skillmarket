---
name: treatment-plans
description: "Creates structured medical treatment plans as professional PDF documents for all clinical specialties: general medicine, rehabilitation, mental health, chronic disease, perioperative, and pain management. Use this skill — NOT the pdf skill — when the task is to write or generate a new treatment plan document from patient information. The pdf skill handles existing PDF files; this skill creates treatment plan content from scratch and delivers a PDF. Includes SMART goals, evidence-based interventions, HIPAA compliance, and professional formatting."
allowed-tools: [Read, Write, Edit, Bash]
---

# Treatment Plan Writing

## Prerequisites — Run This First

**Step 1 — Locate setup.py and run it.**

Find the directory that contains this SKILL.md file. That directory is the
skill root. setup.py is always at:

    <skill-root>/scripts/setup.py

Run it with the absolute path you just located:

    python <skill-root>/scripts/setup.py

The script will:
- Print the confirmed skill root path — **use this value as {skill_dir} in
  every command below.**
- Write the path to `.skill_path` in your working directory for reference.
- Automatically patch `assets/medical_treatment_plan.sty` (pdflatex-safe fix,
  removes hard-coded patient strings). Safe to run multiple times.
- Check all dependencies (LaTeX, Python packages, EasyClaw config, asset
  files) and report READY / MISSING with installation instructions.

**Step 2 — Act on the RESULT immediately. Do NOT proceed to Phase 1 until this is done.**

- `RESULT: READY` → proceed to Execution Workflow.
- `RESULT: NOT READY` → resolve all MISSING items, then re-run setup.py.

**PDF Route Selection (handled automatically by setup.py):**

setup.py detects LaTeX and sets the PDF route:
- LaTeX found → `PDF_ROUTE=latex` written to `.pdf_route` (best quality, uses `.tex` files)
- LaTeX not found → setup.py asks the user:
  - **A) Install LaTeX** — follow the printed instructions, re-run setup.py → LaTeX route
  - **B) Use built-in Python renderer** → `PDF_ROUTE=python` (uses `.json` files,
    clean HTML rendering via Playwright/Chromium, professional layout, native CJK fonts)

The chosen route persists in `.pdf_route`. Phase 6 reads it automatically —
no further decision needed.

> Do NOT write a custom reportlab or Playwright script to generate PDF. Use
> `generate_pdf.py` which handles both routes correctly and consistently.

---

## Overview

Treatment plan writing is the systematic documentation of clinical care
strategies designed to address patient health conditions through
evidence-based interventions, measurable goals, and structured follow-up.
This skill provides LaTeX templates and validation tools for creating
**concise, focused** treatment plans across all medical specialties with
full regulatory compliance.

**Three non-negotiable principles:**
1. **CONCISE & ACTIONABLE** — default to 3-4 pages; prefer 1-page where
   possible.
2. **Patient-Centered** — evidence-based, measurable, HIPAA-compliant.
3. **Minimal Citations** — inline only, 0-3 per plan; standard-of-care
   interventions need no citation.

**Language rule:** Detect the user's language from their first message.
Fill all template placeholders in that language throughout the entire plan.
If the user writes in Chinese, all clinical content must be in Chinese.
Do not mix languages within the same plan.

---

## Execution Workflow

> **Checkpoint:** Before entering Phase 1, confirm that setup.py has been
> run and reported `RESULT: READY`. If not, return to the Prerequisites
> section above and complete it first. Do not proceed until all required
> dependencies are satisfied.

Follow these phases in order. Do not skip ahead.

### Phase 1 — Clarify & Select Format

Ask the user (or infer from context):
- Medical specialty / condition
- Complexity level

Then select format and note your choice — you will use it again in Phase 5:

| Complexity | Format | Template key |
|---|---|---|
| Straightforward / standard protocol | **1-page** (preferred) | `one-page` |
| Moderate / multidisciplinary | **3-4 pages** | `standard` |
| Complex comorbidities / research | **5-6 pages** (rare) | `standard` |

Specialty template types (used in Phase 2):
`general_medical` · `rehabilitation` · `mental_health` ·
`chronic_disease` · `perioperative` · `pain_management`

For 1-page plans, use: `one_page_treatment_plan.tex` (copy directly from
`assets/`; no `--type` argument needed — see Phase 2).

### Phase 2 — Generate Template

**PDF_ROUTE=latex** — generate a `.tex` file:
```
python {skill_dir}/scripts/generate_template.py --type <type> --output <filename>.tex
python {skill_dir}/scripts/generate_template.py --type one_page --output <filename>.tex
```

**PDF_ROUTE=python** — generate a `.json` file (clean, no LaTeX markup):
```
python {skill_dir}/scripts/generate_plan_json.py --type <type> --output <filename>.json
python {skill_dir}/scripts/generate_plan_json.py --list
```

Use the file that matches your PDF route. Note the output path — you will use it in Phases 3-6.

### Phase 3 — Fill Content

**PDF_ROUTE=python (.json file):**

1. **READ** the generated `.json` file to see all field keys and placeholder values.
2. **WRITE** the complete filled `.json` back to disk, replacing every value that
   starts with `[` with patient-specific content in plain text (no LaTeX markup).
   Match the user's language throughout. Remove array items that are not applicable.
3. **CONFIRM** the file has been saved before proceeding to Phase 4.

**PDF_ROUTE=latex (.tex file):**

1. **READ** the generated `.tex` file to locate all `[bracketed placeholder]` positions.
2. **WRITE** the complete filled `.tex` file back to disk, replacing every placeholder
   with patient-specific LaTeX content. Apply SMART goals
   (load `references/goal_setting_frameworks.md` if needed).
3. **CONFIRM** the file has been saved before proceeding to Phase 4.

> Write content directly to disk — do not output file contents in the chat.

### Phase 4 — Generate Figure (Recommended)

Visual elements improve clinical plans. Generate at least one diagram when
the plan includes a multi-step pathway, milestone timeline, or decision
algorithm.

This step is recommended, not mandatory. If image generation fails
(dependency missing, network issue), skip it and note the omission to the
user.

→ See **Visual Enhancement** section below for the full procedure.

### Phase 5 — Validate

**PDF_ROUTE=python (.json file):**

No script validation needed — the JSON structure is self-validating. Instead,
review the filled `.json` manually:
- All values starting with `[` should be replaced with real content.
- Language is consistent throughout (Chinese or English, not mixed).
- No LaTeX markup in any value.

**PDF_ROUTE=latex (.tex file):**

Use the format you chose in Phase 1:

```
# 1-page format
python {skill_dir}/scripts/check_completeness.py <plan>.tex --format one-page
python {skill_dir}/scripts/validate_treatment_plan.py <plan>.tex

# Standard (3-4 page) format
python {skill_dir}/scripts/check_completeness.py <plan>.tex
python {skill_dir}/scripts/validate_treatment_plan.py <plan>.tex
```

Address any items reported as FAIL before compiling. WARN items are advisory.

### Phase 6 — Generate PDF

Run the single command below. `generate_pdf.py` reads `.pdf_route` and
picks the correct renderer automatically.

**PDF_ROUTE=python** — pass the filled `.json` file:
```
python {skill_dir}/scripts/generate_pdf.py <plan>.json <plan>.pdf
```

**PDF_ROUTE=latex** — pass the filled `.tex` file:
```
python {skill_dir}/scripts/generate_pdf.py <plan>.tex <plan>.pdf
```

**What happens internally:**
- `PDF_ROUTE=latex` → compiles with xelatex (preferred) or pdflatex; runs
  twice for correct cross-references and table of contents.
- `PDF_ROUTE=python` → parses the structured `.json`, builds a clean HTML
  document, renders via Playwright/Chromium to professional A4 PDF with
  gradient header, color-coded cards, and native CJK font support.

Override for a single run (does not change `.pdf_route`):
```
python {skill_dir}/scripts/generate_pdf.py <plan>.json <plan>.pdf --route python
python {skill_dir}/scripts/generate_pdf.py <plan>.tex  <plan>.pdf --route latex
```

If the script exits with "PDF route not configured" (exit code 2), run setup.py first to make your route choice — the tool will not generate a PDF until you have explicitly chosen between LaTeX and the built-in Python renderer.

On success the script prints `MEDIA:<absolute-path>` — use this to present
the PDF to the user.

---

## Document Format

### First Page Summary (all formats)

**Every treatment plan — including 1-page — must open with a scannable
summary a clinician can read in under 30 seconds.**

Required first-page elements (in order):
1. Title + subtitle (condition / patient profile)
2. `\begin{patientinfo}` — demographics, ICD-10 code, date
3. `\begin{goalbox}` — 2-3 SMART goals
4. `\begin{keybox}` — 2-3 core interventions
5. `\begin{warningbox}` — critical decision points (omit if none)
6. `\begin{infobox}` — timeline / treatment phases

For 3-4 page plans: table of contents on page 2, detailed sections from
page 3.

```latex
\maketitle
\thispagestyle{empty}

\begin{patientinfo}
  % Age, sex, diagnosis + ICD-10, plan date
\end{patientinfo}

\begin{goalbox}[Primary Treatment Goals]
  % 2-3 SMART goals
\end{goalbox}

\begin{keybox}[Core Interventions]
  % 2-3 key interventions
\end{keybox}

\begin{warningbox}[Critical Decision Points]  % omit if none
  % Safety thresholds, urgent monitoring triggers
\end{warningbox}

\newpage
\tableofcontents   % 3-4 page plans only
\newpage
```

### Concise Documentation Rules

- Use bullet points and tables; avoid narrative prose.
- Patient Education: 3-5 bullets on critical topics only.
- Risk Mitigation: critical drug safety and emergency actions only.
- Expected Outcomes: 2-3 concise statements.
- Eliminate any section that does not change a clinical decision.

### Citations

- Inline only: `(ADA Standards of Care 2024)` or `per ACC/AHA guidelines`.
- 0-3 citations maximum per plan.
- No formal bibliography unless explicitly requested.

---

## Visual Enhancement

Figures make treatment pathways clearer. Generate one when the plan includes
a multi-step pathway, milestone timeline, or decision algorithm.

### Step 1 — Build a focused prompt

Construct the image prompt using this 4-element structure (keep under 80
words total):

```
DIAGRAM TYPE: [flowchart | timeline | pathway diagram | care coordination chart]
KEY ELEMENTS: [list 2-4 steps, phases, or decision nodes to show]
STYLE: clean medical illustration, flat design, white background, labeled boxes
FORMAT: [16:9 for timelines | 1:1 for flowcharts | 4:3 for pathways]
```

Example:
> "Flowchart. Elements: diagnosis → lifestyle modification → metformin
> initiation → HbA1c check at 3 months → escalate if >7%. Style: clean
> medical illustration, flat design, white background. Format: 16:9."

Avoid photorealistic, artistic, or decorative styles. Keep prompt under 80
words.

### Step 2 — Generate the image

```
python {skill_dir}/scripts/generate_image.py \
  --prompt "your focused prompt here" \
  --filename figures/diagram.jpg \
  --aspect-ratio 16:9
```

The script reads EasyClaw runtime config automatically — no API key needed.
Supported aspect ratios: `1:1` `4:3` `3:4` `16:9` `9:16` `3:2` `2:3` `21:9`

### Step 3 — Reference in LaTeX

```latex
\begin{figure}[H]
  \centering
  \includegraphics[width=0.9\textwidth]{figures/diagram.jpg}
  \caption{Treatment pathway overview}
\end{figure}
```

---

## Core Capabilities (Quick Reference)

Load detailed guidance from `references/` only when needed for the active
specialty — do not load all reference files upfront.

| Specialty | Key components | Load when needed |
|---|---|---|
| **General Medical** | SMART goals, pharmacological + lifestyle interventions, monitoring | `references/intervention_guidelines.md` |
| **Rehabilitation** | Functional assessment (FIM/Barthel), PT/OT/SLP goals, HEP | `references/specialty_specific_guidelines.md` |
| **Mental Health** | DSM-5 diagnosis, psychotherapy modality, pharmacology titration | `references/specialty_specific_guidelines.md` |
| **Chronic Disease** | Multimorbidity management, care coordination, risk stratification | `references/specialty_specific_guidelines.md` |
| **Perioperative** | Pre-op optimization, ERAS protocols, discharge criteria | `references/specialty_specific_guidelines.md` |
| **Pain Management** | Multimodal analgesia, opioid risk mitigation, functional goals | `references/specialty_specific_guidelines.md` |

For goal-setting frameworks → `references/goal_setting_frameworks.md`
For HIPAA de-identification → `references/regulatory_compliance.md`
For quality standards → `assets/quality_checklist.md`

---

## Validation & Quality Assurance

```
# Check required sections (choose format matching Phase 1 choice)
python {skill_dir}/scripts/check_completeness.py <plan>.tex
python {skill_dir}/scripts/check_completeness.py <plan>.tex --format one-page

# Validate SMART goals, evidence, safety, medication documentation
python {skill_dir}/scripts/validate_treatment_plan.py <plan>.tex

# Generate text or visual timeline from plan content
python {skill_dir}/scripts/timeline_generator.py --plan <plan>.tex
python {skill_dir}/scripts/timeline_generator.py --plan <plan>.tex --visual --output timeline.png
```

> **Windows encoding note:** Run validation scripts with the `-X utf8` flag
> to avoid GBK codec errors on Chinese content:
> `python -X utf8 {skill_dir}/scripts/check_completeness.py <plan>.tex`

Quality checklist (`assets/quality_checklist.md`) covers:
- Clinical accuracy (ICD-10, SMART goals, evidence-based interventions)
- Patient-centered care (shared decision-making, health literacy)
- Regulatory compliance (HIPAA, medical necessity, provider signature)
- Care coordination (referrals, follow-up schedule, transitions)

---

## Professional Styling

The `assets/medical_treatment_plan.sty` package provides colored section
headers, professional page layout, and five box environments:
`infobox` `warningbox` `goalbox` `keybox` `emergencybox` `patientinfo`

Include in your `.tex` preamble:
```latex
\usepackage{medical_treatment_plan}
```

Ensure `medical_treatment_plan.sty` is in the same directory as your `.tex`
file (or install it to your local TeX path). The sty file is automatically
patched to be pdflatex-safe when you run `setup.py`.

For best font rendering, compile via `generate_pdf.py` with the LaTeX route:
```
python {skill_dir}/scripts/generate_pdf.py <plan>.tex <plan>.pdf --route latex
```

---

## Common Use Cases

**Type 2 Diabetes** → `general_medical` template
Goals: HbA1c <7.5% in 3 months; lose 15 lbs in 6 months
Key interventions: Metformin 500mg BID titrating to 1000mg BID;
Mediterranean diet; 150 min/week exercise; diabetes self-management education

**Post-Stroke Rehabilitation** → `rehabilitation` template
Goals: Right arm strength 2/5→3/5 in 4 weeks; ambulate 150 ft with cane in
12 weeks
Key interventions: PT 3x/week gait + balance; OT 3x/week ADL; SLP 2x/week
dysphagia

**Major Depressive Disorder** → `mental_health` template
Goals: PHQ-9 <10 in 8 weeks; remission (PHQ-9 <5) + return to work
Key interventions: CBT weekly; Sertraline 50mg to 100mg; sleep hygiene +
exercise

**Total Knee Arthroplasty** → `perioperative` template
Pre-op: glucose <180, anticoagulation protocol, medical clearance
Post-op: ambulate 50 ft POD 1; 90 degrees flexion POD 3; discharge POD 2-3

**Chronic Low Back Pain** → `pain_management` template
Goals: Pain 7/10 to 4/10 in 6 weeks; full-time return to work
Key interventions: Gabapentin 300mg TID + duloxetine 60mg; PT core
strengthening; CBT for pain; consider lumbar ESI if inadequate response at
8 weeks

---

## Professional Guidelines Reference

Follow current specialty society recommendations. Load
`references/intervention_guidelines.md` for detailed protocol guidance.

Key guidelines by domain:
- General medicine: ADA, ACC/AHA, GOLD, JNC-8, KDIGO
- Rehabilitation: APTA, AOTA, AHA/AACVPR stroke guidelines
- Mental health: APA, VA/DoD, NICE
- Pain: CDC opioid prescribing, WHO pain ladder, AAPM/APS

---

## Ethical Considerations

- **Informed Consent**: Document patient agreement to proposed interventions.
- **Cultural Sensitivity**: Respect diverse beliefs, language preferences,
  and health literacy levels.
- **Health Equity**: Address social determinants and access barriers.
- **Privacy**: HIPAA Safe Harbor de-identification before any sharing.
- **Autonomy**: Balance clinical recommendations with patient values and
  preferences.

