#!/usr/bin/env python3
"""
Treatment Plans Skill — Setup & Initialization
===============================================
Entry point for first-time setup and environment verification.

Usage:
    python setup.py               # locate skill dir, patch sty, check env
    python setup.py --check-env   # env check only (no patching)
    python setup.py --fix-sty     # patch sty only
    python setup.py --path-only   # print skill dir path and exit

The skill directory path is written to .skill_path in the current
working directory for use by other scripts and the AI agent.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


# ── Paths ─────────────────────────────────────────────────────────────────

def get_skill_dir() -> Path:
    """Return the skill root directory (parent of scripts/)."""
    return Path(__file__).parent.parent.resolve()


def get_assets_dir() -> Path:
    return get_skill_dir() / "assets"


def get_scripts_dir() -> Path:
    return get_skill_dir() / "scripts"


def write_skill_path(skill_dir: Path) -> None:
    """Write skill dir path to .skill_path in cwd for agent reference."""
    path_file = Path.cwd() / ".skill_path"
    path_file.write_text(str(skill_dir), encoding="utf-8")


# ── STY Patch ─────────────────────────────────────────────────────────────

STY_PATCH_MARKER = "% patched-by-setup.py"


def patch_sty(verbose: bool = True) -> bool:
    """
    Verify medical_treatment_plan.sty carries the patch marker written at
    distribution time.  The sty file is pre-patched in the repository
    (pdflatex-safe fontspec, generic headers, \\subtitle support).

    If the marker is missing (e.g. the file was replaced by an un-patched
    copy), this function reports the issue so the user can restore the
    correct file.  It does NOT attempt to re-apply patches automatically,
    because the original hard-coded strings it would search for are no
    longer present in the distributed sty.
    """
    sty_path = get_assets_dir() / "medical_treatment_plan.sty"
    if not sty_path.exists():
        if verbose:
            print(f"  SKIP  sty not found: {sty_path}")
        return True  # not fatal — sty is optional

    content = sty_path.read_text(encoding="utf-8")

    if STY_PATCH_MARKER in content:
        if verbose:
            print("  OK    medical_treatment_plan.sty is correctly patched")
        return True

    # Marker absent — sty may have been overwritten with an un-patched copy
    if verbose:
        print("  WARN  medical_treatment_plan.sty patch marker not found.")
        print("        The sty file may have been replaced with an un-patched copy.")
        print("        Restore it from the skill repository or re-run setup from")
        print("        a fresh skill installation.")
    return False


# ── PDF Route Decision ────────────────────────────────────────────────────

ROUTE_FILE = ".pdf_route"


def _decide_pdf_route(latex_available: bool, interactive: bool = True) -> None:
    """
    Set the PDF route based on LaTeX availability.
    Writes the choice to .pdf_route in cwd so generate_pdf.py reads it later.
    If LaTeX is available, automatically sets route to 'latex'.
    When interactive=False (e.g. --check-env mode), skips the A/B prompt.
    """
    route_path = Path.cwd() / ROUTE_FILE

    if latex_available:
        route_path.write_text("latex", encoding="utf-8")
        print("\n[PDF ROUTE]")
        print("  OK    LaTeX detected → PDF_ROUTE=latex (xelatex/pdflatex)")
        print(f"  Route saved to: {route_path}")
        return

    # LaTeX not available
    print("\n[PDF ROUTE]")
    if not interactive:
        # Non-interactive mode: default to python route silently
        route_path.write_text("python", encoding="utf-8")
        print("  LaTeX not found → PDF_ROUTE=python (Playwright/HTML, default for non-interactive mode)")
        print(f"  Route saved to: {route_path}")
        return

    print("  LaTeX is not installed. Choose how to generate the final PDF:")
    print()
    print("  A) Install LaTeX now for best quality output:")
    print("       macOS  : brew install --cask basictex")
    print("       Windows: winget install MiKTeX.MiKTeX")
    print("       Linux  : sudo apt install texlive-latex-recommended texlive-xetex")
    print("     After installing, re-run setup.py and it will switch to LaTeX route.")
    print()
    print("  B) Use built-in Python/Playwright renderer:")
    print("     - Fill plan.json (clean structured data, no LaTeX markup needed)")
    print("     - Renders via Chromium: professional CSS layout, native CJK fonts")
    print("     - No LaTeX installation required")
    print()

    try:
        choice = input("  Your choice [A/B, default B]: ").strip().upper()
    except EOFError:
        choice = "B"

    if choice == "A":
        print()
        print("  Install LaTeX using the command above, then re-run:")
        print("    python setup.py")
        print("  The route will be set to LaTeX automatically.")
        # Write a pending marker — generate_pdf.py will auto-detect on first run
        route_path.write_text("auto", encoding="utf-8")
        print(f"  Route set to auto-detect, saved to: {route_path}")
    else:
        route_path.write_text("python", encoding="utf-8")
        print("  PDF_ROUTE=python (Playwright/HTML) selected.")
        print(f"  Route saved to: {route_path}")


# ── Environment Check ──────────────────────────────────────────────────────

def check_command(cmd: str) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            [cmd, "--version"], capture_output=True, text=True, timeout=10
        )
        version = (result.stdout or result.stderr).strip().splitlines()[0]
        return True, version
    except (FileNotFoundError, subprocess.TimeoutExpired, IndexError):
        return False, ""


def check_python_package(package: str) -> bool:
    try:
        __import__(package)
        return True
    except ImportError:
        return False


def check_environment(interactive: bool = True) -> bool:
    """
    Run all dependency checks. Returns True if all required deps are satisfied.
    Prints a structured report with READY / MISSING status per item.
    Pass interactive=False to skip the PDF route A/B prompt (e.g. --check-env mode).
    """
    print("\n" + "=" * 70)
    print("ENVIRONMENT CHECK — treatment-plans skill")
    print("=" * 70)

    all_ok = True
    _interactive_mode = interactive

    # [1] LaTeX
    print("\n[1] LaTeX compiler  (optional — improves PDF quality)")
    pdflatex_ok, pdfver = check_command("pdflatex")
    xelatex_ok, xever = check_command("xelatex")
    latex_available = pdflatex_ok or xelatex_ok
    print(f"    {'OK    ' if pdflatex_ok else 'MISSING'} pdflatex: {pdfver or 'not found'}")
    print(f"    {'OK    ' if xelatex_ok else 'MISSING'} xelatex:  {xever or 'not found'}")
    if not latex_available:
        print("    -> LaTeX not found. Python/Playwright PDF route will be used instead.")
        print("       To install LaTeX for best quality:")
        print("         macOS  : brew install --cask basictex")
        print("         Windows: winget install MiKTeX.MiKTeX")
        print("         Linux  : sudo apt install texlive-latex-recommended texlive-xetex")

    # [2] Python packages
    print("\n[2] Python packages")
    pkg_list = [("playwright", "playwright"), ("openai", "openai"), ("PIL", "pillow")]
    for import_name, pip_name in pkg_list:
        found = check_python_package(import_name)
        req = "required (HTML→PDF renderer)" if import_name == "playwright" else "for figures"
        print(f"    {'OK    ' if found else 'MISSING'} {pip_name}  ({req})")
        if not found:
            if import_name == "playwright":
                all_ok = False
                print("      -> python -m pip install playwright && python -m playwright install chromium")
            # openai / pillow are only needed for image generation — not fatal
    missing_img = [pip for imp, pip in pkg_list[1:] if not check_python_package(imp)]
    if missing_img:
        print(f"    -> python -m pip install {' '.join(missing_img)}")

    # [3] EasyClaw runtime config
    print("\n[3] EasyClaw runtime config  (required for image generation)")
    state_dir = Path.home() / ".easyclaw"
    config_items = [
        ("easyclaw.json", state_dir / "easyclaw.json"),
        ("easyclaw-userinfo.json", state_dir / "identity" / "easyclaw-userinfo.json"),
    ]
    for label, path in config_items:
        found = path.exists()
        print(f"    {'OK    ' if found else 'MISSING'} {label}  ({path})")
        if not found:
            all_ok = False
            print("      -> Created automatically by EasyClaw on first login.")

    # [4] matplotlib (optional)
    print("\n[4] matplotlib  (optional — text timeline fallback available)")
    mpl = check_python_package("matplotlib")
    print(f"    {'OK    ' if mpl else 'OPTIONAL'} matplotlib")
    if not mpl:
        print("      -> python -m pip install matplotlib")

    # [5] Skill asset files
    print("\n[5] Skill asset files")
    skill_dir = get_skill_dir()
    expected = [
        get_assets_dir() / "medical_treatment_plan.sty",
        get_assets_dir() / "one_page_treatment_plan.tex",
        get_scripts_dir() / "generate_image.py",
        get_scripts_dir() / "validate_treatment_plan.py",
        get_scripts_dir() / "check_completeness.py",
        get_scripts_dir() / "timeline_generator.py",
        get_scripts_dir() / "generate_template.py",
        get_scripts_dir() / "generate_pdf.py",
        get_scripts_dir() / "generate_plan_json.py",
    ]
    for path in expected:
        found = path.exists()
        rel = path.relative_to(skill_dir)
        print(f"    {'OK    ' if found else 'MISSING'} {rel}")
        if not found:
            all_ok = False

    # PDF Route Decision (interactive only in full init mode)
    _decide_pdf_route(latex_available, interactive=_interactive_mode)

    # Summary
    print("\n" + "=" * 70)
    if all_ok:
        print("RESULT: READY — all required dependencies satisfied.")
    else:
        print("RESULT: NOT READY — resolve items marked MISSING above, then re-run.")
    print("=" * 70 + "\n")
    return all_ok


# ── Main ──────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Treatment Plans skill — setup, patch, and environment check",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python setup.py                # full init: locate, patch sty, check env
  python setup.py --check-env   # env check only
  python setup.py --fix-sty     # patch sty only
  python setup.py --path-only   # print skill dir and exit
        """,
    )
    parser.add_argument(
        "--check-env", action="store_true",
        help="Run environment checks only (skip sty patch)"
    )
    parser.add_argument(
        "--fix-sty", action="store_true",
        help="Patch medical_treatment_plan.sty only"
    )
    parser.add_argument(
        "--path-only", action="store_true",
        help="Print the skill directory path and exit"
    )
    args = parser.parse_args()

    skill_dir = get_skill_dir()

    # -- path-only mode
    if args.path_only:
        print(str(skill_dir))
        return 0

    # -- fix-sty only mode
    if args.fix_sty:
        print("\n[STY PATCH]")
        patch_sty(verbose=True)
        return 0

    # -- check-env only mode
    if args.check_env:
        ok = check_environment(interactive=False)
        return 0 if ok else 1

    # -- full init (default)
    print("\n" + "=" * 70)
    print("TREATMENT PLANS SKILL — SETUP")
    print("=" * 70)
    print(f"\nSkill directory: {skill_dir}")
    write_skill_path(skill_dir)
    print(f"Path saved to  : {Path.cwd() / '.skill_path'}")

    print("\n[STY PATCH]")
    patch_sty(verbose=True)

    ok = check_environment()

    print("=" * 70)
    print("SETUP COMPLETE")
    print(f"Use this path for all subsequent script calls:")
    print(f"  {skill_dir}")
    print("=" * 70 + "\n")

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

