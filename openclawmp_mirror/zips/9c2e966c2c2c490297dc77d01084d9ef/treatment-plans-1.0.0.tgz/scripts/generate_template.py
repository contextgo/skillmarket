﻿#!/usr/bin/env python3
"""
Generate Treatment Plan Template
Interactive script to select and generate treatment plan templates.
Also supports environment checking via --check-env flag.
"""

import os
import sys
import shutil
import argparse
import subprocess
from pathlib import Path
from datetime import datetime

TEMPLATES = {
    'general_medical': {
        'name': 'General Medical Treatment Plan',
        'file': 'general_medical_treatment_plan.tex',
        'description': 'For primary care and chronic disease management (diabetes, hypertension, etc.)'
    },
    'rehabilitation': {
        'name': 'Rehabilitation Treatment Plan',
        'file': 'rehabilitation_treatment_plan.tex',
        'description': 'For physical therapy, occupational therapy, and rehabilitation services'
    },
    'mental_health': {
        'name': 'Mental Health Treatment Plan',
        'file': 'mental_health_treatment_plan.tex',
        'description': 'For psychiatric and behavioral health treatment'
    },
    'chronic_disease': {
        'name': 'Chronic Disease Management Plan',
        'file': 'chronic_disease_management_plan.tex',
        'description': 'For complex multimorbidity and long-term care coordination'
    },
    'perioperative': {
        'name': 'Perioperative Care Plan',
        'file': 'perioperative_care_plan.tex',
        'description': 'For surgical and procedural patient management'
    },
    'pain_management': {
        'name': 'Pain Management Plan',
        'file': 'pain_management_plan.tex',
        'description': 'For acute and chronic pain treatment (multimodal approach)'
    },
    'one_page': {
        'name': 'One-Page Treatment Plan',
        'file': 'one_page_treatment_plan.tex',
        'description': 'Compact single-page format for straightforward clinical scenarios (preferred for most cases)'
    }
}


def get_skill_dir():
    return Path(__file__).parent.parent


def get_templates_dir():
    return get_skill_dir() / 'assets'


def check_command(cmd):
    try:
        result = subprocess.run([cmd, '--version'], capture_output=True, text=True, timeout=10)
        version = (result.stdout or result.stderr).strip().splitlines()[0]
        return True, version
    except (FileNotFoundError, subprocess.TimeoutExpired, IndexError):
        return False, ''


def check_python_package(package):
    try:
        __import__(package)
        return True
    except ImportError:
        return False


def check_environment():
    print("\n" + "=" * 70)
    print("ENVIRONMENT CHECK -- treatment-plans skill")
    print("=" * 70)
    all_required_ok = True

    print("\n[1] LaTeX compiler (required to produce PDF output)")
    pdflatex_ok, pdfver = check_command('pdflatex')
    xelatex_ok, xever = check_command('xelatex')
    print(f"    {'OK' if pdflatex_ok else 'MISSING'} pdflatex: {pdfver if pdflatex_ok else 'not found'}")
    print(f"    {'OK' if xelatex_ok else 'MISSING'} xelatex:  {xever if xelatex_ok else 'not found'}")
    if not pdflatex_ok and not xelatex_ok:
        all_required_ok = False
        print("    -> MISSING. Install one of:")
        print("         macOS  : brew install --cask basictex")
        print("         Windows: https://miktex.org/download  or  winget install MiKTeX.MiKTeX")
        print("         Linux  : sudo apt install texlive-latex-recommended")
        print("       FALLBACK: deliver .tex file; user compiles at https://overleaf.com")

    print("\n[2] Python packages for image generation")
    img_deps = [('openai', 'openai'), ('PIL', 'pillow')]
    img_all_ok = True
    for import_name, pip_name in img_deps:
        found = check_python_package(import_name)
        print(f"    {'OK' if found else 'MISSING'} {pip_name}")
        if not found:
            img_all_ok = False
    if not img_all_ok:
        all_required_ok = False
        print("    -> python -m pip install openai pillow")

    print("\n[3] EasyClaw runtime config")
    state_dir = Path.home() / '.easyclaw'
    for label, path in [
        ('easyclaw.json', state_dir / 'easyclaw.json'),
        ('easyclaw-userinfo.json', state_dir / 'identity' / 'easyclaw-userinfo.json'),
    ]:
        found = path.exists()
        print(f"    {'OK' if found else 'MISSING'} {label}: {path}")
        if not found:
            all_required_ok = False
            print("      -> Created automatically by EasyClaw on first login.")

    print("\n[4] matplotlib (optional - text timeline fallback available)")
    mpl_found = check_python_package('matplotlib')
    print(f"    {'OK' if mpl_found else 'OPTIONAL-MISSING'} matplotlib")
    if not mpl_found:
        print("      -> python -m pip install matplotlib")

    print("\n[5] Skill asset files")
    skill_dir = get_skill_dir()
    assets_dir = get_templates_dir()
    scripts_dir = skill_dir / 'scripts'
    expected = [
        assets_dir / 'medical_treatment_plan.sty',
        assets_dir / 'one_page_treatment_plan.tex',
        scripts_dir / 'generate_image.py',
        scripts_dir / 'validate_treatment_plan.py',
        scripts_dir / 'check_completeness.py',
        scripts_dir / 'timeline_generator.py',
    ]
    for path in expected:
        found = path.exists()
        rel = path.relative_to(skill_dir)
        print(f"    {'OK' if found else 'MISSING'} {rel}")
        if not found:
            all_required_ok = False

    print("\n" + "=" * 70)
    if all_required_ok:
        print("RESULT: READY -- all required dependencies satisfied.")
    else:
        print("RESULT: NOT READY -- resolve the issues marked MISSING above.")
    print("=" * 70 + "\n")
    return 0 if all_required_ok else 1


def list_templates():
    print("\n" + "=" * 70)
    print("AVAILABLE TREATMENT PLAN TEMPLATES")
    print("=" * 70)
    for i, (key, info) in enumerate(TEMPLATES.items(), 1):
        print(f"\n{i}. {info['name']}")
        print(f"   Type: {key}")
        print(f"   File: {info['file']}")
        print(f"   Description: {info['description']}")
    print("\n" + "=" * 70)


def interactive_selection():
    list_templates()
    while True:
        try:
            choice = input("\nSelect template number (1-6) or 'q' to quit: ").strip().lower()
            if choice == 'q':
                print("Exiting...")
                sys.exit(0)
            choice_num = int(choice)
            if 1 <= choice_num <= len(TEMPLATES):
                return list(TEMPLATES.keys())[choice_num - 1]
            else:
                print(f"Please enter a number between 1 and {len(TEMPLATES)}.")
        except ValueError:
            print("Invalid input. Please enter a number or 'q' to quit.")


def get_output_filename(template_key, custom_name=None):
    if custom_name:
        if not custom_name.endswith('.tex'):
            custom_name += '.tex'
        return custom_name
    timestamp = datetime.now().strftime('%Y%m%d')
    return f"{template_key}_plan_{timestamp}.tex"


def copy_template(template_key, output_path):
    templates_dir = get_templates_dir()
    source_path = templates_dir / TEMPLATES[template_key]['file']
    if not source_path.exists():
        raise FileNotFoundError(f"Template not found: {source_path}")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_path, output_path)
    return output_path


def display_success(output_path, template_key):
    skill_dir = get_skill_dir()
    print("\n" + "=" * 70)
    print("TEMPLATE GENERATED SUCCESSFULLY")
    print("=" * 70)
    print(f"\nTemplate: {TEMPLATES[template_key]['name']}")
    print(f"Output  : {output_path}")
    print(f"Size    : {os.path.getsize(output_path):,} bytes")
    print("\nNEXT STEPS:")
    print("  1. Fill in all [bracketed placeholders] with patient-specific data")
    print("  2. Compile:  pdflatex " + str(output_path.name))
    print("     No LaTeX? Upload to https://overleaf.com")
    print("  3. Validate: python \"" + str(skill_dir / 'scripts' / 'check_completeness.py') + "\" " + str(output_path.name))
    print("  4. De-identify before sharing (see references/regulatory_compliance.md)")
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(
        description='Generate treatment plan template / check environment',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_template.py --check-env
  python generate_template.py --type general_medical --output diabetes_plan.tex
  python generate_template.py --list
        """
    )
    parser.add_argument('--type', choices=list(TEMPLATES.keys()))
    parser.add_argument('--output')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--check-env', action='store_true',
                        help='Check all runtime dependencies and exit')

    args = parser.parse_args()

    if args.check_env:
        sys.exit(check_environment())

    if args.list:
        list_templates()
        return

    template_key = args.type if args.type else interactive_selection()
    output_filename = args.output if args.output else get_output_filename(template_key)
    output_path = Path.cwd() / output_filename

    if output_path.exists():
        resp = input(f"\nFile {output_filename} already exists. Overwrite? (y/n): ").strip().lower()
        if resp != 'y':
            print("Cancelled.")
            return

    try:
        output_path = copy_template(template_key, output_path)
        display_success(output_path, template_key)
    except Exception as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()

