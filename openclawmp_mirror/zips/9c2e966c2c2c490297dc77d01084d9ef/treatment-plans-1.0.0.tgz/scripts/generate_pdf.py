#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Treatment Plans — PDF Generator
================================
Converts a filled .tex treatment plan file to PDF.

Route selection (automatic, reads .pdf_route in cwd):
  latex   — compiles with xelatex/pdflatex (best quality, requires LaTeX)
  python  — renders with reportlab (no LaTeX needed, cross-platform)

Usage:
    python generate_pdf.py <plan.tex> <output.pdf>
    python generate_pdf.py <plan.tex> <output.pdf> --route latex
    python generate_pdf.py <plan.tex> <output.pdf> --route python
    python generate_pdf.py <plan.tex> <output.pdf> --route auto   # re-detect

Options:
    --route   latex | python | auto  Override .pdf_route file
    --lang    en | zh | auto         Language hint for font selection (default: auto)

Exit codes:
    0  PDF generated successfully
    1  Error — see stderr for details
"""

from __future__ import annotations

import argparse
import platform
import re
import subprocess
import sys
from pathlib import Path

# ── Route file ────────────────────────────────────────────────────────────

ROUTE_FILE = ".pdf_route"


def read_route(override: str | None) -> str:
    """
    Return 'latex' or 'python'.

    Priority:
      1. --route argument (if provided)
      2. .pdf_route file in cwd (written by setup.py after user choice)
      3. If neither exists: exit with error — user must run setup.py first.

    The user's choice made in setup.py is the authoritative source of truth.
    Silent auto-detection is intentionally disabled to preserve user agency.
    """
    if override and override in ("latex", "python"):
        return override
    if override == "auto":
        return detect_latex_route()

    route_path = Path.cwd() / ROUTE_FILE
    if route_path.exists():
        val = route_path.read_text(encoding="utf-8").strip().lower()
        if val == "auto":
            return detect_latex_route()
        if val in ("latex", "python"):
            return val

    # .pdf_route missing — do NOT silently decide.
    # The user has not yet chosen a PDF route via setup.py.
    print(
        "Error: PDF route not configured.\n"
        "  Run setup.py first to choose your PDF generation method:\n"
        "    python <skill_dir>/scripts/setup.py\n"
        "  setup.py will detect LaTeX and ask whether to use it or the\n"
        "  built-in Python/reportlab renderer.",
        file=sys.stderr,
    )
    sys.exit(2)  # exit code 2 = configuration missing (distinct from 1 = generation error)


def detect_latex_route() -> str:
    """Return 'latex' if xelatex or pdflatex is available, else 'python'."""
    for cmd in ("xelatex", "pdflatex"):
        try:
            subprocess.run([cmd, "--version"], capture_output=True, timeout=10)
            return "latex"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return "python"


# ── LaTeX route ───────────────────────────────────────────────────────────

def compile_latex(tex_path: Path, out_path: Path) -> bool:
    """
    Compile .tex to PDF using xelatex (preferred) or pdflatex.
    Runs twice for correct cross-references.
    Returns True on success.
    """
    tex_dir = tex_path.parent.resolve()

    # Choose compiler
    compiler = None
    for cmd in ("xelatex", "pdflatex"):
        try:
            subprocess.run([cmd, "--version"], capture_output=True, timeout=10)
            compiler = cmd
            break
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    if not compiler:
        print("Error: no LaTeX compiler found (xelatex / pdflatex).", file=sys.stderr)
        return False

    compile_cmd = [
        compiler,
        "-interaction=nonstopmode",
        "-output-directory", str(tex_dir),
        str(tex_path.resolve()),
    ]

    for run in range(2):  # two passes for refs/TOC
        result = subprocess.run(
            compile_cmd, cwd=str(tex_dir),
            capture_output=True, text=True, encoding="utf-8", errors="replace"
        )
        if result.returncode != 0 and run == 1:
            print(f"Error: {compiler} failed (exit {result.returncode}).", file=sys.stderr)
            # Print last 30 lines of log for diagnosis
            log_lines = (result.stdout + result.stderr).splitlines()
            for line in log_lines[-30:]:
                print(f"  {line}", file=sys.stderr)
            return False

    # The compiled PDF lands next to the .tex file
    compiled = tex_dir / tex_path.with_suffix(".pdf").name
    if not compiled.exists():
        print(f"Error: expected PDF not found at {compiled}", file=sys.stderr)
        return False

    # Move to requested output path if different
    if compiled.resolve() != out_path.resolve():
        out_path.parent.mkdir(parents=True, exist_ok=True)
        compiled.replace(out_path)

    return True


# ── Plan data parser ─────────────────────────────────────────────────────
# Supports two input formats:
#   .json  — structured plan.json (Python/Playwright route, clean HTML)
#   .tex   — LaTeX source (legacy; parsed best-effort, may have markup residue)
#
# For Python route, always prefer .json: generate with generate_plan_json.py,
# fill placeholders, then pass to generate_pdf.py.


def _detect_language(text: str) -> str:
    """Return 'zh' if text contains >50 CJK characters, else 'en'."""
    return "zh" if sum(1 for c in text if "\u4e00" <= c <= "\u9fff") > 50 else "en"


def _is_placeholder(v: object) -> bool:
    """Return True if value is an unfilled placeholder."""
    return isinstance(v, str) and v.startswith("[") and v.endswith("]")


def parse_json_plan(json_path: Path) -> dict:
    """
    Parse a filled plan.json into the internal data dict consumed by _build_html().
    Skips unfilled placeholder values.
    """
    import json as _json
    raw = _json.loads(json_path.read_text(encoding="utf-8"))

    lang = _detect_language(_json.dumps(raw, ensure_ascii=False))

    def clean(v):
        if _is_placeholder(v):
            return ""
        if isinstance(v, list):
            return [clean(i) for i in v if not _is_placeholder(i)]
        return str(v) if not isinstance(v, (dict, list)) else v

    def rows_to_text(rows: list, keys: list) -> str:
        """Convert list-of-dicts to readable lines."""
        out = []
        for row in rows:
            if isinstance(row, dict):
                parts = [str(row[k]) for k in keys if k in row and not _is_placeholder(row[k])]
                if parts:
                    out.append(" | ".join(parts))
            elif isinstance(row, str) and not _is_placeholder(row):
                out.append(row)
        return "\n".join(out)

    def dict_to_text(d: dict) -> str:
        out = []
        for k, v in d.items():
            if k.startswith("_"):
                continue
            if isinstance(v, list):
                for item in v:
                    s = str(item).strip()
                    if s and not _is_placeholder(s):
                        out.append(f"• {s}")
            elif isinstance(v, str) and v.strip() and not _is_placeholder(v):
                out.append(f"• {v}")
        return "\n".join(out)

    # ── Title / subtitle ──────────────────────────────────────────────────
    title    = clean(raw.get("title", ""))    or ("医疗治疗方案" if lang == "zh" else "Medical Treatment Plan")
    subtitle = clean(raw.get("subtitle", "")) or ""

    # ── Patient info ──────────────────────────────────────────────────────
    patient = raw.get("patient", {})
    patient_lines = []
    label_map_zh = {"id": "患者编号", "age_range": "年龄段", "sex": "性别", "department": "科室"}
    label_map_en = {"id": "Patient ID", "age_range": "Age Range", "sex": "Sex", "department": "Department"}
    lmap = label_map_zh if lang == "zh" else label_map_en
    for k, label in lmap.items():
        v = patient.get(k, "")
        if v and not _is_placeholder(v):
            patient_lines.append(f"{label}：{v}" if lang == "zh" else f"{label}: {v}")
    patient_info = "\n".join(patient_lines)

    # ── Diagnoses → patient info extension ───────────────────────────────
    diag_lines = []
    for d in raw.get("diagnoses", []):
        if not isinstance(d, dict):
            continue
        name  = d.get("name", "")
        icd   = d.get("icd10", "")
        label = d.get("label", "")
        if _is_placeholder(name):
            continue
        s = name
        if icd and not _is_placeholder(icd):
            s += f"（{icd}）" if lang == "zh" else f" ({icd})"
        if label and not _is_placeholder(label):
            s = f"{label}：{s}" if lang == "zh" else f"{label}: {s}"
        diag_lines.append(s)
    if diag_lines:
        diag_header = "诊断" if lang == "zh" else "Diagnoses"
        patient_info += "\n" + diag_header + "：\n" + "\n".join(f"• {l}" for l in diag_lines)

    # Baseline metrics
    baseline_lines = []
    for b in raw.get("baseline", []):
        if not isinstance(b, dict):
            continue
        param  = b.get("parameter", "")
        value  = b.get("value", "")
        target = b.get("target", "")
        if _is_placeholder(param) or _is_placeholder(value):
            continue
        s = f"{param}：{value}"
        if target and not _is_placeholder(target):
            s += f"（目标：{target}）" if lang == "zh" else f" (target: {target})"
        baseline_lines.append(s)
    if baseline_lines:
        bl_header = "基线评估" if lang == "zh" else "Baseline"
        patient_info += "\n" + bl_header + "：\n" + "\n".join(f"• {l}" for l in baseline_lines)

    # Chief complaint
    cc = clean(raw.get("chief_complaint", ""))
    if cc:
        cc_header = "主诉" if lang == "zh" else "Chief Complaint"
        patient_info += f"\n{cc_header}：{cc}"

    # Current meds
    med_lines = []
    for m in raw.get("current_medications", []):
        if not isinstance(m, dict):
            continue
        parts = [m.get(k, "") for k in ["name", "dose", "frequency"] if not _is_placeholder(m.get(k, ""))]
        if parts and not _is_placeholder(parts[0]):
            med_lines.append(" ".join(parts))
    if med_lines:
        mh = "当前用药" if lang == "zh" else "Current Medications"
        patient_info += "\n" + mh + "：\n" + "\n".join(f"• {l}" for l in med_lines)

    # ── Goals → goalbox ───────────────────────────────────────────────────
    goals_raw = raw.get("goals", {})
    goals_lines = []
    st_label = "短期目标" if lang == "zh" else "Short-Term Goals"
    lt_label = "长期目标" if lang == "zh" else "Long-Term Goals"
    pp_label = "患者个人目标" if lang == "zh" else "Patient Priorities"

    for g in goals_raw.get("short_term", []):
        if isinstance(g, dict):
            v = g.get("goal", "")
            if v and not _is_placeholder(v):
                goals_lines.append(f"[{st_label}] {v}")
        elif isinstance(g, str) and not _is_placeholder(g):
            goals_lines.append(f"[{st_label}] {g}")

    for g in goals_raw.get("long_term", []):
        if isinstance(g, str) and not _is_placeholder(g):
            goals_lines.append(f"[{lt_label}] {g}")

    for p in goals_raw.get("patient_priorities", []):
        if isinstance(p, str) and not _is_placeholder(p):
            goals_lines.append(f"[{pp_label}] {p}")

    # ── Interventions → keybox ────────────────────────────────────────────
    interv_raw = raw.get("interventions", {})
    interv_lines = []
    med_h = "药物" if lang == "zh" else "Medications"
    for m in interv_raw.get("medications", []):
        if not isinstance(m, dict):
            continue
        name = m.get("name", "")
        if _is_placeholder(name):
            continue
        dose = m.get("dose", "")
        freq = m.get("frequency", "")
        instr = m.get("instructions", "")
        parts = [name]
        if dose and not _is_placeholder(dose):
            parts.append(dose)
        if freq and not _is_placeholder(freq):
            parts.append(freq)
        line = " ".join(parts)
        if instr and not _is_placeholder(instr):
            line += f" — {instr[:80]}"
        interv_lines.append(f"[{med_h}] {line}")

    life = interv_raw.get("lifestyle", {})
    life_h = "生活方式" if lang == "zh" else "Lifestyle"
    for item_list in [life.get("diet", []), life.get("exercise", [])]:
        for item in item_list:
            if isinstance(item, str) and not _is_placeholder(item):
                interv_lines.append(f"[{life_h}] {item}")

    for ref in interv_raw.get("referrals", []):
        if isinstance(ref, str) and not _is_placeholder(ref):
            ref_h = "转介" if lang == "zh" else "Referral"
            interv_lines.append(f"[{ref_h}] {ref}")

    # ── Body sections ──────────────────────────────────────────────────────
    body_sections = []

    # Assessment
    assessment = raw.get("assessment", {})
    if isinstance(assessment, dict):
        cp = assessment.get("clinical_presentation", "")
        if cp and not _is_placeholder(cp):
            h = "临床表现" if lang == "zh" else "Clinical Presentation"
            body_sections.append((h, cp, 2))
        risk = assessment.get("risk_stratification", [])
        if risk:
            h = "风险分层" if lang == "zh" else "Risk Stratification"
            body_sections.append((h, "\n".join(f"• {r}" for r in risk if not _is_placeholder(r)), 2))
        rationale = assessment.get("drug_selection_rationale", [])
        if rationale:
            h = "药物选择依据" if lang == "zh" else "Drug Selection Rationale"
            body_sections.append((h, "\n".join(f"• {r}" for r in rationale if not _is_placeholder(r)), 2))

    # SMART goals detail
    for g in goals_raw.get("short_term", []):
        if not isinstance(g, dict):
            continue
        goal_title = g.get("goal", "")
        if _is_placeholder(goal_title):
            continue
        detail_lines = []
        for key in ["specific", "measurable", "achievable", "relevant", "time_bound"]:
            v = g.get(key, "")
            if v and not _is_placeholder(v):
                label = {"specific": "Specific", "measurable": "Measurable",
                         "achievable": "Achievable", "relevant": "Relevant",
                         "time_bound": "Time-bound"}[key]
                detail_lines.append(f"• {label}: {v}")
        if detail_lines:
            body_sections.append((goal_title, "\n".join(detail_lines), 2))

    # Medication safety
    safety = interv_raw.get("medication_safety", [])
    if safety:
        h = "药物安全要点" if lang == "zh" else "Medication Safety"
        body_sections.append((h, "\n".join(f"• {s}" for s in safety if not _is_placeholder(s)), 2))

    # Investigations
    inv_list = interv_raw.get("investigations", [])
    if inv_list:
        h = "实验室检查计划" if lang == "zh" else "Investigation Schedule"
        rows = rows_to_text(inv_list, ["timepoint", "tests", "reason"])
        if rows:
            body_sections.append((h, rows, 2))

    # Timeline
    tl = raw.get("timeline", [])
    if tl:
        h = "治疗时间轴" if lang == "zh" else "Treatment Timeline"
        rows = rows_to_text(tl, ["phase", "period", "focus"])
        if rows:
            body_sections.append((h, rows, 2))

    # Follow-up
    fu = raw.get("followup", [])
    if fu:
        h = "随访计划" if lang == "zh" else "Follow-up Schedule"
        rows = rows_to_text(fu, ["timepoint", "format", "agenda"])
        if rows:
            body_sections.append((h, rows, 2))

    # Monitoring
    mon = raw.get("monitoring", [])
    if mon:
        h = "监测参数" if lang == "zh" else "Monitoring Parameters"
        rows = rows_to_text(mon, ["parameter", "baseline", "target", "frequency"])
        if rows:
            body_sections.append((h, rows, 2))

    # Thresholds
    thresh = raw.get("thresholds", {})
    if thresh:
        h = "干预阈值" if lang == "zh" else "Intervention Thresholds"
        lines_out = []
        for k, items in thresh.items():
            label_map = {
                "emergency":     ("紧急（急救）" if lang == "zh" else "EMERGENCY"),
                "call_same_day": ("当日联系"    if lang == "zh" else "Same-day call"),
                "escalate":      ("升级治疗"    if lang == "zh" else "Escalate treatment"),
            }
            label = label_map.get(k, k)
            for item in items:
                if not _is_placeholder(item):
                    lines_out.append(f"[{label}] {item}")
        if lines_out:
            body_sections.append((h, "\n".join(lines_out), 2))

    # Expected outcomes
    eo = raw.get("expected_outcomes", [])
    if eo:
        h = "预期结果" if lang == "zh" else "Expected Outcomes"
        body_sections.append((h, "\n".join(f"• {e}" for e in eo if not _is_placeholder(e)), 2))

    # Patient education
    pe = raw.get("patient_education", [])
    if pe:
        h = "患者教育要点" if lang == "zh" else "Patient Education"
        body_sections.append((h, "\n".join(f"• {e}" for e in pe if not _is_placeholder(e)), 2))

    # Risk mitigation
    rm = raw.get("risk_mitigation", [])
    if rm:
        h = "风险控制" if lang == "zh" else "Risk Mitigation"
        body_sections.append((h, "\n".join(f"• {r}" for r in rm if not _is_placeholder(r)), 2))

    return {
        "title":        title,
        "subtitle":     subtitle,
        "patient_info": patient_info,
        "goals":        "\n".join(goals_lines),
        "interventions":"\n".join(interv_lines),
        "warnings":     "",
        "timeline":     "",
        "body_sections": body_sections,
        "language":     lang,
    }


# ── HTML template ────────────────────────────────────────────────────────

def _build_html(data: dict) -> str:
    """
    Build a professional HTML document from parsed .tex data.
    Supports both Chinese and English content.
    Uses system fonts via CSS — no font registration needed.
    Extensible: add new card types or section styles via CSS classes.
    """
    lang = data.get("language", "en")
    is_zh = (lang == "zh")

    L = {
        "patient":  "患者信息"      if is_zh else "Patient Information",
        "goals":    "主要目标"      if is_zh else "Primary Goals",
        "interv":   "核心干预"      if is_zh else "Core Interventions",
        "warning":  "⚠ 关键决策点" if is_zh else "⚠ Critical Decision Points",
        "timeline": "治疗时间线"    if is_zh else "Treatment Timeline",
        "footer": (
            "本文档由 treatment-plans 技能（HTML/Playwright 渲染）生成。"
            "如需 LaTeX 版本，安装 MiKTeX 后重新运行 setup.py 选择 A 路线。"
            if is_zh else
            "Generated by treatment-plans skill (HTML/Playwright rendering). "
            "For LaTeX version, install MiKTeX/BasicTeX and re-run setup.py."
        ),
    }

    font_stack = (
        "'Microsoft YaHei','PingFang SC','Hiragino Sans GB',"
        "'WenQuanYi Zen Hei','Source Han Sans CN',sans-serif"
        if is_zh else
        "'Segoe UI','Helvetica Neue',Arial,sans-serif"
    )

    css = f"""
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font-family:{font_stack};font-size:10pt;line-height:1.65;color:#1a1a1a;background:#fff}}
    .page{{width:210mm;min-height:297mm;margin:0 auto;padding:16mm 20mm}}
    /* Header */
    .header{{background:linear-gradient(135deg,#1a3a5c 0%,#2e6da4 100%);color:#fff;
             padding:22px 28px 18px;border-radius:8px;margin-bottom:18px}}
    .header h1{{font-size:21pt;font-weight:700;letter-spacing:.4px;margin-bottom:4px}}
    .header .subtitle{{font-size:11pt;opacity:.85}}
    .header .meta{{font-size:8.5pt;opacity:.65;margin-top:5px}}
    /* Summary cards */
    .summary-grid{{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-bottom:16px}}
    .card{{border-radius:6px;padding:12px 15px}}
    .card-blue  {{background:#e8f4fd;border-left:4px solid #2980b9}}
    .card-green {{background:#eafaf1;border-left:4px solid #27ae60}}
    .card-orange{{background:#fef9e7;border-left:4px solid #e67e22}}
    .card-red   {{background:#fdedec;border-left:4px solid #e74c3c}}
    .card-grey  {{background:#f4f6f7;border-left:4px solid #7f8c8d}}
    .card-full  {{grid-column:1/-1}}
    .card h3{{font-size:8pt;font-weight:700;text-transform:uppercase;
              letter-spacing:.6px;color:#555;margin-bottom:6px}}
    .card ul{{padding-left:14px;font-size:9.5pt}}
    .card ul li{{margin-bottom:2px}}
    .card p{{font-size:9.5pt;margin-bottom:3px}}
    /* Sections */
    .section{{margin-top:16px}}
    .section h2{{font-size:12pt;font-weight:700;color:#1a3a5c;
                border-bottom:2px solid #2980b9;padding-bottom:4px;margin-bottom:9px}}
    .section h3{{font-size:10.5pt;font-weight:600;color:#2c6e9e;margin:9px 0 4px}}
    .section p,.section li{{font-size:9.5pt;margin-bottom:3px}}
    .section ul,.section ol{{padding-left:17px}}
    /* Tables */
    table{{width:100%;border-collapse:collapse;font-size:9pt;margin:7px 0 11px}}
    thead tr{{background:#1a3a5c;color:#fff}}
    thead th{{padding:7px 10px;text-align:left;font-weight:600;font-size:8.5pt}}
    tbody tr:nth-child(even){{background:#f0f4f8}}
    tbody td{{padding:5px 10px;border-bottom:1px solid #dde3ea;vertical-align:top}}
    /* Footer */
    .footer{{margin-top:24px;padding-top:9px;border-top:1px solid #ccc;
             font-size:7.5pt;color:#888;font-style:italic}}
    @media print{{.no-break{{page-break-inside:avoid}}.section{{page-break-inside:avoid}}}}
    """

    def esc(s):
        return (s.replace("&","&amp;").replace("<","&lt;")
                 .replace(">","&gt;").replace('"',"&quot;"))

    def lines_to_html(text):
        if not text.strip():
            return ""
        parts = []
        in_list = False
        for line in text.splitlines():
            line = line.strip()
            if not line:
                if in_list:
                    parts.append("</ul>")
                    in_list = False
                continue
            if line.startswith(("•", "-", "–", "*")):
                clean = esc(line.lstrip("•-–* ").strip())
                if not in_list:
                    parts.append("<ul>")
                    in_list = True
                parts.append(f"<li>{clean}</li>")
            else:
                if in_list:
                    parts.append("</ul>")
                    in_list = False
                parts.append(f"<p>{esc(line)}</p>")
        if in_list:
            parts.append("</ul>")
        return "\n".join(parts)

    # Summary cards
    cards_html = ""
    if data.get("patient_info"):
        cards_html += (f'<div class="card card-blue card-full no-break">'
                       f'<h3>{esc(L["patient"])}</h3>'
                       f'{lines_to_html(data["patient_info"])}</div>')

    g = lines_to_html(data.get("goals", ""))
    iv = lines_to_html(data.get("interventions", ""))
    if g or iv:
        cards_html += (f'<div class="card card-green no-break">'
                       f'<h3>{esc(L["goals"])}</h3>{g}</div>'
                       f'<div class="card card-orange no-break">'
                       f'<h3>{esc(L["interv"])}</h3>{iv}</div>')
    if data.get("warnings"):
        cards_html += (f'<div class="card card-red card-full no-break">'
                       f'<h3>{esc(L["warning"])}</h3>'
                       f'{lines_to_html(data["warnings"])}</div>')
    if data.get("timeline"):
        cards_html += (f'<div class="card card-grey card-full no-break">'
                       f'<h3>{esc(L["timeline"])}</h3>'
                       f'{lines_to_html(data["timeline"])}</div>')

    # Body sections
    body_html = ""
    for heading, content, level in data.get("body_sections", []):
        tag = "h2" if level == 1 else "h3"
        body_html += (f'<div class="section no-break">'
                      f'<{tag}>{esc(heading)}</{tag}>'
                      f'{lines_to_html(content)}</div>')

    title    = esc(data.get("title", "Medical Treatment Plan"))
    subtitle = esc(data.get("subtitle", ""))
    sub_html = f'<div class="subtitle">{subtitle}</div>' if subtitle else ""

    return f"""<!DOCTYPE html>
<html lang="{"zh-CN" if is_zh else "en"}">
<head><meta charset="UTF-8"><title>{title}</title>
<style>{css}</style></head>
<body><div class="page">
<div class="header"><h1>{title}</h1>{sub_html}</div>
<div class="summary-grid">{cards_html}</div>
{body_html}
<div class="footer">{esc(L["footer"])}</div>
</div></body></html>"""


# ── Playwright route ──────────────────────────────────────────────────────

def _ensure_playwright() -> bool:
    """Check playwright + Chromium are available; install if needed."""
    try:
        from playwright.sync_api import sync_playwright  # noqa: F401
        return True
    except ImportError:
        print("Installing playwright...", file=sys.stderr)
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "playwright", "-q"],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            print("Error: failed to install playwright.", file=sys.stderr)
            return False
    r = subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        print("Error: failed to install Chromium for Playwright.", file=sys.stderr)
        print(r.stderr, file=sys.stderr)
        return False
    return True


def render_python(data: dict, out_path: Path) -> bool:
    """
    Render treatment plan to PDF via HTML + Playwright/Chromium.
    Produces publication-quality output with full CSS layout,
    native CJK font support, and professional medical document styling.
    Extensible: modify _build_html() CSS/HTML to customize appearance.

    Non-ASCII path handling: Playwright's Chromium subprocess cannot write
    to paths containing non-ASCII characters on Windows. When detected, the
    PDF is first written to an ASCII-safe temporary path, then renamed to
    the requested destination.
    """
    if not _ensure_playwright():
        return False

    from playwright.sync_api import sync_playwright
    import tempfile

    html_content = _build_html(data)
    tmp_html = Path(tempfile.mktemp(suffix=".html"))
    tmp_html.write_text(html_content, encoding="utf-8")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Playwright cannot write to non-ASCII paths on Windows.
    # Use a temporary ASCII path and rename afterwards if needed.
    needs_rename = False
    try:
        str(out_path).encode("ascii")
        write_path = out_path
    except UnicodeEncodeError:
        write_path = Path(tempfile.mktemp(suffix=".pdf"))
        needs_rename = True

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(tmp_html.as_uri(), wait_until="networkidle")
            page.pdf(
                path=str(write_path),
                format="A4",
                margin={"top": "0", "right": "0", "bottom": "0", "left": "0"},
                print_background=True,
            )
            browser.close()
        if needs_rename:
            import shutil
            shutil.move(str(write_path), str(out_path))
    except Exception as e:
        print(f"Error: Playwright PDF generation failed: {e}", file=sys.stderr)
        if needs_rename and write_path.exists():
            write_path.unlink(missing_ok=True)
        return False
    finally:
        tmp_html.unlink(missing_ok=True)

    return True

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Convert a filled treatment plan .tex to PDF",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Routes:
  latex   Compile with xelatex/pdflatex (best quality, requires LaTeX)
  python  Render with reportlab        (no LaTeX needed, cross-platform)
  auto    Auto-detect based on system

The active route is read from .pdf_route in the current directory.
Run setup.py to set the route interactively.
        """,
    )
    parser.add_argument("input", help="Filled plan.json (Python route) or .tex file (LaTeX route)")
    parser.add_argument("output", help="Output PDF path")
    parser.add_argument(
        "--route", choices=["latex", "python", "auto"], default=None,
        help="Override route (default: read from .pdf_route)"
    )
    parser.add_argument(
        "--lang", choices=["en", "zh", "auto"], default="auto",
        help="Language hint for font selection (default: auto-detect from content)"
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    out_path   = Path(args.output)

    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        return 1

    route = read_route(args.route)
    print(f"PDF route: {route}")

    if route == "latex":
        # LaTeX route always uses .tex file
        tex_path = input_path
        if tex_path.suffix.lower() != ".tex":
            print(f"Error: LaTeX route requires a .tex file, got: {tex_path.name}", file=sys.stderr)
            return 1
        print(f"Compiling with LaTeX: {tex_path.name} -> {out_path.name}")
        ok = compile_latex(tex_path, out_path)
    else:
        # Python route: prefer .json; fall back to .tex with warning
        if input_path.suffix.lower() == ".json":
            print(f"Rendering from JSON: {input_path.name} -> {out_path.name}")
            data = parse_json_plan(input_path)
        else:
            print(
                f"Warning: Python route works best with plan.json. "
                f"Falling back to .tex parsing (may have LaTeX markup residue).",
                file=sys.stderr,
            )
            print(f"Tip: Use generate_plan_json.py to create a clean plan.json instead.")
            print(f"Rendering from .tex: {input_path.name} -> {out_path.name}")
            data = parse_tex(input_path)
        if args.lang != "auto":
            data["language"] = args.lang
        ok = render_python(data, out_path)

    if ok:
        print(f"PDF saved: {out_path.resolve()}")
        print(f"MEDIA:{out_path.resolve()}")
        return 0

    print("PDF generation failed.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
