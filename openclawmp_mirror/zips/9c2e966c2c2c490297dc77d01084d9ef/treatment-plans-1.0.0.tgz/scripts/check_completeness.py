﻿#!/usr/bin/env python3
"""
Check Treatment Plan Completeness
==================================
Validates that all required sections are present in a treatment plan.

Supports two document formats:
  --format standard   (default) 3-4 page plans with standard section headers
  --format one-page             1-page compact plans (different section names)

Usage:
    python check_completeness.py <plan>.tex
    python check_completeness.py <plan>.tex --format one-page
    python check_completeness.py <plan>.tex --format standard
"""

import sys
import re
import argparse
from pathlib import Path
from typing import List, Tuple, Dict

# ── Section definitions per format ────────────────────────────────────────

# Standard 3-4 page format: checks for \section*{...} headings
STANDARD_SECTIONS: List[Tuple[str, str]] = [
    (r'\\section\*\{.*Patient Information',      'Patient Information (de-identified)'),
    (r'\\section\*\{.*Diagnosis.*Assessment',    'Diagnosis and Assessment'),
    (r'\\section\*\{.*Goals',                    'Treatment Goals (SMART format)'),
    (r'\\section\*\{.*Interventions',            'Interventions'),
    (r'\\section\*\{.*Timeline.*Schedule',       'Timeline and Schedule'),
    (r'\\section\*\{.*Monitoring',               'Monitoring Parameters'),
    (r'\\section\*\{.*Outcomes',                 'Expected Outcomes'),
    (r'\\section\*\{.*Follow[- ]?up',            'Follow-up Plan'),
    (r'\\section\*\{.*Education',                'Patient Education'),
    (r'\\section\*\{.*Risk.*Safety',             'Risk Mitigation and Safety'),
]

# One-page format: checks for \section*{...} headings used in one_page_treatment_plan.tex
ONE_PAGE_SECTIONS: List[Tuple[str, str]] = [
    (r'\\section\*\{.*TARGET PATIENT',           'Target Patient Population'),
    (r'\\section\*\{.*PRIMARY TREATMENT',        'Primary Treatment Regimen'),
    (r'\\section\*\{.*SUPPORTIVE CARE',          'Supportive Care'),
    (r'\\section\*\{.*MONITORING',               'Monitoring Requirements'),
    (r'\\section\*\{.*EXPECTED CLINICAL',        'Expected Clinical Benefit'),
    # rationale / evidence / risk are optional on one-page — warn only
]

# One-page optional sections (warn if absent, do not fail)
ONE_PAGE_OPTIONAL: List[Tuple[str, str]] = [
    (r'\\section\*\{.*RATIONALE',                'Rationale'),
    (r'\\section\*\{.*EVIDENCE',                 'Evidence Level'),
    (r'\\section\*\{.*CRITICAL DECISION',        'Critical Decision Points'),
    (r'\\section\*\{.*MOLECULAR.*RISK',          'Molecular Targets / Risk Factors'),
]

FORMAT_SECTIONS: Dict[str, List[Tuple[str, str]]] = {
    'standard': STANDARD_SECTIONS,
    'one-page': ONE_PAGE_SECTIONS,
}


# ── File I/O ───────────────────────────────────────────────────────────────

def read_file(filepath: Path) -> str:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        print(f"Error: File not found: {filepath}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        sys.exit(1)


# ── Section checks ─────────────────────────────────────────────────────────

def check_sections(
    content: str,
    sections: List[Tuple[str, str]],
) -> Tuple[List[bool], List[str]]:
    """Return (checklist, list_of_missing_descriptions)."""
    checklist, missing = [], []
    for pattern, description in sections:
        found = bool(re.search(pattern, content, re.IGNORECASE))
        checklist.append(found)
        if not found:
            missing.append(description)
    return checklist, missing


def check_smart_goals(content: str) -> Tuple[bool, List[str]]:
    criteria = {
        'Specific':   r'\bspecific\b',
        'Measurable': r'\bmeasurable\b',
        'Achievable': r'\bachievable\b',
        'Relevant':   r'\brelevant\b',
        'Time-bound': r'\btime[- ]?bound\b',
    }
    missing = [k for k, pat in criteria.items()
               if not re.search(pat, content, re.IGNORECASE)]
    return len(missing) == 0, missing


def check_hipaa_notice(content: str) -> bool:
    return bool(re.search(
        r'HIPAA|de-identif|protected health information|PHI',
        content, re.IGNORECASE))


def check_provider_signature(content: str) -> bool:
    return bool(re.search(
        r'\\section\*\{.*Signature|Provider Signature|Signature',
        content, re.IGNORECASE))


def check_placeholders_remaining(content: str) -> Tuple[int, List[str]]:
    placeholders = re.findall(r'\[([^\]]+)\]', content)
    filtered = [
        p for p in placeholders
        if not (p.startswith('\\') or p.isdigit()
                or 'cite' in p.lower() or 'ref' in p.lower())
    ]
    return len(filtered), filtered[:5]


# ── Display ────────────────────────────────────────────────────────────────

def display_results(
    filepath: Path,
    fmt: str,
    checklist: List[bool],
    sections: List[Tuple[str, str]],
    missing: List[str],
    optional_checklist: List[bool],
    optional_sections: List[Tuple[str, str]],
    smart_complete: bool,
    smart_missing: List[str],
    has_hipaa: bool,
    has_signature: bool,
    placeholder_count: int,
    placeholder_samples: List[str],
) -> int:
    total = len(sections)
    present = sum(checklist)
    pct = (present / total * 100) if total else 100

    print("\n" + "=" * 70)
    print(f"TREATMENT PLAN COMPLETENESS CHECK  [format: {fmt}]")
    print("=" * 70)
    print(f"\nFile     : {filepath}")
    print(f"Format   : {fmt}")
    print(f"File size: {filepath.stat().st_size:,} bytes")

    # Required sections
    print("\n" + "-" * 70)
    print(f"REQUIRED SECTIONS  ({present}/{total} present, {pct:.0f}%)")
    print("-" * 70)
    for (_, desc), found in zip(sections, checklist):
        print(f"  {'OK  ' if found else 'FAIL'} {desc}")

    # Optional sections (one-page only)
    if optional_sections:
        print("\n" + "-" * 70)
        print("OPTIONAL SECTIONS")
        print("-" * 70)
        for (_, desc), found in zip(optional_sections, optional_checklist):
            print(f"  {'OK  ' if found else 'WARN'} {desc}")

    # SMART goals (standard format only — one-page uses structured boxes)
    if fmt == 'standard':
        print("\n" + "-" * 70)
        print("SMART GOALS CHECK")
        print("-" * 70)
        if smart_complete:
            print("  OK   All SMART criteria found in document")
        else:
            print(f"  WARN Missing SMART criteria: {', '.join(smart_missing)}")
            print("       Goals should be Specific, Measurable, Achievable,")
            print("       Relevant, and Time-bound.")

    # HIPAA & signature
    print("\n" + "-" * 70)
    print("COMPLIANCE")
    print("-" * 70)
    print(f"  {'OK  ' if has_hipaa else 'WARN'} HIPAA / de-identification notice")
    if not has_hipaa:
        print("       Add HIPAA Safe Harbor de-identification guidance.")
    print(f"  {'OK  ' if has_signature else 'WARN'} Provider signature section")

    # Placeholders
    print("\n" + "-" * 70)
    print("CUSTOMIZATION STATUS")
    print("-" * 70)
    if placeholder_count == 0:
        print("  OK   No unfilled placeholders detected")
    else:
        print(f"  WARN {placeholder_count} placeholder(s) may still need filling:")
        for s in placeholder_samples:
            print(f"       [{s}]")
        print("       Replace all [bracketed placeholders] with patient-specific data.")

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)

    # Score: weight required sections 60%, compliance 20%, customization 20%
    compliance_score = (
        (1.0 if has_hipaa else 0.0) +
        (1.0 if has_signature else 0.0)
    ) / 2
    custom_score = 1.0 if placeholder_count == 0 else 0.5
    score = pct * 0.6 + compliance_score * 100 * 0.2 + custom_score * 100 * 0.2

    print(f"\n  Overall score: {score:.0f}%")
    if score >= 90:
        verdict, label = 0, "EXCELLENT — plan is comprehensive"
    elif score >= 75:
        verdict, label = 0, "GOOD — minor improvements recommended"
    elif score >= 60:
        verdict, label = 1, "FAIR — several sections need attention"
    else:
        verdict, label = 1, "INCOMPLETE — significant work required"
    print(f"  Status       : {label}")
    if missing:
        print(f"\n  Missing required sections:")
        for m in missing:
            print(f"    - {m}")
    print("\n" + "=" * 70 + "\n")

    return verdict


# ── Main ───────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(
        description='Check treatment plan completeness',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Format options:
  standard   3-4 page plans using \\section*{} headings (default)
  one-page   1-page compact plans (one_page_treatment_plan.tex)

Examples:
  python check_completeness.py my_plan.tex
  python check_completeness.py my_plan.tex --format one-page
  python check_completeness.py my_plan.tex --format standard

Exit codes:
  0   Required sections >= 75% complete
  1   Required sections < 75% complete
  2   File error
        """,
    )
    parser.add_argument('file', type=Path, help='Treatment plan .tex file to check')
    parser.add_argument(
        '--format', '-f',
        choices=['standard', 'one-page'],
        default='standard',
        dest='fmt',
        help='Document format (default: standard)',
    )
    args = parser.parse_args()

    if not args.file.exists():
        print(f"Error: File not found: {args.file}", file=sys.stderr)
        return 2

    content = read_file(args.file)
    sections = FORMAT_SECTIONS[args.fmt]

    checklist, missing = check_sections(content, sections)

    # Optional sections only for one-page
    opt_checklist: List[bool] = []
    opt_sections: List[Tuple[str, str]] = []
    if args.fmt == 'one-page':
        opt_checklist, _ = check_sections(content, ONE_PAGE_OPTIONAL)
        opt_sections = ONE_PAGE_OPTIONAL

    smart_complete, smart_missing = check_smart_goals(content)
    has_hipaa = check_hipaa_notice(content)
    has_sig = check_provider_signature(content)
    ph_count, ph_samples = check_placeholders_remaining(content)

    return display_results(
        args.file, args.fmt,
        checklist, sections, missing,
        opt_checklist, opt_sections,
        smart_complete, smart_missing,
        has_hipaa, has_sig,
        ph_count, ph_samples,
    )


if __name__ == '__main__':
    sys.exit(main())
