#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Treatment Plans - Plan JSON Template Generator
# Generates structured plan.json for Python/Playwright PDF route.
# Usage: python generate_plan_json.py --type <type> --output <file>.json
#        python generate_plan_json.py --list
# Exit codes: 0=success, 1=error

from __future__ import annotations
import argparse, json, sys
from datetime import datetime
from pathlib import Path


def _base_template(specialty_label: str) -> dict:
    return {
        "_meta": {
            "template_type": specialty_label,
            "generated": datetime.now().strftime("%Y-%m-%d"),
            "instructions": (
                "Fill every value starting with '['. "
                "Use the user's language throughout. "
                "Plain text only - no LaTeX markup."
            )
        },
        "title": "[Treatment Plan Title]",
        "subtitle": f"[{specialty_label}] - [Primary Diagnosis]",
        "date": datetime.now().strftime("%Y-%m"),
        "patient": {
            "id": "[PT-YYYY-NNN]",
            "age_range": "[e.g. 55-60 years]",
            "sex": "[Male / Female / Other]",
            "department": "[e.g. Internal Medicine, Outpatient]"
        },
        "diagnoses": [
            {"label": "[Primary]",   "icd10": "[e.g. E11.65]", "name": "[Primary diagnosis]"},
            {"label": "[Secondary]", "icd10": "[I10]",          "name": "[Comorbidity 1]"},
            {"label": "[Secondary]", "icd10": "[N18.31]",       "name": "[Comorbidity 2]"}
        ],
        "baseline": [
            {"parameter": "[e.g. HbA1c]", "value": "[e.g. 9.2%]",        "target": "[e.g. <7.5%]"},
            {"parameter": "[e.g. BP]",    "value": "[e.g. 152/96 mmHg]", "target": "[e.g. <130/80]"},
            {"parameter": "[e.g. BMI]",   "value": "[e.g. 31.2]",        "target": "[e.g. <30]"},
            {"parameter": "[e.g. eGFR]",  "value": "[e.g. 58]",          "target": "[e.g. >50, stable]"}
        ],
        "current_medications": [
            {"name": "[Medication]", "dose": "[Dose]",
             "frequency": "[Frequency]", "indication": "[Indication]"}
        ],
        "chief_complaint": "[Patient main complaint and personal goals]",
        "assessment": {
            "clinical_presentation": "[Current symptoms, functional limitations, QoL impact]",
            "risk_stratification": [
                "[Cardiovascular risk: ...]",
                "[Renal risk: ...]",
                "[Other risks: ...]"
            ],
            "drug_selection_rationale": [
                "[Why this drug; CKD/hepatic/renal considerations]"
            ]
        },
        "goals": {
            "short_term": [
                {
                    "goal":       "[Short-term goal 1]",
                    "specific":   "[What exactly will be done]",
                    "measurable": "[How it will be measured]",
                    "achievable": "[Why this is achievable]",
                    "relevant":   "[Why this matters to the patient]",
                    "time_bound": "[By when]"
                },
                {
                    "goal":       "[Short-term goal 2]",
                    "specific":   "[...]",
                    "measurable": "[...]",
                    "achievable": "[...]",
                    "relevant":   "[...]",
                    "time_bound": "[...]"
                }
            ],
            "long_term": [
                "[Long-term goal 1 - 6-12 months]",
                "[Long-term goal 2]",
                "[Long-term goal 3]"
            ],
            "patient_priorities": [
                "[What the patient most wants to achieve]",
                "[Secondary patient priority]"
            ]
        },
        "interventions": {
            "medications": [
                {
                    "name":         "[Medication name (new/continue/adjust)]",
                    "dose":         "[Dose]",
                    "frequency":    "[Frequency]",
                    "instructions": "[Instructions, titration plan, rationale, evidence]"
                }
            ],
            "medication_safety": [
                "[Safety point 1: monitoring, contraindications]",
                "[Safety point 2: drug interactions]",
                "[Safety point 3: renal/hepatic dose adjustments]"
            ],
            "lifestyle": {
                "diet":     ["[Dietary pattern]", "[Specific restrictions/targets]", "[Referral]"],
                "exercise": ["[Week 1-2 plan]", "[Progressive goal]", "[Final target]", "[Safety notes]"],
                "weight":   "[Weight management target and strategy]",
                "other":    "[Smoking, alcohol, sleep, stress as applicable]"
            },
            "referrals": [
                "[Specialty 1 + reason]",
                "[Specialty 2 + reason]"
            ],
            "investigations": [
                {"timepoint": "[2 weeks]",  "tests": "[K+, creatinine]",       "reason": "[Safety monitoring]"},
                {"timepoint": "[3 months]", "tests": "[HbA1c, CMP, lipids, UACR]","reason": "[Goal assessment]"},
                {"timepoint": "[6 months]", "tests": "[Repeat all]",            "reason": "[Maintenance review]"},
                {"timepoint": "[Annual]",   "tests": "[TFT, ECG, foot exam]",  "reason": "[Complication screening]"}
            ],
            "preventive_care": ["[Vaccine 1]", "[Vaccine 2]", "[Screening recommendation]"]
        },
        "timeline": [
            {"phase": "[Initiation]",  "period": "[Weeks 1-4]",   "focus": "[New meds, education, monitoring setup]"},
            {"phase": "[Adjustment]",  "period": "[Weeks 5-12]",  "focus": "[Dose titration, lifestyle reinforcement]"},
            {"phase": "[Assessment]",  "period": "[Month 3]",     "focus": "[Full labs, goal review, plan adjustment]"},
            {"phase": "[Maintenance]", "period": "[Months 4-12]", "focus": "[Sustain targets, 6-month reassessment]"}
        ],
        "followup": [
            {"timepoint": "[2 weeks]",  "format": "[Phone/telehealth]", "agenda": "[Medication tolerance, home BP, activity]"},
            {"timepoint": "[4 weeks]",  "format": "[Office visit]",     "agenda": "[Safety labs, BP adjustment, doses]"},
            {"timepoint": "[3 months]", "format": "[Office visit]",     "agenda": "[Full labs, comprehensive goal review]"},
            {"timepoint": "[6 months]", "format": "[Office visit]",     "agenda": "[Repeat labs, weight, referral check]"},
            {"timepoint": "[Annual]",   "format": "[Comprehensive]",    "agenda": "[Complication screen, preventive care]"}
        ],
        "monitoring": [
            {"parameter": "[HbA1c]",      "baseline": "[9.2%]",     "target": "[<7.5%]",        "frequency": "[q3m -> q6m once stable]"},
            {"parameter": "[Office BP]",  "baseline": "[152/96]",   "target": "[<130/80 mmHg]", "frequency": "[Every visit]"},
            {"parameter": "[Home BP]",    "baseline": "[-]",        "target": "[<130/80 mmHg]", "frequency": "[Daily AM log]"},
            {"parameter": "[Weight/BMI]", "baseline": "[BMI 31.2]", "target": "[Lose 4 kg]",    "frequency": "[Weekly home; each visit]"},
            {"parameter": "[eGFR]",       "baseline": "[58]",       "target": "[>50, stable]",  "frequency": "[q6 months]"},
            {"parameter": "[Serum K+]",   "baseline": "[-]",        "target": "[3.5-5.0 mmol/L]","frequency": "[2w post-ACEI; then q6m]"},
            {"parameter": "[UACR]",       "baseline": "[Unknown]",  "target": "[<30 mg/g]",     "frequency": "[q6 months (CKD)]"},
            {"parameter": "[LDL]",        "baseline": "[Unknown]",  "target": "[<100 mg/dL]",   "frequency": "[q6-12 months]"}
        ],
        "thresholds": {
            "emergency": [
                "[BP >180/110 with headache/vision change]",
                "[Glucose <2.8 mmol/L with altered consciousness]",
                "[Chest pain / dyspnoea / stroke symptoms]"
            ],
            "call_same_day": [
                "[BP >160/100 sustained]",
                "[Glucose >16.7 mmol/L]",
                "[Severe medication reaction]"
            ],
            "escalate": [
                "[HbA1c not reduced >=1pp at 3 months]",
                "[BP above goal after maximum dose]"
            ]
        },
        "expected_outcomes": [
            "[4-8 weeks: early response description]",
            "[3 months: expected lab improvements]",
            "[6 months: functional and weight goals]",
            "[Long-term: evidence-based risk reduction]"
        ],
        "patient_education": [
            "[Key point 1: disease understanding]",
            "[Key point 2: medication side effects to watch]",
            "[Key point 3: self-monitoring instructions]",
            "[Key point 4: exercise / lifestyle guidance]",
            "[Emergency contacts and when to call]"
        ],
        "risk_mitigation": [
            "[Renal protection measures]",
            "[Cardiovascular protection]",
            "[Hypoglycemia prevention]",
            "[Adherence support strategy]"
        ],
        "hipaa_notice": (
            "This document contains protected health information. "
            "De-identify per HIPAA Safe Harbor before sharing."
        )
    }


SPECIALTY_OVERRIDES: dict[str, dict] = {
    "general_medical":  {
        "title": "[Medical Treatment Plan]",
        "subtitle": "General Medicine / Chronic Disease - [Diagnosis]"
    },
    "rehabilitation": {
        "title": "[Rehabilitation Treatment Plan]",
        "subtitle": "Rehabilitation Therapy - [Condition / Functional Goal]"
    },
    "mental_health": {
        "title": "[Mental Health Treatment Plan]",
        "subtitle": "Psychiatric / Behavioral Health - [DSM-5 Diagnosis]"
    },
    "chronic_disease": {
        "title": "[Chronic Disease Management Plan]",
        "subtitle": "Multimorbidity / Long-Term Care - [Conditions]"
    },
    "perioperative": {
        "title": "[Perioperative Care Plan]",
        "subtitle": "Surgical Management - [Procedure]"
    },
    "pain_management": {
        "title": "[Pain Management Plan]",
        "subtitle": "Multimodal Pain Management - [Pain Type]"
    },
    "one_page": {
        "title": "[One-Page Treatment Plan]",
        "subtitle": "[Condition] - [Brief patient profile]",
        "_meta": {
            "template_type": "one_page",
            "note": "Keep to 1 page. Remove sections that do not change a clinical decision."
        }
    },
}

TEMPLATE_TYPES = list(SPECIALTY_OVERRIDES.keys())

DESCRIPTIONS = {
    "general_medical":  "General medicine / chronic disease (diabetes, hypertension, etc.)",
    "rehabilitation":   "PT/OT/SLP rehabilitation",
    "mental_health":    "Psychiatric and behavioral health",
    "chronic_disease":  "Complex multimorbidity / long-term care",
    "perioperative":    "Surgical / procedural management",
    "pain_management":  "Acute and chronic pain (multimodal)",
    "one_page":         "Compact single-page plan (preferred for simple cases)",
}


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate plan.json template for Python/Playwright PDF route",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python generate_plan_json.py --type general_medical --output diabetes_plan.json\n"
            "  python generate_plan_json.py --type one_page --output quick_plan.json\n"
            "  python generate_plan_json.py --list\n"
        )
    )
    parser.add_argument("--type", choices=TEMPLATE_TYPES)
    parser.add_argument("--output", "-o")
    parser.add_argument("--list", action="store_true")
    args = parser.parse_args()

    if args.list:
        print("\nAvailable template types:\n")
        for t, d in DESCRIPTIONS.items():
            print(f"  {t:<20}  {d}")
        print()
        return 0

    if not args.type:
        print("Error: --type is required. Use --list to see options.", file=sys.stderr)
        return 1

    out = Path(args.output) if args.output else Path(f"{args.type}_plan.json")
    tmpl = _deep_merge(_base_template(args.type), SPECIALTY_OVERRIDES.get(args.type, {}))

    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(tmpl, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(f"\n{'='*60}")
    print("PLAN JSON TEMPLATE GENERATED")
    print(f"{'='*60}")
    print(f"Type   : {args.type}")
    print(f"Output : {out.resolve()}")
    print(f"Size   : {out.stat().st_size:,} bytes")
    print("\nNEXT STEPS:")
    print("  1. Fill all values starting with '[' with patient data")
    print("  2. Use the user's language throughout (Chinese if user wrote in Chinese)")
    print("  3. Run: python generate_pdf.py <plan>.json <output>.pdf")
    print(f"{'='*60}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
