---
name: chrome-debug
description: Chrome远程调试端口管理技能，用于Playwright等浏览器自动化脚本连接
metadata: {"openclaw":{"requires":{"bins":["launchctl"]}}}
---

# Chrome Debug Skill

管理 Chrome 远程调试端口 (9222)，供 Playwright 等浏览器自动化脚本连接使用。

> ⚠️ **配套使用**: 本技能是 **chrome-shared-state** 的底层依赖！
> - **chrome-debug-portal**: 管理 Chrome 远程调试端口（启动/停止）
> - **browser-shared**: 复用已有登录状态进行自动化
> - 两者搭配使用：先启动调试端口 → 再复用登录状态

## 为什么需要这个技能

- 多个脚本依赖 Chrome 9222 端口（电影监控、代理流量等）
- 统一管理 Chrome 进程，避免重复启动
- 提供启动、停止、重启、状态检查功能

##  启动 Chrome 远程调试
核心命令

###```bash
chrome-debug start
```

### 检查状态
```bash
chrome-debug status
```

### 停止 Chrome
```bash
chrome-debug stop
```

### 重启 Chrome
```bash
chrome-debug restart
```

### 获取 CDP 地址
```bash
chrome-debug address
# 输出: http://127.0.0.1:9222
```

## 内部使用

其他脚本可通过以下方式连接：
```python
from playwright.sync_api import sync_playwright

browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
```

## 实现细节

- 使用 launchd 管理 Chrome 进程
- 配置文件: ~/Library/LaunchAgents/com.openclaw.chrome-debug.plist
- 用户数据目录: ~/.openclaw/chrome-debug-profile

## 故障排除

### 端口被占用
```bash
lsof -i :9222
```

### 查看日志
```bash
tail -f /tmp/openclaw-chrome.log
```
