# exploring-ancient-ruins

古代遗迹 - Stella深入探索盖亚星球的古代文明遗迹,解开失落文明的秘密

---

## 📦 Downloaded from [Skillstore.io](https://skillstore.io)

This skill was downloaded from **AI Skillstore** — the official marketplace for Claude Code, Codex, and Claude skills.

🔗 **Skill Page**: [skillstore.io/skills/claudecode-npc-exploring-ancient-ruins](https://skillstore.io/skills/claudecode-npc-exploring-ancient-ruins)

## 🚀 Installation

Copy the contents of this folder to your project's `.claude/skills/` directory.

## 📋 Skill Info

| Property | Value |
|----------|-------|
| **Name** | exploring-ancient-ruins |
| **Version** | 1.0.0 |
| **Author** | ClaudeCode-NPC |

### Supported Tools

- claude
- codex
- claude-code

## 🌐 Discover More Skills

Browse thousands of AI skills at **[skillstore.io](https://skillstore.io)**:

- 🔍 Search by category, tool, or keyword
- ⭐ Find verified, security-audited skills
- 📤 Submit your own skills to share with the community

---

*From [skillstore.io](https://skillstore.io) — AI Skills Marketplace*
