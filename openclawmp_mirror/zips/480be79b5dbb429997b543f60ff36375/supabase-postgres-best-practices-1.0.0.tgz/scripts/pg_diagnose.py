#!/usr/bin/env python3
"""
Postgres Diagnostic Collector

Collects performance metrics from Postgres/Supabase databases.
Outputs structured JSON for analysis by workflow scripts.

Usage:
    python pg_diagnose.py --connection-string "postgresql://..."
    python pg_diagnose.py --supabase-url "https://..." --supabase-key "..."

Extensible architecture: Register custom collectors for additional metrics.
"""

import argparse
import json
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional
from urllib.parse import urlparse

# Try to import psycopg2, fallback to pg8000
try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    DB_DRIVER = "psycopg2"
except ImportError:
    try:
        import pg8000
        DB_DRIVER = "pg8000"
    except ImportError:
        print("Error: Neither psycopg2 nor pg8000 is installed.")
        print("Install one: pip install psycopg2-binary  # or pip install pg8000")
        sys.exit(1)


@dataclass
class DiagnosticReport:
    """Container for all diagnostic results."""
    metadata: Dict[str, Any] = field(default_factory=dict)
    connections: Dict[str, Any] = field(default_factory=dict)
    queries: List[Dict[str, Any]] = field(default_factory=list)
    tables: List[Dict[str, Any]] = field(default_factory=list)
    indexes: List[Dict[str, Any]] = field(default_factory=list)
    rls_policies: List[Dict[str, Any]] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


class DatabaseConnection:
    """Manages database connection with driver abstraction."""

    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.conn = None
        self.driver = DB_DRIVER

    def connect(self):
        """Establish database connection."""
        if self.driver == "psycopg2":
            self.conn = psycopg2.connect(self.connection_string)
        else:
            # Parse connection string for pg8000
            parsed = urlparse(self.connection_string)
            self.conn = pg8000.connect(
                host=parsed.hostname,
                port=parsed.port or 5432,
                database=parsed.path.lstrip('/'),
                user=parsed.username,
                password=parsed.password
            )
        return self

    def execute(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute query and return results as list of dicts."""
        if self.driver == "psycopg2":
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query, params)
                return [dict(row) for row in cur.fetchall()]
        else:
            with self.conn.cursor() as cur:
                cur.execute(query, params)
                columns = [desc[0] for desc in cur.description]
                return [dict(zip(columns, row)) for row in cur.fetchall()]

    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class MetricCollector(ABC):
    """Base class for metric collectors."""

    name: str = "base"

    @abstractmethod
    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        """Collect metrics and return as dictionary."""
        pass

    def is_available(self, db: DatabaseConnection) -> bool:
        """Check if this collector can run (e.g., extension installed)."""
        return True


class ConnectionCollector(MetricCollector):
    """Collect connection metrics."""

    name = "connections"

    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        query = """
        SELECT
            count(*) as total_connections,
            count(*) FILTER (WHERE state = 'active') as active_connections,
            count(*) FILTER (WHERE state = 'idle') as idle_connections,
            count(*) FILTER (WHERE wait_event_type = 'Lock') as waiting_connections,
            (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') as max_connections,
            (SELECT count(*) FROM pg_stat_activity WHERE backend_type = 'client backend') as client_connections
        FROM pg_stat_activity
        """
        result = db.execute(query)[0]

        # Calculate utilization
        result['utilization_percent'] = round(
            (result['total_connections'] / result['max_connections'] * 100), 2
        ) if result['max_connections'] > 0 else 0

        # Add status assessment
        utilization = result['utilization_percent']
        if utilization > 90:
            result['status'] = 'CRITICAL'
            result['recommendation'] = 'Immediate action required: Implement connection pooling'
        elif utilization > 70:
            result['status'] = 'WARNING'
            result['recommendation'] = 'Monitor closely: Consider connection pooling'
        else:
            result['status'] = 'OK'
            result['recommendation'] = None

        return result


class QueryStatsCollector(MetricCollector):
    """Collect slow query statistics (requires pg_stat_statements)."""

    name = "queries"

    def is_available(self, db: DatabaseConnection) -> bool:
        try:
            result = db.execute(
                "SELECT 1 FROM pg_extension WHERE extname = 'pg_stat_statements'"
            )
            return len(result) > 0
        except:
            return False

    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        if not self.is_available(db):
            return {
                'available': False,
                'message': 'pg_stat_statements extension not installed',
                'slow_queries': []
            }

        query = """
        SELECT
            queryid,
            left(query, 200) as query_preview,
            mean_exec_time,
            calls,
            total_exec_time,
            rows,
            shared_blks_hit,
            shared_blks_read
        FROM pg_stat_statements
        WHERE query NOT LIKE '%pg_stat_statements%'
        ORDER BY mean_exec_time DESC
        LIMIT 10
        """

        slow_queries = db.execute(query)

        # Flag queries that need attention
        for q in slow_queries:
            if q['mean_exec_time'] > 1000:
                q['severity'] = 'CRITICAL'
            elif q['mean_exec_time'] > 100:
                q['severity'] = 'WARNING'
            else:
                q['severity'] = 'OK'

        return {
            'available': True,
            'slow_queries': slow_queries,
            'total_tracked': db.execute(
                "SELECT count(*) as cnt FROM pg_stat_statements"
            )[0]['cnt']
        }


class TableStatsCollector(MetricCollector):
    """Collect table size and scan statistics."""

    name = "tables"

    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        # Table sizes and scan stats
        query = """
        SELECT
            schemaname,
            relname as table_name,
            pg_size_pretty(pg_total_relation_size(relid)) as total_size,
            pg_total_relation_size(relid) as size_bytes,
            seq_scan,
            seq_tup_read,
            idx_scan,
            n_live_tup as estimated_rows,
            n_dead_tup as dead_rows,
            last_vacuum,
            last_autovacuum,
            last_analyze,
            last_autoanalyze
        FROM pg_stat_user_tables
        WHERE schemaname = 'public'
        ORDER BY pg_total_relation_size(relid) DESC
        LIMIT 20
        """

        tables = db.execute(query)

        # Analyze each table
        for table in tables:
            issues = []

            # Check for missing indexes (high seq scans on large tables)
            if table['seq_scan'] > 100 and table['estimated_rows'] > 10000:
                if not table['idx_scan'] or table['seq_scan'] > table['idx_scan']:
                    issues.append('Potential missing index: High sequential scans')

            # Check for vacuum needs
            if table['dead_rows'] and table['estimated_rows'] > 0:
                dead_ratio = table['dead_rows'] / table['estimated_rows']
                if dead_ratio > 0.1:
                    issues.append(f'Vacuum needed: {dead_ratio:.1%} dead rows')

            # Check for analyze needs
            if not table['last_analyze'] and not table['last_autoanalyze']:
                issues.append('Statistics outdated: Never analyzed')

            table['issues'] = issues
            table['needs_attention'] = len(issues) > 0

        return {
            'tables': tables,
            'total_tables': len(tables),
            'tables_needing_attention': sum(1 for t in tables if t['needs_attention'])
        }


class IndexStatsCollector(MetricCollector):
    """Collect index usage statistics."""

    name = "indexes"

    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        query = """
        SELECT
            schemaname,
            relname as table_name,
            indexrelname as index_name,
            pg_size_pretty(pg_relation_size(indexrelid)) as index_size,
            idx_scan,
            idx_tup_read,
            idx_tup_fetch
        FROM pg_stat_user_indexes
        WHERE schemaname = 'public'
        ORDER BY pg_relation_size(indexrelid) DESC
        LIMIT 50
        """

        indexes = db.execute(query)

        # Identify unused indexes
        unused_threshold = 50  # scans
        for idx in indexes:
            if idx['idx_scan'] < unused_threshold:
                idx['usage'] = 'LOW'
            else:
                idx['usage'] = 'ACTIVE'

        return {
            'indexes': indexes,
            'total_indexes': len(indexes),
            'unused_indexes': [i for i in indexes if i['usage'] == 'LOW']
        }


class RLSPolicyCollector(MetricCollector):
    """Collect RLS policy information."""

    name = "rls_policies"

    def collect(self, db: DatabaseConnection) -> Dict[str, Any]:
        # Get policies
        policy_query = """
        SELECT
            schemaname,
            tablename,
            policyname,
            permissive,
            roles::text,
            cmd,
            qual as using_expression,
            with_check
        FROM pg_policies
        WHERE schemaname = 'public'
        ORDER BY tablename, policyname
        """

        policies = db.execute(policy_query)

        # Get RLS enabled tables
        rls_query = """
        SELECT
            schemaname,
            tablename,
            rowsecurity as rls_enabled,
            forcerowsecurity as force_rls
        FROM pg_tables
        JOIN pg_class ON pg_class.relname = pg_tables.tablename
        JOIN pg_namespace ON pg_namespace.oid = pg_class.relnamespace
        WHERE schemaname = 'public'
        AND pg_class.relrowsecurity = true
        """

        rls_tables = db.execute(rls_query)

        # Analyze policies for performance issues
        for policy in policies:
            issues = []
            expression = policy.get('using_expression', '') or ''

            # Check for auth.uid() without caching
            if 'auth.uid()' in expression and '(select auth.uid())' not in expression:
                issues.append('Performance: auth.uid() should be wrapped in (select auth.uid())')

            # Check for complex subqueries
            if expression.count('select') > 1:
                issues.append('Performance: Consider using security definer function for complex checks')

            policy['issues'] = issues

        return {
            'policies': policies,
            'rls_enabled_tables': rls_tables,
            'total_policies': len(policies),
            'tables_with_rls': len(rls_tables)
        }


class DiagnosticEngine:
    """Main engine that runs all collectors and generates report."""

    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.collectors: List[MetricCollector] = []
        self.register_default_collectors()

    def register_default_collectors(self):
        """Register built-in collectors."""
        self.collectors = [
            ConnectionCollector(),
            QueryStatsCollector(),
            TableStatsCollector(),
            IndexStatsCollector(),
            RLSPolicyCollector(),
        ]

    def register_collector(self, collector: MetricCollector):
        """Register a custom collector."""
        self.collectors.append(collector)

    def run(self) -> DiagnosticReport:
        """Run all collectors and generate report."""
        report = DiagnosticReport()

        with DatabaseConnection(self.connection_string) as db:
            # Collect metadata
            report.metadata = self._collect_metadata(db)

            # Run each collector
            for collector in self.collectors:
                try:
                    if collector.is_available(db):
                        data = collector.collect(db)
                        setattr(report, collector.name, data)
                    else:
                        setattr(report, collector.name, {
                            'available': False,
                            'message': f'{collector.name} collector not available'
                        })
                except Exception as e:
                    setattr(report, collector.name, {
                        'available': False,
                        'error': str(e)
                    })

            # Generate recommendations
            report.recommendations = self._generate_recommendations(report)

        return report

    def _collect_metadata(self, db: DatabaseConnection) -> Dict[str, Any]:
        """Collect database metadata."""
        queries = {
            'version': "SELECT version()",
            'database_name': "SELECT current_database()",
            'database_size': "SELECT pg_size_pretty(pg_database_size(current_database()))",
        }

        metadata = {}
        for key, query in queries.items():
            try:
                result = db.execute(query)
                metadata[key] = result[0][list(result[0].keys())[0]] if result else None
            except:
                metadata[key] = None

        return metadata

    def _generate_recommendations(self, report: DiagnosticReport) -> List[str]:
        """Generate recommendations based on collected data."""
        recommendations = []

        # Connection recommendations
        conn = report.connections
        if conn.get('status') == 'CRITICAL':
            recommendations.append(
                "URGENT: Connection utilization >90%. Implement connection pooling immediately."
            )
        elif conn.get('status') == 'WARNING':
            recommendations.append(
                "WARNING: Connection utilization >70%. Consider connection pooling."
            )

        # Query recommendations
        queries = report.queries
        if queries.get('available') and queries.get('slow_queries'):
            critical_queries = [q for q in queries['slow_queries'] if q.get('severity') == 'CRITICAL']
            if critical_queries:
                recommendations.append(
                    f"Found {len(critical_queries)} queries with >1000ms avg execution time. "
                    "Run EXPLAIN ANALYZE and create indexes."
                )

        # Table recommendations
        tables = report.tables
        if tables.get('tables_needing_attention', 0) > 0:
            recommendations.append(
                f"Found {tables['tables_needing_attention']} tables with performance issues. "
                "Review table statistics for details."
            )

        # RLS recommendations
        rls = report.rls_policies
        if rls.get('policies'):
            policies_with_issues = [p for p in rls['policies'] if p.get('issues')]
            if policies_with_issues:
                recommendations.append(
                    f"Found {len(policies_with_issues)} RLS policies with performance issues. "
                    "Review security-rls-performance.md for optimization patterns."
                )

        return recommendations


def main():
    parser = argparse.ArgumentParser(
        description='Collect Postgres performance diagnostics'
    )
    parser.add_argument(
        '--connection-string', '-c',
        help='PostgreSQL connection string'
    )
    parser.add_argument(
        '--supabase-url',
        help='Supabase project URL'
    )
    parser.add_argument(
        '--supabase-key',
        help='Supabase service role key'
    )
    parser.add_argument(
        '--output', '-o',
        default='pg_diagnostic_report.json',
        help='Output file path (default: pg_diagnostic_report.json)'
    )
    parser.add_argument(
        '--format',
        choices=['json', 'summary'],
        default='json',
        help='Output format'
    )

    args = parser.parse_args()

    # Build connection string
    if args.supabase_url and args.supabase_key:
        # Construct connection string from Supabase credentials
        # Note: This is a simplified version; real implementation would use Supabase API
        print("Supabase direct connection not implemented. Use connection string.")
        sys.exit(1)
    elif not args.connection_string:
        print("Error: Provide --connection-string or both --supabase-url and --supabase-key")
        sys.exit(1)

    # Run diagnostics
    try:
        engine = DiagnosticEngine(args.connection_string)
        report = engine.run()

        if args.format == 'json':
            output = report.to_json()
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"Diagnostic report saved to: {args.output}")
        else:
            # Summary format
            print("=" * 60)
            print("POSTGRES DIAGNOSTIC SUMMARY")
            print("=" * 60)
            print(f"Database: {report.metadata.get('database_name', 'Unknown')}")
            print(f"Version: {report.metadata.get('version', 'Unknown')[:50]}...")
            print(f"Size: {report.metadata.get('database_size', 'Unknown')}")
            print()

            conn = report.connections
            print(f"Connections: {conn.get('total_connections', 'N/A')} / {conn.get('max_connections', 'N/A')} ({conn.get('utilization_percent', 'N/A')}%)")
            print(f"Status: {conn.get('status', 'Unknown')}")
            print()

            if report.recommendations:
                print("RECOMMENDATIONS:")
                for i, rec in enumerate(report.recommendations, 1):
                    print(f"  {i}. {rec}")
            else:
                print("No critical issues found.")

            print()
            print(f"Full report saved to: {args.output}")

    except Exception as e:
        print(f"Error running diagnostics: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
