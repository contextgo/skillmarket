---
title: Multi-Symptom Performance Optimization Workflow
impact: CRITICAL
description: Systematic workflow for complex Postgres performance issues with multiple symptoms (connections + slow queries + RLS). Follow gates sequentially - DO NOT SKIP.
---

# Workflow: Multi-Symptom Performance Issues

Use this workflow when user reports **multiple symptoms**:
- Connection errors ("Too many connections")
- Slow queries / timeouts
- RLS-related performance issues
- High CPU or memory usage

**⚠️ CRITICAL: This workflow uses GATES. You MUST complete each gate before proceeding.**

---

## Gate 1: Diagnostic Data Collection [MUST COMPLETE]

**Before giving ANY recommendations, you MUST collect diagnostic data.**

### Step 1.1: Ask User to Run Diagnostic Queries

Ask the user to execute these queries in their Supabase SQL Editor and provide results:

```sql
-- Query 1: Connection Status
SELECT
  count(*) as total_connections,
  count(*) FILTER (WHERE state = 'active') as active_connections,
  count(*) FILTER (WHERE state = 'idle') as idle_connections,
  (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') as max_connections
FROM pg_stat_activity;

-- Query 2: Slowest Queries (requires pg_stat_statements extension)
SELECT
  query,
  mean_exec_time,
  calls,
  total_exec_time
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 5;

-- Query 3: Table Sizes (identify large tables)
SELECT
  schemaname,
  relname as table_name,
  pg_size_pretty(pg_total_relation_size(relid)) as total_size,
  pg_total_relation_size(relid) as size_bytes
FROM pg_stat_user_tables
ORDER BY pg_total_relation_size(relid) DESC
LIMIT 10;

-- Query 4: Missing Indexes (sequential scans on large tables)
SELECT
  schemaname,
  relname as table_name,
  seq_scan,
  seq_tup_read,
  idx_scan,
  n_live_tup as estimated_rows
FROM pg_stat_user_tables
WHERE seq_scan > 0
ORDER BY seq_tup_read DESC
LIMIT 10;

-- Query 5: Current RLS Policies
SELECT
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual as using_expression
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename;
```

### Step 1.2: Parse Diagnostic Results

**Checklist - Mark each as you collect:**

- [ ] Connection counts obtained (total/active/idle/max)
- [ ] Top 5 slow queries identified
- [ ] Table sizes known (especially >100MB tables)
- [ ] Tables with high seq_scan identified
- [ ] Current RLS policies documented

**If user cannot run pg_stat_statements queries**, ask:
- "What specific queries are slow? Please share the SQL"
- "What is the approximate row count of your main tables?"

---

## Gate 2: Root Cause Analysis [MUST COMPLETE]

**Based on diagnostic data, identify which issues exist:**

### Decision Matrix

| Symptom | Threshold | Your Data | Issue Present? |
|---------|-----------|-----------|----------------|
| High Connections | total > max * 0.8 | ___ / ___ | [ ] Yes [ ] No |
| Slow Queries | mean_exec_time > 100ms | ___ ms | [ ] Yes [ ] No |
| Large Tables | size > 100MB | ___ | [ ] Yes [ ] No |
| Missing Indexes | seq_scan > 1000 AND n_live_tup > 10000 | ___ | [ ] Yes [ ] No |
| RLS Performance | RLS exists on large tables | ___ | [ ] Yes [ ] No |

### Priority Order (MUST FOLLOW THIS SEQUENCE)

**CRITICAL Issues (Fix First):**
1. **Connection Issues** - System stability risk
2. **RLS Performance** - Security + performance impact
3. **Missing Indexes** - Query performance

**HIGH/MEDIUM Issues (Fix After Critical):**
4. Schema design improvements
5. Query pattern optimizations (N+1)

**⚠️ IMPORTANT: Even if multiple issues exist, fix in priority order above.**

---

## Gate 3A: Connection Optimization (CRITICAL - First Priority)

**Trigger:** total_connections > max_connections * 0.8

### Step 3A.1: Immediate Assessment

Ask user:
1. "What Supabase plan are you on?" (Free/Pro/Team)
2. "Are you using the connection pooler?"
3. "Is your application serverless (Vercel/Netlify Functions)?"

### Step 3A.2: Supabase-Specific Configuration

**Connection Limits by Plan:**
- Free Plan: 60 direct connections, use pooler for more
- Pro Plan: 200 direct connections
- Team Plan: 500 direct connections

**Immediate Actions:**

```sql
-- Check current connection string format
-- If using postgres://...:5432/postgres → Direct connection (limited)
-- If using postgres://...:6543/postgres → Pooler (recommended)
```

**Recommendation Template:**

> **Connection Issue Detected:** You have [X] active connections out of [Y] max.
>
> **Immediate Fix:**
> 1. Switch to connection pooler port (6543 instead of 5432)
> 2. Use Transaction mode for serverless deployments
> 3. Set appropriate pool size: `(CPU cores * 2) + effective_spindle_count`
>
> **Connection String:**
> ```
> postgres://[user]:[pass]@[host]:6543/postgres?pgbouncer=true
> ```

### Step 3A.3: Connection Pooling Setup

Read `references/conn-pooling.md` for detailed configuration.

**Key Points for Supabase:**
- Port 6543 = PgBouncer (connection pooler)
- Transaction mode = Best for most apps
- Session mode = Only if using prepared statements or temp tables

### Step 3A.4: Validation

After implementing connection pooling:

```sql
-- Verify connections stabilize
SELECT count(*) FROM pg_stat_activity;  -- Should be < 20
```

**[ ]** Connection count stabilized before proceeding to Gate 3B.

---

## Gate 3B: RLS Optimization (CRITICAL - Second Priority)

**Trigger:** RLS policies exist AND slow queries involve RLS tables

### Step 3B.1: Analyze Current RLS Policies

Review the policies from Gate 1 Query 5. Look for these anti-patterns:

**❌ Anti-Pattern 1: auth.uid() in subquery without caching**
```sql
-- BAD: auth.uid() called for every row
using (auth.uid() in (select user_id from team_members where team_id = projects.team_id))
```

**❌ Anti-Pattern 2: Complex joins in policy**
```sql
-- BAD: Join in policy expression
using (exists (select 1 from teams t join team_members tm on ...))
```

**❌ Anti-Pattern 3: No indexes on RLS columns**
```sql
-- If policy uses user_id column, but no index exists
```

### Step 3B.2: Optimize RLS Policies

**Pattern 1: Cache auth.uid() with SELECT wrapper**

```sql
-- BEFORE (slow):
create policy projects_policy on projects
  using (auth.uid() in (
    select user_id from team_members
    where team_id = projects.team_id
  ));

-- AFTER (fast):
create policy projects_policy on projects
  using ((select auth.uid()) in (
    select user_id from team_members
    where team_id = projects.team_id
  ));
```

**Pattern 2: Use Security Definer Functions for Complex Checks**

```sql
-- Create helper function
create or replace function get_user_team_ids()
returns bigint[]
language sql
security definer
set search_path = ''
as $$
  select array_agg(team_id)
  from public.team_members
  where user_id = (select auth.uid());
$$;

-- Use in policy
create policy projects_policy on projects
  using (team_id = any((select get_user_team_ids())));
```

### Step 3B.3: Create Indexes on RLS Columns

**⚠️ WARNING: Creating indexes on large tables (>100k rows) will lock the table.**

**For small tables (<100k rows):**
```sql
-- Safe to run immediately
create index idx_team_members_user_id on team_members(user_id);
create index idx_team_members_team_id on team_members(team_id);
create index idx_projects_team_id on projects(team_id);
```

**For large tables (>100k rows):**
```sql
-- Use CONCURRENTLY to avoid locking (takes longer but doesn't block)
create index concurrently idx_projects_team_id on projects(team_id);
```

**Schedule for low-traffic period:**
- Create index during maintenance window
- Monitor with: `SELECT * FROM pg_stat_progress_create_index;`

### Step 3B.4: Validation

```sql
-- Compare query time with/without RLS
set row_security = off;
explain analyze select * from projects where team_id = 1;  -- Without RLS
set row_security = on;
explain analyze select * from projects where team_id = 1;   -- With RLS
```

**[ ]** RLS overhead reduced (< 20% slower than without RLS).

---

## Gate 3C: Query Optimization (CRITICAL - Third Priority)

**Trigger:** Slow queries identified in Gate 1

### Step 3C.1: Analyze Slow Queries

For each slow query from Gate 1:

```sql
-- Get execution plan
explain (analyze, buffers, format text)
[YOUR_SLOW_QUERY_HERE];
```

**Look for these patterns:**

| Pattern | Meaning | Action |
|---------|---------|--------|
| `Seq Scan` on large table | Missing index | Create index |
| `Rows Removed by Filter: [high number]` | Poor selectivity | Add composite index |
| `Buffers: shared read=[high]` | Data not cached | Consider more RAM or optimize query |
| `Sort Method: external merge` | work_mem too low | Increase work_mem or optimize |

### Step 3C.2: Create Missing Indexes

**Basic Index:**
```sql
create index idx_table_column on table(column);
```

**Composite Index (for multi-column WHERE):**
```sql
-- Order matters: equality filters first, then range
create index idx_orders_user_status on orders(user_id, status);
```

**Covering Index (Include columns):**
```sql
-- Include frequently accessed columns to avoid table lookups
create index idx_orders_user_covering on orders(user_id) include (status, total);
```

### Step 3C.3: Check for N+1 Queries

**Symptom:** Multiple similar queries, one per item.

**Solution - Batch with JOIN or ANY:**
```sql
-- Instead of: SELECT * FROM tasks WHERE project_id = 1; (x100)
-- Use:
select * from tasks where project_id = any(array[1,2,3,...]);

-- Or use JOIN:
select p.*, count(t.id) as task_count
from projects p
left join tasks t on t.project_id = p.id
group by p.id;
```

Read `references/data-n-plus-one.md` for more patterns.

### Step 3C.4: Validation

```sql
-- Re-run EXPLAIN ANALYZE
-- Should show: Index Scan instead of Seq Scan
-- Execution time should be < 100ms
```

**[ ]** All slow queries now use Index Scan and execute < 100ms.

---

## Gate 4: Validation & Monitoring [MUST COMPLETE]

### Step 4.1: Re-run Diagnostic Queries

Execute Gate 1 queries again and compare:

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Total Connections | ___ | ___ | ___% |
| Slow Query Time | ___ms | ___ms | ___% |
| Sequential Scans | ___ | ___ | ___ |

### Step 4.2: Load Testing

Ask user to test with production-like load:
- Simulate [X] concurrent users
- Monitor connection count
- Check query response times

### Step 4.3: 24-48 Hour Monitoring

```sql
-- Set up monitoring queries to run periodically
SELECT
  now() as check_time,
  count(*) as connections,
  count(*) FILTER (WHERE state = 'active') as active
FROM pg_stat_activity;
```

### Step 4.4: Update Statistics

```sql
-- After creating indexes, update statistics
analyze projects;
analyze team_members;
analyze tasks;
```

---

## Completion Checklist

**Before finishing, confirm:**

- [ ] Gate 1: Diagnostic data collected
- [ ] Gate 2: Root causes identified
- [ ] Gate 3A: Connection issues resolved (if present)
- [ ] Gate 3B: RLS optimized (if present)
- [ ] Gate 3C: Query performance improved (if needed)
- [ ] Gate 4: Validation complete, metrics improved
- [ ] User tested and confirmed improvement

---

## References

- `references/conn-limits.md` - Connection limits
- `references/conn-pooling.md` - PgBouncer configuration
- `references/security-rls-performance.md` - RLS optimization
- `references/query-missing-indexes.md` - Index creation
- `references/data-n-plus-one.md` - N+1 query elimination
- `references/monitor-explain-analyze.md` - Query analysis
