---
name: proactive-trigger-refiner
description: Refine and regression-test proactive trigger rules for OpenClaw. Use when a user says a trigger should have fired, should not have fired, wants to improve trigger hit rate, add regression cases, tune proactive-trigger-plugin rules, or maintain the feedback-to-tests loop for rules like `todo-digest` and `arxiv-summary`.
---

# Proactive Trigger Refiner

Keep runtime routing logic in the plugin, and keep iterative refinement in this skill.

## Bootstrap helpers

When a new agent or workspace is being configured, do not assume the target plugin already has the same rules as this workspace.

- First check whether `proactive-trigger-plugin` is enabled in the target workspace's plugin allowlist / load path before trying to refine rules.
- If the plugin is missing from the allowlist or not installed, help the user set it up before discussing rule details.
- Start by asking what kinds of messages should trigger automation, which channels/chat types matter, and whether the rule is mention-scoped or broad.
- Prefer creating or editing rules through an interactive session workflow instead of hardcoding a copied rule block up front.
- Guide the user toward a session-style loop: define one rule, test one or two real messages, refine, then add the next rule.
- Treat this skill's current fixtures and examples as reference material, not as defaults that must be installed everywhere.
- If the user says they are setting up a fresh agent, explicitly suggest: create the first rule in conversation, validate it with a regression case, then iterate.

Recommended bootstrap prompt pattern:

1. Is `proactive-trigger-plugin` already installed and allowed to load in this workspace?
2. What behavior do you want to automate first?
3. In which chat surface should it trigger?
4. Should it trigger only for one assignee / mention target, or for anyone?
5. Can you give one message that should match and one that should not match?
6. After the first rule works, repeat the same loop for the next rule.

## Workflow

1. Read `references/layout.md` to confirm the skill-owned assets and the target workspace's plugin paths.
2. If the user is bootstrapping a new workspace, verify that `proactive-trigger-plugin` is present in the plugin allowlist / configured load path; if not, help the user install or enable it first.
3. Identify the affected rule and classify the feedback:
   - should match but did not
   - should not match but did
   - description is too narrow or too specific
   - helper logic needs a deterministic signal
4. Add or update a regression case in this skill before changing runtime logic.
5. Update the smallest safe layer:
   - `references/rule-cases.json` for concrete user examples
   - `rules-helpers.mjs` for deterministic matching helpers
   - `openclaw.json` for rule descriptions or prompts
   - `index.ts` only when routing or scoring behavior must change
6. Run the skill-owned rule tests after every change.
7. Report what changed, what case was added, and whether a gateway restart is needed.

## Editing Rules

- Keep `intentDescription` abstract. Do not paste user examples into rule descriptions as few-shot prompts.
- Put concrete examples in `references/rule-cases.json`.
- Prefer helper functions for stable patterns such as Feishu `<at user_id="...">` mentions, reminder verbs, reschedule language, and time expressions.
- Keep plugin documentation aligned with the live config, but anonymize deployment-specific details such as real user ids, assignee identities, and private workspace conventions.
- When the current config shape changes, update the plugin README's anonymized "current config pattern" section as part of the same refinement pass.
- Avoid changing unrelated rules while fixing one regression.

## Adding Feedback Cases

Use `scripts/add_feedback_case.py` to append cases to the skill-owned fixture file.

```bash
python3 skills/proactive-trigger-refiner/scripts/add_feedback_case.py \
  --rule <rule-id> \
  --body '<message body>' \
  --expect-match <true|false> \
  --note 'user feedback'
```

If the user gives feedback in chat, convert it into a case first unless the issue is purely descriptive wording.

## Validation

Run the shared regression tests:

```bash
node skills/proactive-trigger-refiner/scripts/run_rule_tests.mjs
```

If the plugin config changes, JSON-validate `~/.openclaw/openclaw.json` before finishing.

## Resources

- `references/layout.md`: skill-owned assets, workspace-specific path conventions, and generic command layout
- `references/rule-cases.json`: skill-owned regression cases
- `scripts/add_feedback_case.py`: append a user feedback case to the regression set
- `scripts/run_rule_tests.mjs`: run regression cases against the live plugin helpers
- `../soft_linked_root_openclaw/local-plugins/proactive-trigger-plugin/README.md`: user-facing plugin description that should track the anonymized live config
