# Proactive Trigger Layout

## Runtime plugin

- Config: `~/.openclaw/openclaw.json`
- Plugin code: `~/.openclaw/local-plugins/proactive-trigger-plugin/index.ts`
- Rule helpers: `~/.openclaw/local-plugins/proactive-trigger-plugin/rules-helpers.mjs`
- User-facing docs: `soft_linked_root_openclaw/local-plugins/proactive-trigger-plugin/README.md`

## Skill-owned assets

These files belong to this skill and can be reused in other workspaces:

- Cases: `skills/proactive-trigger-refiner/references/rule-cases.json`
- Test runner: `skills/proactive-trigger-refiner/scripts/run_rule_tests.mjs`
- Case appender: `skills/proactive-trigger-refiner/scripts/add_feedback_case.py`

## Workspace-specific live config

Treat the live rules below as examples from this workspace, not as universal defaults for every installation.
Read the target workspace's plugin config before assuming the same rule set exists.

- Example pattern: a shared-link summary rule that excludes Feishu/Lark docs
- Example pattern: a mention-scoped todo digest rule for one configured assignee

## Fast commands

```bash
node skills/proactive-trigger-refiner/scripts/run_rule_tests.mjs
python3 skills/proactive-trigger-refiner/scripts/add_feedback_case.py \
  --rule <rule-id> \
  --body '<message body>' \
  --expect-match <true|false> \
  --note 'user feedback'
```

## Documentation rule

- Keep the plugin README synchronized with the live config shape.
- Anonymize deployment-specific details when documenting current rules.
- Put concrete regression phrases in the skill fixture, not in the plugin README.
