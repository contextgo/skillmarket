#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Append a proactive trigger feedback case to the shared rule fixture file."
    )
    default_cases = (
        Path.home()
        / "workspace"
        / "my_openclaw"
        / "workspace"
        / "skills"
        / "proactive-trigger-refiner"
        / "references"
        / "rule-cases.json"
    )
    parser.add_argument("--cases", default=str(default_cases), help="Path to rule-cases.json")
    parser.add_argument("--rule", required=True, help="Rule id, e.g. todo-digest")
    parser.add_argument("--body", required=True, help="Raw message body to record")
    parser.add_argument("--expect-match", required=True, choices=["true", "false"])
    parser.add_argument("--target-user-id", default="ou_f3322cc37ac7293229bf69c17b61b105")
    parser.add_argument("--note", default="feedback case")
    parser.add_argument("--id")
    args = parser.parse_args()

    path = Path(args.cases)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload.get("cases"), list):
        raise SystemExit("Invalid fixture file: missing cases array")

    next_id = args.id or f"{args.rule}-{len(payload['cases']) + 1}"
    payload["cases"].append(
        {
            "id": next_id,
            "ruleId": args.rule,
            "body": args.body,
            "targetUserId": args.target_user_id,
            "expectMatch": args.expect_match == "true",
            "note": args.note,
        }
    )
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(next_id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
