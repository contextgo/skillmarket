import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const skillDir = path.dirname(__dirname);
const casesPath = path.join(skillDir, "references", "rule-cases.json");
const pluginHelpersPath = path.join(
  process.env.HOME ?? "",
  ".openclaw",
  "local-plugins",
  "proactive-trigger-plugin",
  "rules-helpers.mjs",
);

const { hasLinkSummarySignal, hasTodoDigestSignal } = await import(pathToFileURL(pluginHelpersPath).href);
const fixture = JSON.parse(fs.readFileSync(casesPath, "utf8"));

const evaluators = {
  "todo-digest": (testCase) => hasTodoDigestSignal(testCase.body, testCase.targetUserId),
  "arxiv-summary": (testCase) => hasLinkSummarySignal(testCase.body),
};

for (const testCase of fixture.cases) {
  const evaluate = evaluators[testCase.ruleId];
  if (!evaluate) {
    continue;
  }

  test(`${testCase.ruleId} :: ${testCase.id}`, () => {
    const actual = evaluate(testCase);
    assert.equal(actual, testCase.expectMatch, testCase.note);
  });
}
