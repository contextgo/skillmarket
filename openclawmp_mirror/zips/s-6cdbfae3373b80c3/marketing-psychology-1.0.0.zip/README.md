# Claude Code 营销技能

专注于营销任务的 AI 技能集合。为希望 Claude Code（或类似的 AI 编程助手）帮助进行转化优化、文案撰写、SEO、分析和增长工程的技术营销人员和创始人而构建。

由 [Corey Haines](https://corey.co?ref=marketingskills) 构建。需要实际帮助？查看 [Conversion Factory](https://conversionfactory.co?ref=marketingskills) — Corey 的转化优化、落地页和增长策略机构。想了解更多营销知识？订阅 [Swipe Files](https://swipefiles.com?ref=marketingskills)。

刚接触终端和编程代理？查看配套指南 [Coding for Marketers](https://codingformarketers.com?ref=marketingskills)。

**欢迎贡献！** 找到了改进技能的方法或有新技能要添加？[提交 PR](#contributing)。

## 什么是技能？

技能是 Markdown 文件，为 AI 代理提供特定任务的专业知识和工作流程。当您将这些添加到项目中时，Claude Code 可以识别您何时在进行营销任务，并应用适当的框架和最佳实践。

## 可用技能

<!-- SKILLS:START -->
| Skill | Description |
|-------|-------------|
| [ab-test-setup](skills/ab-test-setup/) | 当用户想要计划、设计或实施A/B测试或实验时使用。当用户提到"A/B..."时也使用。|
| [ad-creative](skills/ad-creative/) | 当用户想要生成、迭代或扩展广告创意时使用——包括标题、描述、主要文本或完整广告...|
| [ai-seo](skills/ai-seo/) | 当用户想要优化内容以适应AI搜索引擎，被LLM引用，或出现在AI生成的答案中时使用。|
| [analytics-tracking](skills/analytics-tracking/) | 当用户想要设置、改进或审核分析跟踪和测量时使用。当用户提到...时也使用。|
| [churn-prevention](skills/churn-prevention/) | 当用户想要减少流失率、构建取消流程、设置挽留优惠、恢复失败付款或...时使用。|
| [cold-email](skills/cold-email/) | 撰写能获得回复的B2B冷邮件和跟进序列。当用户想要撰写cold outreach邮件时使用...|
| [competitor-alternatives](skills/competitor-alternatives/) | 当用户想要为SEO和销售支持创建竞争对手比较或替代页面时使用。当...时也使用。|
| [content-strategy](skills/content-strategy/) | 当用户想要规划内容策略、决定创建什么内容或确定涵盖哪些主题时使用。当...时也使用。|
| [copy-editing](skills/copy-editing/) | 当用户想要编辑、审阅或改进现有的营销文案时使用。当用户提到"编辑这个..."时也使用。|
| [copywriting](skills/copywriting/) | 当用户想要为任何页面撰写、重写或改进营销文案时使用——包括首页、落地页...|
| [email-sequence](skills/email-sequence/) | 当用户想要创建或优化电子邮件序列、滴灌活动、自动化邮件流程或生命周期邮件...时使用。|
| [form-cro](skills/form-cro/) | 当用户想要优化任何非注册/登录的表单时使用——包括线索捕获表单、联系表单...|
| [free-tool-strategy](skills/free-tool-strategy/) | 当用户想要为营销目的计划、评估或构建免费工具时使用——包括线索生成、SEO价值或...|
| [launch-strategy](skills/launch-strategy/) | 当用户想要规划产品发布、功能公告或发布策略时使用。当用户...时也使用。|
| [marketing-ideas](skills/marketing-ideas/) | 当用户需要为其SaaS或软件产品获取营销创意、灵感或策略时使用。当...时也使用。|
| [marketing-psychology](skills/marketing-psychology/) | 当用户想要将心理学原理、心智模型或行为科学应用于营销时使用。当...时也使用。|
| [onboarding-cro](skills/onboarding-cro/) | 当用户想要优化注册后的引导、用户激活、首次运行体验或价值实现时间时使用。当...时也使用。|
| [page-cro](skills/page-cro/) | 当用户想要优化、改进或增加任何营销页面的转化率时使用——包括首页、落地页...|
| [paid-ads](skills/paid-ads/) | 当用户需要关于Google Ads、Meta (Facebook/Instagram)、LinkedIn、Twitter/X等平台的付费广告活动帮助时使用。|
| [paywall-upgrade-cro](skills/paywall-upgrade-cro/) | 当用户想要创建或优化应用内付费墙、升级界面、销售模态框或功能门时使用。当...时也使用。|
| [popup-cro](skills/popup-cro/) | 当用户想要创建或优化用于转化的弹出窗口、模态框、覆盖层、滑入式或横幅时使用。当...时也使用。|
| [pricing-strategy](skills/pricing-strategy/) | 当用户需要关于定价决策、包装或货币化策略的帮助时使用。当用户提到...时也使用。|
| [product-marketing-context](skills/product-marketing-context/) | 当用户想要创建或更新其产品营销背景文档时使用。当用户提到...时也使用。|
| [programmatic-seo](skills/programmatic-seo/) | 当用户想要使用模板和数据大规模创建SEO驱动的页面时使用。当用户提到...时也使用。|
| [referral-program](skills/referral-program/) | 当用户想要创建、优化或分析推荐计划、联盟计划或口碑策略时使用。|
| [schema-markup](skills/schema-markup/) | 当用户想要在其网站上添加、修复或优化schema标记和结构化数据时使用。当用户...时也使用。|
| [seo-audit](skills/seo-audit/) | 当用户想要审核、审查或诊断其网站上的SEO问题时使用。当用户提到"SEO..."时也使用。|
| [signup-flow-cro](skills/signup-flow-cro/) | 当用户想要优化注册、注册、账户创建或试用激活流程时使用。当...时也使用。|
| [social-content](skills/social-content/) | 当用户需要帮助创建、安排或优化LinkedIn、Twitter/X、Instagram等平台的社会媒体内容时使用。|
<!-- SKILLS:END -->

## 安装

### 选项 1：CLI 安装（推荐）

使用 [npx skills](https://github.com/vercel-labs/skills) 直接安装技能：

```bash
# 安装所有技能
npx skills add coreyhaines31/marketingskills

# 安装特定技能
npx skills add coreyhaines31/marketingskills --skill page-cro copywriting

# 列出可用技能
npx skills add coreyhaines31/marketingskills --list
```

这会自动安装到您的 `.claude/skills/` 目录中。

### 选项 2：Claude Code 插件

通过 Claude Code 的内置插件系统安装：

```bash
# 添加市场
/plugin marketplace add coreyhaines31/marketingskills

# 安装所有营销技能
/plugin install marketing-skills
```

### 选项 3：克隆并复制

克隆整个仓库并复制技能文件夹：

```bash
git clone https://github.com/coreyhaines31/marketingskills.git
cp -r marketingskills/skills/* .claude/skills/
```

### 选项 4：Git 子模块

作为子模块添加以便轻松更新：

```bash
git submodule add https://github.com/coreyhaines31/marketingskills.git .claude/marketingskills
```

然后从 `.claude/marketingskills/skills/` 引用技能。

### 选项 5：分叉并自定义

1. 分叉此仓库
2. 根据您的特定需求自定义技能
3. 将您的分叉克隆到您的项目中

### 选项 6：SkillKit（多代理）

使用 [SkillKit](https://github.com/rohitg00/skillkit) 在多个 AI 代理（Claude Code、Cursor、Copilot 等）中安装技能：

```bash
# 安装所有技能
npx skillkit install coreyhaines31/marketingskills

# 安装特定技能
npx skillkit install coreyhaines31/marketingskills --skill page-cro copywriting

# 列出可用技能
npx skillkit install coreyhaines31/marketingskills --list
```

## 使用方法

安装后，只需要求 Claude Code 帮助处理营销任务：

```
"Help me optimize this landing page for conversions"
→ 使用 page-cro 技能

"Write homepage copy for my SaaS"
→ 使用 copywriting 技能

"Set up GA4 tracking for signups"
→ 使用 analytics-tracking 技能

"Create a 5-email welcome sequence"
→ 使用 email-sequence 技能
```

您也可以直接调用技能：

```
/page-cro
/email-sequence
/seo-audit
```

## 技能分类

### 转化优化
- `page-cro` - 任何营销页面
- `signup-flow-cro` - 注册流程
- `onboarding-cro` - 注册后激活
- `form-cro` - 线索获取表单
- `popup-cro` - 模态框和覆盖层
- `paywall-upgrade-cro` - 应用内升级时刻

### 内容与文案
- `copywriting` - 营销页面文案
- `copy-editing` - 编辑和润色现有文案
- `cold-email` - B2B 冷 outreach 邮件和序列
- `email-sequence` - 自动化邮件流程
- `social-content` - 社交媒体内容

### SEO 与发现
- `seo-audit` - 技术和页面 SEO
- `ai-seo` - AI 搜索优化（AEO、GEO、LLMO）
- `programmatic-seo` - 规模化页面生成
- `competitor-alternatives` - 比较和替代页面
- `schema-markup` - 结构化数据

### 付费与分发
- `paid-ads` - Google, Meta, LinkedIn 广告活动
- `ad-creative` - 批量广告创意生成和迭代
- `social-content` - 社交媒体排期和策略

### 测量与测试
- `analytics-tracking` - 事件跟踪设置
- `ab-test-setup` - 实验设计

### 留存
- `churn-prevention` - 取消流程、优惠保留、催收、付款恢复

### 增长工程
- `free-tool-strategy` - 营销工具和计算器
- `referral-program` - 推荐和联盟计划

### 策略与变现
- `marketing-ideas` - 140个SaaS营销创意
- `marketing-psychology` - 心理模型和心理学
- `launch-strategy` - 产品发布和公告
- `pricing-strategy` - 定价、包装和变现

## 贡献

找到了改进技能的方法？有新技能建议？欢迎提交PR和问题！

请参阅 [CONTRIBUTING.md](CONTRIBUTING.md) 了解添加或改进技能的指南。

## 许可证

[MIT](LICENSE) - 随意使用这些内容。