#!/usr/bin/env python3
"""
技能初始化器 - 从模板创建新技能

用法：
    init_skill.py <skill-name> --path <path>

示例：
    init_skill.py my-new-skill --path skills/public
    init_skill.py my-api-helper --path skills/private
    init_skill.py custom-skill --path /custom/location
"""

import sys
from pathlib import Path


SKILL_TEMPLATE = """---
name: {skill_name}
description: "[待填写：完整且有信息量的中文描述，说明技能做什么以及何时使用。包含触发场景、文件类型或任务类型。]"
---

# {skill_title}

## 概述

[待填写：1-2 句话说明此技能提供什么能力]

## 结构选择

[待填写：根据技能性质选择最合适的组织方式：

**1. 工作流型**（适合顺序流程）
- 有清晰的步骤流程时效果最好
- 示例：DOCX 技能的"工作流决策树"→"读取"→"创建"→"编辑"
- 结构：## 概述 → ## 工作流决策树 → ## 步骤 1 → ## 步骤 2...

**2. 任务型**（适合工具集合）
- 提供多种独立操作时效果最好
- 示例：PDF 技能的"快速开始"→"合并 PDF"→"拆分 PDF"→"提取文本"
- 结构：## 概述 → ## 快速开始 → ## 任务类别 1 → ## 任务类别 2...

**3. 参考型**（适合标准或规范）
- 品牌指南、编码标准或需求规范时效果最好
- 示例：品牌样式的"品牌指南"→"颜色"→"字体"→"功能"
- 结构：## 概述 → ## 指南 → ## 规范 → ## 用法...

**4. 能力型**（适合集成系统）
- 多个相互关联的功能时效果最好
- 示例：产品管理的"核心能力"→ 编号能力列表
- 结构：## 概述 → ## 核心能力 → ### 1. 功能 → ### 2. 功能...

删除此说明块并替换为实际内容。]
"""


def create_skill(skill_name, base_path):
    """创建新技能的目录结构和模板文件"""
    skill_path = Path(base_path) / skill_name

    if skill_path.exists():
        print(f"Error: {skill_path} already exists")
        return False

    # 创建目录结构
    skill_path.mkdir(parents=True)
    (skill_path / "scripts").mkdir()
    (skill_path / "references").mkdir()

    # 生成标题
    skill_title = skill_name.replace("-", " ").title()

    # 写入 SKILL.md
    skill_md = skill_path / "SKILL.md"
    skill_md.write_text(
        SKILL_TEMPLATE.format(skill_name=skill_name, skill_title=skill_title),
        encoding="utf-8"
    )

    print(f"Created skill at: {skill_path}")
    print(f"  SKILL.md - 主文件（编辑此文件）")
    print(f"  scripts/ - 放置脚本")
    print(f"  references/ - 放置参考资料")
    return True


if __name__ == "__main__":
    if len(sys.argv) < 4 or sys.argv[2] != "--path":
        print("用法: init_skill.py <skill-name> --path <path>")
        print("示例: init_skill.py my-skill --path ~/.stepfun/skills")
        sys.exit(1)

    skill_name = sys.argv[1]
    base_path = sys.argv[3]

    if not create_skill(skill_name, base_path):
        sys.exit(1)
