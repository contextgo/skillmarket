#!/usr/bin/env python3
"""
技能快速验证脚本 - 精简版
"""

import sys
import os
import re
import yaml
from pathlib import Path

def validate_skill(skill_path):
    """基础技能验证"""
    skill_path = Path(skill_path)

    # 检查 SKILL.md 是否存在
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return False, "未找到 SKILL.md"

    # 读取并验证 frontmatter
    content = skill_md.read_text(encoding='utf-8')
    if not content.startswith('---'):
        return False, "未找到 YAML frontmatter"

    # 提取 frontmatter
    match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return False, "frontmatter 格式无效"

    frontmatter_text = match.group(1)

    # 解析 YAML frontmatter
    try:
        frontmatter = yaml.safe_load(frontmatter_text)
        if not isinstance(frontmatter, dict):
            return False, "frontmatter 必须是 YAML 字典"
    except yaml.YAMLError as e:
        return False, f"frontmatter 中的 YAML 无效: {e}"

    # 定义允许的属性
    ALLOWED_PROPERTIES = {'name', 'description', 'license', 'allowed-tools', 'metadata'}

    # 检查意外属性
    unexpected_keys = set(frontmatter.keys()) - ALLOWED_PROPERTIES
    if unexpected_keys:
        return False, (
            f"SKILL.md frontmatter 中有意外的键: {', '.join(sorted(unexpected_keys))}。"
            f"允许的属性为: {', '.join(sorted(ALLOWED_PROPERTIES))}"
        )

    # 检查必需字段
    if 'name' not in frontmatter:
        return False, "frontmatter 中缺少 'name'"
    if 'description' not in frontmatter:
        return False, "frontmatter 中缺少 'description'"

    # 验证 name
    name = frontmatter.get('name', '')
    if not isinstance(name, str):
        return False, f"name 必须是字符串，实际为 {type(name).__name__}"

    # 验证 kebab-case
    if not re.match(r'^[a-z][a-z0-9]*(-[a-z0-9]+)*$', name) and not re.match(r'^[A-Z]', name):
        if ' ' in name:
            return False, f"name 不能包含空格: '{name}'。请使用 kebab-case，如 'my-skill'"

    # 验证 description
    description = frontmatter.get('description', '')
    if not isinstance(description, str):
        return False, f"description 必须是字符串，实际为 {type(description).__name__}"
    if len(description.strip()) < 10:
        return False, "description 太短（至少 10 个字符）"
    if 'TODO' in description or '[' in description[:5]:
        return False, "description 仍包含模板占位符"

    # 检查 SKILL.md 内容
    body = content[match.end():].strip()
    if len(body) < 50:
        return False, "SKILL.md 正文内容太少（至少 50 个字符）"

    return True, f"验证通过: {name}"


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("用法: quick_validate.py <技能路径>")
        sys.exit(1)

    skill_path = sys.argv[1]
    if not os.path.isdir(skill_path):
        print(f"错误: 目录不存在: {skill_path}")
        sys.exit(1)

    valid, message = validate_skill(skill_path)
    if valid:
        print(f"✅ {message}")
    else:
        print(f"❌ {message}")
        sys.exit(1)
