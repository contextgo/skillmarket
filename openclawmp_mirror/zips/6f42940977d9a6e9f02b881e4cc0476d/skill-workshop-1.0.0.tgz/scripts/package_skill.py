#!/usr/bin/env python3
"""
技能打包器 - 将技能文件夹打包为可分发的 .skill 文件

用法：
    python scripts/package_skill.py <技能文件夹路径> [输出目录]

示例：
    python scripts/package_skill.py ~/.stepfun/skills/my-skill
    python scripts/package_skill.py ~/.stepfun/skills/my-skill ./dist
"""

import sys
import zipfile
from pathlib import Path
from quick_validate import validate_skill


def package_skill(skill_path, output_dir=None):
    """
    将技能文件夹打包为 .skill 文件。

    参数：
        skill_path: 技能文件夹路径
        output_dir: 可选的输出目录（默认为当前目录）

    返回：
        创建的 .skill 文件路径，出错时返回 None
    """
    skill_path = Path(skill_path).resolve()

    # 验证技能文件夹存在
    if not skill_path.exists():
        print(f"❌ 错误: 未找到技能文件夹: {skill_path}")
        return None

    if not skill_path.is_dir():
        print(f"❌ 错误: 路径不是目录: {skill_path}")
        return None

    # 验证 SKILL.md 存在
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        print(f"❌ 错误: 未找到 SKILL.md: {skill_path}")
        return None

    # 打包前运行验证
    print("🔍 验证技能...")
    valid, message = validate_skill(skill_path)
    if not valid:
        print(f"❌ 验证失败: {message}")
        print("   请先修复验证错误再打包。")
        return None
    print(f"✅ {message}\n")

    # 确定输出位置
    skill_name = skill_path.name
    if output_dir:
        output_path = Path(output_dir).resolve()
        output_path.mkdir(parents=True, exist_ok=True)
    else:
        output_path = Path.cwd()

    skill_filename = output_path / f"{skill_name}.skill"

    # 创建 .skill 文件（zip 格式）
    try:
        with zipfile.ZipFile(skill_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
            for file_path in sorted(skill_path.rglob('*')):
                if file_path.is_file():
                    # 跳过隐藏文件和 __pycache__
                    rel_path = file_path.relative_to(skill_path)
                    if any(part.startswith('.') or part == '__pycache__' for part in rel_path.parts):
                        continue
                    zf.write(file_path, rel_path)
                    print(f"  📦 {rel_path}")

        print(f"\n✅ 打包成功: {skill_filename}")
        print(f"   大小: {skill_filename.stat().st_size:,} 字节")
        return skill_filename

    except Exception as e:
        print(f"❌ 打包失败: {e}")
        if skill_filename.exists():
            skill_filename.unlink()
        return None


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: package_skill.py <技能文件夹路径> [输出目录]")
        sys.exit(1)

    skill_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None

    result = package_skill(skill_path, output_dir)
    if result is None:
        sys.exit(1)
