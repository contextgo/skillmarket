# 技能创建指南（萃取自 skill-creator）

> 来源：skill-creator SKILL.md | 萃取日期：2026-03-16
> 本文件作为 skill-workshop "技能生成"阶段的参考文档

## Core Principles

### Concise is Key

Context window 是公共资源。技能与系统提示、对话历史、其他技能的元数据共享 context window。

**默认假设：模型已经非常聪明。** 只添加模型不具备的上下文。对每条信息质疑："模型真的需要这个解释吗？"、"这段话值得它的 token 成本吗？"

优先使用简洁示例而非冗长解释。

### Set Appropriate Degrees of Freedom

根据任务的脆弱性和可变性匹配具体程度：

| 自由度 | 适用场景 | 形式 |
|--------|---------|------|
| **高自由度** | 多种方法都有效、决策依赖上下文、启发式指导 | 文本说明 |
| **中自由度** | 存在首选模式、允许一定变化、配置影响行为 | 伪代码或带参数的脚本 |
| **低自由度** | 操作脆弱易出错、一致性至关重要、精确步骤必须遵循 | 具体脚本，少量参数 |

### Skill Structure

```
skill-name/
├── SKILL.md          # 主文件（骨架，≤12KB）
├── references/       # 按需加载的详细文档
│   ├── guide-1.md
│   └── guide-2.md
├── scripts/          # 可执行脚本
│   └── main.ts
└── prompts/          # 提示词模板
    └── system.md
```

### SKILL.md 编写规范

1. **Frontmatter**：必须包含 name、description（中文）、version、updated
2. **正文结构**：概述 → 何时使用 → 快速开始 → 详细说明 → 配合技能
3. **大小限制**：SKILL.md ≤ 12KB（骨架），详细内容放 references/
4. **语言**：description 和正文默认中文，技术术语保留英文

### Best Practices

- 不要重复模型已知的知识（如编程语言语法）
- 用示例代替解释
- 每个 reference 文件 ≤ 10KB
- 脚本必须在 SKILL.md 中声明
- 避免硬编码路径，使用 `${SKILL_DIR}` 变量
