# 技能全景速查表

> 按功能域分组，每个技能一行速查。状态：✅可用 ⚠️需配置 ⛔已废弃 👀观察中

## 元技能层（8个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| user-preferences | 用户偏好与协作规则 | ✅ |
| self-improvement | 持久学习记录（LEARNINGS.md） | ✅ |
| self-improving | 自我反思触发器 | ✅ |
| capability-evolver | 技能级自我进化引擎 | ✅ |
| skill-workshop | 技能生命周期管理（发现/创建/维护） | ✅ |
| skill-integrator | 多技能整合与冲突解决 | ✅ |
| multi-agent-collab | 多Agent协作框架（20种方法） | ✅ |
| planning-with-files | 复杂任务的文件式规划 | ✅ |
| proactive-agent | 主动预判+WAL协议+压缩恢复 | ✅ |

## 搜索层（3个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| WebSearch（内置） | 默认搜索，90%场景 | ✅ |
| web-search-exa | Exa深度搜索（MCP） | ⚠️需MCP |
| multi-search-engine | 17引擎+搜索策略方法论 | ✅ |

## 记忆层（3个+1观察）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| self-improvement | 条目级学习记录 | ✅ |
| capability-evolver | 技能级进化引擎 | ✅ |
| byterover | 项目级知识管理（brv CLI） | ⚠️需npm |
| elite-longterm-memory | 向量语义搜索记忆 | 👀 |

## 写作与文本处理层（3个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| humanizer-zh | 中文去AI痕迹 | ✅ |
| humanize-ai-text | 英文去AI痕迹 | ✅ |
| copywriting | 营销文案撰写 | ✅ |

## 分析层（3个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| deep-reading-analyst | 10+思维框架深度阅读 | ✅ |
| data-storytelling | 数据→叙事+可视化 | ✅ |
| product-manager-toolkit | RICE/访谈/PRD/上市策略 | ✅ |

## 文档处理层（6个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| markdown-converter | 万能格式→Markdown（markitdown） | ✅ |
| pdf | PDF读取/合并/拆分 | ✅ |
| docx | Word文档+修订跟踪 | ✅ |
| xlsx | Excel公式/格式/分析 | ✅ |
| pptx | PowerPoint创建/编辑 | ✅ |
| creating-financial-models | DCF/敏感性/蒙特卡洛 | ✅ |

## 视觉内容层（8个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| baoyu-visual-hub | 视觉内容路由入口 | ⚠️需Gemini |
| baoyu-danger-gemini-web | 图片生成后端 | ⚠️需配置 |
| baoyu-cover-image | 文章封面图 | ⚠️需Gemini |
| baoyu-article-illustrator | 文章配图 | ⚠️需Gemini |
| baoyu-xhs-images | 小红书信息图 | ⚠️需Gemini |
| baoyu-infographic | 专业信息图 | ⚠️需Gemini |
| baoyu-comic | 知识漫画 | ⚠️需Gemini |
| baoyu-slide-deck | 幻灯片图片 | ⚠️需Gemini |
| baoyu-compress-image | 图片压缩 | ✅ |

## 发布层（4个）
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| baoyu-publish-hub | 发布路由入口 | ⚠️需下游 |
| baoyu-post-to-x | 发布到X/Twitter | ⚠️需Chrome |
| baoyu-post-to-wechat | 发布到微信公众号 | ⚠️需Chrome |
| baoyu-danger-x-to-markdown | X推文转Markdown | ⚠️需配置 |

## 独立工具层
| 技能 | 一句话说明 | 状态 |
|------|---------|------|
| stock-analysis | 股票8维分析+传闻扫描 | ⚠️需npm |
| obsidian | Obsidian知识库管理 | ⚠️需改造 |
| github-api | GitHub API+安全交互 | ⚠️需改造 |
| anything-to-notebooklm | 多源→NotebookLM | ⚠️需Google |
| himalaya | 终端邮件管理 | ⚠️需IMAP |
| gemini | Gemini CLI | ⚠️需Google |
| automation-workflows | 自动化工作流方法论 | ✅ |
| market-research-reports | 市场研究报告 | ✅ |
| contract-review | 合同审核 | ✅ |
| chrome-automation | Chrome自动化 | ⚠️需安装 |

## 已废弃（8个）
| 技能 | 价值已整合到 |
|------|------------|
| tavily-search | multi-search-engine |
| brave-search | multi-search-engine |
| summarize | markdown-converter |
| docstrange | markdown-converter |
| markdown-convert | markdown-converter |
| evolver | capability-evolver |
| clawddocs | skill-workshop |
| moltbook | github-api |
