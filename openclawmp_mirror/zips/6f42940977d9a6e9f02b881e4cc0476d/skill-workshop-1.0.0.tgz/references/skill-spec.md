# 技能创建规范（Skill Specification）

> 本文件是 skill-workshop 的技能创建完整规范。在进入技能生成阶段时被加载。
> 来源：整合自 skill-creator + Anthropic 官方规范 + context-engineering 最佳实践

---

## 技能的本质

Skills 是模块化、自包含的包，通过提供专业知识、工作流和工具来扩展 AI 的能力。把它们想象成特定领域的"入职指南"——将通用型 AI 转变为配备了程序性知识的专业化 AI。

### 技能提供什么

1. **专业工作流** — 特定领域的多步骤程序
2. **工具集成** — 处理特定文件格式或 API 的指令
3. **领域专业知识** — 公司特定知识、模式、业务逻辑
4. **捆绑资源** — 脚本、参考文件和资产

---

## 核心原则

### 原则 1：简洁是关键

上下文窗口是公共资源。技能与系统提示词、对话历史、其他技能的 metadata 和用户请求共享上下文窗口。

**默认假设：AI 已经非常聪明。** 只添加 AI 尚不具备的上下文。对每条信息提出挑战："AI 真的需要这个解释吗？""这段话值得它的 token 成本吗？"

优先使用简洁的示例，而非冗长的解释。

### 原则 2：设置适当的自由度

根据任务的脆弱性和可变性匹配具体程度：

| 自由度 | 适用场景 | 形式 |
|--------|---------|------|
| **高** | 多种方法都有效，决策取决于上下文 | 文本指令 |
| **中** | 存在首选模式，允许一些变化 | 伪代码或带参数的脚本 |
| **低** | 操作脆弱易错，一致性至关重要 | 具体脚本，少量参数 |

### 原则 3：渐进式披露（Progressive Disclosure）

这是 Anthropic 官方推荐的核心架构模式：

**第一层：Metadata**（name + description）
- 始终驻留在系统提示词中
- 每个技能约 150 tokens
- 这是"路由层"，决定技能是否被激活
- description 的质量直接决定技能是否被正确触发

**第二层：SKILL.md body**
- 技能被触发时才加载
- 保持在 1000 行以内
- 包含流程骨架和决策逻辑

**第三层：Bundled resources**（references/、scripts/、assets/）
- AI 按需用 Read 工具主动读取
- 理论上无上限
- **关键**：必须在 SKILL.md 中明确说明"何时读取哪个文件"

> "When splitting out content into other files, it is very important to reference them from SKILL.md and describe clearly when to read them." — Anthropic 官方

### 渐进式披露的三种模式

**模式 1：高层指南 + 引用**
SKILL.md 放流程骨架，详细规范放 references/。适合复杂技能。

**模式 2：领域分片**
按领域将内容拆分到不同文件。例如 PDF 技能将表单填写拆到 forms.md。

**模式 3：条件详情**
仅在特定条件下才需要的详情放到单独文件。例如错误处理指南。

### 原则 4：上下文预算控制

| 组件 | 目标预算 |
|------|---------|
| Metadata（name + description） | < 150 tokens |
| SKILL.md body | < 5000 tokens（约 1000 行） |
| 单个 reference 文件 | < 10000 tokens |
| 所有 references 总计 | 无硬限制（按需加载） |

---

## SKILL.md 文件规范

### Frontmatter（必需）

```yaml
---
name: my-skill-name          # 必需，kebab-case
description: "完整描述..."     # 必需，具体说明何时使用
license: MIT                  # 可选
allowed-tools:                # 可选，声明权限范围
  - Read
  - Write
  - WebSearch
---
```

**name 规则：**
- 使用 kebab-case（如 `my-skill-name`）
- 不使用 camelCase 或 snake_case
- 简短但有描述性

**description 规则（极其重要）：**
- 这是技能被正确触发的关键
- 必须具体说明：技能做什么 + 何时使用
- 包含触发短语示例
- 避免模糊描述如"一个有用的工具"

### Body 结构

推荐结构（根据技能类型选择）：

**工作流型技能：**
```markdown
# 技能名称
## 概述（1-2 句话）
## 工作流决策树（何时用哪个流程）
## 流程 1：[名称]
## 流程 2：[名称]
## 引用文件索引
```

**任务型技能：**
```markdown
# 技能名称
## 概述
## 快速开始
## 任务类别 1
## 任务类别 2
## 引用文件索引
```

**参考/指南型技能：**
```markdown
# 技能名称
## 概述
## 指南
## 规范
## 使用方式
## 引用文件索引
```

---

## 资源打包规范

### 目录结构

```
my-skill/
├── SKILL.md                  # 必需：主文件
├── references/               # 可选：参考文档
│   ├── guide.md
│   └── examples.md
├── scripts/                  # 可选：可执行脚本
│   ├── setup.sh
│   └── process.py
├── templates/                # 可选：模板文件
│   └── report-template.md
└── assets/                   # 可选：静态资源
    └── config.json
```

### 脚本规范

- 脚本应有清晰的文档字符串
- 包含使用说明和示例
- 有适当的错误处理
- 不依赖未声明的外部包
- 使用相对路径引用同目录下的文件

### 引用文件规范

- 每个引用文件应有明确的用途
- 在 SKILL.md 中说明何时读取
- 保持单个文件 < 5000 tokens
- 使用 Markdown 格式

---

## 质量检查清单

### 功能检查
- [ ] SKILL.md 存在且有合法 frontmatter
- [ ] name 为 kebab-case，description 非空且具体
- [ ] 包含清晰的使用场景说明
- [ ] 包含核心工作流或操作步骤
- [ ] 引用文件在 SKILL.md 中有明确的加载指令

### 质量检查
- [ ] SKILL.md body < 1000 行
- [ ] 引用了来源（专家/项目）
- [ ] 包含示例输入/输出（或示例用法）
- [ ] 包含常见错误和避坑指南
- [ ] 没有重复 AI 已知的通用知识

### 上下文预算检查
- [ ] 估算 SKILL.md 的 token 数（目标 < 5000）
- [ ] 超过 5000 tokens 的内容是否已拆分到 references/
- [ ] 每个 reference 文件是否 < 10000 tokens
- [ ] references/ 中的文件在 SKILL.md 中是否有明确的"何时读取"指令

### 安全自检
- [ ] 无红线行为（参见 security-gate.md 的 14 条红线）
- [ ] 声明了权限范围（allowed-tools）
- [ ] 操作可追溯（有输出记录）
- [ ] 不修改自身或其他技能的文件
- [ ] 不注入或修改系统提示词

---

## 高级模式

### 多文件技能

当技能复杂到需要多个 reference 文件时：
1. SKILL.md 作为路由中心，只放流程骨架
2. 每个 reference 文件覆盖一个独立关注点
3. 在 SKILL.md 末尾放"引用文件索引"表格

### setup.sh 自动安装

如果技能依赖外部工具，应在 SKILL.md 的前置条件部分明确声明，而非通过脚本自动安装：

```markdown
## 前置条件

本技能依赖以下工具，请确认已安装：
- Python 3.x
- pdfplumber 库

如未安装，请用户手动在终端执行安装。AI 不应代替用户执行安装命令。
```

### 条件逻辑

在 SKILL.md 中使用决策树引导 AI：
```markdown
1. 判断任务类型：
   **创建新内容？** → 读取 references/creation-guide.md
   **编辑现有内容？** → 读取 references/editing-guide.md
```

---

## 输出模式参考

### 模板模式

提供输出格式模板，根据需要匹配严格程度。

**严格要求（如 API 响应）：**
```markdown
## 报告结构
始终使用此精确模板结构：
# [标题]
## 执行摘要
## 关键发现
## 建议
```

**灵活指导（需要适应性时）：**
```markdown
## 报告结构
以下是合理的默认格式，但请根据实际情况判断：
# [标题]
## 执行摘要
## 关键发现（根据发现调整各部分）
## 建议（针对具体场景定制）
```

### 示例模式

当输出质量取决于看到示例时，提供输入/输出对。示例比描述更能帮助理解期望的风格和详细程度。
