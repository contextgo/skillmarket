# 技能生态建设经验模式

> 来源：archives/skill_ecosystem（2026-03-11 归档）
> 回流时间：2026-03-12

## 核心经验模式

### 模式1：分批渐进式操作
从0到50+技能的建设过程中，最有效的策略是分批执行：
- 低风险操作先行（视觉类、工具类技能）
- 高风险操作后置（核心技能、协作类技能）
- 每批完成后验证，确认无副作用再进入下一批

### 模式2：Hub路由模式
当同一领域存在3个以上技能时，建立统一入口Hub：
- Hub负责意图识别和路由分发
- 子技能description中标注"建议通过Hub调用"
- Hub的description中列出所有子技能名称
- 已验证案例：visual-hub（9个视觉技能）、unified-market-research（4个研究技能）、unified-humanizer（3个人性化技能）

### 模式3：信任注册表机制
对外部来源的技能建立信任分级：
- 信任等级：verified / trusted / experimental / deprecated
- 安全审查是强制关卡，不可跳过
- 降级操作需用户确认

### 模式4：SKILL.md 瘦身标准
- 目标：≤12KB（约3000 token）
- 骨架放SKILL.md，详细规范放references/
- 脚本放scripts/，按需加载
- 检查工具：check_skill_sizes.py

### 模式5：废弃技能处理流程
1. 价值萃取：提取可复用的模式和知识
2. 归档备份：移至 archives/deprecated_skills/
3. 清理引用：更新 WORKSPACE_MAP、trust-registry 等
4. 验证删除：确认目录不存在

## 关键数据

| 指标 | 数值 |
|------|------|
| 技能总数峰值 | 56 |
| 优化后目标 | 52 |
| 废弃技能数 | 8（已价值萃取） |
| Hub路由技能 | 3（visual/research/humanizer） |
| 瘦身达标率目标 | ≥95% |
