---
name: a-stock-monitor
description: A股实时行情监控助手 - 支持多股票同时监控、价格预警、自动汇报，专为长期价值投资者设计。基于东方财富数据，无需API密钥。
version: 1.0.0
metadata:
  openclaw:
    emoji: "📈"
    requires:
      bins: ["curl", "jq"]
    author: "HunterJW-Agent"
    tags: ["stock", "finance", "a-share", "monitoring", "investment"]
---

# A股实时行情监控助手

**专为长期价值投资者打造的A股监控工具**

## 功能特性

- 📊 **实时行情查询** - 沪深A股即时价格、涨跌幅
- 📋 **多股监控列表** - 同时跟踪多只股票
- 🔔 **智能价格预警** - 达到目标价位自动提醒
- ⏰ **定时自动汇报** - 交易日开盘/收盘自动推送
- 💾 **本地数据存储** - 监控配置持久化保存
- 🎯 **投资策略建议** - 基于价值投资理念的分析框架

## 安装要求

```bash
# 确保系统已安装
curl --version
jq --version
```

## 使用方法

### 1. 快速查询单只股票

```bash
# 查询四川黄金 (深圳)
curl -s "https://r.jina.ai/http://quote.eastmoney.com/sz001337.html" | head -5

# 查询贵州茅台 (上海)
curl -s "https://r.jina.ai/http://quote.eastmoney.com/sh600519.html" | head -5
```

### 2. 添加到监控列表

创建监控配置文件 `~/.config/a-stock-monitor/watchlist.json`:

```json
{
  "stocks": [
    {
      "code": "001337",
      "market": "sz",
      "name": "四川黄金",
      "buy_price": 47.00,
      "target_prices": [55, 60, 65],
      "stop_loss": 43.00,
      "position": "观望"
    },
    {
      "code": "600519",
      "market": "sh", 
      "name": "贵州茅台",
      "buy_price": 1500.00,
      "target_prices": [1800, 2000],
      "stop_loss": 1400.00,
      "position": "持有"
    }
  ],
  "settings": {
    "report_times": ["09:25", "15:30"],
    "alert_enabled": true
  }
}
```

### 3. 监控脚本

```bash
#!/bin/bash
# stock_monitor.sh - A股实时监控脚本

CONFIG_FILE="$HOME/.config/a-stock-monitor/watchlist.json"
LOG_FILE="$HOME/.config/a-stock-monitor/monitor.log"

# 获取股票信息
get_stock_info() {
    local code=$1
    local market=$2
    curl -s "https://r.jina.ai/http://quote.eastmoney.com/${market}${code}.html" | \
        grep -E "[0-9]+\.[0-9]+.*[0-9]+\.[0-9]+%" | head -1
}

# 解析价格和涨跌幅
parse_stock_data() {
    local raw_data=$1
    echo "$raw_data" | awk -F'|' '{print $2, $3, $4}'
}

# 检查价格预警
check_alerts() {
    local code=$1
    local current_price=$2
    local buy_price=$3
    local target_price=$4
    local stop_loss=$5
    
    if (( $(echo "$current_price <= $buy_price" | bc -l) )); then
        echo "🟢 买入信号: $code 当前 $current_price ≤ 目标买入价 $buy_price"
    elif (( $(echo "$current_price >= $target_price" | bc -l) )); then
        echo "🔴 止盈信号: $code 当前 $current_price ≥ 目标价 $target_price"
    elif (( $(echo "$current_price <= $stop_loss" | bc -l) )); then
        echo "⚠️ 止损警告: $code 当前 $current_price ≤ 止损价 $stop_loss"
    fi
}

# 生成日报
generate_daily_report() {
    echo "=== A股监控日报 $(date '+%Y-%m-%d %H:%M') ==="
    echo ""
    
    while IFS= read -r stock; do
        code=$(echo "$stock" | jq -r '.code')
        market=$(echo "$stock" | jq -r '.market')
        name=$(echo "$stock" | jq -r '.name')
        
        info=$(get_stock_info "$code" "$market")
        echo "📊 $name ($market$code): $info"
    done < <(jq -c '.stocks[]' "$CONFIG_FILE")
}

# 主循环
main() {
    mkdir -p "$(dirname "$CONFIG_FILE")"
    
    case "$1" in
        report)
            generate_daily_report
            ;;
        alert)
            # 检查所有股票的预警条件
            while IFS= read -r stock; do
                code=$(echo "$stock" | jq -r '.code')
                market=$(echo "$stock" | jq -r '.market')
                name=$(echo "$stock" | jq -r '.name')
                buy=$(echo "$stock" | jq -r '.buy_price')
                target=$(echo "$stock" | jq -r '.target_prices[0]')
                stop=$(echo "$stock" | jq -r '.stop_loss')
                
                info=$(get_stock_info "$code" "$market")
                current=$(echo "$info" | awk -F'|' '{gsub(/[^0-9.]/,"",$2); print $2}')
                
                check_alerts "$name" "$current" "$buy" "$target" "$stop"
            done < <(jq -c '.stocks[]' "$CONFIG_FILE")
            ;;
        *)
            echo "用法: $0 {report|alert}"
            ;;
    esac
}

main "$@"
```

### 4. 设置定时任务

使用 OpenClaw Cron 设置自动汇报：

```bash
# 早盘前汇报
openclaw cron add \
  --name "A股早盘监控" \
  --cron "25 9 * * 1-5" \
  --session isolated \
  --message "执行 ~/.config/a-stock-monitor/stock_monitor.sh report" \
  --announce

# 收盘后汇报  
openclaw cron add \
  --name "A股收盘监控" \
  --cron "30 15 * * 1-5" \
  --session isolated \
  --message "执行 ~/.config/a-stock-monitor/stock_monitor.sh report" \
  --announce
```

## 投资策略框架

### 建仓策略

```
本金分配原则:
├── 首次建仓: 30% (测试水位)
├── 二次加仓: 30% (确认趋势)
└── 最终仓位: 40% (完成布局)

触发条件:
- 价格进入买入区间
- 成交量温和放大
- 大盘情绪稳定
```

### 风险管理

```
单笔投资风险控制:
├── 最大仓位: 不超过总资金 20%
├── 止损线: -15% (硬性止损)
├── 止盈策略: 
│   ├── 第一目标 +25%: 减仓 30%
│   ├── 第二目标 +40%: 减仓 30%
│   └── 第三目标 +60%: 清仓或保留底仓
└── 持仓周期: 3-6 个月为主
```

## 数据说明

- **数据源**: 东方财富网 (quote.eastmoney.com)
- **更新频率**: 实时 (3-5秒延迟)
- **覆盖市场**: 沪深A股、港股、美股
- **数据准确性**: 交易所官方数据

## 注意事项

⚠️ **风险提示**: 本工具仅供学习研究，不构成投资建议
⚠️ **数据延迟**: 行情数据有3-5秒延迟，不适合高频交易
⚠️ **网络依赖**: 需要稳定的网络连接

## 相关技能

- `eastmoney-stock` - 基础A股数据获取
- `finnhub` - 美股/港股数据
- `tushare-base` - 专业金融数据接口

## 更新日志

### v1.0.0 (2026-03-04)
- ✨ 初始版本发布
- ✨ 支持多股票监控
- ✨ 价格预警功能
- ✨ 定时自动汇报
