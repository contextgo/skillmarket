#!/bin/bash
# A股实时行情监控脚本
# 支持：价格查询、涨跌幅监控、条件提醒

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 获取股票实时数据
get_stock_data() {
    local code=$1
    local market=$2
    
    if [[ $code =~ ^6 ]]; then
        market="sh"
    elif [[ $code =~ ^(0|3) ]]; then
        market="sz"
    else
        echo "未知市场代码"
        return 1
    fi
    
    curl -s "https://r.jina.ai/http://quote.eastmoney.com/${market}${code}.html" 2>/dev/null | \
        grep -E "^[^#]*[0-9]+\.[0-9]+.*[0-9]+\.[0-9]+%?" | head -1
}

# 解析股票数据
parse_stock_data() {
    local raw_data=$1
    echo "$raw_data" | awk -F'|' '{
        print "名称:", $1
        print "价格:", $2
        print "涨跌额:", $3
        print "涨跌幅:", $4
        print "成交量:", $5
        print "成交额:", $6
    }'
}

# 格式化输出
format_output() {
    local name=$1
    local price=$2
    local change=$3
    local percent=$4
    
    # 判断涨跌
    if [[ $(echo "$change > 0" | bc -l) -eq 1 ]]; then
        color=$RED
        trend="📈"
    elif [[ $(echo "$change < 0" | bc -l) -eq 1 ]]; then
        color=$GREEN
        trend="📉"
    else
        color=$YELLOW
        trend="➖"
    fi
    
    printf "${color}%s %s${NC}\n" "$trend" "$name"
    printf "  价格: ¥%.2f\n" "$price"
    printf "  涨跌: %+.2f (%+.2f%%)\n" "$change" "$percent"
}

# 监控模式
monitor_mode() {
    local code=$1
    local interval=${2:-30}  # 默认30秒刷新
    
    echo "开始监控股票 $code (每 ${interval} 秒刷新，按 Ctrl+C 停止)..."
    echo "=========================================="
    
    while true; do
        clear
        echo "🕐 $(date '+%Y-%m-%d %H:%M:%S')"
        echo "=========================================="
        
        data=$(get_stock_data "$code")
        if [ $? -eq 0 ] && [ -n "$data" ]; then
            echo "$data" | awk -F'|' -v red="$RED" -v green="$GREEN" -v nc="$NC" '{
                name=$1; price=$2; change=$3; pct=$4
                if (change+0 > 0) color=red
                else if (change+0 < 0) color=green
                else color="\033[1;33m"
                printf "%s%s %s%s\n", color, (change+0>=0?"📈":"📉"), name, nc
                printf "  现价: ¥%s\n", price
                printf "  涨跌: %s (%s)\n", change, pct
            }'
        else
            echo "❌ 获取数据失败"
        fi
        
        echo "=========================================="
        sleep "$interval"
    done
}

# 批量查询
batch_query() {
    local codes=$1
    echo "批量查询股票: $codes"
    echo "=========================================="
    
    for code in $(echo $codes | tr ',' ' '); do
        data=$(get_stock_data "$code")
        if [ $? -eq 0 ] && [ -n "$data" ]; then
            echo "$data" | awk -F'|' '{print $1": ¥"$2" ("$4")"}'
        else
            echo "$code: 查询失败"
        fi
        sleep 0.5  # 避免请求过快
    done
}

# 条件提醒
alert_mode() {
    local code=$1
    local condition=$2  # 格式: >50 或 <-10%
    
    echo "设置条件提醒: $code $condition"
    echo "监控中... (按 Ctrl+C 停止)"
    
    while true; do
        data=$(get_stock_data "$code")
        price=$(echo "$data" | cut -d'|' -f2)
        
        # 解析条件并检查
        if [[ $condition =~ ^\>([0-9.]+)$ ]]; then
            target=${BASH_REMATCH[1]}
            if (( $(echo "$price > $target" | bc -l) )); then
                echo "🚨 提醒: $code 价格 ¥$price 已超过 ¥$target"
                break
            fi
        elif [[ $condition =~ ^\<([0-9.]+)$ ]]; then
            target=${BASH_REMATCH[1]}
            if (( $(echo "$price < $target" | bc -l) )); then
                echo "🚨 提醒: $code 价格 ¥$price 已低于 ¥$target"
                break
            fi
        fi
        
        sleep 30
    done
}

# 主函数
main() {
    case $1 in
        query|q)
            shift
            get_stock_data "$1"
            ;;
        monitor|m)
            shift
            monitor_mode "$1" "$2"
            ;;
        batch|b)
            shift
            batch_query "$1"
            ;;
        alert|a)
            shift
            alert_mode "$1" "$2"
            ;;
        *)
            cat << 'EOF'
A股实时行情监控助手 v1.0.0

用法:
  ./stock-monitor.sh query <股票代码>     查询单只股票
  ./stock-monitor.sh monitor <代码> [秒]  实时监控模式
  ./stock-monitor.sh batch <代码1,代码2>  批量查询
  ./stock-monitor.sh alert <代码> <条件>  条件提醒

示例:
  ./stock-monitor.sh query 001337         查询四川黄金
  ./stock-monitor.sh monitor 600000 60    每分钟刷新浦发银行
  ./stock-monitor.sh batch 001337,600000  批量查询多只股票
  ./stock-monitor.sh alert 001337 \>50    价格超过50元时提醒

股票代码规则:
  6xxxxx = 上海主板
  0xxxxx = 深圳主板
  3xxxxx = 创业板
EOF
            ;;
    esac
}

main "$@"
