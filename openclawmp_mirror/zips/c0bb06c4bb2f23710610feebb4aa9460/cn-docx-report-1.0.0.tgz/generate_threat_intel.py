# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Inches, Cm
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

# 创建文档
doc = Document()

# 设置页面边距：上下1.46英寸，左右1.1英寸
sections = doc.sections
for section in sections:
    section.top_margin = Inches(1.46)
    section.bottom_margin = Inches(1.46)
    section.left_margin = Inches(1.1)
    section.right_margin = Inches(1.1)

# 定义样式
styles = doc.styles

# 标题样式：方正小标宋简体，二号，加粗，居中
title_style = styles['Heading 1']
title_style.font.name = '方正小标宋简体'
title_style.font.size = Pt(22)
title_style.font.bold = True

# 正文样式：仿宋_GB2312，三号，首行缩进2字符，1.5倍行距
def set_paragraph_format(para):
    para_format = para.paragraph_format
    para_format.first_line_indent = Inches(0.5)  # 首行缩进2字符（约0.5英寸）
    para_format.line_spacing = 1.5  # 1.5倍行距
    para_format.space_after = Pt(0)

def set_body_style(para):
    para.style = 'Normal'
    for run in para.runs:
        run.font.name = '仿宋_GB2312'
        run.font.size = Pt(16)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

# 一级标题样式：黑体，三号，加粗
def add_heading_numbered(doc, text, level=0):
    para = doc.add_paragraph()
    para_format = para.paragraph_format
    para_format.first_line_indent = Inches(0)
    para_format.line_spacing = 1.5
    para_format.space_after = Pt(0)
    
    run = para.add_run(text)
    run.font.name = '黑体'
    run.font.size = Pt(16)
    run.font.bold = True
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    return para

# 标题
title_para = doc.add_paragraph()
title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
title_run = title_para.add_run('FBI警告：俄罗斯黑客大规模钓鱼攻击Signal与WhatsApp')
title_run.font.name = '方正小标宋简体'
title_run.font.size = Pt(22)
title_run.font.bold = True
title_run._element.rPr.rFonts.set(qn('w:eastAsia'), '方正小标宋简体')

# 概览段（直接写内容，不要"概览"标题）
overview_para = doc.add_paragraph()
set_paragraph_format(overview_para)
set_body_style(overview_para)
overview_text = '''2026年3月，美国网络安全和基础设施安全局（CISA）与联邦调查局（FBI）联合发布警报，称与俄罗斯情报机构有关联的威胁行为者正在实施大规模钓鱼攻击，旨在入侵Signal和WhatsApp等商业消息应用程序（CMA），以夺取具有高情报价值个人的账户控制权。该攻击活动主要针对美国现任及前任政府官员、军事人员、政治人物和记者等群体，全球范围内已导致数千个账户被未经授权访问。攻击者可通过入侵账户查看消息内容和联系人列表，并以受害者身份发送信息，进行二次钓鱼攻击。'''
run = overview_para.add_run(overview_text)
run.font.name = '仿宋_GB2312'
run.font.size = Pt(16)
run._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

# 一、基本情况
heading1 = add_heading_numbered(doc, '一、基本情况')
heading1.runs[0].font.name = '黑体'
heading1.runs[0].font.size = Pt(16)
heading1.runs[0].font.bold = True
heading1.runs[0]._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

para1 = doc.add_paragraph()
set_paragraph_format(para1)
body_text1 = '''（一）攻击活动概述。美国CISA和FBI于2026年3月21日发布联合警报，指出与俄罗斯情报机构（RIS）有关联的威胁行为者正在开展大规模网络钓鱼活动，目标为商业消息应用程序（CMAs），主要是Signal和WhatsApp。攻击者通过钓鱼手段获取受害者账户控制权，进而访问其敏感通信内容。FBI局长Kash Patel在社交媒体X上表示，该攻击活动专门针对具有高情报价值的个人，包括现任和前任美国政府官员、军事人员、政治人物和记者。值得注意的是，此次攻击并非利用平台加密漏洞或安全弱点，而是通过社会工程学手段实施钓鱼。'''
run1 = para1.add_run(body_text1)
run1.font.name = '仿宋_GB2312'
run1.font.size = Pt(16)
run1._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para2 = doc.add_paragraph()
set_paragraph_format(para2)
body_text2 = '''（二）攻击技术手段。攻击者通过发送精心构造的钓鱼消息，声称受害者账户检测到异常活动或来自未知设备/位置的登录尝试，制造紧迫感诱导用户点击恶意链接或提供验证码。具体手法包括：1.冒充"Signal客服支持"或"WhatsApp支持"，主动联系目标并诱导其点击链接或扫描二维码；2.欺骗目标提供PIN码或验证码，如受害者配合，攻击者即可在其设备上恢复账户，导致受害者失去账户访问权限；3.如受害者点击链接或扫描二维码，攻击者控制的设备将与受害者账户绑定，可访问所有历史消息，而受害者仍保留账户访问权限（除非被攻击者从设置中移除）。攻击者还利用信任关系对其他目标实施二次钓鱼。'''
run2 = para2.add_run(body_text2)
run2.font.name = '仿宋_GB2312'
run2.font.size = Pt(16)
run2._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para3 = doc.add_paragraph()
set_paragraph_format(para3)
body_text3 = '''（三）关联威胁组织。虽然CISA和FBI未将此次活动归因于特定威胁行为者，但微软和谷歌威胁情报团队的先前报告显示，此类活动与多个俄罗斯关联威胁组织有关，包括Star Blizzard（又称UNC5792、UAC-0195）和UNC4221（又称UAC-0185）。这些组织长期针对政府官员、记者和商业领袖实施定向攻击。法国国家网络安全局（ANSSI）下属网络危机协调中心（C4）也发布类似警报，警告针对政府官员、记者和企业高管的即时通讯账户攻击活动激增。'''
run3 = para3.add_run(body_text3)
run3.font.name = '仿宋_GB2312'
run3.font.size = Pt(16)
run3._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

# 二、事件影响
heading2 = add_heading_numbered(doc, '二、事件影响')
heading2.runs[0].font.name = '黑体'
heading2.runs[0].font.size = Pt(16)
heading2.runs[0].font.bold = True
heading2.runs[0]._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

para4 = doc.add_paragraph()
set_paragraph_format(para4)
body_text4 = '''（一）对我国内政安全构成直接威胁。该攻击活动明确针对现任和前任政府官员、军事人员及政治人物。虽然主要目标为美国及相关国家人员，但鉴于我国外交人员、驻外机构工作人员及与外国政府有业务往来的官员均使用此类国际主流即时通讯工具，存在被针对性攻击的现实风险。攻击者获取的通信内容可能涉及国家机密、外交谈判信息及敏感政治动态。'''
run4 = para4.add_run(body_text4)
run4.font.name = '仿宋_GB2312'
run4.font.size = Pt(16)
run4._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para5 = doc.add_paragraph()
set_paragraph_format(para5)
body_text5 = '''（二）对我公民及企业海外利益造成安全隐患。我国在海外有大量企业、机构和公民，他们经常使用Signal和WhatsApp与外界进行商务和个人通信。这些应用在跨境商务、外贸谈判、供应链协调等场景中广泛使用。一旦账户被攻击者控制，可能导致商业机密泄露、合同谈判信息外泄、海关及合规资料被窃取，对我国企业海外利益造成直接经济损害。'''
run5 = para5.add_run(body_text5)
run5.font.name = '仿宋_GB2312'
run5.font.size = Pt(16)
run5._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para6 = doc.add_paragraph()
set_paragraph_format(para6)
body_text6 = '''（三）示范效应可能引发更多针对我国的网络攻击。此类国家级定向攻击活动的公开披露，可能被其他APT组织视为有效攻击手法而纷纷效仿。俄罗斯情报机构此次攻击的成功经验可能扩散至其他与我存在地缘政治竞争的国家或组织，从而加剧针对我国公民和机构的网络间谍活动风险。特别是"国家级"攻击者可能将目标扩展至中国籍记者、学者、海外华人社团组织者等群体。'''
run6 = para6.add_run(body_text6)
run6.font.name = '仿宋_GB2312'
run6.font.size = Pt(16)
run6._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para7 = doc.add_paragraph()
set_paragraph_format(para7)
body_text7 = '''（四）对国家信息基础设施安全的警示。此次攻击凸显了商业即时通讯工具在处理敏感信息时存在的系统性安全风险。我国党政机关、国有企业使用的办公通讯工具虽多为国产平台，但与外方机构沟通时仍不可避免使用Signal、WhatsApp等应用。这种"跨平台"通信场景增加了信息泄露的复杂性和隐蔽性，对国家信息基础设施安全防御体系提出了更高要求。'''
run7 = para7.add_run(body_text7)
run7.font.name = '仿宋_GB2312'
run7.font.size = Pt(16)
run7._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

# 三、对策建议
heading3 = add_heading_numbered(doc, '三、对策建议')
heading3.runs[0].font.name = '黑体'
heading3.runs[0].font.size = Pt(16)
heading3.runs[0].font.bold = True
heading3.runs[0]._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')

para8 = doc.add_paragraph()
set_paragraph_format(para8)
body_text8 = '''（一）立即开展针对高风险群体的专项安全预警。建议由国家网络安全主管部门牵头，立即对以下群体发布专项安全警示：1.现任及离职政府官员、军事人员；2.驻外外交人员及商务参赞；3.从事国际报道的媒体记者；4.参与国际贸易谈判的企业高管；5.在海外设立机构的高校及科研院所人员。预警内容应包括：停止使用Signal、WhatsApp处理任何涉及公务或敏感信息的通信；在必须使用时应启用端到端加密并严格验证对方身份；定期检查账户关联设备列表，及时移除未知设备。'''
run8 = para8.add_run(body_text8)
run8.font.name = '仿宋_GB2312'
run8.font.size = Pt(16)
run8._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para9 = doc.add_paragraph()
set_paragraph_format(para9)
body_text9 = '''（二）推动党政机关建立安全通讯替代方案。建议相关部门研究制定针对特定场景的安全通讯规范，明确要求：1.涉及国家秘密的通信必须使用经安全认证的国产加密通信平台；2.与外国政府机构及国际组织的正式外交沟通，应通过外交渠道或专用加密链路进行；3.紧急情况下确需使用商业即时通讯工具时，应事先建立身份验证机制（如预先交换密钥或使用硬件安全密钥），并在通信结束后及时清除敏感信息。'''
run9 = para9.add_run(body_text9)
run9.font.name = '仿宋_GB2312'
run9.font.size = Pt(16)
run9._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para10 = doc.add_paragraph()
set_paragraph_format(para10)
body_text10 = '''（三）加强面向全社会的网络安全宣传教育。建议由网信部门组织制作防范钓鱼攻击的公益宣传材料，重点宣传：1."官方客服绝不会主动通过应用内消息、短信或社交媒体索要验证码"的核心理念；2.Signal和WhatsApp的官方支持渠道和求助方式；3.收到可疑消息时的正确处置流程（不点击链接、不提供验证码、第一时间向平台报告）。宣传对象应覆盖所有使用国际主流即时通讯工具的中国公民，特别是经常进行跨境通信的商务人群。'''
run10 = para10.add_run(body_text10)
run10.font.name = '仿宋_GB2312'
run10.font.size = Pt(16)
run10._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

para11 = doc.add_paragraph()
set_paragraph_format(para11)
body_text11 = '''（四）建立国家级网络威胁情报共享机制。建议依托国家计算机网络与信息安全管理中心（CNCERT）等现有机构，建立针对此类高级持续性威胁（APT）的专项情报共享机制：1.与CISA、FBI等外国网络安全机构建立 threat intel 交换渠道，及时获取第一手攻击活动信息；2.要求国内安全企业报送相关攻击活动监测数据，形成全国性威胁态势感知能力；3.对重点单位实施7×24小时安全监测，第一时间发现账户被入侵的异常情况；4.定期开展针对关键岗位人员的安全演练，提升实战防御能力。'''
run11 = para11.add_run(body_text11)
run11.font.name = '仿宋_GB2312'
run11.font.size = Pt(16)
run11._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')

# 保存文档
output_path = r'C:\Users\hyss\Desktop\0323（情报）【威胁情报】俄罗斯黑客大规模钓鱼攻击Signal与WhatsApp\0323（情报）【威胁情报】俄罗斯黑客大规模钓鱼攻击Signal与WhatsApp.docx'
doc.save(output_path)
print(f"文档已保存至: {output_path}")