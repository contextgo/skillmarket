# -*- coding: utf-8 -*-
import os
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

# 创建文档
doc = Document()

# 设置页面边距
sections = doc.sections
for section in sections:
    section.top_margin = Inches(1.46)
    section.bottom_margin = Inches(1.46)
    section.left_margin = Inches(1.1)
    section.right_margin = Inches(1.1)

# 设置中文字体
def set_chinese_font(run, font_name, font_size):
    run.font.name = font_name
    run.font.size = Pt(font_size)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)

# 标题
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = title.add_run('DarkSword iPhone零日漏洞利用工具包大规模扩散 数亿设备面临威胁')
set_chinese_font(run, '方正小标宋简体', 22)
run.bold = True

# 概览段
doc.add_paragraph()
overview = doc.add_paragraph()
run = overview.add_run('概览：')
set_chinese_font(run, '仿宋_GB2312', 16)
run.bold = True
overview_run = overview.add_run('2026年3月18日，安全研究人员披露发现名为"DarkSword"的iPhone零日漏洞利用工具包。该工具包由俄罗斯黑客开发，可通过感染网站自动入侵访问者的iOS设备，已导致数亿台iPhone面临被黑客完全控制的风险。')
set_chinese_font(overview_run, '仿宋_GB2312', 16)

# 一、基本情况
doc.add_paragraph()
h1 = doc.add_paragraph()
run = h1.add_run('一、基本情况')
set_chinese_font(run, '黑体', 16)
run.bold = True

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('2026年3月18日，谷歌、iVerify和Lookout三家安全公司联合披露，发现俄罗')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('斯黑客组织使用名为"DarkSword"的先进iPhone漏洞利用工具包。该工具包以')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('网站为载体，嵌入到正常的乌克兰新闻网站和政府机构网站中，当用户访问这些')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('受感染网站时，即可在用户不知情的情况下自动入侵其iPhone设备。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('该漏洞利用工具包针对运行iOS 18的设备，虽然Apple已发布安全更新修复')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('该漏洞，但截至上月底，约四分之一的iPhone用户仍在使用存在漏洞的iOS 18')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('版本，涉及数亿台设备。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('值得注意的是，黑客在使用该工具包时留下了完整的、未混淆的DarkSword')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('源代码（含英文注释说明），使得任何人都可以轻易获取并重新使用该工具')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('包发动攻击。')
set_chinese_font(run, '仿宋_GB2312', 16)

# 二、事件影响
doc.add_paragraph()
h1 = doc.add_paragraph()
run = h1.add_run('二、事件影响')
set_chinese_font(run, '黑体', 16)
run.bold = True

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('一）大规模设备感染风险：该工具包可自动入侵访问受感染网站的用')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('户设备，安全研究人员指出"大量iOS用户仅因访问热门网站就可能导致其所有')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('个人数据被窃取"。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('二）敏感数据窃取：该工具包可窃取用户密码、照片、iMessage、')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('WhatsApp和Telegram消息、浏览器历史记录、日历和备忘录数据，甚至 Apple')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('Health应用中的健康数据。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('三）加密货币盗窃：除间谍活动外，该工具包还窃取用户加密货币钱包')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('凭证，表明攻击者可能同时从事盈利性网络犯罪。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = p = doc.add_paragraph()
run = p.add_run('四）工具包快速扩散：研究人员发现该工具包已被多个黑客组织使用，')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('包括针对沙特阿拉伯、土耳其和马来西亚目标的黑客活动。土耳其安全监控公司')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('PARS Defense的客户似乎也使用了该入侵工具。')
set_chinese_font(run, '仿宋_GB2312', 16)

# 三、对策建议
doc.add_paragraph()
h1 = doc.add_paragraph()
run = h1.add_run('三、对策建议')
set_chinese_font(run, '黑体', 16)
run.bold = True

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('一）立即更新iOS系统：Apple已发布安全更新修复该漏洞，用户应立即')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('将设备更新至最新版本的iOS系统。对于无法运行iOS 26的旧设备，Apple也')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('发布了紧急安全更新。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('二）启用Lockdown Mode：iOS的严格安全设置Lockdown Mode可有效防护')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('此类漏洞利用攻击，建议高风险用户启用该功能。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('三）谨慎访问网站：在浏览网页时保持警惕，避免访问不可信的新闻网站')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('或政府机构网站，尤其是涉及敏感地区（如乌克兰相关）的网站。')
set_chinese_font(run, '仿宋_GB2312', 16)

doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('四）定期检查设备：定期检查iPhone的"设置-通用-传输或还原iPhone"')
set_chinese_font(run, '仿宋_GB2312', 16)
run = p.add_run('中的"还原"选项，查看是否有未知的已连接设备，并及时移除可疑设备。')
set_chinese_font(run, '仿宋_GB2312', 16)

# 保存文档
output_path = r'C:\Users\hyss\Desktop\0323（情报）【威胁情报】DarkSword iPhone零日漏洞利用工具包\0323（情报）【威胁情报】DarkSword iPhone零日漏洞利用工具包.docx'
doc.save(output_path)
print(f'Document saved to: {output_path}')