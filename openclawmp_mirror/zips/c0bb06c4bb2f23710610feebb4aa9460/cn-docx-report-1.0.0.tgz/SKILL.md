---
name: cn-docx-report
description: "自动生成中文公文格式Word报告，支持方正小标宋、仿宋_GB2312等字体"
version: 1.0.0
displayName: 中文Word报告生成器
tags: ["docx", "word", "中文", "报告", "公文"]
---

# 中文Word报告生成器 (cn-docx-report)

使用 python-docx 自动生成符合中文公文规范（党政机关公文格式）的 Word 文档。

## 功能

- 中文标题格式：方正小标宋简体 22pt 加粗居中
- 中文正文格式：仿宋_GB2312 16pt，首行缩进2字符，1.5倍行距
- 一级标题：黑体 16pt 加粗
- 标准化页面边距：上下1.46英寸，左右1.1英寸
- 完整中文排版样式系统

## 依赖

```bash
pip install python-docx
```

## 使用方法

运行脚本生成报告：

```bash
python generate_threat_intel.py
```

默认输出到用户桌面 `~/Desktop/threat_intel_report.docx`

## 核心函数

### set_paragraph_format(para)
设置段落格式：仿宋_GB2312、三号字、首行缩进、1.5倍行距

### add_heading_with_style(doc, text, level)
添加带中文样式的标题

### add_content_paragraph(doc, text)
添加正文段落

## 自定义

修改脚本中的以下配置：

```python
# 页面边距
section.top_margin = Inches(1.46)
section.bottom_margin = Inches(1.46)

# 标题字体
title_style.font.name = '方正小标宋简体'
title_style.font.size = Pt(22)

# 正文字体
para.runs[0]._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')
```

## 适用场景

- 威胁情报报告
- 政府公文
- 企业报告
- 任何需要中文规范格式的 Word 文档