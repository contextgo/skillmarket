# 「职」属于你 /zhi-shu-yu-ni

**「职」属于你 — 你的职业方向,不应该是别人选剩的。**

这个技能从中国大陆应届/在校毕业生的可迁移技能出发,先排除 3 个显而易见的邻近岗位(那是大家都看得见的路径),再帮你找出 5–7 条真正属于你的非显然方向。每条方向带可复现的检索配方(平台+关键词+筛选+5 家示例公司),不编造投递链接;若运行时支持 WebSearch 则补充验证后的真实在招岗位。覆盖 大厂校招 / 国央企编制 / 选调考公 / 早期创业 等多档轨道,按低/中/高三档风险路由,内置两遍自检协议,确保输出可审计、不空话。**最终输出 markdown(在 chat 内查看 + 迭代)+ `.docx` 文件(供保存 / 分享 / 打印 / 给家人朋友看)。**

## 功能特性

- **「专属方向」发现机制**:每次生成前先列出 3 个显而易见的邻近岗位并**排除**,把"别人选剩的"先剔掉,剩下的才是真正属于你的
- **可迁移技能驱动**:不看专业看技能,从你已有的技能映射到不同行业的真实岗位
- **风险档位路由**:低/中/高三档,自动调整体制内 / 大厂 / 创业 路径的比例分布
- **检索配方,不编造链接**:每条方向给可复现的 平台 + 关键词组合 + 筛选 + 5 家示例公司,不输出虚假 URL
- **WebSearch opportunistic**:若运行时提供 WebSearch,自动验证真实在招岗位并标注 `WebSearch verified, YYYY-MM-DD`
- **中国大陆校招市场专属**:秋招/春招/补录 时间窗口、牛客/实习僧/BOSS直聘 平台地图、985/211/双非/户口/编制 信号系统
- **两遍自检协议**:8 项打分块 `<self-check>` 必须可见,任意项 = 0 → 自动重写对应章节
- **双输出**:chat 内 markdown(供查看 + 迭代) + `.docx` 附件(供保存 / 分享 / 打印 / 给家人朋友看)
- **迭代友好**:支持 `排除 #2 #5,再来 3 条偏 [方向]` 的增量探索

## 安装

```bash
openclawmp install skill/zhi-shu-yu-ni --target-dir ./skills
```

> SkillHub 元数据 `name` 字段必须为 ASCII(由上传规范规定),所以安装命令使用拼音 slug `zhi-shu-yu-ni`;chat 中的触发命令 `/「职」属于你` 与显示名称 `「职」属于你` 全部为中文。

### 系统依赖(.docx 渲染)

`.docx` 输出依赖 [pandoc](https://pandoc.org/installing.html)(由 `scripts/render-docx.py` 调用)。如果运行环境没有 pandoc,本技能会自动降级到「仅 markdown 输出」并在末尾给出安装提示 — 不会失败。

```bash
# macOS
brew install pandoc

# Debian / Ubuntu
sudo apt install pandoc

# Windows
winget install --id JohnMacFarlane.Pandoc
```

## 使用方法

### 1. 完整流程

输入 `/「职」属于你`、`/职属于你` 或 `/找属于我的职业`,按提示填写 5 个字段:

- **当前职位 / 背景**:学校 + 专业 + 年级,或第一份工作的岗位 + 公司类型
- **主要技能与优势**:技术栈 + 项目 + 真实可证明的能力
- **工作之外兴趣爱好**:至少 2 个,带「频率/深度」证据
- **工作环境偏好**:通勤、城市、出差、远程容忍度
- **风险承受能力**:低 / 中 / 高 + 一句解释

输入过短或过笼统,代理会先发起最多 3 个澄清追问,再生成方向。

### 2. 迭代探索

```
排除 #2 #5,再来 3 条更偏 [文创/科研/行政]
深入 #3
把 #1 的薪资范围换成上海 2025
```

### 3. 仅输出 markdown(跳过 .docx)

适合纯 chat 场景,或不需要 Word 文件时:

```
/「职」属于你 no-docx
```

### 4. 输出结构

每次输出包含(markdown 与 .docx 内容一致):

- 当前求职窗口(秋招/春招/补录/实习季)
- 可迁移技能总结
- 已排除的显然路径(反例,3 条)
- 真正属于你的职业方向(5–7 条,每条:行业/轨道/风险档位/技能匹配/入门 3 步/薪资估算/检索配方)
- 快速取胜的机会(本周/本月/本季度 各 1 条)
- 现实检验
- `<self-check>` 自检块(8 项 0/1)

## 与其他技能的搭配

| 技能 | 用法 |
|---|---|
| **`/resume-parser`** | 探索方向用「职」属于你,简历自检 JD 匹配度用 resume-parser,组合形成「方向 → 简历」闭环 |
| **`/zhide-offer`** | 「职」属于你 输出方向后,用 zhide-offer 查具体岗位 + 面经,补充检索配方的真实数据 |
| **`/compact`** | 长会话中压缩 「职」属于你 历史,保留排除列表 + 已生成方向 |

## 配置说明

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `min_paths` | 最少方向数 | 5 |
| `max_paths` | 最多方向数 | 7 |
| `excluded_obvious_count` | 必须先排除的显然路径数 | 3 |
| `clarification_max_turns` | 澄清门最多追问次数 | 3 |
| `websearch_max_per_path` | WebSearch 验证岗位上限/方向 | 5 |
| `render_docx_default` | 默认是否生成 .docx | true |

## 依赖

- StepClaw ≥ 0.3.0
- 推荐模型:Step-3.5-flash 及以上 / Claude Opus 4.7 / 同级 frontier LLM
- WebSearch 工具(可选,无则自动降级为检索配方模式)
- pandoc(系统依赖,可选,无则自动降级为仅 markdown)
- Python 3.8+(用于 `scripts/render-docx.py`,仅依赖 stdlib)

## 资产结构

```
「职」属于你/
├── .metadata.json           # 资产元数据(name=zhi-shu-yu-ni, displayName=「职」属于你)
├── README.md                # 本文件
├── SKILL.md                 # Skill 完整定义(触发、运行时行为、系统提示词)
├── scripts/
│   ├── README.md            # 脚本说明
│   └── render-docx.py       # markdown → .docx (pandoc)
└── references/
    ├── schema.json          # 输出 JSON Schema
    └── example-output.md    # 一份完整示例(小学教师 → 5 条方向)
```

## 边界

- 仅服务 **中国大陆校招市场**,海外/港澳/新加坡求职建议另开 thread
- 仅服务 **应届/在校** 或 应届身份保留期内,社招/3 年+ 经验请改用通用职业规划 prompt
- 不输出:鸡汤、套话、未经验证的 URL

## 反馈

按 StepClaw 用户 FAQ 手册流程反馈:

```
【阶跃号】<UID>
【设备ID】<DID>
【技能】/「职」属于你 (zhi-shu-yu-ni v1.2.0)
【问题描述】...
```

---

*作者:LiXuan@StepFun · 2026-04-27*
