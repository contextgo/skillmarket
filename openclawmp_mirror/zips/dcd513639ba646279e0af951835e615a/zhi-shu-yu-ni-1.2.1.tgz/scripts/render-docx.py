#!/usr/bin/env python3
"""Render /「职」属于你 (zhi-shu-yu-ni) markdown output to a .docx file.

Reads markdown from stdin (or a file path passed as --input), writes .docx to
the path given by --output (or a timestamped default in the current directory).

Default backend: pandoc (recommended). If pandoc is unavailable, the script
exits with install instructions rather than silently producing degraded output.

Usage:
    cat output.md | render-docx.py
    cat output.md | render-docx.py --output ~/Desktop/「职」属于你.docx
    render-docx.py --input output.md --output report.docx
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

PANDOC_INSTALL_HINTS = (
    "pandoc not found. Install one of:\n"
    "  macOS:        brew install pandoc\n"
    "  Debian/Ubuntu: sudo apt install pandoc\n"
    "  Windows:      winget install --id JohnMacFarlane.Pandoc\n"
    "  Other:        https://pandoc.org/installing.html"
)


def render(md_text: str, out_path: Path) -> Path:
    if not shutil.which("pandoc"):
        raise RuntimeError(PANDOC_INSTALL_HINTS)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    subprocess.run(
        [
            "pandoc",
            "--from", "gfm+pipe_tables",
            "--to", "docx",
            "--standalone",
            "--output", str(out_path),
        ],
        input=md_text,
        encoding="utf-8",
        check=True,
    )
    return out_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render /「职」属于你 (zhi-shu-yu-ni) markdown output to .docx via pandoc."
    )
    parser.add_argument(
        "--input", "-i",
        type=Path,
        help="Markdown file to read. If omitted, reads from stdin.",
    )
    parser.add_argument(
        "--output", "-o",
        type=Path,
        help="Output .docx path. Defaults to ./「职」属于你-YYYYMMDD-HHMMSS.docx",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.input:
        md_text = args.input.read_text(encoding="utf-8")
    else:
        md_text = sys.stdin.read()

    if not md_text.strip():
        print("error: empty markdown input", file=sys.stderr)
        return 2

    out_path = args.output or Path(
        f"「职」属于你-{datetime.now():%Y%m%d-%H%M%S}.docx"
    )

    try:
        result = render(md_text, out_path)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 3
    except subprocess.CalledProcessError as e:
        print(f"error: pandoc failed with exit code {e.returncode}", file=sys.stderr)
        return 4

    print(result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
