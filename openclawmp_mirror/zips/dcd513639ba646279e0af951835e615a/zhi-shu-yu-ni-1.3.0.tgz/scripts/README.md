# 「职」属于你/scripts

`render-docx.py` — converts /「职」属于你 (zhi-shu-yu-ni) markdown output to a `.docx` file.

## System dependency

Requires [pandoc](https://pandoc.org/installing.html). The script does not bundle pandoc; install it once on the host:

```bash
# macOS
brew install pandoc

# Debian / Ubuntu
sudo apt install pandoc

# Windows
winget install --id JohnMacFarlane.Pandoc
```

No Python packages are required (the script uses only stdlib).

## Usage

```bash
# from stdin
cat output.md | python3 render-docx.py

# from file, custom output path
python3 render-docx.py --input output.md --output ~/Desktop/「职」属于你.docx
```

Stdout = the absolute path of the generated `.docx`.

## Why pandoc

The /「职」属于你 output contains H2/H3 headings, pipe tables (`<self-check>` block), bullet lists, bold runs, and code blocks. pandoc handles all of these in one shot with sane Word styling. A pure-Python alternative (`python-docx` + custom markdown parser) would take 150+ lines and reproduce edge cases pandoc already gets right.

## Exit codes

| code | meaning |
|---|---|
| 0 | success — `.docx` written, path printed to stdout |
| 2 | empty markdown input |
| 3 | pandoc not installed (install hints printed to stderr) |
| 4 | pandoc invocation failed (exit code propagated) |

---

## Note: browser-attach (档位 A) requires no script

The §十三 Browser-attach 实时检索协议 is driven by Playwright MCP tool calls from the skill prompt itself — there is no Python wrapper in this directory for it. Setup is documented in the top-level `README.md` under「浏览器接入(可选)」.
