---
name: reddit-daily-news
description: "每日早盘热点新闻推送技能。每天早上9点自动从Reddit获取政治、金融热点新闻，过滤后整理成简报推送给用户。触发场景：'推送今日新闻'、'获取reddit热点'、'每日早报'、'新闻推送'。数据来源：reddit.com 的 r/politics、r/business、r/worldnews 等版块。"
---

# Reddit 每日热点新闻推送

## 技能概述

本技能通过 Reddit API 获取英文热点新闻，自动过滤政治、金融相关主题，每天早上9点定时推送给用户。

## 数据来源

- **政治新闻**: r/politics (美国政治为主)
- **商业财经**: r/business, r/economics, r/wallstreetbets
- **全球要闻**: r/worldnews, r/news
- **金融投资**: r/investing, r/stocks

## 使用方式

### 立即执行

用户说"推送今日新闻"或类似指令时，立即执行新闻抓取和推送。

### 定时任务

每天早上9:00（北京时间）自动执行，通过 OpenClaw cron 调度。

## 新闻抓取流程

### Step 1: 获取 Reddit 热帖

使用 `scripts/fetch_reddit_news.py` 脚本获取目标版块的热帖：

```bash
python scripts/fetch_reddit_news.py --subreddits politics,business,worldnews --limit 30
```

脚本会返回热门帖子列表，包含：
- 标题 (title)
- 点赞数 (score)
- 评论数 (num_comments)
- 发布时间 (created_utc)
- URL 链接 (url)

### Step 2: 过滤与筛选

根据以下条件过滤低质量内容：
- 点赞数 >= 100（热门门槛）
- 非推广/广告内容
- 标题清晰可读

### Step 3: 分类整理

将新闻分为三大类：
1. **政治要闻** 🏛️ - 国际政治、大选、政策动向
2. **金融财经** 💰 - 股市、经济数据、行业动态
3. **市场热点** 📊 - 交易机会、板块动向、机构观点

### Step 4: 生成报告

整理成如下格式的报告：

```
📰 早盘热点新闻 | 2026年4月2日 09:00

【政治要闻】🏛️
1. [标题]
   来源: r/politics | 👍 12,345 | 💬 567
   摘要: ...
   
【金融财经】💰
...

【市场热点】📊
...
```

## 输出格式

- 使用 emoji 分类标识
- 包含 Reddit 原始链接（供深度阅读）
- 简洁摘要，一眼看懂
- 推送到用户指定的飞书群/频道

## 参考文档

- Reddit API 设置: `references/reddit_api.md`
- 支持的 Reddit 版块列表: `references/subreddits.md`
