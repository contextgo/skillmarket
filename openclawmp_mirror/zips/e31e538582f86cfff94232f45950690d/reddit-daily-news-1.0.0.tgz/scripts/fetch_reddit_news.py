"""
Reddit Daily News Fetcher
从 Reddit 获取政治、金融热点新闻

依赖安装: pip install requests praw
"""

import argparse
import json
import time
from datetime import datetime

# 尝试使用 praw (官方Reddit API库)，否则回退到 requests
try:
    import praw
    USE_PRAW = True
except ImportError:
    import requests
    USE_PRAW = False


def fetch_with_praw(subreddits: list, limit: int = 30) -> list:
    """使用 PRAW 库获取 Reddit 热帖"""
    
    # 从环境变量获取 Reddit API 凭证
    import os
    client_id = os.environ.get('REDDIT_CLIENT_ID')
    client_secret = os.environ.get('REDDIT_CLIENT_SECRET')
    user_agent = os.environ.get('REDDIT_USER_AGENT', 'OpenClaw-NewsBot/1.0')
    
    if not client_id or not client_secret:
        print("[WARN] Reddit API credentials not found in environment variables.")
        print("[INFO] Falling back to public access mode...")
        return fetch_with_requests(subreddits, limit)
    
    reddit = praw.Reddit(
        client_id=client_id,
        client_secret=client_secret,
        user_agent=user_agent
    )
    
    posts = []
    for sub in subreddits:
        subreddit = reddit.subreddit(sub)
        for post in subreddit.hot(limit=limit):
            posts.append({
                'title': post.title,
                'score': post.score,
                'num_comments': post.num_comments,
                'created_utc': post.created_utc,
                'url': post.url,
                'permalink': post.permalink,
                'subreddit': sub,
                'link': f"https://reddit.com{post.permalink}"
            })
    
    return posts


def fetch_with_requests(subreddits: list, limit: int = 30) -> list:
    """使用 requests 回退方案（公共RSS/API）"""
    posts = []
    
    # 使用 Reddit 的 JSON API（无需认证的公开接口）
    for sub in subreddits:
        url = f"https://www.reddit.com/r/{sub}/hot/.json?limit={limit}"
        
        try:
            headers = {
                'User-Agent': 'OpenClaw-NewsBot/1.0 (news aggregator)',
                'Accept': 'application/json'
            }
            resp = requests.get(url, headers=headers, timeout=10)
            
            if resp.status_code == 200:
                data = resp.json()
                children = data.get('data', {}).get('children', [])
                
                for child in children:
                    post_data = child.get('data', {})
                    posts.append({
                        'title': post_data.get('title', ''),
                        'score': post_data.get('score', 0),
                        'num_comments': post_data.get('num_comments', 0),
                        'created_utc': post_data.get('created_utc', 0),
                        'url': post_data.get('url', ''),
                        'permalink': post_data.get('permalink', ''),
                        'subreddit': sub,
                        'link': f"https://reddit.com{post_data.get('permalink', '')}"
                    })
        except Exception as e:
            print(f"[ERROR] Failed to fetch r/{sub}: {e}")
        
        # 避免请求过快
        time.sleep(0.5)
    
    return posts


def filter_posts(posts: list, min_score: int = 100) -> list:
    """过滤低质量帖子"""
    filtered = [p for p in posts if p['score'] >= min_score]
    # 按热度排序
    filtered.sort(key=lambda x: x['score'], reverse=True)
    return filtered


def categorize_posts(posts: list) -> dict:
    """将帖子分类"""
    
    # 政治关键词
    politics_keywords = [
        'trump', 'biden', 'president', 'congress', 'senate', 'election',
        'government', 'policy', 'law', 'court', 'supreme', 'democrat',
        'republican', 'vote', 'campaign', 'party', 'minister', 'prime minister',
        'parliament', 'political', 'diplomatic', 'sanction', 'treaty',
        'china', 'russia', 'ukraine', 'israel', 'iran', 'north korea'
    ]
    
    # 金融关键词
    finance_keywords = [
        'stock', 'market', 'fed', 'federal reserve', 'inflation', 'gdp',
        'economy', 'economic', 'interest rate', 'bond', 'treasury',
        'dollar', 'yuan', 'euro', 'currency', 'forex', 'trade',
        'earnings', 'revenue', 'profit', 'loss', 'quarterly', 'annual',
        'investment', 'investor', 'bank', 'financing', 'ipo',
        'bitcoin', 'crypto', 'ethereum', 'oil', 'gold', 'commodity'
    ]
    
    categorized = {
        'politics': [],
        'finance': [],
        'other': []
    }
    
    for post in posts:
        title_lower = post['title'].lower()
        
        # 判断类别
        is_politics = any(kw in title_lower for kw in politics_keywords)
        is_finance = any(kw in title_lower for kw in finance_keywords)
        
        if is_politics:
            categorized['politics'].append(post)
        elif is_finance:
            categorized['finance'].append(post)
        else:
            categorized['other'].append(post)
    
    return categorized


def format_timestamp(utc_timestamp: float) -> str:
    """格式化时间戳"""
    dt = datetime.fromtimestamp(utc_timestamp)
    return dt.strftime('%Y-%m-%d %H:%M')


def generate_report(posts: list, min_score: int = 100) -> str:
    """生成新闻报告"""
    
    filtered = filter_posts(posts, min_score)
    categorized = categorize_posts(filtered)
    
    now = datetime.now().strftime('%Y年%m月%d日 %H:%M')
    
    report_lines = [
        f"📰 早盘热点新闻 | {now}",
        "",
        "=" * 50,
        "",
        "【政治要闻】🏛️",
        ""
    ]
    
    for i, post in enumerate(categorized['politics'][:5], 1):
        report_lines.extend([
            f"{i}. {post['title']}",
            f"   来源: r/{post['subreddit']} | 👍 {post['score']:,} | 💬 {post['num_comments']:,}",
            f"   🔗 {post['link']}",
            ""
        ])
    
    report_lines.extend([
        "【金融财经】💰",
        ""
    ])
    
    for i, post in enumerate(categorized['finance'][:5], 1):
        report_lines.extend([
            f"{i}. {post['title']}",
            f"   来源: r/{post['subreddit']} | 👍 {post['score']:,} | 💬 {post['num_comments']:,}",
            f"   🔗 {post['link']}",
            ""
        ])
    
    report_lines.extend([
        "【其他热点】📊",
        ""
    ])
    
    for i, post in enumerate(categorized['other'][:3], 1):
        report_lines.extend([
            f"{i}. {post['title']}",
            f"   来源: r/{post['subreddit']} | 👍 {post['score']:,}",
            f"   🔗 {post['link']}",
            ""
        ])
    
    report_lines.extend([
        "=" * 50,
        "",
        "🤖 由 OpenClaw Joker 生成 | 数据来源: Reddit"
    ])
    
    return "\n".join(report_lines)


def main():
    parser = argparse.ArgumentParser(description='Reddit Daily News Fetcher')
    parser.add_argument(
        '--subreddits', 
        default='politics,business,worldnews,news,investing',
        help='要抓取的 subreddit 列表，用逗号分隔'
    )
    parser.add_argument(
        '--limit', 
        type=int, 
        default=30,
        help='每个版块抓取的帖子数量'
    )
    parser.add_argument(
        '--min-score',
        type=int,
        default=100,
        help='最低点赞数门槛'
    )
    parser.add_argument(
        '--output',
        choices=['text', 'json'],
        default='text',
        help='输出格式'
    )
    
    args = parser.parse_args()
    
    subreddits = [s.strip() for s in args.subreddits.split(',')]
    
    print(f"[INFO] Fetching posts from: {', '.join(subreddits)}")
    
    if USE_PRAW:
        posts = fetch_with_praw(subreddits, args.limit)
    else:
        posts = fetch_with_requests(subreddits, args.limit)
    
    print(f"[INFO] Fetched {len(posts)} posts")
    
    if args.output == 'json':
        # 输出 JSON 格式
        filtered = filter_posts(posts, args.min_score)
        categorized = categorize_posts(filtered)
        print(json.dumps(categorized, ensure_ascii=False, indent=2))
    else:
        # 输出文本报告
        report = generate_report(posts, args.min_score)
        print(report)


if __name__ == '__main__':
    main()
