# Reddit API 设置指南

## 方式一：使用 PRAW（推荐）

### 1. 创建 Reddit 应用

1. 访问 https://www.reddit.com/prefs/apps
2. 点击 "Create App" 或 "Create Another App"
3. 选择 "script" 类型
4. 填写：
   - **name**: OpenClaw-NewsBot
   - **description**: News aggregator for OpenClaw
   - **redirect uri**: http://localhost:8080

### 2. 获取凭证

创建后会获得：
- `client_id`: 位于应用名称下方的 14 位字符
- `client_secret`: "secret" 字段的值

### 3. 设置环境变量

```bash
# Windows
set REDDIT_CLIENT_ID=your_client_id
set REDDIT_CLIENT_SECRET=your_client_secret
set REDDIT_USER_AGENT=OpenClaw-NewsBot/1.0

# Linux/Mac
export REDDIT_CLIENT_ID=your_client_id
export REDDIT_CLIENT_SECRET=your_client_secret
export REDDIT_USER_AGENT=OpenClaw-NewsBot/1.0
```

## 方式二：公共访问（无需认证）

脚本默认使用 Reddit 的公共 JSON API，无需认证即可访问热门帖子。

**限制**：
- 请求频率受限
- 可能遇到 rate limiting

## 方式三：在 OpenClaw 中配置

在 OpenClaw 的环境变量配置中添加：

```
REDDIT_CLIENT_ID=your_client_id
REDDIT_CLIENT_SECRET=your_client_secret
```

## Rate Limit 处理

Reddit API 有速率限制：
- 公共 API: 约 60 请求/分钟
- 认证 API: 约 600 请求/分钟

脚本内置了 0.5 秒的请求间隔以避免触发限制。
