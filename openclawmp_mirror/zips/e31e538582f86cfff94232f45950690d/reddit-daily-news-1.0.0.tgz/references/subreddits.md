# Reddit 版块参考列表

## 政治新闻

| 版块 | 描述 | 热度 |
|------|------|------|
| r/politics | 美国政治新闻 | 极高 |
| r/worldnews | 国际新闻 | 极高 |
| r/news | 综合新闻 | 极高 |
| r/ geopolitics | 地缘政治 | 高 |

## 金融财经

| 版块 | 描述 | 热度 |
|------|------|------|
| r/business | 商业新闻 | 高 |
| r/economics | 经济学讨论 | 高 |
| r/wallstreetbets | 散户投资 | 极高 |
| r/investing | 投资讨论 | 高 |
| r/stocks | 股票讨论 | 高 |
| r/personalfinance | 个人理财 | 中高 |
| r/finance | 金融综合 | 中 |

## 默认抓取列表

```
politics, business, worldnews, news, investing
```

## 可选扩展列表

```
wallstreetbets, economics, stocks, personalfinance, finance
```

## 过滤说明

- **r/wallstreetbets**: 散户情绪浓厚，信号较多噪音也较多
- **r/politics**: 仅限美国政治，海外政治新闻主要在 r/worldnews
- **r/investing**: 专业投资者为主，质量较高
