#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
转行决策分析报告生成器
生成Word格式的转行决策分析文档
"""

import json
import sys
from datetime import datetime
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def set_chinese_font(run, font_name='微软雅黑', font_size=11, bold=False, color=None):
    """设置中文字体"""
    font = run.font
    font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    font.size = Pt(font_size)
    font.bold = bold
    if color:
        font.color.rgb = RGBColor(*color)

def add_heading_zh(doc, text, level=1):
    """添加中文标题"""
    heading = doc.add_heading(level=level)
    run = heading.add_run(text)
    if level == 1:
        set_chinese_font(run, '微软雅黑', 18, True, (0, 112, 192))
        heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif level == 2:
        set_chinese_font(run, '微软雅黑', 14, True, (0, 112, 192))
    else:
        set_chinese_font(run, '微软雅黑', 12, True)
    return heading

def add_paragraph_zh(doc, text, bold=False, color=None, alignment=WD_ALIGN_PARAGRAPH.LEFT):
    """添加中文段落"""
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_chinese_font(run, '微软雅黑', 11, bold, color)
    p.alignment = alignment
    return p

def generate_career_report(user_data, output_path=None):
    """生成转行决策分析报告Word文档"""
    
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = '微软雅黑'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    
    # 封面
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()
    
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('转行决策分析报告')
    set_chinese_font(run, '微软雅黑', 28, True, (0, 112, 192))
    
    doc.add_paragraph()
    
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run('——系统分析，理性决策')
    set_chinese_font(run, '微软雅黑', 14, False, (128, 128, 128))
    
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 日期
    date_p = doc.add_paragraph()
    date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = date_p.add_run(f'生成日期：{datetime.now().strftime("%Y年%m月%d日")}')
    set_chinese_font(run, '微软雅黑', 11)
    
    doc.add_page_break()
    
    # 一、决策背景
    add_heading_zh(doc, '一、决策背景', 2)
    
    add_paragraph_zh(doc, '当前状况：', bold=True)
    current = user_data.get('current_situation', '_________________________________')
    add_paragraph_zh(doc, current)
    
    add_paragraph_zh(doc, '转行动机：', bold=True)
    motivation = user_data.get('motivation', '_________________________________')
    add_paragraph_zh(doc, motivation)
    
    add_paragraph_zh(doc, '目标行业/岗位：', bold=True)
    target = user_data.get('target', '_________________________________')
    add_paragraph_zh(doc, target)
    
    doc.add_paragraph()
    
    # 二、个人底层维度评估
    add_heading_zh(doc, '二、个人底层维度评估', 2)
    
    add_paragraph_zh(doc, '能力匹配度：', bold=True)
    ability = user_data.get('ability_match', '_________________________________')
    add_paragraph_zh(doc, ability)
    
    add_paragraph_zh(doc, '性格与特质匹配度：', bold=True)
    personality = user_data.get('personality_match', '_________________________________')
    add_paragraph_zh(doc, personality)
    
    add_paragraph_zh(doc, '兴趣与动机：', bold=True)
    interest = user_data.get('interest', '_________________________________')
    add_paragraph_zh(doc, interest)
    
    add_paragraph_zh(doc, '价值观契合度：', bold=True)
    values = user_data.get('values', '_________________________________')
    add_paragraph_zh(doc, values)
    
    score1 = user_data.get('score_personal', '___')
    add_paragraph_zh(doc, f'个人匹配度评分：{score1}/5', bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 三、行业维度评估
    add_heading_zh(doc, '三、行业维度评估', 2)
    
    add_paragraph_zh(doc, '行业趋势：', bold=True)
    trend = user_data.get('industry_trend', '_________________________________')
    add_paragraph_zh(doc, trend)
    
    add_paragraph_zh(doc, '市场需求：', bold=True)
    demand = user_data.get('market_demand', '_________________________________')
    add_paragraph_zh(doc, demand)
    
    add_paragraph_zh(doc, '地域差异：', bold=True)
    location = user_data.get('location_factor', '_________________________________')
    add_paragraph_zh(doc, location)
    
    add_paragraph_zh(doc, '行业天花板：', bold=True)
    ceiling = user_data.get('industry_ceiling', '_________________________________')
    add_paragraph_zh(doc, ceiling)
    
    score2 = user_data.get('score_industry', '___')
    add_paragraph_zh(doc, f'行业前景评分：{score2}/5', bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 四、岗位维度评估
    add_heading_zh(doc, '四、岗位维度评估', 2)
    
    add_paragraph_zh(doc, '工作内容：', bold=True)
    job_content = user_data.get('job_content', '_________________________________')
    add_paragraph_zh(doc, job_content)
    
    add_paragraph_zh(doc, '准入门槛：', bold=True)
    barrier = user_data.get('entry_barrier', '_________________________________')
    add_paragraph_zh(doc, barrier)
    
    add_paragraph_zh(doc, '成长路径：', bold=True)
    growth = user_data.get('growth_path', '_________________________________')
    add_paragraph_zh(doc, growth)
    
    add_paragraph_zh(doc, '薪资结构：', bold=True)
    salary = user_data.get('salary_structure', '_________________________________')
    add_paragraph_zh(doc, salary)
    
    score3 = user_data.get('score_job', '___')
    add_paragraph_zh(doc, f'岗位可行性评分：{score3}/5', bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 五、成本与风险维度评估
    add_heading_zh(doc, '五、成本与风险维度评估', 2)
    
    add_paragraph_zh(doc, '时间成本：', bold=True)
    time_cost = user_data.get('time_cost', '_________________________________')
    add_paragraph_zh(doc, time_cost)
    
    add_paragraph_zh(doc, '经济成本：', bold=True)
    money_cost = user_data.get('money_cost', '_________________________________')
    add_paragraph_zh(doc, money_cost)
    
    add_paragraph_zh(doc, '机会成本：', bold=True)
    opportunity_cost = user_data.get('opportunity_cost', '_________________________________')
    add_paragraph_zh(doc, opportunity_cost)
    
    add_paragraph_zh(doc, '家庭与生活风险：', bold=True)
    family_risk = user_data.get('family_risk', '_________________________________')
    add_paragraph_zh(doc, family_risk)
    
    score4 = user_data.get('score_risk', '___')
    add_paragraph_zh(doc, f'成本风险可控评分：{score4}/5', bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 六、长期发展维度评估
    add_heading_zh(doc, '六、长期发展维度评估', 2)
    
    add_paragraph_zh(doc, '可积累性：', bold=True)
    accumulation = user_data.get('accumulation', '_________________________________')
    add_paragraph_zh(doc, accumulation)
    
    add_paragraph_zh(doc, '跨界可能性：', bold=True)
    crossover = user_data.get('crossover', '_________________________________')
    add_paragraph_zh(doc, crossover)
    
    add_paragraph_zh(doc, '抗风险能力：', bold=True)
    risk_resistance = user_data.get('risk_resistance', '_________________________________')
    add_paragraph_zh(doc, risk_resistance)
    
    score5 = user_data.get('score_longterm', '___')
    add_paragraph_zh(doc, f'长期发展评分：{score5}/5', bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 七、综合评估
    add_heading_zh(doc, '七、综合评估', 2)
    
    # 评分汇总表
    table = doc.add_table(rows=7, cols=4)
    table.style = 'Light Grid Accent 1'
    
    headers = ['维度', '评分', '权重', '加权分']
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        run = cell.paragraphs[0].add_run(header)
        set_chinese_font(run, '微软雅黑', 10, True)
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    rows_data = [
        ['个人匹配度', str(score1), '25%', ''],
        ['行业前景', str(score2), '20%', ''],
        ['岗位可行性', str(score3), '20%', ''],
        ['成本风险可控', str(score4), '20%', ''],
        ['长期发展', str(score5), '15%', ''],
        ['总分', '-', '100%', user_data.get('total_score', '___')]
    ]
    
    for row_idx, row_data in enumerate(rows_data, 1):
        for col_idx, cell_data in enumerate(row_data):
            cell = table.rows[row_idx].cells[col_idx]
            run = cell.paragraphs[0].add_run(cell_data)
            set_chinese_font(run, '微软雅黑', 10)
            if row_idx == 6:  # 总分行
                set_chinese_font(run, '微软雅黑', 11, True, (0, 112, 192))
    
    doc.add_paragraph()
    
    add_paragraph_zh(doc, '决策建议：', bold=True)
    suggestion = user_data.get('suggestion', '_________________________________')
    add_paragraph_zh(doc, suggestion)
    
    doc.add_paragraph()
    
    # 八、落地执行方案
    add_heading_zh(doc, '八、落地执行方案', 2)
    
    add_paragraph_zh(doc, '调研计划：', bold=True)
    research_plan = user_data.get('research_plan', '_________________________________')
    add_paragraph_zh(doc, research_plan)
    
    add_paragraph_zh(doc, '过渡方案：', bold=True)
    transition = user_data.get('transition_plan', '_________________________________')
    add_paragraph_zh(doc, transition)
    
    add_paragraph_zh(doc, '时间规划：', bold=True)
    timeline = user_data.get('timeline', '_________________________________')
    add_paragraph_zh(doc, timeline)
    
    add_paragraph_zh(doc, '资源准备：', bold=True)
    resources = user_data.get('resources', '_________________________________')
    add_paragraph_zh(doc, resources)
    
    add_paragraph_zh(doc, '退路设计：', bold=True)
    backup_plan = user_data.get('backup_plan', '_________________________________')
    add_paragraph_zh(doc, backup_plan)
    
    doc.add_paragraph()
    
    # 九、行动清单
    add_heading_zh(doc, '九、行动清单', 2)
    
    add_paragraph_zh(doc, '本周行动：', bold=True)
    week1 = user_data.get('week1_action', '_________________________________')
    add_paragraph_zh(doc, week1)
    
    add_paragraph_zh(doc, '本月行动：', bold=True)
    month1 = user_data.get('month1_action', '_________________________________')
    add_paragraph_zh(doc, month1)
    
    add_paragraph_zh(doc, '三个月目标：', bold=True)
    month3 = user_data.get('month3_goal', '_________________________________')
    add_paragraph_zh(doc, month3)
    
    add_paragraph_zh(doc, '半年目标：', bold=True)
    month6 = user_data.get('month6_goal', '_________________________________')
    add_paragraph_zh(doc, month6)
    
    doc.add_paragraph()
    
    # 十、风险提示
    add_heading_zh(doc, '十、风险提示', 2)
    
    add_paragraph_zh(doc, '最大风险：', bold=True)
    max_risk = user_data.get('max_risk', '_________________________________')
    add_paragraph_zh(doc, max_risk)
    
    add_paragraph_zh(doc, '应对措施：', bold=True)
    countermeasure = user_data.get('countermeasure', '_________________________________')
    add_paragraph_zh(doc, countermeasure)
    
    add_paragraph_zh(doc, '止损点：', bold=True)
    stop_loss = user_data.get('stop_loss', '_________________________________')
    add_paragraph_zh(doc, stop_loss)
    
    doc.add_paragraph()
    
    # 十一、最终决策
    add_heading_zh(doc, '十一、最终决策', 2)
    
    decision = user_data.get('final_decision', '□ 转    □ 不转    □ 暂缓')
    add_paragraph_zh(doc, f'决策：{decision}', bold=True, color=(0, 112, 192))
    
    add_paragraph_zh(doc, '决策理由：', bold=True)
    reason = user_data.get('decision_reason', '_________________________________')
    add_paragraph_zh(doc, reason)
    
    add_paragraph_zh(doc, '下一步行动：', bold=True)
    next_step = user_data.get('next_step', '_________________________________')
    add_paragraph_zh(doc, next_step)
    
    doc.add_paragraph()
    
    # 结尾
    doc.add_paragraph()
    ending = doc.add_paragraph()
    ending.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = ending.add_run('🎯 选对赛道比努力重要，系统分析比冲动靠谱')
    set_chinese_font(run, '微软雅黑', 12, True, (0, 112, 192))
    
    # 保存文档
    if not output_path:
        output_path = f'转行决策分析报告_{datetime.now().strftime("%Y%m%d")}.docx'
    
    doc.save(output_path)
    print(f'✅ 转行决策分析报告已生成：{output_path}')
    return output_path

if __name__ == '__main__':
    # 示例数据
    example_data = {
        'current_situation': '目前在传统行业做行政工作5年，感觉发展受限',
        'motivation': '想转行到互联网运营，寻求更好的发展机会和薪资',
        'target': '互联网运营岗位',
        'ability_match': '有文案基础，沟通能力好，但需要学习数据分析',
        'personality_match': '性格外向，喜欢挑战，能接受加班',
        'interest': '对互联网产品感兴趣，经常研究各类App',
        'values': '更看重成长空间和薪资',
        'score_personal': '4',
        'industry_trend': '互联网行业仍在发展，但竞争激烈',
        'market_demand': '运营岗位需求大，但要求也越来越高',
        'location_factor': '所在城市互联网产业发达，不需要换城市',
        'industry_ceiling': '运营可以做到管理岗，35+仍有市场',
        'score_industry': '4',
        'job_content': '用户运营、活动策划、数据分析',
        'entry_barrier': '需要学习运营知识和工具，门槛中等',
        'growth_path': '运营专员→高级运营→运营经理→运营总监',
        'salary_structure': '底薪+绩效，初级6-8k，高级15-25k',
        'score_job': '4',
        'time_cost': '预计学习3-6个月',
        'money_cost': '培训费约5000-10000，空档期生活费约2万',
        'opportunity_cost': '放弃现有稳定工作，转行失败可能回不来',
        'family_risk': '单身，暂无家庭负担，父母支持',
        'score_risk': '3.5',
        'accumulation': '运营经验可以积累，越老越吃香',
        'crossover': '可以转产品、市场，也可以自由职业',
        'risk_resistance': '互联网行业波动大，但运营需求稳定',
        'score_longterm': '4',
        'total_score': '3.9',
        'suggestion': '可以考虑转行，但建议骑驴找马，先副业验证',
        'research_plan': '访谈3个在职运营，学习运营课程',
        'transition_plan': '在职期间学习，找到工作再辞职',
        'timeline': '3个月学习，1-2个月找工作',
        'resources': '存款3万，可以支撑6个月',
        'backup_plan': '如果3个月找不到，回原行业或降低预期',
        'week1_action': '报名运营课程，开始系统学习',
        'month1_action': '完成基础课程，搭建作品集',
        'month3_goal': '开始投递简历，争取面试机会',
        'month6_goal': '成功入职互联网运营岗位',
        'max_risk': '转行失败，空窗期长，经济压力大',
        'countermeasure': '保持学习，积累作品，降低预期先入行',
        'stop_loss': '如果6个月找不到工作，考虑回原行业',
        'final_decision': '□ 转    □ 不转    ☑ 暂缓（先准备）',
        'decision_reason': '个人匹配度高，但需要充分准备，降低风险',
        'next_step': '报名运营课程，3个月内完成学习'
    }
    
    generate_career_report(example_data)
