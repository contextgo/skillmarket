# Perplexity 搜索

AI 驱动的网络搜索，提供带有引用的可靠答案。

## 搜索

单个查询：
```bash
node {baseDir}/scripts/search.mjs "what's happening in AI today"
```

多个查询（批量）：
```bash
node {baseDir}/scripts/search.mjs "What is Perplexity?" "Latest AI news" "Best coffee in NYC"
```

## 选项

- `--json`: 输出原始 JSON 响应

## 注意事项

- 需要 `PERPLEXITY_API_KEY` 环境变量
- 响应中在可用时包含引用
- 批量查询在单个 API 调用中处理