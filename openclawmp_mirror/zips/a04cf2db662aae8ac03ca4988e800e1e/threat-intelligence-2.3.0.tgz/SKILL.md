---
name: threat-intelligence
description: "威胁情报分析技能。自动从国际网络安全媒体获取当天最新威胁情报，生成符合中文公文格式的Word报告，包含原文截图、译文截图、原文链接四个标准输出文件。"
version: 5.0.0
type: skill
tags:
  - threat-intelligence
  - security
  - docx
  - report
  - apt
  - malware
  - phishing
  - osint
---

# 威胁情报分析技能

## 用途

自动从国际网络安全媒体获取当天最新威胁情报，生成符合中文公文格式的威胁情报分析报告（Word文档），包含完整的取证材料。

## 标准输出（4个文件）

每个威胁情报报告必须包含以下4个文件：

| 序号 | 文件名 | 说明 |
|------|--------|------|
| 1 | `MMDD（情报）【威胁情报】标题.docx` | 中文威胁情报Word文档 |
| 2 | `原文截图.png` | 英文原文网页截图 |
| 3 | `译文截图.png` | Google翻译后的中文页面截图 |
| 4 | `原文链接.txt` | 原文URL链接（只保留1个主要来源） |

## 工作流程

### 标准操作流程（必须按顺序执行）

#### 步骤1：搜索最新威胁情报
- **首选方法：用 `browser` 工具访问**（默认无头模式，真实浏览器引擎，天然绕过 Cloudflare）
  - 使用 `browser` 工具（profile="openclaw"）访问 The Hacker News 首页
  - 滚动页面获取当天新闻列表，记录感兴趣文章的标题和 URL
  - 点击进入文章获取完整内容
- **备选方法：用 `web_fetch`**（The Register 无 Cloudflare 可用）
  - 访问 The Register：`https://www.theregister.com/security`
  - 或搜索关键词：`cybersecurity news today`、`APT attack`、`ransomware`、`zero-day`
- **优先选当天的新闻**（即今天的日期），如果没有当天新闻才用昨天的
- **推荐来源**：The Hacker News（内容最全）、The Register、BleepingComputer、SecurityWeek
- **无需打开可见浏览器**，默认 headless 模式即可绕过 Cloudflare

#### 步骤2：获取详细内容
- 步骤1中通过 Playwright 浏览器已获取文章内容，直接使用
- 提取关键信息：攻击者、目标、技术手段（漏洞编号CVE）、影响范围、时间线

#### 步骤3：生成Word文档
- 使用 Python + python-docx 生成标准格式文档
- 字体：方正小标宋简体（标题）、黑体（一级标题）、仿宋_GB2312（正文）
- 章节：标题、概览、一、基本情况、二、事件影响、三、对策建议

#### 步骤4：截取原文截图
- 使用 Edge 无头模式截取英文原文网页
```powershell
& "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" `
  --headless --disable-gpu --screenshot=原文截图.png `
  --window-size=1920,8000 "原文URL"
```
**⚠️ 关键要求**：
- **必须使用 `--headless` 参数**，不能打开可见浏览器窗口
- 必须使用 `--window-size=1920,8000` 确保足够大的视口截取全页内容
- 截图必须是整页截图，从页面顶部到底部

**⚠️ 浏览器使用规范（全程无头）：**
- **获取内容**：用 `browser` 工具（profile="openclaw"，默认无头模式即可绕过 Cloudflare）
- **截图**：用 Edge 无头模式（`--headless`）或 Python Playwright 无头模式
- 全程不需要打开可见浏览器窗口

#### 步骤5：截取译文截图（Playwright + Google翻译注入法）

**这是目前最可靠的方法**，能绕过 Cloudflare 拦截，保留原网页样式：

```javascript
// 1. 访问原网页（Playwright 能绕过 Cloudflare），等待完全加载，使用无头模式
await page.goto(url, { waitUntil: 'networkidle', headless: true });

// 2. 设置合适视口（确保清晰度）
await page.setViewportSize({ width: 1920, height: 1080 });

// 3. 注入 Google 翻译脚本
await page.evaluate(() => {
  const script = document.createElement('script');
  script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
  document.head.appendChild(script);

  window.googleTranslateElementInit = function() {
    new google.translate.TranslateElement({
      pageLanguage: 'en',
      includedLanguages: 'zh-CN',
      autoDisplay: false
    }, 'google_translate_element');
  };

  const div = document.createElement('div');
  div.id = 'google_translate_element';
  div.style.display = 'none';
  document.body.appendChild(div);
});

// 4. 等待脚本加载并触发翻译
await sleep(5000);
await page.evaluate(() => {
  const select = document.querySelector('.goog-te-combo');
  if (select) {
    select.value = 'zh-CN';
    select.dispatchEvent(new Event('change', { bubbles: true }));
  }
});

// 5. 等待翻译完成（等待时间要充足，至少10秒）
await sleep(10000);

// 6. 可选：再次触发翻译确保所有内容都翻译完成
await page.evaluate(() => {
  const select = document.querySelector('.goog-te-combo');
  if (select) {
    select.value = 'zh-CN';
    select.dispatchEvent(new Event('change', { bubbles: true }));
  }
});
await sleep(3000);

// 7. 激活中文显示（改 lang 和 class 属性）
await page.evaluate(() => {
  const html = document.documentElement;
  html.setAttribute('lang', 'zh-CN');
  html.classList.add('translated-ltr');

  const toolbar = document.querySelector('[role="toolbar"]');
  if (toolbar) toolbar.remove();

  document.querySelectorAll('iframe').forEach(el => {
    if (el.src && el.src.includes('translate')) {
      el.remove();
    }
  });
});

// 8. 截图（使用 fullPage: true 确保截取整个页面）
await page.screenshot({ path: screenshotPath, fullPage: true, type: 'png' });
```

**原理：**
- Playwright 能绕过 Cloudflare，直接访问原网页
- Google 翻译脚本把中文翻译内容注入到 DOM
- 改 `lang="zh-CN"` 和 `translated-ltr` class 激活中文 CSS 显示
- 既绕过了 Cloudflare，又保留了原网页完整样式

**优势：**
- 绕过 Cloudflare 拦截
- 保留原网页所有样式和布局
- 完整的中文翻译内容
- 全自动化

#### 步骤6：保存原文链接
- 创建 `原文链接.txt` 文件，**只保留1个主要来源URL**
- 优先选择 The Hacker News 或原始信息来源的URL

## 文档格式规范

### 字体设置
- **标题**：方正小标宋简体，二号（22pt），加粗，居中
- **一级标题**：黑体，三号（16pt），加粗（一、二、三）
- **正文**：仿宋_GB2312，三号（16pt），1.5倍行距，首行缩进2字符

### 页面设置
- **页面边距**：上下1.46英寸，左右1.1英寸
- **行距**：1.5倍行距

### 标准章节结构
1. **标题** - 威胁事件核心描述
2. **概览段** - 事件摘要（时间、攻击者、目标、技术手段）
3. **一、基本情况** - 详细事件描述、攻击者背景、技术细节（分点：（一）（二）（三））
4. **二、事件影响** - 影响分析（分点：（一）（二）（三））
5. **三、对策建议** - **重点针对中国提出应对策略**，分点阐述，每点单独成段

**核心写作要求**：

**① 称呼规范（重要！）：**
- 报告中涉及中国时，**必须使用"我国"**，不能用"中国"
- 这是上报材料的规范要求，"我国"体现正式性

**② 事件影响和对策建议是上报机关的核心内容，必须写得深入具体，不得水字数**
- 每一点都要有实质内容，紧扣文章实际情况
- 禁止套模板、堆砌空话、重复表述
- 分析角度要根据具体事件灵活选取，不固定套路
- 对策建议要具体可执行，不写"加强安全意识"这类空话
- 事件影响必须结合文章中提到的具体攻击手法、技术特点来分析

**③ 全文必须使用标准公文格式**
- 字体严格执行：方正小标宋简体（标题）、黑体（一级标题）、仿宋_GB2312（正文）
- 分点用"一、二、三"或"（一）（二）（三）"，不用数字序号或bullet

### Python代码格式模板

```python
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def create():
    doc = Document()
    for s in doc.sections:
        s.top_margin = Inches(1.46)
        s.bottom_margin = Inches(1.46)
        s.left_margin = Inches(1.1)
        s.right_margin = Inches(1.1)

    # 标题
    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run('报告标题')
    r.font.name = '方正小标宋简体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '方正小标宋简体')
    r.font.size = Pt(22)
    r.font.bold = True

    doc.add_paragraph()

    # 概览段
    p = doc.add_paragraph()
    r = p.add_run('概览内容...')
    r.font.name = '仿宋_GB2312'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')
    r.font.size = Pt(16)
    p.paragraph_format.first_line_indent = Inches(0.44)
    p.paragraph_format.line_spacing = 1.5

    # 一级标题
    h = doc.add_paragraph()
    r = h.add_run('一、基本情况')
    r.font.name = '黑体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    r.font.size = Pt(16)
    r.font.bold = True

    #正文（带二级标题）
    p = doc.add_paragraph()
    r = p.add_run('（一）攻击组织背景。具体内容...')
    r.font.name = '仿宋_GB2312'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')
    r.font.size = Pt(16)
    p.paragraph_format.first_line_indent = Inches(0.44)
    p.paragraph_format.line_spacing = 1.5

    doc.save('文件名.docx')

if __name__ == '__main__':
    create()
```

## 内容撰写要求

### 一、基本情况（必须包含）
- （一）攻击组织背景：APT组织名称、所属国家/机构、历史活动
- （二）攻击手法分析：具体技术手段、攻击流程、利用的漏洞或服务
- （三）技术特点研判：攻击的独特性、与其他攻击的关联性

### 二、事件影响（必须深入贴合文章实际，使用"我国"描述）
- （一）攻击组织背景与能力评估：基于文章实际描述分析其威胁水平
- （二）对我国的潜在威胁（**核心重点**）：
  - 必须结合文章中提到的具体攻击手法、技术特点来分析对我国的具体威胁
  - 要写出文章实际涉及的领域（如电信网络、政府网络等）在我国的情况
  - 不能套用通用模板，必须基于文章实际内容展开深入分析
  - 分析角度要灵活：可能是关键基础设施安全、人员安全、数据安全、供应链安全等
- （三）对全球网络安全格局的影响：基于文章实际内容分析

### 三、对策建议（必须可操作，使用"我国"描述）
- （一）安全意识/管理措施：针对文章中提到的威胁提出具体措施
- （二）技术防护措施：基于实际攻击手法给出可操作的技术方案
- （三）体系建设建议：结合文章分析的威胁现状提出体系建设方向
- （四）情报共享机制：如何获取和利用威胁情报
- （五）应急响应预案：针对此类攻击的应对预案

## 关键信息提取要点

生成报告前必须确认以下信息：

- [ ] **攻击时间**：具体日期或时间段
- [ ] **攻击者**：APT组织名称或威胁行为者
- [ ] **攻击目标**：受影响的行业、地区、组织类型
- [ ] **技术手段**：漏洞编号（CVE）、恶意软件名称、攻击手法
- [ ] **影响范围**：受影响系统数量、数据泄露规模
- [ ] **地理政治背景**：如有相关地缘政治因素需说明

### 情报筛选优先级（重要）

**优先选择与美国相关的威胁情报：**

| 优先级 | 关联类型 | 示例 |
|--------|----------|------|
| 1 | **美国机构/企业受影响** | 美国政府、企业、基础设施成为攻击目标 |
| 2 | **美国执法行动** | FBI、DoJ、CISA等发布的执法公告、行动成果 |
| 3 | **美国技术产品漏洞** | 美国科技公司产品（Microsoft、Apple、Google等）的安全漏洞 |
| 4 | **美国地缘政治相关** | 针对美国的网络间谍活动、APT组织 |
| 5 | **其他西方国家** | 英国、欧盟、澳大利亚等盟友的安全事件 |

**搜索关键词建议：**
- "US"、"American"、"FBI"、"DoJ"、"CISA"
- "Microsoft"、"Apple"、"Google"、"Amazon"
- "critical infrastructure"、"government"

**说明：** 当多篇新闻可选时，优先选择与美国关联度最高的主题。如无明显美国相关情报，再考虑其他重要安全事件。

## 信息来源优先级

| 优先级 | 来源类型 | 示例 |
|--------|----------|------|
| 1 | 国际安全媒体 | The Hacker News、BleepingComputer、SecurityWeek |
| 2 | 安全厂商博客 | Symantec、Kaspersky、FireEye、CrowdStrike |
| 3 | 政府安全公告 | CISA、FBI、NCSC |
| 4 | 技术社区 | GitHub Security Lab、SANS ISC |

## 输出规范

### 文件夹命名格式
```
~/Desktop/MMDD（情报）【威胁情报】简短标题/
```

### 示例
```
~/Desktop/0323（情报）【威胁情报】俄罗斯情报机构针对Signal和WhatsApp的大规模钓鱼攻击/
```

## 常见错误与解决方案

### 错误1：web_fetch 读取内容被 Cloudflare 拦截
**原因**：web_fetch 是简单 HTTP 请求，无法通过 Cloudflare 的 JavaScript 机器人检测

**解决方案**：使用 `browser` 工具（默认无头模式，已验证可行）
1. 用 `browser` 工具（profile="openclaw"）访问目标网站获取文章内容
2. 无头 Playwright 运行真实浏览器引擎，天然绕过 Cloudflare 检测
3. 从页面中提取文章标题、URL 和正文内容
4. 截图用 Edge 无头模式或 Python Playwright 无头模式

**已验证可用的来源**：The Hacker News（无头模式即可绕过）、The Register（可用 web_fetch）

### 错误2：Python docx模块未找到
**原因**：使用了错误的Python环境

**解决方案**：
1. 使用已验证含docx的Python：`C:\Users\hyss\AppData\Local\Programs\Python\Python313\python.exe`
2. 不要使用系统默认的 python.exe，可能缺少 docx 模块

### 错误3：字体显示异常
**原因**：系统中缺少中文字体

**解决方案**：
1. 确保系统已安装：方正小标宋简体、仿宋_GB2312、黑体
2. 如缺少字体，可使用替代字体：SimSun（宋体）、SimHei（黑体）

### 错误4：Playwright截图失败
**原因**：Node.js环境下playwright模块未安装

**解决方案**：使用Python版playwright（已验证可用）
- Python脚本：`from playwright.sync_api import sync_playwright`
- 路径：`C:\Users\hyss\AppData\Local\Programs\Python\Python313\python.exe`

### 错误4：原文链接404或截图无内容
**原因**：URL拼写错误、网页已下线、或被 Cloudflare 拦截

**解决方案**：
1. 使用 `web_fetch` 验证URL可访问性
2. 从搜索结果中找到正确的文章URL
3. 优先使用 The Hacker News（无 Cloudflare）和 SecurityWeek 的URL
4. 避免使用 Krebs on Security 等有严格反爬的网站
5. **原文链接.txt 只保留1个确认可访问的URL**

### 错误5：文档格式不符合公文标准
**原因**：章节结构、字体、缩进设置不正确

**解决方案**：
1. 严格按照"一、二、三"作为一级标题
2. 二级标题使用"（一）（二）（三）"格式，而非"一是、二是"
3. 正文首行缩进0.44英寸（约2字符）
4. 行距设置为1.5倍
5. 参考本SKILL.md中的Python代码格式模板

## 依赖工具

- **Python 3.x** + **python-docx** 库 - 生成Word文档
  - Python路径：`C:\Users\hyss\AppData\Local\Programs\Python\Python313\python.exe`（已验证含docx）
- **Microsoft Edge** - 网页截图（无头模式：`--headless --disable-gpu --screenshot=... --window-size=1920,8000`）
- **Playwright** - 绕过 Cloudflare 获取内容 + 截取译文截图
  - **使用Python版**（Node.js版playwright未装全局模块）
  - 路径：`C:\Users\hyss\AppData\Local\Programs\Python\Python313\python.exe`
  - 用法：`from playwright.sync_api import sync_playwright`

## 使用示例

**用户请求：**
> "帮我生成今天的威胁情报报告"

**执行流程：**
1. 访问 The Hacker News 获取当天新闻
2. 找到感兴趣的新闻，获取详细内容
3. 提取关键信息（攻击者、目标、技术手段等）
4. 生成Word文档（使用标准公文格式）
5. 截取原文截图
6. 截取译文截图（使用 Playwright + Google 翻译注入法）
7. 保存原文链接（只保留1个）
8. 确认4个文件都已生成
9. **删除残留的Python脚本文件**

## 禁止行为

- **不得** 自行编造威胁情报内容
- **不得** 使用过时的新闻（超过3天）
- **不得** 省略4个标准文件中的任何一个
- **不得** 在没有搜索的情况下直接生成报告
- **不得** 使用非官方翻译（如自己翻译的HTML页面）作为译文截图
- **不得** 在输出文件夹中残留Python脚本文件

## 质量检查清单

提交前确认：
- [ ] Word文档包含完整的5个章节（标题、概览、一、二、三）
- [ ] **称呼检查**：全文使用"我国"，无"中国"字样
- [ ] 标题使用方正小标宋简体，二号，加粗，居中
- [ ] 一级标题使用黑体，三号，加粗，"一、二、三"格式
- [ ] 正文使用仿宋_GB2312，三号，首行缩进2字符，1.5倍行距
- [ ] **二、事件影响**：深入贴合文章实际分析对我国的威胁（非套模板）
- [ ] **三、对策建议**：针对文章实际威胁提出具体可执行措施（非空话）
- [ ] 两个核心章节内容有实质价值，无水字数
- [ ] **原文截图**：整页截图、页面完全加载（networkidle）、清晰可辨认
- [ ] **译文截图**：整页截图（fullPage: true）、中文翻译完整、清晰可读
- [ ] 原文链接只保留1个主来源，且可访问
- [ ] 所有4个文件在同一文件夹中
- [ ] 文件夹命名符合规范（~/Desktop/MMDD（情报）【威胁情报】标题/）
- [ ] 无残留Python脚本文件

---

**重要提示**：此技能的核心价值在于**自动获取最新威胁情报**并生成完整的取证材料，而非基于已有信息重写。每次执行时必须先搜索当天最新的网络安全新闻，并确保生成完整的4个文件。

**经验教训（持续积累，供后续版本参考）**：

**核心规范：**
1. **称呼规范**：报告中"中国"必须改为"我国"，符合上报材料规范
2. **截图必须完整**：使用 `fullPage: true` 截取整页，不能截半页
3. **页面加载等待**：截图前必须 `waitUntil: 'networkidle'`，等页面完全加载
4. **译文翻译时间**：Google翻译注入后等待时间要充足（至少10秒），避免翻译不完整
5. **截图清晰度**：使用合适视口（如1920x1080）和 `type: 'png'` 确保清晰
6. **无头模式强制要求**：所有浏览器操作必须使用 `--headless` 参数，禁止打开可见窗口
7. **当天新闻优先**：优先选当天的新闻，如无当天新闻才用昨天的

**技术细节：**
8. 原文链接只保留1个主要来源，优先选 The Hacker News / SecurityWeek
9. 有 Cloudflare 的网站用 Playwright 注入翻译脚本，不要用 Google 翻译 URL
10. 截图前务必使用 `web_fetch` 验证URL可访问性
11. 事件影响必须深入贴合文章实际内容分析，不能套用通用模板
12. 对策建议要具体可执行，不能写空话套话
13. 任务完成后删除所有Python脚本文件，保持输出文件夹整洁
14. 译文截图如翻译不完整，可再次触发翻译选择器确保所有内容都翻完

**常见故障排查：**
- 译文截图空白或翻译不完整：增加翻译等待时间至15秒以上
- 原文截图只截了一半：确认使用了 `--window-size=1920,8000` 或 `fullPage: true`
- 浏览器窗口弹出：确认使用了 `--headless` 参数，绝不能省略
- 内容与文章实际不符：重新用 `web_fetch` 抓取原文，确保提取的信息准确
