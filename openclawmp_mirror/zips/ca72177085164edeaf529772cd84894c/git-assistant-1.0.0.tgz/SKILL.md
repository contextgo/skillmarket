---
name: git-assistant
description: "Git 辅助工具，提供合并冲突解决向导、分支管理、提交优化等功能。帮助用户快速解决 Git 冲突，理解冲突原因，并提供智能解决方案。"
metadata:
  version: "1.0.0"
  author: "Vice"
  tags: ["git", "merge", "conflict", "version-control", "assistant"]
---

# Git Assistant

智能 Git 辅助工具，帮助解决合并冲突、优化提交历史、管理分支。

## 功能

- 🔍 **冲突检测**：自动检测工作区中的合并冲突
- 🧭 **冲突向导**：交互式引导解决冲突
- 📝 **冲突分析**：解释冲突原因和上下文
- 🤖 **智能建议**：提供冲突解决方案建议
- 🔀 **分支管理**：分支操作辅助和检查
- 📊 **提交优化**：提交历史整理建议

## 使用场景

- 执行 `git pull` 或 `git merge` 后出现冲突
- 不确定如何解决复杂的合并冲突
- 需要理解冲突文件的变更历史
- 想要优化 Git 工作流程

## 使用方法

### 命令行调用

```bash
# 检查当前是否有冲突
python3 <skill-dir>/scripts/git_assistant.py --check

# 启动冲突解决向导
python3 <skill-dir>/scripts/git_assistant.py --resolve

# 分析特定文件的冲突
python3 <skill-dir>/scripts/git_assistant.py --analyze <file-path>

# 显示冲突统计
python3 <skill-dir>/scripts/git_assistant.py --stats

# 获取智能解决建议
python3 <skill-dir>/scripts/git_assistant.py --suggest
```

### 在 OpenClaw 中使用

```
帮我解决 Git 冲突
分析这个文件的冲突: <文件路径>
检查当前分支状态
```

## 输出格式

### 冲突检测输出

```json
{
  "has_conflicts": true,
  "conflict_files": [
    {
      "path": "src/config.json",
      "status": "both modified",
      "ours_branch": "feature-branch",
      "theirs_branch": "main"
    }
  ],
  "total_conflicts": 1
}
```

### 冲突分析输出

```json
{
  "file": "src/config.json",
  "conflict_sections": [
    {
      "line_start": 15,
      "line_end": 25,
      "ours_changes": "本地修改内容",
      "theirs_changes": "远程修改内容",
      "suggestion": "建议保留本地修改，因为..."
    }
  ]
}
```

## 冲突解决策略

1. **自动检测**：扫描工作区中的所有冲突标记
2. **上下文分析**：获取冲突文件的变更历史
3. **智能建议**：基于变更内容提供解决建议
4. **交互式解决**：引导用户逐步解决每个冲突
5. **验证提交**：解决后自动验证并提交

## 注意事项

- 解决冲突前建议先备份重要文件
- 对于复杂的冲突，建议手动审查自动建议
- 使用 `--dry-run` 可以先预览解决方案而不实际应用

## 依赖

- Python 3.7+
- Git 命令行工具
- 标准库：`subprocess`, `os`, `re`, `json`, `argparse`
