#!/usr/bin/env python3
"""
Git 辅助工具 - 合并冲突解决向导

用法:
    python git_assistant.py --check          # 检查是否有冲突
    python git_assistant.py --resolve        # 启动冲突解决向导
    python git_assistant.py --analyze FILE   # 分析特定文件的冲突
    python git_assistant.py --stats          # 显示冲突统计
    python git_assistant.py --suggest        # 获取智能解决建议
    python git_assistant.py --abort          # 中止当前合并

返回代码:
    0 - 成功 / 无冲突
    1 - 存在冲突
    2 - Git 仓库错误
"""

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional


class GitAssistant:
    """Git 辅助工具类"""
    
    CONFLICT_MARKER_OURS = "<<<<<<<"
    CONFLICT_MARKER_BASE = "======="
    CONFLICT_MARKER_THEIRS = ">>>>>>>"
    
    def __init__(self, repo_path: Optional[str] = None):
        self.repo_path = repo_path or os.getcwd()
        self._validate_repo()
    
    def _validate_repo(self) -> None:
        """验证是否为有效的 Git 仓库"""
        git_dir = os.path.join(self.repo_path, ".git")
        if not os.path.isdir(git_dir):
            raise GitAssistantError(f"不是有效的 Git 仓库: {self.repo_path}")
    
    def _run_git(self, args: list[str]) -> tuple[int, str, str]:
        """执行 Git 命令"""
        try:
            result = subprocess.run(
                ["git"] + args,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            return result.returncode, result.stdout, result.stderr
        except FileNotFoundError:
            raise GitAssistantError("未找到 Git 命令，请确保 Git 已安装")
        except subprocess.TimeoutExpired:
            raise GitAssistantError("Git 命令执行超时")
    
    def check_conflicts(self) -> dict:
        """检查当前是否有合并冲突"""
        # 检查是否有未完成的合并
        merge_head = os.path.join(self.repo_path, ".git", "MERGE_HEAD")
        is_merging = os.path.exists(merge_head)
        
        # 获取冲突文件列表
        code, stdout, stderr = self._run_git(["diff", "--name-only", "--diff-filter=U"])
        conflict_files = [f.strip() for f in stdout.strip().split("\n") if f.strip()]
        
        # 获取每个冲突文件的详细信息
        detailed_files = []
        for file_path in conflict_files:
            file_info = self._get_conflict_file_info(file_path)
            detailed_files.append(file_info)
        
        return {
            "has_conflicts": len(conflict_files) > 0,
            "is_merging": is_merging,
            "conflict_files": detailed_files,
            "total_conflicts": len(conflict_files)
        }
    
    def _get_conflict_file_info(self, file_path: str) -> dict:
        """获取冲突文件的详细信息"""
        # 获取文件状态
        code, stdout, stderr = self._run_git(["status", "--porcelain", file_path])
        status = stdout[:2] if stdout else "??"
        
        # 尝试获取分支信息
        code, stdout, stderr = self._run_git(["log", "--oneline", "-1", "HEAD"])
        ours_commit = stdout.strip() if stdout else "HEAD"
        
        # 尝试获取 MERGE_HEAD
        merge_head_file = os.path.join(self.repo_path, ".git", "MERGE_HEAD")
        theirs_commit = "MERGE_HEAD"
        if os.path.exists(merge_head_file):
            with open(merge_head_file, 'r') as f:
                theirs_commit = f.read().strip()[:7]
        
        return {
            "path": file_path,
            "status": self._interpret_status(status),
            "ours_branch": self._get_current_branch(),
            "theirs_ref": theirs_commit
        }
    
    def _interpret_status(self, status: str) -> str:
        """解释 Git 状态码"""
        status_map = {
            "UU": "both modified",
            "AA": "both added",
            "DD": "both deleted",
            "AU": "added by us",
            "UA": "added by them",
            "DU": "deleted by us",
            "UD": "deleted by them"
        }
        return status_map.get(status, f"unknown ({status})")
    
    def _get_current_branch(self) -> str:
        """获取当前分支名"""
        code, stdout, stderr = self._run_git(["branch", "--show-current"])
        return stdout.strip() if stdout else "HEAD"
    
    def analyze_file(self, file_path: str) -> dict:
        """分析特定文件的冲突"""
        full_path = os.path.join(self.repo_path, file_path)
        
        if not os.path.exists(full_path):
            return {"error": f"文件不存在: {file_path}"}
        
        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 解析冲突标记
        conflict_sections = self._parse_conflicts(content)
        
        # 获取文件变更历史
        history = self._get_file_history(file_path)
        
        return {
            "file": file_path,
            "total_sections": len(conflict_sections),
            "conflict_sections": conflict_sections,
            "history": history
        }
    
    def _parse_conflicts(self, content: str) -> list[dict]:
        """解析文件中的冲突部分"""
        sections = []
        lines = content.split('\n')
        
        i = 0
        while i < len(lines):
            if lines[i].startswith(self.CONFLICT_MARKER_OURS):
                # 找到冲突开始
                start_line = i
                ours_content = []
                theirs_content = []
                in_ours = True
                
                i += 1
                while i < len(lines):
                    if lines[i].startswith(self.CONFLICT_MARKER_BASE):
                        in_ours = False
                        i += 1
                        continue
                    elif lines[i].startswith(self.CONFLICT_MARKER_THEIRS):
                        # 冲突结束
                        end_line = i
                        sections.append({
                            "line_start": start_line + 1,
                            "line_end": end_line + 1,
                            "ours_content": '\n'.join(ours_content).strip(),
                            "theirs_content": '\n'.join(theirs_content).strip(),
                            "ours_lines": len(ours_content),
                            "theirs_lines": len(theirs_content)
                        })
                        i += 1
                        break
                    else:
                        if in_ours:
                            ours_content.append(lines[i])
                        else:
                            theirs_content.append(lines[i])
                        i += 1
            else:
                i += 1
        
        return sections
    
    def _get_file_history(self, file_path: str) -> dict:
        """获取文件变更历史"""
        # 获取最近的提交历史
        code, stdout, stderr = self._run_git([
            "log", "--oneline", "-5", "--", file_path
        ])
        
        commits = [line.strip() for line in stdout.strip().split('\n') if line.strip()]
        
        return {
            "recent_commits": commits,
            "total_commits": len(commits)
        }
    
    def suggest_resolution(self) -> dict:
        """为冲突提供智能解决建议"""
        conflicts = self.check_conflicts()
        
        if not conflicts["has_conflicts"]:
            return {"message": "当前没有冲突", "suggestions": []}
        
        suggestions = []
        for file_info in conflicts["conflict_files"]:
            file_path = file_info["path"]
            analysis = self.analyze_file(file_path)
            
            for section in analysis.get("conflict_sections", []):
                suggestion = self._generate_suggestion(file_path, section)
                suggestions.append({
                    "file": file_path,
                    "lines": f"{section['line_start']}-{section['line_end']}",
                    "suggestion": suggestion
                })
        
        return {
            "total_suggestions": len(suggestions),
            "suggestions": suggestions
        }
    
    def _generate_suggestion(self, file_path: str, section: dict) -> str:
        """为特定冲突段生成建议"""
        ours = section["ours_content"]
        theirs = section["theirs_content"]
        
        # 简单的启发式建议
        if not ours:
            return "建议保留远程版本（theirs），本地无修改"
        elif not theirs:
            return "建议保留本地版本（ours），远程无修改"
        elif len(ours) > len(theirs):
            return "本地修改内容较多，建议仔细对比后选择"
        elif len(theirs) > len(ours):
            return "远程修改内容较多，建议仔细对比后选择"
        else:
            return "双方修改量相近，建议手动合并关键差异"
    
    def abort_merge(self) -> dict:
        """中止当前合并"""
        code, stdout, stderr = self._run_git(["merge", "--abort"])
        
        if code == 0:
            return {"success": True, "message": "合并已中止"}
        else:
            return {"success": False, "error": stderr or "无法中止合并"}


class GitAssistantError(Exception):
    """Git 辅助工具错误"""
    pass


def main():
    parser = argparse.ArgumentParser(
        description="Git 辅助工具 - 合并冲突解决向导"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="检查是否有冲突"
    )
    parser.add_argument(
        "--resolve",
        action="store_true",
        help="启动冲突解决向导"
    )
    parser.add_argument(
        "--analyze",
        metavar="FILE",
        help="分析特定文件的冲突"
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="显示冲突统计"
    )
    parser.add_argument(
        "--suggest",
        action="store_true",
        help="获取智能解决建议"
    )
    parser.add_argument(
        "--abort",
        action="store_true",
        help="中止当前合并"
    )
    parser.add_argument(
        "--path",
        default=".",
        help="Git 仓库路径（默认为当前目录）"
    )
    
    args = parser.parse_args()
    
    try:
        assistant = GitAssistant(args.path)
        
        if args.check:
            result = assistant.check_conflicts()
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 1 if result["has_conflicts"] else 0
        
        elif args.resolve:
            result = assistant.check_conflicts()
            if not result["has_conflicts"]:
                print("✅ 当前没有冲突需要解决")
                return 0
            
            print(f"🔍 发现 {result['total_conflicts']} 个冲突文件:\n")
            for f in result["conflict_files"]:
                print(f"  📄 {f['path']} ({f['status']})")
            
            print("\n💡 解决建议:")
            suggestions = assistant.suggest_resolution()
            for s in suggestions["suggestions"]:
                print(f"\n  {s['file']} (行 {s['lines']}):")
                print(f"    → {s['suggestion']}")
            
            print("\n📝 下一步操作:")
            print("  1. 编辑冲突文件，解决冲突标记")
            print("  2. 执行: git add <文件>")
            print("  3. 执行: git commit -m '解决合并冲突'")
            print("\n  或中止合并: git merge --abort")
            
            return 0
        
        elif args.analyze:
            result = assistant.analyze_file(args.analyze)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 0
        
        elif args.stats:
            result = assistant.check_conflicts()
            print(f"冲突统计:")
            print(f"  是否有冲突: {'是' if result['has_conflicts'] else '否'}")
            print(f"  冲突文件数: {result['total_conflicts']}")
            print(f"  当前分支: {assistant._get_current_branch()}")
            if result["has_conflicts"]:
                print(f"\n冲突文件列表:")
                for f in result["conflict_files"]:
                    print(f"  - {f['path']}: {f['status']}")
            return 0
        
        elif args.suggest:
            result = assistant.suggest_resolution()
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 0
        
        elif args.abort:
            result = assistant.abort_merge()
            if result["success"]:
                print(f"✅ {result['message']}")
                return 0
            else:
                print(f"❌ 错误: {result.get('error', '未知错误')}")
                return 1
        
        else:
            # 默认行为：检查冲突
            result = assistant.check_conflicts()
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 1 if result["has_conflicts"] else 0
            
    except GitAssistantError as e:
        print(f"❌ 错误: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"❌ 未知错误: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
