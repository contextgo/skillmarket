# Qwik Framework Guide

Qwik is a resumable framework that achieves instant page loads by shipping zero JavaScript initially and resuming interactivity on interaction.

## Core Innovation: Resumability

- **Zero hydration**: No JS ships on page load
- **Resumable**: State serialized in HTML, JS loads on-demand
- **Instant loading**: Sub-second Time to Interactive
- **Lazy by default**: Components load only when needed

## Project Setup

```bash
npm create qwik@latest
```

## Component Example

```tsx
import { component$, useSignal } from '@builder.io/qwik';

export default component$(() => {
  const count = useSignal(0);
  return (
    <button onClick$={() => count.value++}>
      Count: {count.value}
    </button>
  );
});
```

## Key Concepts

- `component$()`: Marks a component as resumable
- `$()`: QRL (Qwik URL) marker for lazy loading
- `useSignal()`: Reactive primitive
- `useStore()`: Reactive object state
- `useTask$()`: Computed/watcher

## Routing

```
src/routes/
├── index.tsx          # Home
├── about/
│   └── [name]/index.tsx  # Dynamic route
└── api/
    └── hello/index.tsx   # API route
```

## Best Practices

- Always use `$` suffix for event handlers: `onClick$`
- Use `useVisibleTask$` for client-only code
- Prefer `useSignal` over `useState` pattern
- Use `Resource` for async data loading
- Keep components small and focused