---
name: openclawmp-setup
description: |
  自动化配置 OpenClaw 环境工具。基于 openclawmp-dl.stepfun.com/resources/install_guide/install_guide.md 规范流程。
  功能：检查CLI、安装CLI、写入Token、安装skill、验证环境、报告结果。
  当用户说「配置 OpenClaw 环境」「安装 openclawmp」「帮我配置环境」时触发。
  也适用于：「检查 OpenClaw 环境」「验证 openclawmp 安装」。
---

# OpenClaw 环境配置自动化工具

## 功能概述

本 Skill 自动化执行 OpenClaw 环境配置，包含以下步骤：

| 步骤 | 描述 | 命令 |
|------|------|------|
| 1 | 检查 CLI 是否可用 | `openclawmp --version` |
| 2 | 写入 Token 鉴权 | `openclawmp oauth <token>` |
| 3 | 安装 skill | `openclawmp install skill/f3ab5236724cf9b7f4cbf6bda8478a6e` |
| 4 | 验证环境 | 综合验证 |

---

## 核心执行流程

### 步骤 1：检查 CLI 可用性

```bash
openclawmp --version
```

**判断逻辑**：
- 成功输出版本号 → CLI 已安装，跳到步骤 2
- 命令不存在 → CLI 未安装，需要安装

**安装 CLI**：
```bash
npm install -g openclawmp
```

---

### 步骤 2：写入 Token 鉴权

```bash
openclawmp oauth <token>
```

**关键约束**：
- 禁止在回复中回显完整 token
- 只显示 token 前缀和后缀，如 sk_c...b01e

---

### 步骤 3：安装 Skill

**安装命令**：
```bash
openclawmp install skill/f3ab5236724cf9b7f4cbf6bda8478a6e
```

---

### 步骤 4：验证环境

依次执行验证命令：

```bash
openclawmp --version
openclawmp list
```

---

## 环境配置完成判断标准

必须同时满足以下条件才算配置完成：

| 条件 | 验证方式 |
|------|----------|
| CLI 可用 | `openclawmp --version` 正常执行 |
| Skill 已安装 | `openclawmp list` 显示目标 skill |
| Token 已写入 | `openclawmp oauth <token>` 执行成功 |

---

## 执行边界（禁止事项）

| 禁止行为 | 说明 |
|----------|------|
| 使用 sudo | 除非用户明确批准 |
| 手动复制 skill 文件 | 优先使用 CLI 安装 |
| 安装无关软件 | 只安装 OpenClaw 相关 |
| 删除用户现有 skill | 保留已有配置 |
| 回显完整 token | 保护敏感信息 |
| 未验证宣称成功 | 必须完成所有验证步骤 |

---

## 错误处理

### 常见错误及处理方式

| 错误 | 原因 | 处理 |
|------|------|------|
| CLI 不存在 | 未安装 | 安装 CLI |
| npm 不存在 | Node.js 未安装 | 提示用户安装 Node.js |
| Token 写入失败 | Token 无效 | 提示用户检查 Token |
| Skill 安装失败 | 网络问题或ID错误 | 检查网络或 skill ID |
| 权限错误 | npm 全局目录权限 | 提示用户处理权限 |

---

## 使用方法

1. **触发条件**：用户说「配置 OpenClaw 环境」「安装 openclawmp」「帮我配置环境」

2. **执行流程**：
   - 检查 CLI 是否可用
   - 写入 Token
   - 安装 skill
   - 验证环境
   - 向用户报告结果

3. **Token 处理**：
   - 要求用户提供 Token
   - 写入后隐藏完整 Token
   - 保存到 /root/.openclaw/hub-credentials.json
