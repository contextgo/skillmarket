# 威胁情报分析技能

## 用途

自动从国际网络安全媒体获取当天最新威胁情报，生成符合中文公文格式的威胁情报分析报告（Word文档），包含完整的取证材料。

## 标准输出（4个文件）

每个威胁情报报告必须包含以下4个文件：

| 序号 | 文件名 | 说明 |
|------|--------|------|
| 1 | `MMDD（全州）【威胁情报】标题.docx` | 中文威胁情报Word文档 |
| 2 | `原文截图.png` | 英文原文网页截图 |
| 3 | `译文截图.png` | Google翻译后的中文页面截图 |
| 4 | `原文链接.txt` | 原文URL链接（只保留1个主要来源） |

## 工作流程

### 标准操作流程（必须按顺序执行）

#### 步骤1：搜索最新威胁情报
- 使用 `web_fetch` 访问 The Hacker News 首页获取当天新闻
- 或搜索关键词：`cybersecurity news today`、`APT attack`、`ransomware`、`zero-day`
- 优先来源：The Hacker News、BleepingComputer、SecurityWeek

#### 步骤2：获取详细内容
- 使用 `web_fetch` 获取新闻详情
- 提取关键信息：攻击者、目标、技术手段、影响范围、时间线

#### 步骤3：生成Word文档
- 使用 Python + python-docx 生成标准格式文档
- 字体：方正小标宋简体（标题）、黑体（一级标题）、仿宋_GB2312（正文）
- 章节：标题、概览、一、基本情况、二、事件影响、三、对策建议

#### 步骤4：截取原文截图
- 使用 Edge 无头模式截取英文原文网页
```powershell
& "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" `
  --headless --disable-gpu --screenshot=原文截图.png `
  --window-size=1920,8000 "原文URL"
```

#### 步骤5：截取译文截图
- 使用 Google 翻译后的 URL 截取中文页面
- URL格式：`https://域名-translate.goog/路径?_x_tr_sl=en&_x_tr_tl=zh-CN`
- 或使用临时文件方式（如果翻译URL不可用）

#### 步骤6：保存原文链接
- 创建 `原文链接.txt` 文件，**只保留1个主要来源URL**
- 优先选择 The Hacker News 或原始信息来源的URL

## 文档格式规范

### 字体设置
- **标题**：方正小标宋简体，二号（22pt），加粗，居中
- **一级标题**：黑体，三号（16pt），加粗（一、二、三）
- **正文**：仿宋_GB2312，三号（16pt），1.5倍行距，首行缩进2字符

### 页面设置
- **页面边距**：上下1.46英寸，左右1.1英寸
- **行距**：1.5倍行距

### 标准章节结构
1. **标题** - 威胁事件核心描述
2. **概览段** - 事件摘要（时间、攻击者、目标、技术手段）
3. **一、基本情况** - 详细事件描述、攻击者背景、技术细节（分点：（一）（二）（三））
4. **二、事件影响** - 影响分析（分点：（一）（二）（三））
5. **三、对策建议** - 防护建议（分点：（一）（二）（三）（四）（五））

### Python代码格式模板

```python
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def create():
    doc = Document()
    for s in doc.sections:
        s.top_margin = Inches(1.46)
        s.bottom_margin = Inches(1.46)
        s.left_margin = Inches(1.1)
        s.right_margin = Inches(1.1)
    
    # 标题
    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run('报告标题')
    r.font.name = '方正小标宋简体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '方正小标宋简体')
    r.font.size = Pt(22)
    r.font.bold = True
    
    doc.add_paragraph()
    
    # 概览段
    p = doc.add_paragraph()
    r = p.add_run('概览内容...')
    r.font.name = '仿宋_GB2312'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')
    r.font.size = Pt(16)
    p.paragraph_format.first_line_indent = Inches(0.44)  # 首行缩进2字符
    p.paragraph_format.line_spacing = 1.5
    
    # 一级标题
    h = doc.add_paragraph()
    r = h.add_run('一、基本情况')
    r.font.name = '黑体'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    r.font.size = Pt(16)
    r.font.bold = True
    
    # 正文（带二级标题）
    p = doc.add_paragraph()
    r = p.add_run('（一）攻击组织背景。具体内容...')
    r.font.name = '仿宋_GB2312'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '仿宋_GB2312')
    r.font.size = Pt(16)
    p.paragraph_format.first_line_indent = Inches(0.44)
    p.paragraph_format.line_spacing = 1.5
    
    doc.save('文件名.docx')

if __name__ == '__main__':
    create()
```

## 内容撰写要求

### 一、基本情况（必须包含）
- （一）攻击组织背景：APT组织名称、所属国家/机构、历史活动
- （二）攻击手法分析：具体技术手段、攻击流程、利用的漏洞或服务
- （三）技术特点研判：攻击的独特性、与其他攻击的关联性

### 二、事件影响（必须包含对中国的分析）
- （一）对美国的直接影响：受害者范围、损失程度
- （二）对我国的潜在威胁：
  - 一是外交人员面临针对性攻击风险
  - 二是涉密人员安全隐患突出
  - 三是供应链攻击风险传导
  - 四是地缘政治博弈加剧
- （三）对全球网络安全格局的影响：行业影响、技术趋势

### 三、对策建议（必须可操作）
- （一）安全意识/管理措施
- （二）技术防护措施
- （三）体系建设建议
- （四）情报共享机制
- （五）应急响应预案

## 关键信息提取要点

生成报告前必须确认以下信息：

- [ ] **攻击时间**：具体日期或时间段
- [ ] **攻击者**：APT组织名称或威胁行为者
- [ ] **攻击目标**：受影响的行业、地区、组织类型
- [ ] **技术手段**：漏洞编号（CVE）、恶意软件名称、攻击手法
- [ ] **影响范围**：受影响系统数量、数据泄露规模
- [ ] **地理政治背景**：如有相关地缘政治因素需说明

### ⚠️ 情报筛选优先级（重要）

**优先选择与美国相关的威胁情报：**

| 优先级 | 关联类型 | 示例 |
|--------|----------|------|
| 1 | **美国机构/企业受影响** | 美国政府、企业、基础设施成为攻击目标 |
| 2 | **美国执法行动** | FBI、DoJ、CISA等发布的执法公告、行动成果 |
| 3 | **美国技术产品漏洞** | 美国科技公司产品（Microsoft、Apple、Google等）的安全漏洞 |
| 4 | **美国地缘政治相关** | 针对美国的网络间谍活动、APT组织 |
| 5 | **其他西方国家** | 英国、欧盟、澳大利亚等盟友的安全事件 |

**搜索关键词建议：**
- "US"、"American"、"FBI"、"DoJ"、"CISA"
- "Microsoft"、"Apple"、"Google"、"Amazon"
- "critical infrastructure"、"government"

**说明：** 当多篇新闻可选时，优先选择与美国关联度最高的主题。如无明显美国相关情报，再考虑其他重要安全事件。

## 信息来源优先级

| 优先级 | 来源类型 | 示例 |
|--------|----------|------|
| 1 | 国际安全媒体 | The Hacker News、BleepingComputer、SecurityWeek |
| 2 | 安全厂商博客 | Symantec、Kaspersky、FireEye、CrowdStrike |
| 3 | 政府安全公告 | CISA、FBI、NCSC |
| 4 | 技术社区 | GitHub Security Lab、SANS ISC |

## 输出规范

### 文件夹命名格式
```
~/Desktop/MMDD（全州）【威胁情报】简短标题/
```

### 示例
```
~/Desktop/0323（全州）【威胁情报】俄罗斯情报机构针对Signal和WhatsApp的大规模钓鱼攻击/
```

## 常见错误与解决方案

### 错误1：译文截图失败
**原因**：Google翻译URL无法直接访问或Edge翻译功能在headless模式下不可用

**解决方案**：
1. 使用 Google 翻译后的 URL：`https://域名-translate.goog/路径?_x_tr_sl=en&_x_tr_tl=zh-CN`
2. 或使用临时HTML文件方式生成中文页面后截图
3. 检查临时文件夹中是否已生成截图文件

### 错误2：Python docx模块未找到
**原因**：使用了错误的Python环境

**解决方案**：
1. 查找系统中已安装python-docx的Python版本：`Get-Command python -All`
2. 使用正确的Python路径运行脚本

### 错误3：字体显示异常
**原因**：系统中缺少中文字体

**解决方案**：
1. 确保系统已安装：方正小标宋简体、仿宋_GB2312、黑体
2. 如缺少字体，可使用替代字体：SimSun（宋体）、SimHei（黑体）

### 错误4：原文链接404或截图无内容
**原因**：URL拼写错误或网页已下线

**解决方案**：
1. 使用 `web_fetch` 验证URL可访问性
2. 从搜索结果中找到正确的文章URL
3. 优先使用 The Hacker News 的URL，避免使用Krebs on Security等可能受限的网站
4. **原文链接.txt 只保留1个确认可访问的URL**

### 错误5：文档格式不符合公文标准
**原因**：章节结构、字体、缩进设置不正确

**解决方案**：
1. 严格按照"一、二、三"作为一级标题
2. 二级标题使用"（一）（二）（三）"格式，而非"一是、二是"
3. 正文首行缩进0.44英寸（约2字符）
4. 行距设置为1.5倍
5. 参考本SKILL.md中的Python代码格式模板

## 依赖工具

- **Python 3.x** + **python-docx** 库 - 生成Word文档
- **Microsoft Edge** - 网页截图
- **web_fetch** - 获取新闻内容

## 使用示例

**用户请求：**
> "帮我生成今天的威胁情报报告"

**执行流程：**
1. 访问 The Hacker News 获取当天新闻
2. 找到感兴趣的新闻，获取详细内容
3. 提取关键信息（攻击者、目标、技术手段等）
4. 生成Word文档（使用标准公文格式）
5. 截取原文截图
6. 截取译文截图（使用Google翻译URL）
7. 保存原文链接（只保留1个）
8. 确认4个文件都已生成
9. **删除残留的Python脚本文件**

## 禁止行为

❌ **不得** 自行编造威胁情报内容
❌ **不得** 使用过时的新闻（超过3天）
❌ **不得** 省略4个标准文件中的任何一个
❌ **不得** 在没有搜索的情况下直接生成报告
❌ **不得** 使用非官方翻译（如自己翻译的HTML页面）作为译文截图
❌ **不得** 在输出文件夹中残留Python脚本文件

## 质量检查清单

提交前确认：
- [ ] Word文档包含完整的5个章节（标题、概览、一、二、三）
- [ ] 一级标题使用"一、二、三"格式
- [ ] 二级标题使用"（一）（二）（三）"格式
- [ ] 正文首行缩进2字符，1.5倍行距
- [ ] 原文截图清晰可辨认
- [ ] 译文截图是中文内容
- [ ] 原文链接只保留1个，且可访问
- [ ] 所有4个文件在同一文件夹中
- [ ] 文件夹命名符合规范
- [ ] 已删除残留的Python脚本文件

---

**重要提示**：此技能的核心价值在于**自动获取最新威胁情报**并生成完整的取证材料，而非基于已有信息重写。每次执行时必须先搜索当天最新的网络安全新闻，并确保生成完整的4个文件。

**经验教训（2026-03-23更新）**：
1. 原文链接只保留1个主要来源，避免多个链接导致维护困难
2. 截图前务必使用 `web_fetch` 验证URL可访问性
3. 严格按照公文格式：一级标题"一、二、三"，二级标题"（一）（二）"
4. 内容必须深入分析对中国的影响，提出可操作的对策建议
5. 任务完成后删除所有Python脚本文件，保持输出文件夹整洁