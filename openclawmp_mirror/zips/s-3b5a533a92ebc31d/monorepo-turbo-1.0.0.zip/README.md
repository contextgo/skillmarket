# Monorepo with Turborepo

Turborepo is a high-performance build system for JavaScript/TypeScript monorepos with remote caching and incremental builds.

## Project Setup

```bash
npx create-turbo@latest my-monorepo
```

## Workspace Structure

```
my-monorepo/
├── apps/
│   ├── web/          # Next.js app
│   └── docs/         # Docs site
├── packages/
│   ├── ui/           # Shared UI components
│   ├── config/       # Shared configs (ESLint, TS)
│   └── db/           # Shared database client
├── turbo.json
└── package.json
```

## turbo.json Configuration

```json
{
  "$schema": "https://turbo.build/schema.json",
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**"]
    },
    "test": {
      "dependsOn": ["build"]
    },
    "lint": {},
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}
```

## Key Features

- **Remote Caching**: Share build cache across CI/CD and team
- **Incremental Builds**: Only rebuild what changed
- **Parallel Execution**: Run tasks across packages in parallel
- **Task Pipeline**: Define task dependencies
- **Filtered Runs**: `turbo run build --filter=web`

## Common Commands

```bash
turbo build            # Build all packages
turbo build --filter=web  # Build only web app
turbo dev              # Run all dev servers
turbo run test --parallel  # Run tests in parallel
```

## Best Practices

- Use `workspace:*` protocol for internal deps
- Keep packages small and focused
- Use `turbo prune` for Docker builds
- Enable remote cache for CI/CD
- Use strict TypeScript paths