# A股股票分析 Skill

## 功能概述

本Skill提供完整的A股市场数据分析能力：

### 1. 基础行情
- 主要指数监控（上证、深证、创业板、科创50等）
- 指数估值指标（PE、PB、换手率）
- 个股资金流向分析

### 2. 技术分析
- MA均线（5日、10日、20日）
- MACD指标
- RSI相对强弱指标
- KDJ随机指标
- 布林带(BOLL)

### 3. 板块分析
- 行业资金流向TOP10
- 概念板块资金流向
- 涨跌停统计分析

### 4. 早盘选股 (JWZZ策略)
- 竞价涨幅分析
- 量比、换手率筛选
- 昨日表现评估
- 流通市值适中度
- 综合JWZZ评分 >= 95分

## 数据源

1. **TuShare Pro** - 主要数据源
2. **东方财富** - 实时行情备用源

## 使用方法

### 1. 基础复盘

```bash
uv run python scripts/market_review.py [YYYYMMDD]
```

### 2. 完整技术分析报告

```bash
uv run python scripts/technical_analysis.py [YYYYMMDD]
```

### 3. 早盘选股 (JWZZ >= 95)

```bash
uv run python scripts/morning_stock_picker.py [YYYYMMDD] [最低分数]
```

示例：
```bash
# 选股JWZZ>=95的股票
uv run python scripts/morning_stock_picker.py 20250319 95

# 选股JWZZ>=90的股票
uv run python scripts/morning_stock_picker.py 20250319 90
```

### 4. Python调用

```python
from scripts.market_review import generate_report
from scripts.technical_analysis import generate_full_report
from scripts.morning_stock_picker import select_stocks

# 基础复盘
report = generate_report('20250319')

# 完整分析
full_report = generate_full_report('20250319')

# 早盘选股
stocks = select_stocks('20250319', min_score=95)
```

## 文件结构

```
a-stock-analyzer/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── market_review.py              # 基础复盘
│   ├── technical_analysis.py         # 技术分析
│   └── morning_stock_picker.py       # 早盘选股
└── references/
    └── jwzz_strategy.md              # JWZZ策略详解
```

## JWZZ选股策略说明

JWZZ (竞价王中王) 是一个综合早盘竞价数据的选股指标：

| 指标项 | 权重 | 说明 |
|--------|------|------|
| 竞价涨幅 | 30分 | 9:25开盘价相对昨日收盘涨幅 |
| 竞价量比 | 25分 | 竞价成交量/昨日同时段成交量 |
| 竞价换手率 | 20分 | 竞价成交量/流通股本 |
| 昨日表现 | 15分 | 昨日是否涨停、涨幅如何 |
| 流通市值 | 10分 | 10-100亿为佳 |

**选股条件**: JWZZ总分 >= 95分

## 配置

本Skill使用环境变量获取TuShare Pro Token：

```bash
# 设置环境变量
export TUSHARE_TOKEN='your_token_here'

# Windows PowerShell
$env:TUSHARE_TOKEN='your_token_here'

# Windows CMD
set TUSHARE_TOKEN=your_token_here
```

或者创建 `.env` 文件：
```
TUSHARE_TOKEN=your_token_here
```

## 依赖

- tushare
- pandas
- numpy
- requests

## 定时任务建议

| 时间 | 任务 |
|------|------|
| 9:25:02 | 早盘选股 (JWZZ>=95) |
| 13:00 | 午盘复盘 |
| 17:30 | 收盘复盘 |

## 风险提示

本Skill提供的分析结果仅供参考，不构成投资建议。股市有风险，投资需谨慎。