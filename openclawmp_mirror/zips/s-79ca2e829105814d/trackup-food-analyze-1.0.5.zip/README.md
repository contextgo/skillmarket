# TrackUp 食物营养分析

使用此技能通过以下 API 分析食物图片：

- `https://deepeat.ai/step.aispark.api.API/AnalyzeWholeFood`
- `https://deepeat.ai/step.aispark.api.API/ExtractFoodMacros`
- `https://deepeat.ai/step.aispark.api.API/AnalyzeIngredients`
- `https://deepeat.ai/step.aispark.api.API/GetHealthInsight`
- `https://deepeat.ai/step.aispark.api.API/SearchFood`

## 规则

- 始终使用 `POST` 方法
- 始终发送 `Content-Type: application/json`
- 图片分析请求必须包含 `image_url` 或 `image_base64`
- 如果两者都存在，`image_base64` 优先
- `image_base64` 必须是纯 base64 编码，不带 `data:image/...;base64,` 前缀
- 对于完整的食物图片分析，直接调用 `AnalyzeWholeFood`
- 仅当用户明确要求某个特定分析维度时，才调用对应的专项 API
- 使用 `ExtractFoodMacros` 进行基础宏量营养素提取
- 使用 `AnalyzeIngredients` 进行深度成分与代谢分析
- 使用 `GetHealthInsight` 获取专业健康洞察
- `SearchFood` 请求体必须包含 `keyword`
- `SearchFood` 最多返回前 `20` 条结果

## API 选择

根据用户意图选择对应的 API：

1. 完整食物分析：`AnalyzeWholeFood`
2. 仅提取基础宏量营养素：`ExtractFoodMacros`
3. 仅深度成分与代谢分析：`AnalyzeIngredients`
4. 仅专业健康洞察：`GetHealthInsight`
5. 基于关键词查询（无需图片）：`SearchFood`

## 食物搜索

当用户想通过关键词查找食物而非图片分析时，使用 `SearchFood`。

请求示例：

```bash
curl --silent --show-error --location \
  'https://deepeat.ai/step.aispark.api.API/SearchFood' \
  --header 'Content-Type: application/json' \
  --data '{
    "keyword": "banana"
  }'
```

预期返回格式：

```json
{
  "foods": [
    {
      "food_name": "Banana",
      "calories_cal": "89000",
      "weight_g": "100",
      "carbs_g": "22.8",
      "proteins_g": "1.1",
      "fats_g": "0.3",
      "display_gi": 51,
      "brand": ""
    }
  ],
  "pagination": {
    "size": 20,
    "page": 1,
    "total": 123
  }
}
```

## 图片来源解析（优先级顺序）

当用户发送/提及食物图片时，按以下顺序解析图片来源：

1. **本地文件路径** — 用户明确提供路径，或已知文件存在（如 Downloads 目录）
2. **自动剪贴板捕获** — 当用户在网页聊天（或其他不保存本地图片的渠道）中粘贴/拖入内联图片时，**立即**尝试读取系统剪贴板。由于用户刚粘贴，图片极有可能还在剪贴板中。不要先询问用户，直接静默尝试读取。
3. **图片 URL** — 用户提供 URL，直接使用 `image_url` 参数

**关键行为：** 当你看到消息中有内联图片但没有本地文件路径时，**始终先自动尝试剪贴板读取**。如果失败，再回退询问用户。

### macOS 剪贴板图片读取器

当收到内联图片但没有本地文件路径时使用：

```bash
cat > /tmp/clipboard_image.swift << 'SWIFT'
import Cocoa
let pb = NSPasteboard.general
let outputPath = "/tmp/clipboard_image.png"

if let imgData = pb.data(forType: .png) {
    try! imgData.write(to: URL(fileURLWithPath: outputPath))
    print("OK: saved \(imgData.count) bytes")
} else if let tiffData = pb.data(forType: .tiff) {
    if let img = NSBitmapImageRep(data: tiffData),
       let pngData = img.representation(using: .png, properties: [:]) {
        try! pngData.write(to: URL(fileURLWithPath: outputPath))
        print("OK: saved \(pngData.count) bytes (from TIFF)")
    } else {
        print("ERR: could not convert TIFF to PNG")
    }
} else {
    let types = pb.types?.map { $0.rawValue } ?? []
    print("ERR: no image in clipboard. Types: \(types)")
}
SWIFT
swift /tmp/clipboard_image.swift
```

如果成功，图片保存在 `/tmp/clipboard_image.png`。然后按下方"本地图片工作流"继续处理。

如果剪贴板中没有图片（输出 ERR），请提示用户先复制/截图，或提供文件路径。

## 本地图片工作流

将本地图片转为 base64：

```bash
base64 < /absolute/path/to/image.jpg | tr -d '\n' > /tmp/food_image.b64
```

构建请求体：

```bash
printf '{"image_base64":"' > /tmp/food_image.json
cat /tmp/food_image.b64 >> /tmp/food_image.json
printf '"}' >> /tmp/food_image.json
```

调用完整食物分析：

```bash
curl --silent --show-error --location \
  'https://deepeat.ai/step.aispark.api.API/AnalyzeWholeFood' \
  --header 'Content-Type: application/json' \
  --data-binary @/tmp/food_image.json
```

## 代理修复

如果 `curl` 错误地尝试本地代理如 `127.0.0.1:7890`，使用以下方式重试：

```bash
env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY curl ...
```

## 返回字段

`AnalyzeWholeFood`（完整食物分析）：

- `food_name` — 食物名称
- `total_weight_g` — 总重量（克）
- `total_calories_kcal` — 总热量（千卡）
- `carbs_g` — 碳水化合物（克）
- `proteins_g` — 蛋白质（克）
- `fats_g` — 脂肪（克）
- `display_gi` — 升糖指数（GI）
- `dietary_fiber_g` — 膳食纤维（克）
- `sugar_g` — 糖分（克）
- `ingredients[]` — 成分列表
- `health_score` — 健康评分
- `health_profile` — 健康概况

`ExtractFoodMacros`（宏量营养素提取）：

- `food_name` — 食物名称
- `total_weight_g` — 总重量（克）
- `total_calories_kcal` — 总热量（千卡）
- `carbs_g` — 碳水化合物（克）
- `proteins_g` — 蛋白质（克）
- `fats_g` — 脂肪（克）

`AnalyzeIngredients`（深度成分分析）：

- `display_gi` — 升糖指数（GI）
- `dietary_fiber_g` — 膳食纤维（克）
- `sugar_g` — 糖分（克）
- `ingredients[]` — 成分列表

`GetHealthInsight`（健康洞察）：

- `health_score` — 健康评分
- `health_profile` — 健康概况

`SearchFood`（食物搜索）：

- `foods[]` — 食物列表
- `pagination.page` — 当前页码
- `pagination.size` — 每页数量
- `pagination.total` — 总数

`health_score` 含义：

- AI 食物评估生成的 `1-5` 分评分
- `5` 为最高分
- 用于帮助用户做出更合理的营养选择

## 输出规则

- 保持数值与 API 返回完全一致
- 不要编造缺失的字段
- 完整图片分析默认使用 `AnalyzeWholeFood`
- 专项分析仅使用与用户请求匹配的专用 API
- `SearchFood` 按 API 返回顺序展示结果，实际返回多少就展示多少，不要声称超过 `20` 条

## 常见错误

- `400 invalid_request` — 请求无效
- `422 food_not_recognized` — 未识别到食物
- `422 barcode_only_result` — 仅识别到条形码
- `429 rate_limit_exceeded` — 请求频率超限
- `500 internal_error` — 服务器内部错误
- `502 upstream_flow_error` — 上游服务错误

