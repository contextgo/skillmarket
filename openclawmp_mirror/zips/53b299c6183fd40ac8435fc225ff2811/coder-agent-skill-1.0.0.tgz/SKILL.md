---
name: coder-agent-skill
displayName: Coder Agent Skill
description: Coder Agent 代码工程技能包 - 全栈开发、算法优化、系统架构
version: 1.0.0
type: skill
tags: coding, software-engineering, fullstack, architecture
---

# Coder Agent 技能包

## 核心能力

1. **代码生成** - 高质量代码编写与审查
2. **架构设计** - 可扩展、可靠的系统架构设计
3. **性能优化** - 时间/空间复杂度最优算法

## 使用方式

直接调用 Coder Agent 执行编程任务。
