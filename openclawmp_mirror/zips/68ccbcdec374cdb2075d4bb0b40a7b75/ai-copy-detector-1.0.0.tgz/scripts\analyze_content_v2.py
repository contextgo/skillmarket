#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI内容检测器 V2 - 优化版
基于真实案例重新设计的检测算法
"""

import re
import json
import sys
import io
from collections import Counter
from typing import Dict, List, Tuple

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')


class AIContentDetectorV2:
    """检测文本的AI生成特征 - V2优化版"""
    
    # AI中文写作特征 - 过度修饰
    AI_CHINESE_PATTERNS = {
        # AI喜欢堆砌的成语和四字词
        'chengyu_ai_favorite': [
            '愈发', '渐渐', '深深', '淡淡', '默默',
            '不知不觉', '潜移默化', '历历在目', '栩栩如生',
            '情不自禁', '不由自主', '莫名其妙', '不可思议',
            '恍然大悟', '豁然开朗', '心潮澎湃', '百感交集'
        ],
        # AI常用的对偶/排比结构
        'parallel_structures': [
            '说长不长', '说短不短', '说大不大', '说小不小',
            '非但没有', '反而', '不但没有', '反而',
            '一方面', '另一方面', '时而', '时而'
        ],
        # AI常用的文学意象（过于典型）
        'typical_imagery': [
            '宣纸', '墨迹', '晕开', '镌刻', '心版',
            '梅树', '枯枝', '新枝', '落叶', '秋风',
            '夕阳', '黄昏', '晨曦', '暮色', '月色',
            '潺潺', '悠悠', '袅袅', '徐徐', '缓缓'
        ],
        # AI过度使用的情感词
        'ai_emotion_words': [
            '不能忘记', '难以忘怀', '铭记于心', '刻骨铭心',
            '愈发清晰', '愈发沉重', '渐渐模糊', '渐渐远去',
            '深深', '淡淡', '浓浓', '浅浅'
        ],
        # AI过渡词（过于正式）
        'formal_transitions': [
            '综上所述', '总而言之', '由此可见', '不难发现',
            '值得注意的是', '需要指出的是', '从某种意义上说',
            '首先', '其次', '最后', '第一', '第二', '第三'
        ]
    }
    
    # AI英文写作特征
    AI_ENGLISH_PATTERNS = {
        # 学术AI常用连接词（过度使用）
        'academic_connectors': [
            'based on', 'through', 'via', 'by means of',
            'in order to', 'with respect to', 'in terms of',
            'as a result', 'therefore', 'thus', 'hence',
            'furthermore', 'moreover', 'additionally',
            'consequently', 'subsequently', 'accordingly'
        ],
        # AI模板句式
        'template_phrases': [
            'we propose', 'we present', 'we introduce',
            'it is worth noting', 'it is important to note',
            'experiments show', 'results demonstrate',
            'achieves state-of-the-art', 'outperforms existing methods'
        ],
        # 过度复杂的学术词汇
        'overly_academic': [
            'utilize', 'leverage', 'employ', 'exploit',
            'demonstrate', 'illustrate', 'indicate', 'suggest',
            'significantly', 'substantially', 'considerably'
        ]
    }
    
    # 人工写作特征 - 不完美但真实
    HUMAN_PATTERNS = {
        'chinese': {
            # 口语化表达
            'colloquial': [
                '嗯', '啊', '呢', '吧', '啦', '嘛', '呗',
                '其实', '说实话', '老实说', '讲真',
                '反正', '就是', '那个', '然后'
            ],
            # 工程化表达（技术文档）
            'engineering': [
                '实现', '达到', '完成', '搞定', '搞定',
                '优化', '改进', '调整', '修改',
                '测试', '验证', '确认', '确保'
            ],
            # 中英文混用（技术文档特征）
            'mixed_language': [
                'PTZ', 'AI', 'API', 'UI', 'CPU', 'GPU',
                'OK', 'bug', 'debug', 'code'
            ]
        },
        'english': {
            # 简单直接的表达
            'simple_direct': [
                'get', 'make', 'do', 'have', 'take',
                'use', 'work', 'run', 'go', 'come'
            ],
            # 语法不完美标志
            'imperfections': [
                'is on the research of',  # 中式英语
                'moving object',  # 单复数错误
                'the datas',  # 不可数名词加s
            ],
            # 口语化缩写
            'contractions': [
                "don't", "can't", "won't", "it's", "that's",
                "we're", "they're", "isn't", "aren't"
            ]
        }
    }
    
    def __init__(self, text: str):
        self.text = text
        self.is_chinese = any(ord(c) > 127 for c in text)
        self.sentences = self._split_sentences(text)
        self.words = self._extract_words(text)
        
    def _split_sentences(self, text: str) -> List[str]:
        """分割句子"""
        if self.is_chinese:
            pattern = r'[。！？；]'
        else:
            pattern = r'[.!?]+'
        sentences = re.split(pattern, text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _extract_words(self, text: str) -> List[str]:
        """提取词汇"""
        if self.is_chinese:
            # 中文按字符分词
            return list(text.replace(' ', '').replace('\n', ''))
        else:
            # 英文按空格分词
            return text.lower().split()
    
    def _calculate_rhetoric_density(self) -> float:
        """计算修辞密度（AI倾向于过度修辞）"""
        if not self.is_chinese:
            return 0.0
        
        # 检测比喻、对偶等修辞
        rhetoric_markers = 0
        
        # 比喻词
        if '像' in self.text or '仿佛' in self.text or '如同' in self.text:
            rhetoric_markers += 1
        
        # 对偶结构
        if '；' in self.text:
            rhetoric_markers += self.text.count('；')
        
        # 排比结构检测
        parallel_patterns = ['足以', '像是', '愈发']
        for pattern in parallel_patterns:
            if self.text.count(pattern) >= 2:
                rhetoric_markers += 1
        
        # 归一化
        return min(rhetoric_markers / max(len(self.sentences), 1), 1.0)
    
    def _calculate_chengyu_density(self) -> float:
        """计算成语/固定搭配密度"""
        if not self.is_chinese:
            return 0.0
        
        chengyu_count = 0
        all_chengyu = (self.AI_CHINESE_PATTERNS['chengyu_ai_favorite'] + 
                      self.AI_CHINESE_PATTERNS['typical_imagery'] +
                      self.AI_CHINESE_PATTERNS['ai_emotion_words'])
        
        for chengyu in all_chengyu:
            chengyu_count += self.text.count(chengyu)
        
        # 归一化：每100字中的成语数
        text_length = len(self.text)
        if text_length > 0:
            return min(chengyu_count / (text_length / 100), 1.0)
        return 0
    
    def _calculate_emotion_density(self) -> float:
        """计算情感词汇密度"""
        if not self.is_chinese:
            return 0.0
        
        emotion_count = 0
        for word in self.AI_CHINESE_PATTERNS['ai_emotion_words']:
            emotion_count += self.text.count(word)
        
        # 额外的情感词检测
        additional_emotion = ['爱', '恨', '喜', '悲', '愁', '思', '念']
        for char in additional_emotion:
            emotion_count += self.text.count(char)
        
        text_length = len(self.text)
        if text_length > 0:
            return min(emotion_count / (text_length / 50), 1.0)
        return 0
    
    def _calculate_parallelism(self) -> float:
        """计算句式工整度（AI过于工整）"""
        if not self.is_chinese:
            return 0.0
        
        parallel_count = 0
        for pattern in self.AI_CHINESE_PATTERNS['parallel_structures']:
            if pattern in self.text:
                parallel_count += 1
        
        return min(parallel_count / 2, 1.0)
    
    def _calculate_academic_connector_density(self) -> float:
        """计算学术连接词密度（英文）"""
        if self.is_chinese:
            return 0.0
        
        text_lower = self.text.lower()
        connector_count = 0
        
        for connector in self.AI_ENGLISH_PATTERNS['academic_connectors']:
            connector_count += text_lower.count(connector)
        
        for template in self.AI_ENGLISH_PATTERNS['template_phrases']:
            connector_count += text_lower.count(template)
        
        word_count = len(self.words)
        if word_count > 0:
            return min(connector_count / (word_count / 20), 1.0)
        return 0
    
    def _calculate_sentence_complexity_variance(self) -> float:
        """计算句子复杂度变化（人类变化更大）"""
        if len(self.sentences) < 2:
            return 0.5
        
        lengths = [len(s) for s in self.sentences]
        avg_length = sum(lengths) / len(lengths)
        
        # 计算标准差
        variance = sum((l - avg_length) ** 2 for l in lengths) / len(lengths)
        std_dev = variance ** 0.5
        
        # 人类写作标准差通常较大
        # 归一化：标准差越大越像人类
        return min(std_dev / 30, 1.0)
    
    def _calculate_imperfection_score(self) -> float:
        """计算不完美度（人工写作有小错误）"""
        if self.is_chinese:
            # 中文：检测口语化、中英文混用
            score = 0
            
            # 口语化
            for word in self.HUMAN_PATTERNS['chinese']['colloquial']:
                if word in self.text:
                    score += 0.1
            
            # 工程化表达
            for word in self.HUMAN_PATTERNS['chinese']['engineering']:
                if word in self.text:
                    score += 0.05
            
            # 中英文混用
            for word in self.HUMAN_PATTERNS['chinese']['mixed_language']:
                if word in self.text:
                    score += 0.15
            
            return min(score, 1.0)
        else:
            # 英文：检测简单词汇、语法不完美
            score = 0
            text_lower = self.text.lower()
            
            # 简单直接词汇
            for word in self.HUMAN_PATTERNS['english']['simple_direct']:
                if word in text_lower:
                    score += 0.02
            
            # 口语化缩写
            for contraction in self.HUMAN_PATTERNS['english']['contractions']:
                if contraction in text_lower:
                    score += 0.1
            
            # 语法不完美（中式英语）
            if 'is on the research of' in text_lower:
                score += 0.3
            if 'moving object' in text_lower and 'objects' not in text_lower:
                score += 0.2
            
            return min(score, 1.0)
    
    def _calculate_terminology_density(self) -> float:
        """计算专业术语密度（人工技术文档更高）"""
        if self.is_chinese:
            # 中文技术术语
            tech_terms = ['算法', '系统', '检测', '跟踪', '自适应', 
                         '方差', '序列', '像素', '阈值', '优化']
            count = sum(self.text.count(term) for term in tech_terms)
        else:
            # 英文技术术语
            tech_terms = ['algorithm', 'system', 'detect', 'track', 
                         'covariance', 'sequence', 'pixel', 'threshold']
            text_lower = self.text.lower()
            count = sum(text_lower.count(term) for term in tech_terms)
        
        text_length = len(self.text)
        if text_length > 0:
            return min(count / (text_length / 100), 1.0)
        return 0
    
    def analyze(self) -> Dict:
        """执行完整分析"""
        # 计算各项指标
        rhetoric_density = self._calculate_rhetoric_density()
        chengyu_density = self._calculate_chengyu_density()
        emotion_density = self._calculate_emotion_density()
        parallelism = self._calculate_parallelism()
        academic_density = self._calculate_academic_connector_density()
        complexity_variance = self._calculate_sentence_complexity_variance()
        imperfection = self._calculate_imperfection_score()
        terminology = self._calculate_terminology_density()
        
        # 根据语言类型调整权重
        if self.is_chinese:
            # 中文检测权重
            ai_indicators = (
                rhetoric_density * 0.25 +      # 修辞密度
                chengyu_density * 0.25 +       # 成语密度
                emotion_density * 0.20 +       # 情感密度
                parallelism * 0.15             # 工整度
            )
            
            human_indicators = (
                complexity_variance * 0.20 +   # 句式变化
                imperfection * 0.30 +          # 不完美度（口语化）
                terminology * 0.25 +           # 术语密度
                (1 - chengyu_density) * 0.15   # 少成语
            )
        else:
            # 英文检测权重
            ai_indicators = (
                academic_density * 0.35 +      # 学术连接词
                (1 - imperfection) * 0.20 +    # 过于完美
                (1 - complexity_variance) * 0.15  # 句式过于规整
            )
            
            human_indicators = (
                imperfection * 0.35 +          # 不完美度（语法错误、口语化）
                complexity_variance * 0.25 +   # 句式变化
                terminology * 0.20 +           # 术语密度
                (1 - academic_density) * 0.10  # 少连接词
            )
        
        # 计算最终分数
        ai_score = min(ai_indicators * 100, 70)
        human_score = min(human_indicators * 100, 70)
        
        # 疑似AI区域
        ambiguous = max(0, 100 - ai_score - human_score)
        
        # 归一化
        total = ai_score + human_score + ambiguous
        if total > 0:
            ai_score = (ai_score / total) * 100
            human_score = (human_score / total) * 100
            ambiguous = (ambiguous / total) * 100
        
        # 生成特征说明
        features = self._extract_features(
            rhetoric_density, chengyu_density, emotion_density,
            parallelism, academic_density, complexity_variance,
            imperfection, terminology
        )
        
        return {
            'scores': {
                'human': round(human_score, 1),
                'ambiguous': round(ambiguous, 1),
                'ai': round(ai_score, 1)
            },
            'features': features,
            'statistics': {
                'total_chars': len(self.text),
                'sentence_count': len(self.sentences),
                'avg_sentence_length': round(len(self.text) / max(len(self.sentences), 1), 1),
                'rhetoric_density': round(rhetoric_density, 2),
                'chengyu_density': round(chengyu_density, 2) if self.is_chinese else None,
                'emotion_density': round(emotion_density, 2) if self.is_chinese else None,
                'academic_density': round(academic_density, 2) if not self.is_chinese else None,
                'imperfection': round(imperfection, 2),
                'terminology': round(terminology, 2)
            }
        }
    
    def _extract_features(self, rhetoric, chengyu, emotion, parallelism,
                         academic, complexity, imperfection, terminology) -> Dict:
        """提取详细特征说明"""
        features = {
            'human_indicators': [],
            'ai_indicators': [],
            'neutral': []
        }
        
        if self.is_chinese:
            # 中文特征分析
            if rhetoric > 0.3:
                features['ai_indicators'].append(f'修辞密度过高 ({rhetoric:.0%})，可能过度修饰')
            if chengyu > 0.3:
                features['ai_indicators'].append(f'成语/固定搭配密集 ({chengyu:.0%})，有堆砌感')
            if emotion > 0.3:
                features['ai_indicators'].append(f'情感词汇过于集中 ({emotion:.0%})')
            if parallelism > 0.3:
                features['ai_indicators'].append(f'句式过于工整对称 ({parallelism:.0%})')
            
            if terminology > 0.3:
                features['human_indicators'].append(f'专业术语密度高 ({terminology:.0%})，技术性强')
            if imperfection > 0.2:
                features['human_indicators'].append(f'有口语化/工程化表达 ({imperfection:.0%})')
            if chengyu < 0.1:
                features['human_indicators'].append('成语使用自然，无堆砌感')
            if complexity > 0.5:
                features['human_indicators'].append('句式长度变化丰富')
                
        else:
            # 英文特征分析
            if academic > 0.4:
                features['ai_indicators'].append(f'学术连接词过度使用 ({academic:.0%})')
            if complexity < 0.3:
                features['ai_indicators'].append('句式长度过于规整')
            if imperfection < 0.1:
                features['ai_indicators'].append('表达过于完美，缺乏人类写作痕迹')
            
            if imperfection > 0.2:
                features['human_indicators'].append(f'有语法不完美/口语化痕迹 ({imperfection:.0%})')
            if terminology > 0.3:
                features['human_indicators'].append(f'专业术语使用 ({terminology:.0%})')
            if complexity > 0.5:
                features['human_indicators'].append('句式复杂度变化大')
            if academic < 0.2:
                features['human_indicators'].append('连接词使用自然，无过度堆砌')
        
        features['neutral'].append(f'文本长度: {len(self.text)} 字符')
        features['neutral'].append(f'句子数: {len(self.sentences)}')
        
        return features


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("Usage: python analyze_content_v2.py '<text>'")
        print("   or: python analyze_content_v2.py - < file.txt")
        sys.exit(1)
    
    # 获取输入文本
    if sys.argv[1] == '-':
        text = sys.stdin.read()
    else:
        text = sys.argv[1]
    
    if not text.strip():
        print(json.dumps({'error': 'Empty text provided'}, ensure_ascii=False))
        sys.exit(1)
    
    detector = AIContentDetectorV2(text)
    result = detector.analyze()
    
    print(json.dumps(result, ensure_ascii=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
