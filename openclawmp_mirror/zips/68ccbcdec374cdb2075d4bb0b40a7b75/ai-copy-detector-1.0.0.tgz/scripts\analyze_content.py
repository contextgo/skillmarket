#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI内容检测器 - 分析文本的人工/AI特征比例
"""

import re
import json
import sys
import io
from collections import Counter
from typing import Dict, List, Tuple

# 设置UTF-8编码
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

class AIContentDetector:
    """检测文本的AI生成特征"""
    
    # AI常见词汇和短语
    AI_PATTERNS = {
        'formal_transitions': [
            '此外', '另外', '与此同时', '综上所述', '总而言之',
            '首先', '其次', '最后', '综上所述', '值得注意的是',
            'furthermore', 'moreover', 'additionally', 'in conclusion',
            'firstly', 'secondly', 'finally', 'it is worth noting'
        ],
        'ai_phrases': [
            '让我们一起', '值得注意的是', '不难发现', '显而易见',
            '毫无疑问', '毫无疑问', '必须承认', '客观地说',
            'let\'s', 'it is important to note', 'as we can see',
            'it is evident that', 'undoubtedly', 'objectively speaking'
        ],
        'hedging_words': [
            '可能', '也许', '一定程度上', '某种程度上', '相对',
            '比较', '较为', '略微', '稍微', '一定程度上',
            'possibly', 'perhaps', 'to some extent', 'relatively',
            'fairly', 'somewhat', 'slightly', 'moderately'
        ],
        'list_indicators': [
            '第一', '第二', '第三', '第四', '第五',
            '1.', '2.', '3.', '4.', '5.',
            'one', 'two', 'three', 'four', 'five',
            'first', 'second', 'third', 'fourth', 'fifth'
        ]
    }
    
    # 人类写作特征
    HUMAN_PATTERNS = {
        'informal_markers': [
            '哈哈', '嘿嘿', '嗯', '啊', '呢', '吧', '啦', '嘛',
            '绝了', '真的假的', '不是吧',
            'haha', 'lol', 'tbh', 'imo', 'idk'
        ],
        'emotional_words': [
            '超', '巨', '贼', '特', '老', '爆',
            '超级', '特别', '非常', '真的', '简直', '实在',
            'super', 'really', 'totally', 'absolutely', 'literally'
        ],
        'personal_pronouns': [
            '我', '你', '咱', '俺', '本人',
            'i ', 'you ', 'we ', 'my ', 'your ', 'our '
        ],
        'imperfections': [
            '嗯', '那个', '就是', '然后', '怎么说呢'
        ]
    }
    
    def __init__(self, text: str):
        self.text = text
        self.sentences = self._split_sentences(text)
        self.words = self._extract_words(text)
        
    def _split_sentences(self, text: str) -> List[str]:
        """分割句子"""
        # 支持中英文句子分割
        pattern = r'[。！？.!?]+|\n'
        sentences = re.split(pattern, text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _extract_words(self, text: str) -> List[str]:
        """提取词汇"""
        # 中文分词（简单版）
        chinese_words = re.findall(r'[\u4e00-\u9fff]+', text)
        # 英文单词
        english_words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
        return chinese_words + english_words
    
    def _calculate_repetition_score(self) -> float:
        """计算重复度分数"""
        if not self.words:
            return 0.0
        word_counts = Counter(self.words)
        total_words = len(self.words)
        unique_words = len(word_counts)
        # 重复度 = 1 - (唯一词数/总词数)
        repetition = 1 - (unique_words / total_words) if total_words > 0 else 0
        return min(repetition * 2, 1.0)  # 归一化到0-1
    
    def _calculate_sentence_variance(self) -> float:
        """计算句子长度变化度"""
        if len(self.sentences) < 2:
            return 0.5
        lengths = [len(s) for s in self.sentences]
        avg_length = sum(lengths) / len(lengths)
        variance = sum((l - avg_length) ** 2 for l in lengths) / len(lengths)
        # 变化度越高越像人类
        normalized_variance = min(variance / 100, 1.0)
        return normalized_variance
    
    def _count_pattern_matches(self, patterns: Dict[str, List[str]]) -> int:
        """统计模式匹配次数"""
        text_lower = self.text.lower()
        count = 0
        for category, phrases in patterns.items():
            for phrase in phrases:
                count += text_lower.count(phrase.lower())
        return count
    
    def _detect_structure_patterns(self) -> float:
        """检测结构化程度（列表、编号等）"""
        structure_score = 0
        
        # 检测列表模式
        list_patterns = self.AI_PATTERNS['list_indicators']
        for pattern in list_patterns:
            structure_score += self.text.count(pattern)
        
        # 检测换行符使用（结构化内容常用换行）
        newline_count = self.text.count('\n')
        structure_score += newline_count * 0.5
        
        # 检测冒号使用（常用于结构化说明）
        colon_count = self.text.count('：') + self.text.count(':')
        structure_score += colon_count * 0.3
        
        # 归一化
        text_length = len(self.text)
        if text_length > 0:
            return min(structure_score / (text_length / 100), 1.0)
        return 0
    
    def analyze(self) -> Dict:
        """执行完整分析"""
        # 计算各项指标
        ai_pattern_count = self._count_pattern_matches(self.AI_PATTERNS)
        human_pattern_count = self._count_pattern_matches(self.HUMAN_PATTERNS)
        
        repetition_score = self._calculate_repetition_score()
        variance_score = self._calculate_sentence_variance()
        structure_score = self._detect_structure_patterns()
        
        text_length = len(self.text)
        
        # 计算基础分数
        ai_base = (ai_pattern_count * 2 + structure_score * 10 + repetition_score * 5) / max(text_length / 50, 1)
        human_base = (human_pattern_count * 3 + variance_score * 10) / max(text_length / 50, 1)
        
        # 调整分数范围
        ai_score = min(ai_base * 10, 60)
        human_score = min(human_base * 10, 60)
        
        # 疑似AI区域是两者的重叠部分
        ambiguous = max(0, 100 - ai_score - human_score)
        
        # 如果总和小于100，按比例分配剩余部分到疑似区域
        total = ai_score + human_score + ambiguous
        if total < 100:
            ambiguous += (100 - total)
        elif total > 100:
            # 归一化
            factor = 100 / total
            ai_score *= factor
            human_score *= factor
            ambiguous *= factor
        
        # 生成详细特征
        features = self._extract_features(ai_pattern_count, human_pattern_count, 
                                         repetition_score, variance_score, structure_score)
        
        return {
            'scores': {
                'human': round(human_score, 1),
                'ambiguous': round(ambiguous, 1),
                'ai': round(ai_score, 1)
            },
            'features': features,
            'statistics': {
                'total_chars': text_length,
                'sentence_count': len(self.sentences),
                'word_count': len(self.words),
                'avg_sentence_length': round(text_length / max(len(self.sentences), 1), 1)
            }
        }
    
    def _extract_features(self, ai_patterns: int, human_patterns: int,
                         repetition: float, variance: float, structure: float) -> Dict:
        """提取详细特征说明"""
        features = {
            'human_indicators': [],
            'ai_indicators': [],
            'neutral': []
        }
        
        # 人类特征
        if human_patterns > 0:
            features['human_indicators'].append(f"检测到 {human_patterns} 处口语化表达")
        if variance > 0.5:
            features['human_indicators'].append("句子长度变化丰富")
        if human_patterns == 0 and variance < 0.3:
            features['ai_indicators'].append("缺乏口语化表达")
        
        # AI特征
        if ai_patterns > 0:
            features['ai_indicators'].append(f"检测到 {ai_patterns} 处AI常用过渡词")
        if structure > 0.3:
            features['ai_indicators'].append("内容结构高度组织化")
        if repetition > 0.3:
            features['ai_indicators'].append("词汇重复度较高")
        
        # 中性特征
        features['neutral'].append(f"文本长度: {len(self.text)} 字符")
        features['neutral'].append(f"句子数: {len(self.sentences)}")
        
        return features


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("Usage: python analyze_content.py '<text>'")
        print("   or: echo '<text>' | python analyze_content.py")
        sys.exit(1)
    
    # 获取输入文本
    if sys.argv[1] == '-':
        text = sys.stdin.read()
    else:
        text = sys.argv[1]
    
    if not text.strip():
        print(json.dumps({'error': 'Empty text provided'}, ensure_ascii=False))
        sys.exit(1)
    
    # 执行分析
    detector = AIContentDetector(text)
    result = detector.analyze()
    
    # 输出JSON结果
    print(json.dumps(result, ensure_ascii=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
