/**
 * 趋势分析模块
 * 技术指标计算：MA、RSI、布林带
 */
const api = require('./api');

/**
 * 计算简单移动平均线
 */
function calculateMA(prices, period) {
  const result = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      result.push(null);
    } else {
      const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      result.push(sum / period);
    }
  }
  return result;
}

/**
 * 计算 RSI
 */
function calculateRSI(prices, period = 14) {
  const changes = [];
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }

  const gains = changes.map(c => c > 0 ? c : 0);
  const losses = changes.map(c => c < 0 ? Math.abs(c) : 0);

  const result = [];
  let avgGain = 0;
  let avgLoss = 0;

  for (let i = 0; i < gains.length; i++) {
    if (i < period) {
      avgGain = (avgGain * i + gains[i]) / (i + 1);
      avgLoss = (avgLoss * i + losses[i]) / (i + 1);
    } else {
      avgGain = (avgGain * (period - 1) + gains[i]) / period;
      avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
    }

    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    result.push(rsi);
  }

  return [null, ...result];
}

/**
 * 计算布林带
 */
function calculateBB(prices, period = 20, stdDev = 2) {
  const ma = calculateMA(prices, period);
  const result = { upper: [], middle: ma, lower: [] };

  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      result.upper.push(null);
      result.lower.push(null);
    } else {
      const slice = prices.slice(i - period + 1, i + 1);
      const mean = ma[i];
      const variance = slice.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / period;
      const std = Math.sqrt(variance);

      result.upper.push(mean + stdDev * std);
      result.lower.push(mean - stdDev * std);
    }
  }

  return result;
}

/**
 * 趋势信号分析
 */
async function analyzeTrend(symbol, timeframe = '1h') {
  const ohlcv = await api.getOHLCV(symbol, timeframe, 100);
  const closes = ohlcv.map(k => k.close);
  const latestClose = closes[closes.length - 1];

  // MA 信号
  const ma20 = calculateMA(closes, 20);
  const ma50 = calculateMA(closes, 50);
  const maSignal = latestClose > ma20[ma20.length - 1] ? 1 : -1;

  // RSI 信号
  const rsi = calculateRSI(closes);
  const latestRSI = rsi[rsi.length - 1];
  let rsiSignal = 0;
  if (latestRSI < 30) rsiSignal = 1;      // 超卖，多
  else if (latestRSI > 70) rsiSignal = -1; // 超买，空
  else rsiSignal = 0;

  // 布林带信号
  const bb = calculateBB(closes);
  const latestBB = {
    upper: bb.upper[bb.upper.length - 1],
    middle: bb.middle[bb.middle.length - 1],
    lower: bb.lower[bb.lower.length - 1]
  };
  let bbSignal = 0;
  if (latestClose < latestBB.lower) bbSignal = 1;
  else if (latestClose > latestBB.upper) bbSignal = -1;

  // 综合评分
  const score = (maSignal * 0.4) + (rsiSignal * 0.3) + (bbSignal * 0.3);

  return {
    symbol,
    timeframe,
    price: latestClose,
    indicators: {
      ma: { value: latestMA, signal: maSignal > 0 ? 'bullish' : 'bearish' },
      rsi: { value: latestRSI.toFixed(2), signal: rsiSignal === 1 ? 'oversold' : rsiSignal === -1 ? 'overbought' : 'neutral' },
      bb: { upper: latestBB.upper, middle: latestBB.middle, lower: latestBB.lower }
    },
    score,
    signal: score > 0.3 ? 'LONG' : score < -0.3 ? 'SHORT' : 'NEUTRAL',
    timestamp: new Date().toISOString()
  };
}

// 多时间周期分析
async function multiTimeframeAnalysis(symbol) {
  const timeframes = ['15m', '1h', '4h'];
  const results = [];

  for (const tf of timeframes) {
    const analysis = await analyzeTrend(symbol, tf);
    results.push(analysis);
  }

  // 综合判断
  const longCount = results.filter(r => r.signal === 'LONG').length;
  const shortCount = results.filter(r => r.signal === 'SHORT').length;

  return {
    symbol,
    timeframes: results,
    consensus: longCount > shortCount ? 'LONG' : shortCount > longCount ? 'SHORT' : 'NEUTRAL',
    confidence: Math.max(longCount, shortCount) / timeframes.length
  };
}

// 命令行
const args = process.argv.slice(2);
if (args[0] === '--symbol' && args[1]) {
  analyzeTrend(args[1], args[2] || '1h').then(r => {
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  });
} else if (args[0] === '--multi' && args[1]) {
  multiTimeframeAnalysis(args[1]).then(r => {
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  });
}

module.exports = {
  calculateMA,
  calculateRSI,
  calculateBB,
  analyzeTrend,
  multiTimeframeAnalysis
};
