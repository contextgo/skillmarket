/**
 * 自动交易执行模块
 * 趋势策略自动开仓/平仓
 */
const api = require('./api');
const trend = require('./trend');
const fs = require('fs');
const path = require('path');

let isRunning = false;
let positions = [];
let stateFile = path.join(__dirname, '../state.json');

// 加载状态
function loadState() {
  if (fs.existsSync(stateFile)) {
    return JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  }
  return { positions: [], lastTrade: null };
}

// 保存状态
function saveState(state) {
  fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
}

// 检查是否需要开仓
async function checkEntry(symbol) {
  const config = api.loadConfig();
  const analysis = await trend.multiTimeframeAnalysis(symbol);

  console.log(`\n📊 ${symbol} 多时间周期分析:`);
  analysis.timeframes.forEach(t => {
    console.log(`  ${t.timeframe}: ${t.signal} (score: ${t.score.toFixed(2)})`);
  });
  console.log(`  综合信号: ${analysis.consensus} (置信度: ${(analysis.confidence * 100).toFixed(0)}%)`);

  // 检查是否已有持仓
  const existingPosition = positions.find(p => p.symbol === symbol);
  if (existingPosition) {
    console.log(`⚠️ ${symbol} 已有持仓，跳过开仓`);
    return null;
  }

  // 检查风控
  if (positions.length >= config.risk.maxOpenPositions) {
    console.log(`⚠️ 已达最大持仓数 ${config.risk.maxOpenPositions}，暂停开仓`);
    return null;
  }

  const totalValue = positions.reduce((sum, p) => sum + p.value, 0);
  if (totalValue >= config.risk.maxPosition) {
    console.log(`⚠️ 已达最大仓位价值 $${config.risk.maxPosition}，暂停开仓`);
    return null;
  }

  // 开仓信号
  if (analysis.consensus === 'LONG' && analysis.confidence >= 0.6) {
    return 'LONG';
  } else if (analysis.consensus === 'SHORT' && analysis.confidence >= 0.6) {
    return 'SHORT';
  }

  return null;
}

// 检查是否需要平仓
async function checkExit(position) {
  const config = api.loadConfig();
  const currentPrice = await api.getPrice(position.symbol);
  const priceChange = (currentPrice.last - position.entryPrice) / position.entryPrice * 100;
  const pnl = priceChange * (position.leverage || config.leverage);

  console.log(`\n📊 ${position.symbol} 仓位检查:`);
  console.log(`  入场价: $${position.entryPrice}`);
  console.log(`  当前价: $${currentPrice.last}`);
  console.log(`  价格变化: ${priceChange.toFixed(2)}%`);
  console.log(`  盈亏 (${config.leverage}x): ${pnl.toFixed(2)}%`);

  // 止盈
  if (pnl >= config.risk.takeProfitPercent) {
    console.log(`✅ 触及止盈 ${config.risk.takeProfitPercent}%，平仓`);
    return 'TAKE_PROFIT';
  }

  // 止损
  if (pnl <= -config.risk.stopLossPercent) {
    console.log(`🛡️ 触及止损 -${config.risk.stopLossPercent}%，平仓`);
    return 'STOP_LOSS';
  }

  // 反向信号
  const analysis = await trend.multiTimeframeAnalysis(position.symbol);
  if (position.side === 'LONG' && analysis.consensus === 'SHORT') {
    console.log(`⚠️ 反向信号，平仓`);
    return 'REVERSE';
  }
  if (position.side === 'SHORT' && analysis.consensus === 'LONG') {
    console.log(`⚠️ 反向信号，平仓`);
    return 'REVERSE';
  }

  return null;
}

// 开仓
async function openPosition(symbol, side) {
  const config = api.loadConfig();
  const priceData = await api.getPrice(symbol);

  // 计算开仓数量
  const positionSize = config.risk.maxPosition / config.risk.maxOpenPositions / priceData.last;

  // 设置杠杆
  await api.setLeverage(symbol, config.leverage);

  // 开仓
  let order;
  if (side === 'LONG') {
    order = await api.openLong(symbol, positionSize, priceData.last);
  } else {
    order = await api.openShort(symbol, positionSize, priceData.last);
  }

  const newPosition = {
    symbol,
    side,
    entryPrice: priceData.last,
    amount: positionSize,
    leverage: config.leverage,
    openTime: new Date().toISOString(),
    orderId: order.id
  };

  positions.push(newPosition);
  saveState({ positions });

  console.log(`✅ ${side} 开仓成功: ${symbol} @ $${priceData.last}`);
  return newPosition;
}

// 平仓
async function closePosition(position, reason) {
  const config = api.loadConfig();
  const priceData = await api.getPrice(position.symbol);

  await api.closePosition(position.symbol, position.amount, priceData.last);

  const pnl = (priceData.last - position.entryPrice) / position.entryPrice * 100 * position.leverage;

  positions = positions.filter(p => p.symbol !== position.symbol);
  saveState({ positions, lastTrade: { ...position, closePrice: priceData.last, pnl, reason, closeTime: new Date().toISOString() } });

  console.log(`✅ 平仓成功: ${position.symbol} @ $${priceData.last}, 盈亏: ${pnl.toFixed(2)}%`);
}

// 交易循环
async function tradingLoop() {
  if (!isRunning) return;

  const config = api.loadConfig();

  try {
    // 检查所有监控的币种
    for (const symbol of config.symbols) {
      // 检查平仓
      const position = positions.find(p => p.symbol === symbol);
      if (position) {
        const exitSignal = await checkExit(position);
        if (exitSignal) {
          await closePosition(position, exitSignal);
        }
      } else {
        // 检查开仓
        const entrySignal = await checkEntry(symbol);
        if (entrySignal) {
          await openPosition(symbol, entrySignal);
        }
      }
    }
  } catch (error) {
    console.error('❌ 交易循环错误:', error.message);
  }

  // 5分钟检查一次
  setTimeout(tradingLoop, 5 * 60 * 1000);
}

// 启动
async function start() {
  const config = api.loadConfig();

  // 测试API
  const connected = await api.testConnection();
  if (!connected) {
    console.error('❌ API 连接失败，无法启动');
    return;
  }

  // 加载持仓
  positions = loadState().positions;
  console.log(`📂 加载了 ${positions.length} 个持仓`);

  isRunning = true;
  console.log('🚀 交易机器人已启动');

  // 立即执行一次
  await tradingLoop();
}

// 停止
function stop() {
  isRunning = false;
  console.log('🛑 交易机器人已停止');
}

// 命令行
const args = process.argv.slice(2);
if (args[0] === '--start') {
  start();
} else if (args[0] === '--stop') {
  stop();
} else if (args[0] === '--status') {
  positions = loadState().positions;
  console.log('当前持仓:', positions);
}

module.exports = { start, stop, tradingLoop };
