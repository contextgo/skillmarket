/**
 * 交易所 API 模块
 * 支持 Binance、OKX 合约交易
 */
const ccxt = require('ccxt');
const fs = require('fs');
const path = require('path');

// 加载配置
function loadConfig() {
  const configPath = path.join(__dirname, '../config.json');
  if (!fs.existsSync(configPath)) {
    throw new Error('请先配置 config.json: cp config.example.json config.json');
  }
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

// 创建交易所实例
function createExchange() {
  const config = loadConfig();
  const { exchange, apiKey, secretKey, testnet } = config;

  let exchangeInstance;

  if (exchange === 'binance') {
    exchangeInstance = new ccxt.binance({
      apiKey,
      secret,
      enableRateLimit: true,
      options: {
        defaultType: 'future',
        testnet
      }
    });
  } else if (exchange === 'okx') {
    exchangeInstance = new ccxt.okx({
      apiKey,
      secret,
      enableRateLimit: true,
      options: {
        defaultType: 'swap'
      }
    });
  } else {
    throw new Error(`不支持的交易所: ${exchange}`);
  }

  return exchangeInstance;
}

// 测试连接
async function testConnection() {
  try {
    const exchange = createExchange();
    const balance = await exchange.fetchBalance();
    console.log('✅ API 连接成功');
    console.log('📊 合约账户余额:', balance.total);
    return true;
  } catch (error) {
    console.error('❌ API 连接失败:', error.message);
    return false;
  }
}

// 获取合约价格
async function getPrice(symbol) {
  const exchange = createExchange();
  const ticker = await exchange.fetchTicker(symbol);
  return {
    symbol,
    last: ticker.last,
    bid: ticker.bid,
    ask: ticker.ask,
    volume: ticker.volume,
    change: ticker.percentage
  };
}

// 获取K线数据
async function getOHLCV(symbol, timeframe = '1h', limit = 100) {
  const exchange = createExchange();
  const ohlcv = await exchange.fetchOHLCV(symbol, timeframe, undefined, limit);
  return ohlcv.map(k => ({
    timestamp: k[0],
    open: k[1],
    high: k[2],
    low: k[3],
    close: k[4],
    volume: k[5]
  }));
}

// 设置杠杆
async function setLeverage(symbol, leverage) {
  const config = loadConfig();
  const exchange = createExchange();

  if (config.exchange === 'binance') {
    await exchange.setLeverage(leverage, symbol);
  } else if (config.exchange === 'okx') {
    await exchange.setLeverage(leverage, symbol);
  }
  console.log(`✅ 已设置 ${symbol} 杠杆为 ${leverage}x`);
}

// 开多仓
async function openLong(symbol, amount, price) {
  const exchange = createExchange();
  const order = await exchange.createOrder(symbol, 'limit', 'buy', amount, price);
  console.log(`✅ 多单下单成功: ${order.id}`);
  return order;
}

// 开空仓
async function openShort(symbol, amount, price) {
  const exchange = createExchange();
  const order = await exchange.createOrder(symbol, 'limit', 'sell', amount, price);
  console.log(`✅ 空单下单成功: ${order.id}`);
  return order;
}

// 平仓
async function closePosition(symbol, amount, price) {
  const exchange = createExchange();
  const positions = await exchange.fetchPositions(symbol);
  const position = positions.find(p => p.symbol === symbol && p.side === 'short' || p.side === 'long');

  if (!position) {
    console.log('⚠️ 无持仓');
    return null;
  }

  const side = position.side === 'long' ? 'sell' : 'buy';
  const order = await exchange.createOrder(symbol, 'limit', side, Math.abs(position.amount), price);
  console.log(`✅ 平仓成功: ${order.id}`);
  return order;
}

// 获取当前持仓
async function getPositions() {
  const exchange = createExchange();
  const positions = await exchange.fetchPositions();
  return positions.filter(p => p.contracts > 0);
}

// 命令行参数处理
const args = process.argv.slice(2);
if (args[0] === '--test') {
  testConnection().then(() => process.exit(0));
} else if (args[0] === '--price' && args[1]) {
  getPrice(args[1]).then(p => {
    console.log(p);
    process.exit(0);
  });
} else if (args[0] === '--positions') {
  getPositions().then(p => {
    console.log('当前持仓:', p);
    process.exit(0);
  });
}

module.exports = {
  loadConfig,
  createExchange,
  testConnection,
  getPrice,
  getOHLCV,
  setLeverage,
  openLong,
  openShort,
  closePosition,
  getPositions
};
