/**
 * 仓位监控与风控模块
 */
const api = require('./api');
const fs = require('fs');
const path = require('path');

const stateFile = path.join(__dirname, '../state.json');

function loadState() {
  if (fs.existsSync(stateFile)) {
    return JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  }
  return { positions: [], lastTrade: null };
}

// 显示状态
async function showStatus() {
  const state = loadState();
  const config = api.loadConfig();

  console.log('\n' + '='.repeat(50));
  console.log('📊 交易机器人状态');
  console.log('='.repeat(50));

  // 账户信息
  try {
    const balance = await api.createExchange().fetchBalance();
    console.log('\n💰 账户余额:');
    console.log(`  总权益: $${balance.total?.USDT || 'N/A'}`);
    console.log(`  可用: $${balance.free?.USDT || 'N/A'}`);
  } catch (e) {
    console.log('  (无法获取余额)');
  }

  // 当前持仓
  console.log('\n📌 当前持仓:');
  if (state.positions.length === 0) {
    console.log('  无持仓');
  } else {
    for (const pos of state.positions) {
      const currentPrice = await api.getPrice(pos.symbol).catch(() => ({ last: pos.entryPrice }));
      const pnl = (currentPrice.last - pos.entryPrice) / pos.entryPrice * 100 * (pos.leverage || config.leverage);

      console.log(`  ${pos.symbol} ${pos.side}`);
      console.log(`    入场: $${pos.entryPrice} | 当前: $${currentPrice.last}`);
      console.log(`    杠杆: ${pos.leverage || config.leverage}x | 盈亏: ${pnl > 0 ? '+' : ''}${pnl.toFixed(2)}%`);
    }
  }

  // 风控状态
  console.log('\n🛡️ 风控参数:');
  console.log(`  最大仓位: $${config.risk.maxPosition}`);
  console.log(`  最大持仓数: ${config.risk.maxOpenPositions}`);
  console.log(`  止损: ${config.risk.stopLossPercent}%`);
  console.log(`  止盈: ${config.risk.takeProfitPercent}%`);

  // 最近交易
  if (state.lastTrade) {
    console.log('\n📜 最近交易:');
    console.log(`  ${state.lastTrade.symbol} ${state.lastTrade.side} → ${state.lastTrade.reason}`);
    console.log(`  盈亏: ${state.lastTrade.pnl?.toFixed(2) || 'N/A'}%`);
    console.log(`  时间: ${state.lastTrade.closeTime}`);
  }

  console.log('\n' + '='.repeat(50));
}

// 风险检查
async function riskCheck() {
  const state = loadState();
  const config = api.loadConfig();
  const issues = [];

  // 检查持仓数
  if (state.positions.length > config.risk.maxOpenPositions) {
    issues.push(`⚠️ 持仓数 ${state.positions.length} 超过限制 ${config.risk.maxOpenPositions}`);
  }

  // 检查总仓位
  const totalValue = state.positions.reduce((sum, p) => sum + (p.amount * p.entryPrice), 0);
  if (totalValue > config.risk.maxPosition) {
    issues.push(`⚠️ 总仓位 $${totalValue.toFixed(2)} 超过限制 $${config.risk.maxPosition}`);
  }

  // 检查单日亏损
  const todayTrades = state.lastTrade ? [state.lastTrade] : [];
  const todayPnl = todayTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  if (todayPnl < -config.risk.maxDailyLoss) {
    issues.push(`🛑 单日亏损 ${todayPnl.toFixed(2)}% 超过限制 -${config.risk.maxDailyLoss}%`);
  }

  if (issues.length > 0) {
    console.log('\n🚨 风控警告:');
    issues.forEach(i => console.log('  ' + i));
    return false;
  }

  console.log('✅ 风控检查通过');
  return true;
}

// 强制平仓所有
async function closeAll() {
  const state = loadState();

  console.log(`⚠️ 准备平仓所有 ${state.positions.length} 个持仓...`);

  for (const pos of state.positions) {
    try {
      await api.closePosition(pos.symbol, pos.amount, await api.getPrice(pos.symbol).then(p => p.last));
      console.log(`  ✅ ${pos.symbol} 已平仓`);
    } catch (e) {
      console.log(`  ❌ ${pos.symbol} 平仓失败: ${e.message}`);
    }
  }

  state.positions = [];
  fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
  console.log('✅ 全部平仓完成');
}

// 命令行
const args = process.argv.slice(2);
if (args[0] === '--status') {
  showStatus().then(() => process.exit(0));
} else if (args[0] === '--check') {
  riskCheck().then(r => process.exit(r ? 0 : 1));
} else if (args[0] === '--close-all') {
  closeAll().then(() => process.exit(0));
}

module.exports = { showStatus, riskCheck, closeAll };
