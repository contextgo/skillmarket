---
name: crypto-futures-trend-bot
displayName: 合约趋势交易机器人
description: "加密货币合约趋势追踪自动交易机器人，支持 Binance/OKX，支持多时间周期分析，10x杠杆自动开仓平仓，止盈止损风控"
version: 1.0.0
type: skill
tags: crypto, futures, trading, bot, binance, okx, trend
---

# 🚀 合约趋势交易机器人

> 加密货币合约自动交易，趋势追踪策略，10x杠杆

## 功能概览

- 🔌 支持 Binance、OKX 合约 API
- 📈 多时间周期趋势分析 (15m/1h/4h/1d)
- ⚡ 10x 杠杆自动开仓
- 🛡️ 止盈/止损自动平仓
- 📊 风控模块（最大持仓、单日止损、仓位管理）

## 快速开始

### 1. 配置 API

```bash
cp config.example.json config.json
```

编辑 `config.json`：

```json
{
  "exchange": "binance",
  "apiKey": "your_api_key",
  "secretKey": "your_secret_key",
  "testnet": true,
  "symbol": "BTCUSDT",
  "leverage": 10,
  "trend": {
    "timeframes": ["1h", "4h"],
    "indicators": ["ma", "rsi", "bb"]
  },
  "risk": {
    "maxPosition": 1000,
    "stopLoss": 2,
    "takeProfit": 5
  }
}
```

### 2. 测试连接

```bash
node scripts/api.js --test
```

### 3. 启动交易

```bash
node scripts/executor.js --start
```

## 命令参考

| 命令 | 说明 |
|------|------|
| `node scripts/api.js --test` | 测试 API 连接 |
| `node scripts/trend.js --symbol BTCUSDT` | 查看当前趋势信号 |
| `node scripts/executor.js --start` | 启动自动交易 |
| `node scripts/executor.js --stop` | 停止交易 |
| `node scripts/monitor.js --status` | 查看当前仓位 |

## 策略说明

### 趋势判断

- **MA** (Moving Average): 收盘价 > 均线 = 多头
- **RSI**: RSI < 30 超卖买入，RSI > 70 超买卖出
- **BB** (Bollinger Bands): 价格触及下轨买入，上轨卖出

### 风控规则

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 最大仓位 | $1000 | 单笔最大投入 |
| 止损 | 2% | 价格反向 2% 自动平仓 |
| 止盈 | 5% | 盈利 5% 自动止盈 |
| 杠杆 | 10x | 10倍杠杆 |

## 风险提示

⚠️ **杠杆交易风险极高，可能爆仓归零！**

- 10x 杠杆，价格波动 10% 就会爆仓
- 建议先用 testnet 模拟盘测试
- 务必设置合理的止损
- 不要投入超过承受能力的资金

## 依赖

```bash
npm install ccxt dotenv
```

## 作者

由 OpenClaw Agent 生成
