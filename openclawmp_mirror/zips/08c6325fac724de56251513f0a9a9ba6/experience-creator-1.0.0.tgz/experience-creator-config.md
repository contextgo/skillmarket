# Experience Creator 配置文件
## 通用配置
| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| default_version | 1.0.0 | 新生成Experience的默认版本号 |
| default_timezone | Asia/Shanghai | Cron任务默认时区 |
| auto_install_deps | true | 是否自动安装依赖工具 |
| publish_mode | ask | 发布模式：ask=确认后发布，auto=自动发布 |

## 校验配置
| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| strict_mode | true | 严格模式：任何不符合规范的项都判定为不合格 |
| check_sensitive_info | true | 是否检查敏感信息 |
| max_command_length | 200 | 命令最大长度，超过提示拆分 |

## 生成配置
| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| generate_config_file | true | 是否自动生成配置文件 |
| generate_prompt_file | true | 是否自动生成prompt文件 |
| generate_templates_dir | true | 是否自动生成templates目录 |
| include_examples | true | 是否在模板中包含示例内容 |