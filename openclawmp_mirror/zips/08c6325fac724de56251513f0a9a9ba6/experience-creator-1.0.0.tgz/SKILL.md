---
name: experience-creator
description: Experience标准化制作工具，支持自动校验格式、生成标准模板、一键发布到水产市场，触发关键词：制作Experience、生成模板、校验、发布。
version: 1.0.0
---

# Experience Creator 工具使用指南

这是标准化的Experience制作Skill，支持三个核心功能，不需要手动按照规范编写，AI自动帮你完成所有标准化流程。

## 🚀 核心功能
### 1. 📋 格式自动校验
自动检查Experience是否符合水产市场官方规范，输出检查报告，指出不符合的地方和修改建议。
**触发方式**："帮我校验这个Experience是否符合规范" + 提供Experience文件路径/内容

### 2. 📦 模板自动生成
用户只需要提供Experience的核心信息（名称、解决的问题、核心流程），自动生成标准的Experience目录结构和所有必填文件，包括：
- 标准结构的README.md（自动填充7个必填部分）
- 配置文件模板
- 示例prompt文件
- 模板文件目录
**触发方式**："帮我生成一个Experience模板" + 提供Experience的核心信息

### 3. 🚢 一键发布到水产市场
自动打包Experience，校验格式，生成发布命令，用户确认后直接发布到水产市场。
**触发方式**："帮我发布这个Experience" + 提供Experience目录路径

## 📋 校验标准
严格遵循水产市场官方规范：
1. README.md必须包含7个标准部分
2. 所有命令必须是可直接复制运行的完整命令
3. 没有硬编码的敏感信息
4. 目录结构符合标准规范
5. Cron时区默认Asia/Shanghai
6. 所有引用的文件路径正确

## 🔧 使用示例
### 生成模板示例
> 用户：帮我生成一个"每日早安问候"的Experience模板，功能是每天定时给用户发送早安问候
> 自动生成：完整的目录结构、README.md、Cron任务配置、所有需要的文件

### 校验示例
> 用户：帮我校验`/workspace/experiences/my-exp`这个Experience
> 自动输出：校验报告，列出所有不符合规范的地方和修改建议

### 发布示例
> 用户：帮我发布`/workspace/experiences/my-exp`这个Experience
> 自动执行：格式校验 → 打包 → 生成发布命令 → 用户确认后执行发布