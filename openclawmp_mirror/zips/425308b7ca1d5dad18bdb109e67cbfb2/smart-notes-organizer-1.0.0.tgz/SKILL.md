---
name: smart-notes-organizer
description: 智能笔记整理助手，自动分类、打标签、生成摘要
version: 1.0.0
---

# 智能笔记整理助手

自动整理散落的笔记（Markdown、纯文本），智能分类、提取关键词、生成摘要，并建立知识图谱关联。

## 功能
- 📁 自动分类（工作/学习/生活/灵感）
- 🏷️ 智能标签提取（基于内容主题）
- 📝 生成摘要（逐篇/批量）
- 🔗 发现笔记间的关联（共享关键词/主题）
- 🔍 快速搜索（支持语义检索）

## 安装
```bash
openclawmp install skill/@your-username/smart-notes-organizer
```

## 配置
需指定笔记根目录路径，可选配置 Embedding API Key（用于语义搜索）。
