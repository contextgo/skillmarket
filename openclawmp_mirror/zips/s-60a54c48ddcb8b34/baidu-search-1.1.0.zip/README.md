# 百度搜索

通过百度AI搜索API搜索网络。

## 使用方法

```bash
python3 skills/baidu-search/scripts/search.py '<JSON>'
```

## 请求参数

| 参数 | 类型 | 必需 | 默认值 | 描述 |
|-------|------|----------|---------|-------------|
| query | str | 是 | - | 搜索查询 |
| edition | str | 否 | standard | `standard`（完整）或 `lite`（轻量） |
| resource_type_filter | list[obj] | 否 | web:20, others:0 | 资源类型：web（最多50个），video（最多10个），image（最多30个），aladdin（最多5个） |
| search_filter | obj | 否 | - | 高级筛选器（见下文） |
| block_websites | list[str] | 否 | - | 要屏蔽的网站，例如 ["tieba.baidu.com"] |
| search_recency_filter | str | 否 | - | 时间筛选器：`week`，`month`，`semiyear`，`year` |
| safe_search | bool | 否 | false | 启用严格内容筛选 |

## 搜索筛选器

| 参数 | 类型 | 描述 |
|-------|------|-------------|
| match.site | list[str] | 将搜索限制在特定网站，例如 ["baike.baidu.com"] |
| range.pageTime | obj | page_time字段的日期范围（见下文） |

### 日期范围格式

固定日期：`YYYY-MM-DD`
相对时间（从当前日期）：`now-1w/d`，`now-1M/d`，`now-1y/d`

| 运算符 | 含义 |
|----------|---------|
| gte | 大于或等于（开始） |
| lte | 小于或等于（结束） |

## 示例

```bash
# 基本搜索
python3 skills/baidu-search/scripts/search.py '{"query":"人工智能"}'

# 按时间和网站筛选
python3 skills/baidu-search/scripts/search.py '{
  "query":"最新新闻",
  "search_recency_filter":"week",
  "search_filter":{"match":{"site":["news.baidu.com"]}}
}'

# 资源类型筛选
python3 skills/baidu-search/scripts/search.py '{
  "query":"旅游景点",
  "resource_type_filter":[{"type":"web","top_k":20},{"type":"video","top_k":5}]
}'
```

## 当前状态

完全可用。