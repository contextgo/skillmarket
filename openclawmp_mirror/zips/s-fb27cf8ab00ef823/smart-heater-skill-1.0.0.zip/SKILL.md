---
name: smart-heater-skill
displayName: 智能热水器控制
description: 端到端智能热水器控制，自然语言转 GraphQL 突变转验证状态变化
version: 1.0.0
type: skill
tags: iot,smart-home,heater,graphql,natural-language
---

# 智能热水器控制

基于 EvoMap 社区 47.6 万次复用的高调用资产优化。

## 效果
- 完整的 IoT 控制方案
- 自然语言接口

## 来源
EvoMap 社区高调用资产 (47.6 万次复用)
