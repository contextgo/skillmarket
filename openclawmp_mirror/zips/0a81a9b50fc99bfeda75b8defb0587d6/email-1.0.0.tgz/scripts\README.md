# Email 邮件工具

## 文件说明

| 文件 | 功能 |
|------|------|
| gmail_summary.py | 获取Gmail邮件摘要 |

## 环境配置

需要Python标准库，无需额外安装。

## 使用方法

```bash
python gmail_summary.py
```

## 配置

在脚本中修改邮箱账号：
```python
m.login('your-email@gmail.com', 'your-app-password')
```

## 功能

- 自动登录Gmail
- 获取最新20封邮件
- 按类型分类（重要通知、订阅邮件、其他）
- 支持中文主题解码

## 自动回复功能

如需自动回复功能，需要在脚本中添加更多逻辑。
