#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gmail 邮件摘要生成器
自动读取Gmail并生成每日摘要
"""
import imaplib
import email.header


def decode_str(s):
    """解码邮件头"""
    if not s:
        return ""
    decoded = email.header.decode_header(s)
    result = ""
    for part, encoding in decoded:
        if isinstance(part, bytes):
            result += part.decode(encoding or 'utf-8', errors='ignore')
        else:
            result += part
    return result.strip()


def get_quick_summary():
    """快速获取邮件摘要"""
    m = imaplib.IMAP4_SSL('imap.gmail.com')
    m.login('cjye29213@gmail.com', 'lumciayotmkfjnre')
    m.select('INBOX')
    
    typ, data = m.uid('search', None, 'ALL')
    uids = data[0].split()[-20:]
    
    emails = []
    for uid in reversed(uids):
        try:
            typ, msg = m.uid('fetch', uid, '(UID FLAGS BODY[HEADER.FIELDS (SUBJECT FROM)])')
            if msg[0] and msg[0][1]:
                header_text = msg[0][1].decode('utf-8', errors='ignore')
                
                subject = ""
                from_addr = ""
                for line in header_text.split('\r\n'):
                    if line.startswith('Subject:'):
                        subject = decode_str(line[8:])
                    elif line.startswith('From:'):
                        from_addr = decode_str(line[5:])
                
                emails.append({
                    'from': from_addr[:50],
                    'subject': subject[:50] if subject else '(无主题)'
                })
        except:
            continue
    
    m.logout()
    return emails


def main():
    print("📧 正在获取Gmail摘要...")
    
    emails = get_quick_summary()
    
    # 分类
    important = []
    newsletters = []
    other = []
    
    for e in emails:
        f = e['from'].lower()
        if 'nvidia' in f or 'google' in f or 'github' in f or 'gtc' in f:
            important.append(e)
        elif 'newsletter' in f or 'noreply' in f:
            newsletters.append(e)
        else:
            other.append(e)
    
    print("\n" + "="*50)
    print("📧 Gmail 每日邮件摘要")
    print("="*50)
    print(f"📊 共 {len(emails)} 封新邮件\n")
    
    if important:
        print("🔴 重要通知:")
        for e in important[:5]:
            print(f"  • {e['subject']}")
        print()
    
    if newsletters:
        print("📬 订阅邮件:")
        for e in newsletters[:5]:
            print(f"  • {e['subject']}")
        print()
    
    if other:
        print("📭 其他:")
        for e in other[:5]:
            print(f"  • {e['subject']}")
    
    print("\n" + "="*50)
    print("✅ 摘要完成")


if __name__ == "__main__":
    main()
