#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发送邮件
支持Gmail/QQ邮箱等
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import os


def send_gmail(to_addr, subject, body, attachments=None):
    """发送Gmail邮件"""
    from_addr = 'cjye29213@gmail.com'
    password = 'lumciayotmkfjnre'  # App密码
    
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_addr
    msg['To'] = to_addr
    msg.attach(MIMEText(body, 'plain', 'utf-8'))
    
    # 添加附件
    if attachments:
        for filepath in attachments:
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    img = MIMEImage(f.read())
                    img.add_header('Content-Disposition', 'attachment', 
                                 filename=os.path.basename(filepath))
                    msg.attach(img)
    
    # 发送
    smtp = smtplib.SMTP('smtp.gmail.com', 587)
    smtp.starttls()
    smtp.login(from_addr, password)
    smtp.send_message(msg)
    smtp.quit()
    return True


def send_qqmail(to_addr, subject, body, attachments=None):
    """发送QQ邮箱邮件"""
    from_addr = '3584297541@qq.com'
    password = 'your-password'  # QQ邮箱授权码
    
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_addr
    msg['To'] = to_addr
    msg.attach(MIMEText(body, 'plain', 'utf-8'))
    
    if attachments:
        for filepath in attachments:
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    att = MIMEText(f.read(), 'base64', 'utf-8')
                    att.add_header('Content-Disposition', 'attachment',
                                 filename=os.path.basename(filepath))
                    msg.attach(att)
    
    smtp = smtplib.SMTP('smtp.qq.com', 587)
    smtp.starttls()
    smtp.login(from_addr, password)
    smtp.send_message(msg)
    smtp.quit()
    return True


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("用法: python send_mail.py <收件人> <主题> [正文]")
        print("示例: python send_mail.py test@example.com '你好' '这是一封测试邮件'")
        sys.exit(1)
    
    to_addr = sys.argv[1]
    subject = sys.argv[2]
    body = sys.argv[3] if len(sys.argv) > 3 else '你好！'
    
    try:
        send_gmail(to_addr, subject, body)
        print(f'✅ 邮件已发送到 {to_addr}')
    except Exception as e:
        print(f'❌ 发送失败: {e}')
