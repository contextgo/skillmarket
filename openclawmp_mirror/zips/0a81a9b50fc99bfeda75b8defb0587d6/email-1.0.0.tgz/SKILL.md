---
name: email
description: 邮件工具，支持读取、发送、自动摘要。支持Gmail/QQ邮箱等。
---

# Email 邮件工具

统一的邮件管理技能，支持多种功能。

## 功能

- 📧 读取邮件（IMAP）
- 📝 生成每日摘要
- ✉️ 发送邮件（SMTP）
- 🔍 自动分类（重要通知/订阅/其他）

## 脚本

| 文件 | 功能 |
|------|------|
| gmail_summary.py | 邮件摘要生成 |
| send_mail.py | 发送邮件 |

## 使用方法

```bash
# 生成邮件摘要
python gmail_summary.py

# 发送邮件
python send_mail.py
```

## 配置

在脚本中修改邮箱配置：
```python
# Gmail
imap.gmail.com / smtp.gmail.com
port: 993 / 587

# QQ邮箱
imap.qq.com / smtp.qq.com
port: 993 / 587
```

## 输出

- 摘要保存到：output/email_summary.txt
- 图片保存在：output/pixiv/
