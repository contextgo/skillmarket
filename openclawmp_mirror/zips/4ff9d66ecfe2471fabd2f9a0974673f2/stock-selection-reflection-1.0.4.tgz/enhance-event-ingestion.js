#!/usr/bin/env node

/**
 * 多源抓取框架 - enhance-event-ingestion.js
 * 功能：从多个信源抓取事件信息、去重、冲突检测、权重计算
 * 状态：框架版本（需对接实际数据源）
 *
 * 信源权重：
 *   公司公告: 40%
 *   券商研报: 30%
 *   权威媒体: 20%
 *   群聊/社交: 10%
 */

const crypto = require('crypto');

// 模拟数据源（实际应对接API）
const MOCK_SOURCES = {
  announcements: [ // 模拟公告
    { id: 'ann_001', title: '隆基绿能发布战略调整公告', confidence: 0.9, weight: 0.4 },
    { id: 'ann_002', title: '天山铝业发布Q1业绩预告', confidence: 0.95, weight: 0.4 }
  ],
  research: [ // 模拟研报
    { id: 'rpt_001', title: '隆基绿能深度报告：轻资产转型', confidence: 0.85, weight: 0.3 },
    { id: 'rpt_002', title: '铝业板块Q2展望', confidence: 0.8, weight: 0.3 }
  ],
  media: [ // 模拟媒体
    { id: 'med_001', title: '中东铝厂遭袭影响分析', confidence: 0.75, weight: 0.2 },
    { id: 'med_002', title: '储能行业竞争格局解读', confidence: 0.7, weight: 0.2 }
  ],
  social: [ // 模拟群聊
    { id: 'soc_001', title: '隆基不做电芯是好事还是坏事？', confidence: 0.3, weight: 0.1 },
    { id: 'soc_002', title: '铝业要涨了！', confidence: 0.25, weight: 0.1 }
  ]
};

/**
 * 生成事件指纹（用于去重）
 * 指纹 = 公司代码 + 关键词 + 7天窗口
 */
function generateFingerprint(eventTitle, stockCode = '') {
  const key = `${stockCode}_${eventTitle}`.toLowerCase();
  return crypto.createHash('md5').update(key).digest('hex');
}

/**
 * 计算事件相似度（用于去重）
 */
function similarity(a, b) {
  const setA = new Set(a.toLowerCase().split(/\s+/));
  const setB = new Set(b.toLowerCase().split(/\s+/));
  const intersection = new Set([...setA].filter(x => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  return intersection.size / union.size;
}

/**
 * 抓取单个信源的事件（模拟）
 */
function fetchFromSource(sourceType, query) {
  // 实际应调用API：feishu_im_user_search_messages / web_fetch / 爬虫等
  console.log(`🔍 从 ${sourceType} 抓取: "${query}"`);

  // 这里返回模拟数据
  return MOCK_SOURCES[sourceType] || [];
}

/**
 * 多源抓取主函数
 */
async function enhanceEventIngestion(eventTitle, stockCode = '', options = {}) {
  console.log(`\n=== 多源抓取: "${eventTitle}" ===\n`);

  const sources = [
    { type: 'announcements', name: '公司公告' },
    { type: 'research', name: '券商研报' },
    { type: 'media', name: '权威媒体' },
    { type: 'social', name: '群聊/社交' }
  ];

  let allResults = [];
  let sourceStats = {};

  // 并行抓取各信源
  for (const source of sources) {
    try {
      const results = await fetchFromSource(source.type, eventTitle);
      sourceStats[source.name] = results.length;

      results.forEach(item => {
        allResults.push({
          ...item,
          source: source.name,
          sourceType: source.type,
          weight: item.weight // 每个信源的权重
        });
      });
    } catch (error) {
      console.error(`❌ ${source.name} 抓取失败:`, error.message);
    }
  }

  console.log('📊 信源统计:');
  for (const [name, count] of Object.entries(sourceStats)) {
    console.log(`  ${name}: ${count} 条`);
  }

  // 去重（基于指纹）
  console.log('\n🔄 去重处理...');
  const deduped = deduplicate(allResults);

  // 冲突检测
  console.log('⚖️  冲突检测...');
  const conflicts = detectConflicts(deduped);

  // 计算综合置信度
  const combined = calculateCombinedConfidence(deduped);

  return {
    eventTitle,
    stockCode,
    totalRaw: allResults.length,
    afterDedup: deduped.length,
    sources: sourceStats,
    dedupedResults: deduped,
    conflicts,
    combinedConfidence: combined.confidence,
    weightedScore: combined.weightedScore,
    recommendedStrength: calculateRecommendedStrength(combined),
    suggestion: generateSuggestion(combined, conflicts)
  };
}

/**
 * 去重：基于标题相似度和信源权重
 */
function deduplicate(results) {
  const unique = [];
  const seenFingerprints = new Set();

  // 按信源权重排序（公告 > 研报 > 媒体 > 群聊）
  const weightOrder = { '公司公告': 4, '券商研报': 3, '权威媒体': 2, '群聊/社交': 1 };
  results.sort((a, b) => (weightOrder[b.source] || 0) - (weightOrder[a.source] || 0));

  for (const item of results) {
    const fp = generateFingerprint(item.title);

    // 检查是否与已有条目高度相似
    let isDuplicate = false;
    for (const existing of unique) {
      if (similarity(item.title, existing.title) > 0.7) {
        isDuplicate = true;
        // 保留权重更高的
        if (item.weight > existing.weight) {
          existing.title = item.title; // 用更高质量的标题
          existing.confidence = Math.max(existing.confidence, item.confidence);
        }
        break;
      }
    }

    if (!isDuplicate && !seenFingerprints.has(fp)) {
      seenFingerprints.add(fp);
      unique.push(item);
    }
  }

  console.log(`   原始: ${results.length} → 去重后: ${unique.length}`);
  return unique;
}

/**
 * 冲突检测：不同信源给出矛盾结论
 */
function detectConflicts(results) {
  const conflicts = [];

  // 按事件分组（简单按标题聚类）
  const groups = {};
  results.forEach(item => {
    const key = item.title.substring(0, 20); // 简单聚类
    if (!groups[key]) groups[key] = [];
    groups[key].push(item);
  });

  for (const [key, items] of Object.entries(groups)) {
    if (items.length >= 2) {
      // 检查置信度差异
      const confidences = items.map(i => i.confidence);
      const maxConf = Math.max(...confidences);
      const minConf = Math.min(...confidences);

      if (maxConf - minConf > 0.3) {
        conflicts.push({
          cluster: key,
          items: items.map(i => ({ source: i.source, confidence: i.confidence })),
          severity: 'high'
        });
      }
    }
  }

  if (conflicts.length > 0) {
    console.log(`   ⚠️  发现 ${conflicts.length} 处冲突（信源结论不一致）`);
  } else {
    console.log('   ✅ 未发现明显冲突');
  }

  return conflicts;
}

/**
 * 计算综合置信度和加权分数
 */
function calculateCombinedConfidence(results) {
  if (results.length === 0) {
    return { confidence: 0, weightedScore: 0 };
  }

  // 加权平均
  let totalWeight = 0;
  let weightedConf = 0;

  results.forEach(item => {
    weightedConf += item.confidence * item.weight;
    totalWeight += item.weight;
  });

  const weightedScore = totalWeight > 0 ? weightedConf / totalWeight : 0;
  const confidence = Math.round(weightedScore * 100) / 100;

  return { confidence, weightedScore };
}

/**
 * 根据综合置信度推荐强度
 */
function calculateRecommendedStrength(combined) {
  const score = combined.weightedScore;

  if (score >= 0.85) return 5;  // 多源高置信
  if (score >= 0.7) return 4;   // 多源中等置信
  if (score >= 0.5) return 3;   // 信源一般或较少
  if (score >= 0.3) return 2;   // 信源少且置信低
  return 1;                     // 极低置信
}

/**
 * 生成建议
 */
function generateSuggestion(combined, conflicts) {
  if (conflicts.length > 0) {
    return '⚠️ 信源冲突，建议人工审核后再决策';
  }
  if (combined.confidence < 0.5) {
    return '⚠️ 置信度偏低，建议补充信源';
  }
  if (combined.weightedScore >= 0.7) {
    return '✅ 多源验证通过，可谨慎操作';
  }
  return '💡 信息有限，建议观望或小仓位测试';
}

/**
 * 命令行入口
 */
async function main() {
  const args = process.argv.slice(2);

  if (args.length < 1) {
    console.log('用法: node enhance-event-ingestion.js "事件标题" ["股票代码"]');
    console.log('示例: node enhance-event-ingestion.js "隆基绿能宣布不做电芯" "688331"');
    process.exit(1);
  }

  const eventTitle = args[0];
  const stockCode = args[1] || '';

  try {
    const result = await enhanceEventIngestion(eventTitle, stockCode);

    console.log('\n=== 综合分析结果 ===\n');
    console.log(`事件: ${result.eventTitle}`);
    console.log(`标的: ${result.stockCode || '未指定'}`);
    console.log(`信源数: ${result.totalRaw} → 去重后 ${result.afterDedup} 条`);
    console.log(`综合置信度: ${(result.combinedConfidence * 100).toFixed(1)}%`);
    console.log(`加权分数: ${result.weightedScore.toFixed(2)}/1.0`);
    console.log(`建议强度: ${result.recommendedStrength}/5`);
    console.log(`操作建议: ${result.suggestion}`);

    if (result.conflicts.length > 0) {
      console.log('\n⚠️  冲突详情:');
      result.conflicts.forEach(c => {
        console.log(`  - ${c.cluster}`);
        c.items.forEach(i => console.log(`    ${i.source}: 置信度${(i.confidence * 100).toFixed(0)}%`));
      });
    }

    // 输出详细结果（JSON）
    console.log('\n--- JSON输出 ---');
    console.log(JSON.stringify({
      event: result.eventTitle,
      stock: result.stockCode,
      confidence: result.combinedConfidence,
      strength: result.recommendedStrength,
      suggestion: result.suggestion,
      sources: result.sources,
      conflicts: result.conflicts.length
    }, null, 2));

  } catch (error) {
    console.error('❌ 执行失败:', error.message);
    process.exit(1);
  }
}

// 直接运行
if (require.main === module) {
  main();
}

module.exports = { enhanceEventIngestion, deduplicate, detectConflicts };
