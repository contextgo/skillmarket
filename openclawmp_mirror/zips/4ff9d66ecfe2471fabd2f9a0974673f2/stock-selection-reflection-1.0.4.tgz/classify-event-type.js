#!/usr/bin/env node

/**
 * 战略分类器 - classify-event-type.js
 * 功能：自动识别事件性质（被动风险 / 主动战略 / 行业催化 / 业绩兑现）
 * 使用：node classify-event-type.js "事件标题" [可选：事件描述]
 *
 * 示例：
 *   node classify-event-type.js "隆基绿能宣布储能业务不做电芯"
 *   node classify-event-type.js "公司发生火灾" "风范股份厂房火灾"
 *
 * 输出：JSON格式 {type, confidence, reason, suggestions}
 */

const args = process.argv.slice(2);
if (args.length < 1) {
  console.error('用法: node classify-event-type.js "事件标题" ["事件描述"]');
  process.exit(1);
}

const title = args[0];
const description = args[1] || '';
const text = (title + ' ' + description).toLowerCase();

// 关键词库（按类别）
const keywordSets = {
  // 被动风险：外部强制、负面事件
  passiveRisk: {
    keywords: [
      '火灾', '爆炸', '事故', '处罚', '调查', '查封', '停产', '整改',
      '违规', '立案', '诉讼', '仲裁', '罚款', '谴责', '批评', '通报',
      '供应链中断', '供应商出事', '原材料短缺', '技术封锁', '制裁'
    ],
    weight: 0.9,
    defaultType: '被动风险',
    triggers: ['被', '遭', '因', '由于', '受'] // 被动语态关键词
  },

  // 主动战略：主动选择、聚焦、合作、轻资产
  activeStrategy: {
    keywords: [
      '不做', '不开展', '退出', '剥离', '出售', '聚焦', '专注',
      '轻资产', '战略合作', '签署协议', '授权', '绑定', '联合',
      '合作', '合资', '战略投资', '生态伙伴', '产业链合作',
      '资源整合', '优势互补', '强强联合'
    ],
    weight: 0.85,
    defaultType: '主动战略',
    triggers: ['宣布', '决定', '计划', '拟', '将', '拟'] // 主动语态
  },

  // 行业催化：行业层面政策/技术/市场变化
  industryCatalyst: {
    keywords: [
      '政策', '补贴', '试点', '规划', '批复', '征求意见',
      '技术突破', '研发成功', '创新', '首台套', '首条产线',
      '市场规模', '行业增速', '渗透率', '国产替代', '集采',
      '中标', '入围', '认证', '获批', '通过评审'
    ],
    weight: 0.8,
    defaultType: '行业催化',
    triggers: ['行业', '产业', '领域', '领域'] // 行业相关
  },

  // 业绩兑现：财务/订单/业绩超预期
  performance: {
    keywords: [
      '净利润', '营收', '业绩', '利润', '订单', '合同',
      '超预期', '同比增长', '增幅', '创历史新高', '突破',
      '大单', '中标', '签署合同', '预增', '扭亏', '大增',
      '预增', '预告', '快报', '分红', '送转', '回购'
    ],
    weight: 0.95,
    defaultType: '业绩兑现',
    triggers: ['业绩', '利润', '订单', '合同', '预增', '增长']
  }
};

/**
 * 计算文本与关键词集合的匹配度
 */
function calculateMatchScore(text, keywords) {
  let score = 0;
  const matchedKeywords = [];

  keywords.forEach(keyword => {
    if (text.includes(keyword)) {
      score += 1;
      matchedKeywords.push(keyword);
    }
  });

  return { score, matchedKeywords };
}

/**
 * 主分类逻辑
 */
function classifyEvent(text, title, description) {
  const results = {};

  // 计算每个类别的匹配分
  for (const [category, config] of Object.entries(keywordSets)) {
    const { score, matchedKeywords } = calculateMatchScore(text, config.keywords);
    results[category] = {
      score,
      matchedKeywords,
      weight: config.weight,
      defaultType: config.defaultType
    };
  }

  // 加权总分
  let maxScore = 0;
  let bestCategory = 'unknown';
  let confidence = 0;

  for (const [category, data] of Object.entries(results)) {
    const weightedScore = data.score * data.weight;
    if (weightedScore > maxScore) {
      maxScore = weightedScore;
      bestCategory = category;
      confidence = data.score > 0 ? data.weight : 0;
    }
  }

  // 特殊规则修正
  let finalType = bestCategory;
  let reason = '';

  // 规则1: 被动语态检查
  const hasPassiveTrigger = keywordSets.passiveRisk.triggers.some(t => text.includes(t));
  const hasActiveTrigger = keywordSets.activeStrategy.triggers.some(t => text.includes(t));

  if (hasPassiveTrigger && results.passiveRisk.score > 0) {
    finalType = '被动风险';
    reason = '被动语态 + 负面关键词';
  } else if (hasActiveTrigger && results.activeStrategy.score > 0) {
    finalType = '主动战略';
    reason = '主动语态 + 战略关键词';
  } else if (results.performance.score >= 2) {
    finalType = '业绩兑现';
    reason = `多个业绩关键词: ${results.performance.matchedKeywords.join(', ')}`;
  } else if (results.industryCatalyst.score >= 2) {
    finalType = '行业催化';
    reason = `行业相关关键词: ${results.industryCatalyst.matchedKeywords.join(', ')}`;
  } else if (maxScore === 0) {
    finalType = '待人工审核';
    confidence = 0;
    reason = '未识别到明确关键词，需人工判断';
  } else {
    finalType = results[bestCategory].defaultType;
    reason = `关键词匹配: ${results[bestCategory].matchedKeywords.join(', ')}`;
  }

  // 置信度计算
  const maxPossibleScore = 5; // 假设最多匹配5个关键词
  confidence = Math.min(maxScore / maxPossibleScore * 100, 100);
  confidence = Math.round(confidence * 10) / 10;

  // 强度建议
  let suggestedStrength = 3;
  if (finalType === '被动风险' && results.passiveRisk.score >= 2) {
    suggestedStrength = 4;
    if (text.includes('重大') || text.includes('严重') || text.includes('停产')) {
      suggestedStrength = 5;
    }
  } else if (finalType === '主动战略') {
    suggestedStrength = 2;
    if (hasActiveTrigger && text.includes('重大合作')) suggestedStrength = 3;
  } else if (finalType === '行业催化') {
    suggestedStrength = 3;
    if (results.industryCatalyst.score >= 3) suggestedStrength = 4;
  } else if (finalType === '业绩兑现') {
    suggestedStrength = 4;
    if (text.includes('大幅') || text.includes('超预期') || text.includes('创历史')) {
      suggestedStrength = 5;
    }
  }

  return {
    title,
    description,
    type: finalType,
    confidence,
    reason,
    suggestedStrength,
    keywordMatches: Object.fromEntries(
      Object.entries(results).map(([k, v]) => [k, { score: v.score, keywords: v.matchedKeywords }])
    ),
    recommendation: getRecommendation(finalType, suggestedStrength)
  };
}

/**
 * 操作建议生成
 */
function getRecommendation(type, strength) {
  const recommendations = {
    '被动风险': {
      5: '强烈规避，重大风险事件',
      4: '规避，短期利空',
      3: '观望，评估影响程度',
      2: '观望，影响轻微',
      1: '信息提示，无需操作'
    },
    '主动战略': {
      5: '买入（若估值合理），战略转型利好',
      4: '持有/买入（视成本而定）',
      3: '观望，跟踪执行情况',
      2: '观望，影响中性',
      1: '信息提示'
    },
    '行业催化': {
      5: '买入，行业重大利好',
      4: '买入，催化明确',
      3: '持有/观望，催化力度有限',
      2: '观望，影响轻微',
      1: '信息提示'
    },
    '业绩兑现': {
      5: '买入，业绩超预期',
      4: '买入，业绩符合预期+增长',
      3: '持有，业绩平稳',
      2: '观望，业绩低于预期',
      1: '规避，业绩大幅下滑'
    },
    '待人工审核': {
      3: '人工审核，不确定事件性质'
    }
  };

  const typeRecs = recommendations[type] || recommendations['待人工审核'];
  const strengthKey = Math.min(Math.max(strength, 1), 5);
  return typeRecs[strengthKey] || '需人工判断';
}

// 执行分类
const result = classifyEvent(text, title, description);

// 输出结果
console.log(JSON.stringify(result, null, 2));

// 人类可读摘要
console.log('\n=== 分类结果 ===');
console.log(`事件: ${title}`);
console.log(`类型: ${result.type} (置信度 ${result.confidence}%)`);
console.log(`理由: ${result.reason}`);
console.log(`建议强度: ${result.suggestedStrength}/5`);
console.log(`操作建议: ${result.recommendation}`);
