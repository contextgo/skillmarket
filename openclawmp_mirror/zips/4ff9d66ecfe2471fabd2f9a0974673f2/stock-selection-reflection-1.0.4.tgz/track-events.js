#!/usr/bin/env node

/**
 * 动态跟踪引擎 - track-events.js
 * 功能：管理事件跟踪节点、强度自动调整、提前预警
 * 使用：
 *   node track-events.js add --event "evt_20260403_001" --catalyst "2026-08-15" --note "中报验证"
 *   node track-events.js list --upcoming 7  （查看7天内到期的跟踪节点）
 *   node track-events.js adjust --event "evt_20260403_001" --delta +1 --reason "合作公告落地"
 */

const fs = require('fs');
const path = require('path');

// 数据文件路径
const DATA_FILE = path.join(__dirname, 'tracking-data.json');

// 初始化数据结构
function initDataFile() {
  if (!fs.existsSync(DATA_FILE)) {
    const initialData = {
      events: {},
      lastUpdate: new Date().toISOString(),
      version: '1.0'
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(initialData, null, 2));
  }
}

// 读取数据
function loadData() {
  initDataFile();
  const content = fs.readFileSync(DATA_FILE, 'utf-8');
  return JSON.parse(content);
}

// 保存数据
function saveData(data) {
  data.lastUpdate = new Date().toISOString();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

/**
 * 添加跟踪节点
 */
function addTrackingNode(eventId, catalystDate, note = '') {
  const data = loadData();

  if (!data.events[eventId]) {
    data.events[eventId] = {
      eventId,
      createdAt: new Date().toISOString(),
      catalystDate,
      notes: [],
      adjustments: [],
      reminders: []
    };
  }

  const event = data.events[eventId];
  event.catalystDate = catalystDate;
  event.notes.push({
    date: new Date().toISOString(),
    note: note || '添加跟踪节点'
  });

  // 生成提醒（提前3天、提前7天）
  const catalyst = new Date(catalystDate);
  const reminder3d = new Date(catalyst);
  reminder3d.setDate(reminder3d.getDate() - 3);
  const reminder7d = new Date(catalyst);
  reminder7d.setDate(reminder7d.getDate() - 7);

  event.reminders = [
    { date: reminder7d.toISOString(), days: -7, sent: false, message: `事件 ${eventId} 还有7天到达催化剂时间` },
    { date: reminder3d.toISOString(), days: -3, sent: false, message: `事件 ${eventId} 还有3天到达催化剂时间，准备强度调整` }
  ];

  saveData(data);
  console.log(`✅ 事件 ${eventId} 跟踪节点已设置: ${catalystDate}`);
  console.log(`   提醒: 提前7天、提前3天`);
}

/**
 * 列出跟踪事件
 */
function listEvents(filter = 'all', daysAhead = 30) {
  const data = loadData();
  const now = new Date();
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() + daysAhead);

  console.log('\n=== 事件跟踪列表 ===\n');

  let count = 0;
  for (const [eventId, event] of Object.entries(data.events)) {
    const catalyst = new Date(event.catalystDate);
    const daysToCatalyst = Math.ceil((catalyst - now) / (1000 * 60 * 60 * 24));

    // 过滤
    if (filter === 'upcoming' && (daysToCatalyst < 0 || daysToCatalyst > daysAhead)) {
      continue;
    }
    if (filter === 'overdue' && daysToCatalyst >= 0) {
      continue;
    }

    count++;
    console.log(`事件ID: ${eventId}`);
    console.log(`  催化剂时间: ${event.catalystDate} (还有 ${daysToCatalyst} 天)`);
    console.log(`  强度调整: ${event.adjustments.length} 次`);
    console.log(`  最新备注: ${event.notes[event.notes.length - 1]?.note || '无'}`);
    console.log('');
  }

  if (count === 0) {
    console.log('无符合条件的跟踪事件。');
  }
}

/**
 * 调整事件强度
 */
function adjustStrength(eventId, delta, reason) {
  const data = loadData();
  const event = data.events[eventId];

  if (!event) {
    console.error(`❌ 事件 ${eventId} 不存在`);
    return;
  }

  const oldStrength = event.currentStrength || 3; // 默认3
  const newStrength = Math.max(1, Math.min(5, oldStrength + delta));

  event.currentStrength = newStrength;
  event.adjustments.push({
    date: new Date().toISOString(),
    oldStrength,
    newStrength,
    reason: reason || '未说明原因'
  });

  saveData(data);
  console.log(`✅ 事件 ${eventId} 强度调整: ${oldStrength} → ${newStrength}`);
  console.log(`   原因: ${reason || '未说明'}`);
}

/**
 * 检查即将到期的提醒
 */
function checkReminders() {
  const data = loadData();
  const now = new Date();
  const alerts = [];

  for (const [eventId, event] of Object.entries(data.events)) {
    for (const reminder of event.reminders) {
      if (reminder.sent) continue;

      const reminderTime = new Date(reminder.date);
      if (reminderTime <= now) {
        alerts.push({
          eventId,
          message: reminder.message,
          days: reminder.days
        });
        reminder.sent = true;
      }
    }
  }

  if (alerts.length > 0) {
    console.log('\n=== 跟踪提醒 ===\n');
    alerts.forEach(alert => {
      console.log(`⚠️  ${alert.message}`);
    });
    console.log('\n请及时处理！\n');
  } else {
    console.log('✅ 暂无即将到期的跟踪节点');
  }

  saveData(data);
  return alerts;
}

/**
 * 命令行解析
 */
const args = process.argv.slice(2);
const command = args[0];

function showUsage() {
  console.log(`
用法: node track-events.js <命令> [选项]

命令:
  add       添加跟踪节点
    --event <事件ID>     事件ID（必需）
    --catalyst <日期>    催化剂时间 YYYY-MM-DD（必需）
    --note <备注>        备注说明（可选）

  list     列出跟踪事件
    [--upcoming <天数>]  查看未来N天内到期的（默认30天）
    [--overdue]          查看已过期的事件

  adjust   调整强度
    --event <事件ID>     事件ID（必需）
    --delta <±N>         调整幅度，如 +1、-2（必需）
    --reason <原因>      调整原因（必需）

  remind   检查提醒（自动检查是否需提醒）

示例:
  node track-events.js add --event "evt_20260403_001" --catalyst "2026-08-15" --note "隆基中报验证"
  node track-events.js list --upcoming 7
  node track-events.js adjust --event "evt_20260403_001" --delta +1 --reason "合作公告落地"
  node track-events.js remind
`);
}

// 主逻辑
if (args.length === 0 || ['add', 'list', 'adjust', 'remind', 'help'].indexOf(command) === -1) {
  showUsage();
  process.exit(1);
}

if (command === 'help') {
  showUsage();
  process.exit(0);
}

// 解析键值参数
function parseArgs(arr) {
  const result = {};
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].startsWith('--')) {
      const key = arr[i].slice(2);
      const value = arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true;
      result[key] = value;
      if (value !== true) i++;
    }
  }
  return result;
}

const options = parseArgs(args.slice(1));

switch (command) {
  case 'add':
    if (!options.event || !options.catalyst) {
      console.error('❌ add 命令需要 --event 和 --catalyst 参数');
      showUsage();
      process.exit(1);
    }
    addTrackingNode(options.event, options.catalyst, options.note);
    break;

  case 'list':
    listEvents(options.upcoming ? 'upcoming' : 'all', parseInt(options.upcoming) || 30);
    break;

  case 'adjust':
    if (!options.event || !options.delta) {
      console.error('❌ adjust 命令需要 --event、--delta 和 --reason 参数');
      showUsage();
      process.exit(1);
    }
    adjustStrength(options.event, parseInt(options.delta), options.reason);
    break;

  case 'remind':
    checkReminders();
    break;

  default:
    showUsage();
}
