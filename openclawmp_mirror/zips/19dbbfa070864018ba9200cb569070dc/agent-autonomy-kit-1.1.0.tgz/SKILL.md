---
name: agent-autonomy-kit
version: 1.1.0
description: "Agent自主工作套件。触发词：agent autonomy、自主工作、proactive agent、任务队列、heartbeat、持续工作、自动推进、无人值守。This skill should be used when an agent needs to keep working without repeated prompts, maintain a task queue, or drive its own heartbeat loop."
last_updated: "2026-04-15"
changelog: "- 补强流程、异常处理和验收标准"
homepage: https://github.com/itskai-dev/agent-autonomy-kit
metadata:
  openclaw:
    emoji: "🚀"
    category: productivity
---

# Agent Autonomy Kit

## Goal
Keep work moving without waiting for repeated prompts.

## Workflow

### Phase 1: Intake
- Identify the goal, current state, and next action
- Rewrite vague goals into one concrete task

### Phase 2: Queue Setup
- Split work into Ready, In Progress, Blocked, Done
- Keep each item small enough to start fast

### Phase 3: Heartbeat Loop
- Recheck the queue on every heartbeat
- Finish current work before pulling the next item

### Phase 4: Recovery
- Record blockers, dependencies, and unblock conditions
- Refresh context when it goes stale

## Guardrails
- Do not invent progress
- Do not loop on blocked work forever
- Do not keep working without a clear stop condition

## Success Criteria
- A fresh agent knows the next action
- The queue is always actionable
- Blockers are visible
