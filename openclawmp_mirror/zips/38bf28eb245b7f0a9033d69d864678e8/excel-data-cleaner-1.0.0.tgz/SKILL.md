---
name: excel-data-cleaner
description: Excel数据清洗工具 | 批量处理Excel文件：去重、填充空值、格式统一、拆分合并、条件筛选导出
---

# Excel数据清洗工具

批量处理Excel/XLSX文件的数据清洗任务，支持去重、空值处理、格式统一、条件筛选、行列操作。

## 适用场景

- 供应商报价单数据清洗
- 实验测试数据整理
- 质量检验记录处理
- 客户信息数据规范化
- 大批量Excel报表预处理

## 核心功能

| 功能 | 说明 |
|------|------|
| 去重 | 按指定列或全表去重 |
| 空值处理 | 删除/填充（均值/前值/固定值） |
| 格式统一 | 数字格式、日期格式、文本格式规范化 |
| 拆分 | 按列值拆分为多个文件 |
| 合并 | 多个文件按列对齐合并 |
| 筛选导出 | 按条件筛选数据到新文件 |
| 列操作 | 重命名、删除、排序、拆分列 |
| 行操作 | 删除空行、筛选重复行 |

## 使用方法

### 对话式

```
用户：帮我清洗这个Excel文件：删除重复行，邮箱列的空值填充为"未知"，日期列统一为YYYY-MM-DD格式

用户：把这份报价单按供应商拆分成多个文件

用户：两个Excel文件的物料编号对齐合并，保留两个表的所有数据
```

### 命令行

```powershell
excel-cleaner dedup -i "data.xlsx" -o "clean.xlsx" -k "订单号"
excel-cleaner fillna -i "data.xlsx" -o "filled.xlsx" -c "邮箱" -v "未知"
excel-cleaner filter -i "data.xlsx" -o "filtered.xlsx" -c "供应商" -v "华阳"
excel-cleaner split -i "data.xlsx" -c "供应商" -o "./output/"
```

## 输入要求

- 支持 .xlsx / .xls / .csv 格式
- 第一行应为表头
- 中文字段名支持良好

## 输出说明

- 默认输出UTF-8编码的XLSX文件
- 保留原格式（字体、颜色等尽量不变）
- 处理前自动备份原文件
