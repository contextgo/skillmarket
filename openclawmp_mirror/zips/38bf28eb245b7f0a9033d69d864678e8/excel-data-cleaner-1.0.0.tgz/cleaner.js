/**
 * Excel数据清洗工具
 * 支持：去重、空值处理、格式统一、拆分、合并、筛选
 */

const fs = require('fs');
const path = require('path');

/**
 * 读取Excel文件（需要xlsx模块）
 */
function readExcel(filePath) {
  try {
    const xlsx = require('xlsx');
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(sheet, { defval: '' });
    const headers = Object.keys(data.length > 0 ? data[0] : {});
    return { workbook, sheetName, data, headers };
  } catch (e) {
    throw new Error(`读取Excel失败: ${e.message}`);
  }
}

/**
 * 写入Excel文件
 */
function writeExcel(filePath, data, headers) {
  const xlsx = require('xlsx');
  const ws = xlsx.utils.json_to_sheet(data, { header: headers });
  const wb = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
  xlsx.writeFile(wb, filePath);
}

/**
 * 按列去重
 */
function dedupByColumn(data, keyColumn) {
  const seen = new Set();
  return data.filter(row => {
    const key = String(row[keyColumn] ?? '');
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/**
 * 填充空值
 */
function fillNa(data, column, fillValue) {
  return data.map(row => {
    const val = row[column];
    if (val === '' || val === null || val === undefined) {
      return { ...row, [column]: fillValue };
    }
    return row;
  });
}

/**
 * 按条件筛选
 */
function filterByColumn(data, column, value) {
  return data.filter(row => {
    const cell = String(row[column] ?? '');
    return cell.includes(String(value));
  });
}

/**
 * 统一日期格式
 */
function formatDateColumn(data, column, format = 'YYYY-MM-DD') {
  const xlsx = require('xlsx');
  return data.map(row => {
    const val = row[column];
    if (!val) return row;
    let dateStr = val;
    try {
      if (typeof val === 'number') {
        // Excel日期序列号
        dateStr = xlsx.SSF.parse_date_code(val);
        dateStr = `${dateStr.y}-${String(dateStr.m).padStart(2, '0')}-${String(dateStr.d).padStart(2, '0')}`;
      } else if (typeof val === 'string') {
        // 尝试解析常见格式
        const d = new Date(val);
        if (!isNaN(d)) {
          dateStr = d.toISOString().slice(0, 10);
        }
      }
    } catch (e) { /* keep original */ }
    return { ...row, [column]: dateStr };
  });
}

/**
 * 按列值拆分文件
 */
function splitByColumn(inputPath, column, outputDir) {
  const { data, headers } = readExcel(inputPath);
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const groups = {};
  data.forEach(row => {
    const key = String(row[column] ?? '未知');
    if (!groups[key]) groups[key] = [];
    groups[key].push(row);
  });
  
  const results = [];
  Object.entries(groups).forEach(([key, rows]) => {
    const safeName = key.replace(/[<>:"/\\|?*]/g, '_');
    const outputPath = path.join(outputDir, `${safeName}.xlsx`);
    writeExcel(outputPath, rows, headers);
    results.push({ group: key, count: rows.length, file: outputPath });
    console.log(`✅ 已拆分: ${key} (${rows.length}行) → ${outputPath}`);
  });
  
  return results;
}

/**
 * 合并两个Excel文件（按key列对齐）
 */
function mergeExcel(file1, file2, keyColumn, outputPath) {
  const { data: data1 } = readExcel(file1);
  const { data: data2, headers: headers2 } = readExcel(file2);
  
  // 创建file2的索引
  const index2 = new Map();
  data2.forEach(row => {
    index2.set(String(row[keyColumn] ?? ''), row);
  });
  
  // 合并
  const merged = data1.map(row1 => {
    const key = String(row1[keyColumn] ?? '');
    const row2 = index2.get(key) || {};
    // 避免keyColumn重复
    const mergedRow = { ...row1 };
    Object.entries(row2).forEach(([k, v]) => {
      if (k !== keyColumn) {
        mergedRow[`${k}_2`] = v;
      }
    });
    return mergedRow;
  });
  
  const allHeaders = [...Object.keys(merged[0] || {})];
  writeExcel(outputPath, merged, allHeaders);
  console.log(`✅ 合并完成: ${outputPath} (${merged.length}行)`);
  return merged.length;
}

// CLI
const [,, cmd, ...argsList] = process.argv;

const COMMANDS = {
  dedup: () => {
    const i = argsList.indexOf('-i'), o = argsList.indexOf('-o'), k = argsList.indexOf('-k');
    if ([i,o,k].some(x=>x===-1)) { console.log('用法: cleaner dedup -i in.xlsx -o out.xlsx -k 列名'); return; }
    const { data, headers } = readExcel(argsList[i+1]);
    const cleaned = dedupByColumn(data, argsList[k+1]);
    writeExcel(argsList[o+1], cleaned, headers);
    console.log(`✅ 去重完成: ${data.length}行 → ${cleaned.length}行`);
  },
  
  fillna: () => {
    const i = argsList.indexOf('-i'), o = argsList.indexOf('-o'), c = argsList.indexOf('-c'), v = argsList.indexOf('-v');
    if ([i,o,c,v].some(x=>x===-1)) { console.log('用法: cleaner fillna -i in.xlsx -o out.xlsx -c 列名 -v 填充值'); return; }
    const { data, headers } = readExcel(argsList[i+1]);
    const filled = fillNa(data, argsList[c+1], argsList[v+1]);
    writeExcel(argsList[o+1], filled, headers);
    console.log(`✅ 空值填充完成`);
  },
  
  filter: () => {
    const i = argsList.indexOf('-i'), o = argsList.indexOf('-o'), c = argsList.indexOf('-c'), v = argsList.indexOf('-v');
    if ([i,o,c,v].some(x=>x===-1)) { console.log('用法: cleaner filter -i in.xlsx -o out.xlsx -c 列名 -v 值'); return; }
    const { data, headers } = readExcel(argsList[i+1]);
    const filtered = filterByColumn(data, argsList[c+1], argsList[v+1]);
    writeExcel(argsList[o+1], filtered, headers);
    console.log(`✅ 筛选完成: 匹配${filtered.length}行`);
  },
  
  split: () => {
    const i = argsList.indexOf('-i'), o = argsList.indexOf('-o'), c = argsList.indexOf('-c');
    if ([i,o,c].some(x=>x===-1)) { console.log('用法: cleaner split -i in.xlsx -c 列名 -o 输出目录'); return; }
    splitByColumn(argsList[i+1], argsList[c+1], argsList[o+1]);
  },
  
  merge: () => {
    const i = argsList.indexOf('-i1'), j = argsList.indexOf('-i2'), k = argsList.indexOf('-k'), o = argsList.indexOf('-o');
    if ([i,j,k,o].some(x=>x===-1)) { console.log('用法: cleaner merge -i1 f1.xlsx -i2 f2.xlsx -k 列名 -o out.xlsx'); return; }
    mergeExcel(argsList[i+1], argsList[j+1], argsList[k+1], argsList[o+1]);
  },
  
  formatdate: () => {
    const i = argsList.indexOf('-i'), o = argsList.indexOf('-o'), c = argsList.indexOf('-c');
    if ([i,o,c].some(x=>x===-1)) { console.log('用法: cleaner formatdate -i in.xlsx -o out.xlsx -c 列名'); return; }
    const { data, headers } = readExcel(argsList[i+1]);
    const formatted = formatDateColumn(data, argsList[c+1]);
    writeExcel(argsList[o+1], formatted, headers);
    console.log(`✅ 日期格式统一完成`);
  }
};

if (COMMANDS[cmd]) {
  COMMANDS[cmd]();
} else {
  console.log(`
Excel数据清洗工具
================
用法: cleaner <命令> [选项]

命令:
  dedup       按列去重
  fillna      填充空值
  filter      按条件筛选
  split       按列值拆分为多文件
  merge       合并两个Excel文件
  formatdate  统一日期格式

示例:
  cleaner dedup -i data.xlsx -o clean.xlsx -k "订单号"
  cleaner fillna -i data.xlsx -o filled.xlsx -c "邮箱" -v "未知"
  cleaner filter -i data.xlsx -o result.xlsx -c "供应商" -v "华阳"
  cleaner split -i data.xlsx -c "供应商" -o "./output/"
  cleaner merge -i1 f1.xlsx -i2 f2.xlsx -k "编号" -o merged.xlsx
`);
}

module.exports = { readExcel, writeExcel, dedupByColumn, fillNa, filterByColumn, splitByColumn, mergeExcel };
