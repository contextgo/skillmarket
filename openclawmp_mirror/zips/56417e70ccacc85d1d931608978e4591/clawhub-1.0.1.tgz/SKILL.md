---
name: clawhub
version: 1.0.1
description: 虾滑 ClawHub 命令行工具：使用 ClawHub CLI 从 clawhub.com 搜索、安装、更新和发布 agent 技能；Use the ClawHub CLI to search, install, update, and publish agent skills from clawhub.com. Use when you need to fetch new skills on the fly, sync installed skills to latest or a specific version, or publish new/updated skill folders with the npm-installed clawhub CLI.
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["clawhub"] },
        "install":
          [
            {
              "id": "node",
              "kind": "node",
              "package": "clawhub",
              "bins": ["clawhub"],
              "label": "Install ClawHub CLI (npm)",
            },
          ],
      },
  }
---

# 虾滑 ClawHub 命令行工具（ClawHub CLI）

使用 ClawHub CLI 从 clawhub.com 搜索、安装、更新和发布 agent 技能。当你需要动态获取新技能、将已安装的技能同步到最新或特定版本、或者使用 npm 安装的 clawhub CLI 发布新的/更新的技能目录时，请使用本工具。

## 安装

```bash
npm i -g clawhub
```

## 认证（用于发布）

```bash
clawhub login
clawhub whoami
```

## 搜索

```bash
clawhub search "postgres backups"
```

## 安装

```bash
clawhub install my-skill
clawhub install my-skill --version 1.2.3
```

## 更新（基于哈希匹配 + 升级）

```bash
clawhub update my-skill
clawhub update my-skill --version 1.2.3
clawhub update --all
clawhub update my-skill --force
clawhub update --all --no-input --force
```

## 列表

```bash
clawhub list
```

## 发布

```bash
clawhub publish ./my-skill --slug my-skill --name "My Skill" --version 1.2.0 --changelog "Fixes + docs"
```

## 注意事项

- 默认仓库：https://clawhub.com（可通过 CLAWHUB_REGISTRY 或 --registry 覆盖）
- 默认工作目录：当前目录（降级使用 OpenClaw 工作区）；安装目录：./skills（可通过 --workdir / --dir / CLAWHUB_WORKDIR 覆盖）
- update 命令会对本地文件进行哈希计算，解析匹配的版本，除非设置了 --version 否则会升级到最新版

---

> Use the ClawHub CLI to search, install, update, and publish agent skills from clawhub.com. Use when you need to fetch new skills on the fly, sync installed skills to latest or a specific version, or publish new/updated skill folders with the npm-installed clawhub CLI.

## Install

```bash
npm i -g clawhub
```

## Auth (publish)

```bash
clawhub login
clawhub whoami
```

## Search

```bash
clawhub search "postgres backups"
```

## Install

```bash
clawhub install my-skill
clawhub install my-skill --version 1.2.3
```

## Update (hash-based match + upgrade)

```bash
clawhub update my-skill
clawhub update my-skill --version 1.2.3
clawhub update --all
clawhub update my-skill --force
clawhub update --all --no-input --force
```

## List

```bash
clawhub list
```

## Publish

```bash
clawhub publish ./my-skill --slug my-skill --name "My Skill" --version 1.2.0 --changelog "Fixes + docs"
```

## Notes

- Default registry: https://clawhub.com (override with CLAWHUB_REGISTRY or --registry)
- Default workdir: cwd (falls back to OpenClaw workspace); install dir: ./skills (override with --workdir / --dir / CLAWHUB_WORKDIR)
- Update command hashes local files, resolves matching version, and upgrades to latest unless --version is set
