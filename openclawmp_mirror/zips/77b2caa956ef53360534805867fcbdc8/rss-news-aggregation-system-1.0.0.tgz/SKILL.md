---
name: rss-news-aggregation-system
description: "RSS 新闻聚合系统构建指南，当 web search 不可用时的可靠替代方案"
version: 1.0.0
tags: ["rss", "news", "aggregation", "api-fallback"]
---

# RSS News Aggregation System

## Overview
当 web search API 不可用或额度耗尽时，RSS feeds 是最可靠的数据源替代方案。本指南提供完整的 RSS 新闻聚合系统构建方法。

## Why RSS?
- **Free**: 无 API key 要求
- **Reliable**: 不受 search API 限制
- **Fast**: 直接 HTTP 请求，无中间层
- **Structured**: 标准化的 XML 格式
- **Comprehensive**: Google News RSS 覆盖全球新闻

## Google News RSS Feeds

### Topic-Specific Feeds
```
https://news.google.com/rss/search?q={topic}&hl=en-US&gl=US&ceid=US:en
```

### Recommended Topics for Market Analysis
- `oil+price` — Oil market
- `bitcoin+price` — BTC market
- `iran+war` — Geopolitics
- `federal+reserve` — Central bank
- `gold+price` — Gold market
- `stock+market` — Equities
- `quantum+computing` — Tech
- `ceasefire` — Conflict resolution

## Implementation

```python
import feedparser
import concurrent.futures

TOPICS = {
    "oil": "https://news.google.com/rss/search?q=oil+price+breit&hl=en",
    "bitcoin": "https://news.google.com/rss/search?q=bitcoin+price+crypto&hl=en",
    "geopolitics": "https://news.google.com/rss/search?q=iran+war+military&hl=en",
}

def fetch_feed(topic, url, timeout=10):
    try:
        feed = feedparser.parse(url)
        return [(e.title, e.get('summary', '')) for e in feed.entries[:20]]
    except Exception:
        return []

# Parallel fetch all feeds
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    futures = {topic: executor.submit(fetch_feed, topic, url) 
               for topic, url in TOPICS.items()}
    results = {topic: f.result() for topic, f in futures.items()}
```

## Supplementary RSS Sources
- **CryptoSlate**: `https://cryptoslate.com/feed/`
- **CryptoCompare**: API + RSS
- **Alternative.me**: Fear & Greed Index API
- **CoinDesk**: `https://www.coindesk.com/arc/outboundfeeds/rss/`

## Resilience Tips
1. **Timeout**: 每个 feed 10s 超时
2. **Parallel**: 8 个并发 worker
3. **Retry**: 单次重试，不阻塞其他 feed
4. **Dedup**: 按 title hash 去重
5. **Cache**: 5 分钟缓存避免重复请求

## Monitoring
- Track feeds that consistently fail
- Monitor article count per topic
- Alert on >3 consecutive failures
