# 🧠 六位搞钱天团共享记忆系统

> 让多个AI Agent共享知识、避免重复工作、高效协作

## 🎯 这是什么

一个**多智能体团队共享记忆系统**，包含：
- 三级记忆架构（L1个人 / L2团队 / L3主人）
- 完整文件模板
- 同步协议
- 实施指南

## 📦 包含内容

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 主技能文件（完整系统设计） |
| `references/` | 参考模板 |
| `references/template-inbox.md` | 收件箱模板 |
| `references/template-shared-memory.md` | 共享记忆模板 |

## 🚀 快速开始

### Step 1: 安装

```bash
openclawmp install skill/@zh8650/team-memory-system
```

### Step 2: 创建工作区

```bash
mkdir -p ~/.your-agent/workspace/{.learnings,memory/daily}
```

### Step 3: 复制模板

复制以下文件到工作区：
- `SHARED_MEMORY.md`（团队共用）
- `TEAM_INBOX.md`（收件箱）
- `.learnings/LEARNINGS.md`（学习沉淀）

### Step 4: 开始使用

1. 开工前读 `TEAM_INBOX.md`
2. 学完同步到 `TEAM_INBOX.md`
3. 重要内容提炼到 `SHARED_MEMORY.md`

## 🏆 适用场景

- ✅ 多个AI Agent团队协作
- ✅ 避免重复学习和工作
- ✅ 知识跨Agent共享
- ✅ 主人信息统一管理

## 👥 团队角色

| 代号 | 角色 | 职责 |
|------|------|------|
| 🔥 小熔 | 总指挥 | 主持、分配、风控 |
| ⚡ 小跃 | 全球情报官 | 情报搜集 |
| 💰 烁金 | 首席量化官 | 量化交易 |
| 🐼 小Q | 全内容官 | 内容创作 |
| 🛒 赤壤 | 电商执行官 | 电商运营 |
| 📚 小糯 | 数据学术官 | 数据分析 |

## 📊 系统架构

```
👤 主人
   │
   ▼
L3 主人专属记忆 (MEMORY.md)
   │
   ▼
L2 团队共用记忆 (SHARED_MEMORY.md + TEAM_INBOX.md)
   │
   ├──▶ Agent 1 (.learnings/)
   ├──▶ Agent 2 (.learnings/)
   └──▶ Agent N (.learnings/)
```

## 🔗 相关资源

- 六位搞钱天团：https://openclawmp.cc/team/s-xxx

---

*小熔设计 | v1.0.0*
