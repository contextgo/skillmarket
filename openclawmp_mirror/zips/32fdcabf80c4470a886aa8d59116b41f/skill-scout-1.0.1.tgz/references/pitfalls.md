# 踩坑记录

## 1. openclawmp search API 偶尔 500
- 现象：`HTTP 500, asset search provider request failed`
- 原因：水产市场搜索后端偶尔不稳定
- 解决：脚本里每个关键词之间 sleep 1 秒避免限流，单个失败不影响其他关键词

## 2. cron isolated session 读不到主 session 上下文
- 现象：cron agent 不知道已安装了哪些技能
- 原因：isolated session 是独立的，没有主 session 的对话历史
- 解决：在 cron prompt 里明确要求先跑 `openclawmp list` 获取已安装列表

## 3. openclaw cron list 命令经常超时
- 现象：`openclaw cron list` 挂住不返回
- 解决：直接读 `/root/.openclaw/cron/jobs.json` 文件验证 cron 配置

## 4. cron job 写入后 Gateway 不一定立即识别
- 现象：写入 jobs.json 后 `openclaw cron list` 看不到新 job
- 解决：Gateway 会在下次调度周期自动加载，或者重启 Gateway

## 5. pumpkinai.vip 等代理不稳定导致 cron 超时
- 现象：cron status=ok 但实际没完成
- 解决：cron timeoutSeconds 设够长（3600s），不要用默认的 30s

## 6. 水产市场 README 图片必须用公网 URL
- 现象：README 里用相对路径 `demo.jpg` 图片裂了
- 原因：水产市场渲染器不支持包内本地图片引用
- 解决：上传到公网图床（freeimage.host 等国内可访问的），用绝对 URL

## 7. imgur 在国内被墙
- 现象：图片显示 "Content not viewable in your region"
- 解决：用 freeimage.host（iili.io）等国内可访问的图床
