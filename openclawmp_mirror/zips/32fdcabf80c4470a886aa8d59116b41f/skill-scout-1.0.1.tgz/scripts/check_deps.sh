#!/bin/bash
# check_deps.sh - 检查技能巡检依赖是否就绪

echo "=== 技能巡检依赖检查 ==="

OK=true

if command -v openclawmp &>/dev/null; then
  VER=$(openclawmp --version 2>&1)
  echo "✅ openclawmp: v$VER"
else
  echo "❌ openclawmp: 未安装 → npm install -g openclawmp"
  OK=false
fi

if command -v openclaw &>/dev/null; then
  echo "✅ openclaw: 已安装"
else
  echo "❌ openclaw: 未安装"
  OK=false
fi

# 检查登录状态
if command -v openclawmp &>/dev/null; then
  LOGIN=$(openclawmp login 2>&1)
  if echo "$LOGIN" | grep -q "已登录"; then
    echo "✅ openclawmp 登录状态: 已登录"
  else
    echo "⚠️ openclawmp 登录状态: 未登录 → openclawmp oauth <token>"
  fi
fi

# 检查 cron 文件
if [ -f "/root/.openclaw/cron/jobs.json" ]; then
  echo "✅ cron jobs 文件: 存在"
else
  echo "❌ cron jobs 文件: 不存在"
  OK=false
fi

echo ""
if [ "$OK" = true ]; then
  echo "🎉 所有依赖就绪，可以开始巡检了！"
else
  echo "⚠️ 有缺失依赖，请先安装"
fi
