#!/bin/bash
# skill-scout.sh - 水产市场技能巡检脚本
# 搜索多个关键词，输出合并结果供 cron agent 分析
# 用法: skill-scout.sh [自定义关键词...]

set -e

# 默认关键词，可通过参数覆盖
if [ $# -gt 0 ]; then
    KEYWORDS=("$@")
else
    KEYWORDS=("agent" "automation" "memory" "telegram" "monitor" "cron" "tool" "search" "productivity" "security" "git" "api" "notification" "schedule" "backup" "image" "voice" "translate" "news" "rss")
fi

echo "=== 水产市场技能巡检 $(date '+%Y-%m-%d %H:%M') ==="
echo "关键词数量: ${#KEYWORDS[@]}"
echo ""

# 获取已安装列表
echo "--- 已安装技能 ---"
openclawmp list 2>&1
echo ""

# 搜索各关键词
for kw in "${KEYWORDS[@]}"; do
    echo "--- 搜索: $kw ---"
    openclawmp search "$kw" --page-size 5 2>&1
    echo ""
    sleep 1  # 避免触发限流
done

echo "=== 巡检完成 ==="
