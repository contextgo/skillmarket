#!/bin/bash
# setup_cron.sh - 一键创建技能巡检 cron job
# 用法: setup_cron.sh <cron表达式> <时区> <通道> <账号> <目标>
# 示例: setup_cron.sh "0 11 * * *" "Asia/Shanghai" "telegram" "default" "-1003715249520"

set -e

CRON_EXPR="${1:-0 11 * * *}"
TZ="${2:-Asia/Shanghai}"
CHANNEL="${3:-telegram}"
ACCOUNT="${4:-default}"
TARGET="${5}"

if [ -z "$TARGET" ]; then
  echo "用法: setup_cron.sh <cron表达式> <时区> <通道> <账号> <目标>"
  echo "示例: setup_cron.sh \"0 11 * * *\" \"Asia/Shanghai\" \"telegram\" \"default\" \"-1003715249520\""
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
JOBS_FILE="/root/.openclaw/cron/jobs.json"

if [ ! -f "$JOBS_FILE" ]; then
  echo "❌ cron jobs 文件不存在: $JOBS_FILE"
  exit 1
fi

python3 -c "
import json, uuid, time

with open('$JOBS_FILE') as f:
    data = json.load(f)

# 检查是否已存在同名 job
for j in data.get('jobs', []):
    if j.get('name') == '水产市场技能巡检':
        print('⚠️ 已存在同名 cron job，ID:', j['id'])
        print('如需重建，请先删除旧的')
        exit(0)

prompt = '''你是技能巡检员。任务：去水产市场搜索对我有用的新技能，列出推荐清单发到聊天群。

第一步：用 exec 执行 bash $SCRIPT_DIR/skill-scout.sh 获取搜索结果。

第二步：用 exec 执行 openclawmp list 获取已安装技能列表。

第三步：分析搜索结果，筛选出对我有用的新技能（排除已安装的）。筛选标准：
- 能增强记忆/知识管理能力
- 能提升自动化/效率
- 能增强 Telegram/飞书等通道能力
- 能增强监控/安全/运维能力
- 能增强信息获取能力（RSS、新闻、搜索等）
- 安装量 > 5 的优先考虑
- 排除明显无关的（Windows专用、特定硬件依赖等）

第四步：生成推荐清单，每个技能包含：
- 名称和类型
- 对我有什么用（一句话）
- 预期效果（一句话）
- 安装量
- 安装命令

第五步：必须调用 exec 执行以下命令发送到群里：
openclaw message send --channel $CHANNEL --account $ACCOUNT --target \"$TARGET\" --message \"🔍 每日技能巡检报告\\n\\n[推荐清单内容]\\n\\n回复告诉我要装哪个！\"

规则：
1. 如果没有值得推荐的新技能，发送\"🔍 今日巡检：暂无新的值得推荐的技能\"
2. 推荐数量控制在 3-8 个，精选不贪多
3. 禁止输出 ANNOUNCE_SKIP，禁止跳过发送步骤'''

new_job = {
    'id': str(uuid.uuid4()),
    'name': '水产市场技能巡检',
    'enabled': True,
    'createdAtMs': int(time.time() * 1000),
    'updatedAtMs': int(time.time() * 1000),
    'schedule': {
        'kind': 'cron',
        'expr': '$CRON_EXPR',
        'tz': '$TZ'
    },
    'sessionTarget': 'isolated',
    'wakeMode': 'now',
    'payload': {
        'kind': 'agentTurn',
        'message': prompt,
        'timeoutSeconds': 3600
    },
    'delivery': {
        'mode': 'announce',
        'channel': '$CHANNEL',
        'to': '$TARGET'
    },
    'state': {
        'consecutiveErrors': 0
    }
}

data['jobs'].append(new_job)

with open('$JOBS_FILE', 'w') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print(f'✅ Cron job 创建成功')
print(f'   ID: {new_job[\"id\"]}')
print(f'   名称: {new_job[\"name\"]}')
print(f'   调度: {new_job[\"schedule\"][\"expr\"]} @ {new_job[\"schedule\"][\"tz\"]}')
print(f'   通道: $CHANNEL/$ACCOUNT -> $TARGET')
"
