# 水产市场技能巡检

让你的 OpenClaw Agent 每天自动去水产市场逛一圈，找到对自己有用的新技能，列出推荐清单发给你，你拍板装哪个。Agent 自己给自己挑装备。

## 效果展示

![技能巡检效果图](https://iili.io/BNNn2KG.jpg)

## 能力

- 自动搜索水产市场 20 个关键词，覆盖 agent/自动化/记忆/通道/监控/安全等方向
- 智能筛选：排除已安装、排除无关、安装量优先
- 每个推荐标注用途、效果、安装命令
- 定时推送到 Telegram/飞书等通道
- 你回复编号，Agent 直接安装

## 快速开始

```bash
# 1. 检查依赖
bash scripts/check_deps.sh

# 2. 手动跑一次测试
bash scripts/skill-scout.sh

# 3. 一键创建定时巡检 cron（每天 11:00）
bash scripts/setup_cron.sh "0 11 * * *" "Asia/Shanghai" "telegram" "default" "<your_chat_id>"
```

## 文件结构

```
skill-scout/
├── SKILL.md                    # 完整配置流程
├── .metadata.json              # 资产元数据
├── README.md                   # 本文件
├── scripts/
│   ├── check_deps.sh           # 依赖检查
│   ├── skill-scout.sh          # 巡检脚本（搜索 20 个关键词）
│   └── setup_cron.sh           # 一键创建 cron job
└── references/
    ├── cron-config-example.json # cron 配置示例
    └── pitfalls.md              # 踩坑记录（7 个实战坑）
```

## 工作流程

```
每天定时触发 → 搜索 20 个关键词 → 获取已安装列表 → 智能筛选 → 生成 3-8 个推荐 → 发送到群 → 你拍板 → Agent 安装
```
