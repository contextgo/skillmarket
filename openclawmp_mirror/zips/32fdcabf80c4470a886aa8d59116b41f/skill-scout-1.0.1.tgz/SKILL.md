---
name: skill-scout
description: 水产市场技能自动巡检：每天定时搜索新技能，智能筛选推荐，发送清单到聊天群，等你拍板安装。让 Agent 自己逛商店给自己挑装备。
version: 1.0.0
tags: [skill, scout, automation, cron, openclaw, marketplace, openclawmp]
author: X
---

# 水产市场技能巡检

让你的 Agent 每天自动去水产市场（openclawmp）逛一圈，找到对自己有用的新技能，列出推荐清单发给你，你拍板装哪个。

## 前置条件检查

```bash
# 检查 openclawmp CLI 是否可用
bash scripts/check_deps.sh
```

需要：
- `openclawmp` CLI 已安装且已登录
- `openclaw` CLI 可用（用于发消息和管理 cron）
- 一个消息通道（Telegram/飞书等）用于接收推荐清单

## 第一步：安装 openclawmp

```bash
npm install -g openclawmp
```

登录检查：
```bash
openclawmp login
```

如果未登录，需要先在水产市场网页获取 token，然后：
```bash
openclawmp oauth <your_token>
```

## 第二步：部署巡检脚本

巡检脚本 `scripts/skill-scout.sh` 会搜索 20 个关键词，每个取 top 5 结果：

```bash
# 手动跑一次测试
bash scripts/skill-scout.sh
```

关键词覆盖：agent、automation、memory、telegram、monitor、cron、tool、search、productivity、security、git、api、notification、schedule、backup、image、voice、translate、news、rss

可以根据自己需求在脚本里增删关键词。

## 第三步：创建定时巡检 Cron

用 `scripts/setup_cron.sh` 一键创建 cron job：

```bash
# 参数：<cron表达式> <时区> <通道> <账号> <目标>
bash scripts/setup_cron.sh "0 11 * * *" "Asia/Shanghai" "telegram" "default" "-1003715249520"
```

这会在 `/root/.openclaw/cron/jobs.json` 中添加一个 isolated cron job。

也可以手动编辑 cron 配置，参考 `references/cron-config-example.json`。

## 第四步：验证

```bash
# 查看 cron 列表确认已添加
openclaw cron list

# 手动触发一次测试
openclaw cron run <job_id>
```

或者直接手动跑完整流程：
```bash
bash scripts/skill-scout.sh > /tmp/scout-result.txt 2>&1
cat /tmp/scout-result.txt
```

## 工作流程

```
每天定时触发
    ↓
skill-scout.sh 搜索 20 个关键词
    ↓
获取已安装技能列表
    ↓
智能筛选（排除已装、排除无关、安装量>5优先）
    ↓
生成 3-8 个精选推荐（名称、用途、效果、安装命令）
    ↓
发送到聊天群
    ↓
你回复要装哪个 → Agent 执行安装
```

## 筛选标准

Cron agent 按以下标准筛选推荐：
- 能增强记忆/知识管理能力
- 能提升自动化/效率
- 能增强通道能力（Telegram/飞书等）
- 能增强监控/安全/运维能力
- 能增强信息获取能力（RSS、新闻、搜索等）
- 安装量 > 5 的优先
- 排除明显无关的（Windows 专用、特定硬件依赖等）
- 排除已安装的技能

## 自定义

### 修改搜索关键词
编辑 `scripts/skill-scout.sh` 中的 `KEYWORDS` 数组。

### 修改筛选标准
编辑 `scripts/setup_cron.sh` 中的 cron prompt。

### 修改推送通道
setup_cron.sh 支持参数化配置通道、账号和目标。

## 踩过的坑

详见 `references/pitfalls.md`
