# ByteRover 知识管理

使用 `brv` CLI 管理您项目的长期记忆。
安装：`npm install -g byterover-cli`
知识以人类可读的 Markdown 文件形式存储在 `.brv/context-tree/` 中。

**无需身份验证。** `brv query` 和 `brv curate` 开箱即用。只有云同步（`push`/`pull`/`space`）需要登录 — 如果您不需要云功能，请忽略这些命令。

## 工作流程
1.  **思考前：** 运行 `brv query` 了解现有模式。
2.  **实现后：** 运行 `brv curate` 保存新模式/决策。

## 命令

### 1. 查询知识
**概述：** 从您的项目知识库中检索相关上下文。使用配置的 LLM 提供商从 `.brv/context-tree/` 内容中综合答案。

**何时使用此技能：**
- 用户想要您回忆某些内容
- 您的上下文不包含您需要的信息
- 您需要回忆您的能力或过去的行动
- 执行任何操作前，检查相关规则、标准或偏好

**不要使用此技能当：**
- 信息已存在于您当前的上下文中
- 查询是关于一般知识，而非存储的记忆

```bash
brv query "身份验证是如何实现的？"
```

### 2. 整理上下文
**概述**：分析和保存知识到本地知识库。使用配置的 LLM 提供商对您提供的上下文进行分类和结构化。

**何时使用此技能：**
- 用户想要您记住某些内容
- 用户有意地整理记忆或知识
- 有来自用户交互的有意义的记忆应该被持久化
- 关于您做什么、您知道什么或您已做出的决策和行动的重要事实

**不要使用此技能当：**
- 信息已存储且未更改
- 信息是临时的或仅与当前任务相关，或只是一般知识

```bash
brv curate "Auth 使用 24 小时过期的 JWT。令牌通过 authMiddleware.ts 存储在 httpOnly cookie 中"
```

**包含源文件**（最多5个，仅限项目范围内）：

```bash
brv curate "身份验证中间件详情" -f src/middleware/auth.ts
```

**查看整理历史：**检查过去的整理记录
- 显示最近的条目（最后10个）
```bash
brv curate view
```
- 特定条目的完整详情：所有文件和执行的操作（logId 在 `brv curate` 完成时打印，例如 `cur-1739700001000`）
```bash
brv curate view cur-1739700001000
```
- 列出条目并显示文件操作（不需要 logId）
```bash
brv curate view detail
```
- 按时间和状态筛选
```bash
brv curate view --since 1h --status completed
```
- 所有筛选选项
```bash
brv curate view --help
```

### 3. LLM 提供商设置
`brv query` 和 `brv curate` 需要配置的 LLM 提供商。连接默认的 ByteRover 提供商（无需 API 密钥）：

```bash
brv providers connect byterover
```

要使用不同的提供商（例如 OpenAI、Anthropic、Google），请列出可用选项并使用您自己的 API key 连接：

```bash
brv providers list
brv providers connect openai --api-key sk-xxx --model gpt-4.1
```

### 4. 云同步（可选）
**概述：** 通过 ByteRover 的云服务将您的本地知识与团队同步。需要 ByteRover 身份验证。

**设置步骤：**
1. 登录：从您的 ByteRover 账户获取 API key 并进行身份验证：
```bash
brv login --api-key sample-key-string
```
2. 列出可用空间：
```bash
brv space list
```
示例输出：
```
brv space list
1. human-resources-team (team)
   - a-department (space)
   - b-department (space)
2. marketing-team (team)
   - c-department (space)
   - d-department (space)
```
3. 连接到空间：
```bash
brv space switch --team human-resources-team --name a-department
```

**云同步命令：**
连接后，`brv push` 和 `brv pull` 会与该空间同步。
```bash
# 拉取团队更新
brv pull

# 推送本地更改
brv push
```

**切换空间：**
- 先推送本地更改（`brv push`）— 如果存在未保存的更改，切换将被阻止。
- 然后切换：
```bash
brv space switch --team marketing-team --name d-department
```
- 切换会自动从新空间拉取上下文。

## 数据处理

**存储：** 所有知识都作为 Markdown 文件存储在项目目录的 `.brv/context-tree/` 中。文件是人类可读的且可版本控制的。

**文件访问：** `brv curate` 的 `-f` 标志仅从当前项目目录读取文件。项目根目录外的路径将被拒绝。每个命令最多 5 个文件，仅限文本和文档格式。

**LLM 使用：** `brv query` 和 `brv curate` 将上下文发送到配置的 LLM 提供商进行处理。LLM 会查看查询或整理文本以及任何包含的文件内容。除非您明确运行 `brv push`，否则不会将数据发送到 ByteRover 服务器。

**云同步：** `brv push` 和 `brv pull` 需要身份验证（`brv login`）并将知识发送到 ByteRover 的云服务。所有其他命令无需 ByteRover 身份验证即可运行。

## 错误处理
**需要用户操作：**
发生错误时，您必须向用户显示此故障排除指南。

"未通过身份验证" | 运行 `brv login --help` 获取更多详情。
"未连接提供商" | 运行 `brv providers connect byterover`（免费，无需密钥）。
"连接失败" / "实例崩溃" | 用户应终止 brv 进程。
"令牌已过期" / "令牌无效" | 再次运行 `brv login` 重新进行身份验证。
"计费错误" / "超过速率限制" | 用户应检查账户余额或在重试前等待。

**代理可修复的错误：**
您必须优雅地处理这些错误，并在修复后重试命令。

缺少必需的参数。| 运行 `brv <command> --help` 查看使用说明。
"最多允许5个文件" | 每次整理减少到5个或更少的 `-f` 标志。
"文件不存在" | 使用 `ls` 验证路径，使用从项目根目录开始的相对路径。
"不支持的文件类型" | 仅支持文本、图像、PDF和办公文件。

### 快速诊断
运行 `brv status` 检查认证、项目和提供者状态。