#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stock DataHub - 股票数据中枢
提供统一的股票数据获取接口
"""

import json
import os
from pathlib import Path

import akshare as ak
import pandas as pd


class StockDataHub:
    """股票数据中枢类"""
    
    def __init__(self, config_path=None):
        """初始化数据中枢"""
        self.config = self._load_config(config_path)
        self._cache = {}
        
    def _load_config(self, config_path):
        """加载配置文件"""
        if config_path is None:
            config_path = Path(__file__).parent / "config" / "config.json"
        
        if not os.path.exists(config_path):
            config_path = Path(__file__).parent / "config" / "sample.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"配置加载失败: {e}")
            return {}
    
    def get_stock_info(self, code):
        """
        获取股票基本信息
        
        Args:
            code: 股票代码，如 "000001"
            
        Returns:
            dict: 股票基本信息
        """
        try:
            # 使用 akshare 获取股票信息
            df = ak.stock_individual_info_em(symbol=code)
            if df is not None and not df.empty:
                info = {
                    "code": code,
                    "name": df[df["item"] == "股票简称"]["value"].values[0] if "股票简称" in df["item"].values else "",
                    "industry": df[df["item"] == "行业"]["value"].values[0] if "行业" in df["item"].values else "",
                    "total_mv": df[df["item"] == "总市值"]["value"].values[0] if "总市值" in df["item"].values else "",
                    "circ_mv": df[df["item"] == "流通市值"]["value"].values[0] if "流通市值" in df["item"].values else "",
                }
                return info
        except Exception as e:
            print(f"获取股票信息失败: {e}")
        return None
    
    def get_realtime_quote(self, code):
        """
        获取实时行情
        
        Args:
            code: 股票代码
            
        Returns:
            dict: 实时行情数据
        """
        try:
            df = ak.stock_zh_a_spot_em()
            stock = df[df["代码"] == code]
            if not stock.empty:
                return {
                    "code": code,
                    "name": stock["名称"].values[0],
                    "price": stock["最新价"].values[0],
                    "change": stock["涨跌幅"].values[0],
                    "volume": stock["成交量"].values[0],
                    "amount": stock["成交额"].values[0],
                    "high": stock["最高"].values[0],
                    "low": stock["最低"].values[0],
                    "open": stock["今开"].values[0],
                    "pre_close": stock["昨收"].values[0],
                }
        except Exception as e:
            print(f"获取实时行情失败: {e}")
        return None
    
    def get_kline_data(self, code, days=30, period="daily"):
        """
        获取历史K线数据
        
        Args:
            code: 股票代码
            days: 天数
            period: 周期 (daily/weekly/monthly)
            
        Returns:
            DataFrame: K线数据
        """
        try:
            if period == "daily":
                df = ak.stock_zh_a_hist(symbol=code, period="daily", start_date="", end_date="", adjust="qfq")
            elif period == "weekly":
                df = ak.stock_zh_a_hist(symbol=code, period="weekly", start_date="", end_date="", adjust="qfq")
            elif period == "monthly":
                df = ak.stock_zh_a_hist(symbol=code, period="monthly", start_date="", end_date="", adjust="qfq")
            else:
                df = ak.stock_zh_a_hist(symbol=code, period="daily", start_date="", end_date="", adjust="qfq")
            
            if df is not None and not df.empty:
                return df.tail(days)
        except Exception as e:
            print(f"获取K线数据失败: {e}")
        return None
    
    def get_money_flow(self, code):
        """
        获取资金流向
        
        Args:
            code: 股票代码
            
        Returns:
            dict: 资金流向数据
        """
        try:
            df = ak.stock_individual_fund_flow(stock=code, market="sh")
            if df is not None and not df.empty:
                latest = df.iloc[0]
                return {
                    "code": code,
                    "date": latest.get("日期", ""),
                    "main_in": latest.get("主力净流入-净额", ""),
                    "main_in_percent": latest.get("主力净流入-净占比", ""),
                    "retail_in": latest.get("散户净流入-净额", ""),
                    "retail_in_percent": latest.get("散户净流入-净占比", ""),
                }
        except Exception as e:
            print(f"获取资金流向失败: {e}")
        return None
    
    def get_stock_list(self):
        """
        获取股票列表
        
        Returns:
            DataFrame: 股票列表
        """
        try:
            df = ak.stock_zh_a_spot_em()
            return df[["代码", "名称", "最新价", "涨跌幅", "换手率", "市盈率-动态", "总市值"]]
        except Exception as e:
            print(f"获取股票列表失败: {e}")
        return None


def main():
    """CLI 入口"""
    import fire
    
    hub = StockDataHub()
    
    def info(code):
        """获取股票基本信息"""
        result = hub.get_stock_info(code)
        if result:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"未找到股票 {code} 的信息")
    
    def quote(code):
        """获取实时行情"""
        result = hub.get_realtime_quote(code)
        if result:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"未找到股票 {code} 的行情")
    
    def kline(code, days=30, period="daily"):
        """获取历史K线"""
        result = hub.get_kline_data(code, days, period)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print(f"未找到股票 {code} 的K线数据")
    
    def money(code):
        """获取资金流向"""
        result = hub.get_money_flow(code)
        if result:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"未找到股票 {code} 的资金流向")
    
    def list():
        """获取股票列表"""
        result = hub.get_stock_list()
        if result is not None:
            print(result.head(20).to_string(index=False))
            print(f"\n共 {len(result)} 只股票")
        else:
            print("获取股票列表失败")
    
    fire.Fire({
        "info": info,
        "quote": quote,
        "kline": kline,
        "money": money,
        "list": list,
    })


if __name__ == "__main__":
    main()
