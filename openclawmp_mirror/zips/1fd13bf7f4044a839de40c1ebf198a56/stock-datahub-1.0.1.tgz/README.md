# 股票数据中枢 (stock-datahub)

股票数据中枢 Skill，提供统一的股票数据获取接口。作为其他股票相关 Skill 的基础依赖。

## 功能

- 获取股票基本信息（名称、行业、市值等）
- 获取实时行情数据
- 获取历史K线数据
- 获取资金流向数据
- 获取股票列表

## 安装

```bash
openclawmp install skill/stock-datahub --target-dir ~/.stepclaw/skills
```

## 使用

```bash
# 获取股票基本信息
python main.py info 000001

# 获取实时行情
python main.py quote 000001

# 获取历史K线
python main.py kline 000001 --days 30

# 获取资金流向
python main.py money 000001

# 获取股票列表
python main.py list
```

## 配置

复制 `config/sample.json` 为 `config/config.json`：

```json
{
  "tushare_token": "your_tushare_token",
  "akshare_timeout": 30,
  "cache_enabled": true,
  "cache_ttl": 300
}
```

## 依赖

- akshare
- pandas
- requests

## License

MIT
