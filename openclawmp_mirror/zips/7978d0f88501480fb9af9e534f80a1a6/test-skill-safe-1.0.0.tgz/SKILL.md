---
name: test-skill-safe
description: 查询全球城市的实时天气和未来7天预报。支持摄氏度/华氏度切换，适合旅行规划和日常参考。
allowed-tools:
  - web_fetch
---

# 天气查询助手

一个简单的天气查询工具，通过 Open-Meteo 免费 API 获取实时气象数据，无需 API Key。

## 能力范围

- 查询任意城市当前温度、湿度、风速、天气状况
- 获取未来 7 天天气预报
- 支持摄氏度（默认）和华氏度切换

## 使用方式

直接告诉我城市名称即可：

- "北京今天天气怎么样？"
- "明天上海会下雨吗？"
- "帮我查一下纽约本周的天气预报"

## 数据来源

- 地理编码：Open-Meteo Geocoding API（https://geocoding-api.open-meteo.com）
- 天气数据：Open-Meteo（https://api.open-meteo.com）
- 完全免费，无需注册，无使用限制

## 技术说明

使用 `web_fetch` 工具调用公开 API，仅读取天气数据，不收集用户信息，不写入任何文件。
