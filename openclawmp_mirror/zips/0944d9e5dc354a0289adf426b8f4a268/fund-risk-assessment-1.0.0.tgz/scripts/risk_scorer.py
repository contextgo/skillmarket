#!/usr/bin/env python3
"""
基金综合风险评分脚本
提供多维度风险指标计算和综合评分功能
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class FundRiskScorer:
    """基金风险评分器"""
    
    def __init__(self, weights=None):
        """
        初始化风险评分器
        
        Args:
            weights: 风险权重字典，如不提供使用默认权重
        """
        self.default_weights = {
            "market_risk": 0.30,      # 市场风险权重
            "fund_risk": 0.25,        # 基金风险权重
            "liquidity_risk": 0.20,   # 流动性风险权重
            "management_risk": 0.15,  # 管理风险权重
            "operational_risk": 0.10  # 操作风险权重
        }
        
        self.weights = weights if weights else self.default_weights
        
        # 风险指标阈值
        self.thresholds = {
            "volatility": {
                "low": 15,      # 年化波动率<15%
                "medium": 25,   # 年化波动率<25%
                "high": 35      # 年化波动率<35%
            },
            "max_drawdown": {
                "low": 15,      # 最大回撤<15%
                "medium": 25,   # 最大回撤<25%
                "high": 35      # 最大回撤<35%
            },
            "liquidity": {
                "low": 10000000,    # 日均成交额>1000万
                "medium": 5000000,  # 日均成交额>500万
                "high": 1000000     # 日均成交额>100万
            }
        }
    
    def calculate_market_risk(self, fund_data):
        """
        计算市场风险评分
        
        Args:
            fund_data: 基金数据字典，包含历史收益等数据
            
        Returns:
            市场风险评分(0-100分，分数越高风险越高)
        """
        try:
            # 获取历史收益数据
            returns = fund_data.get('returns', [])
            if len(returns) < 30:
                return 50  # 数据不足，返回中等风险
            
            # 计算年化波动率
            volatility = np.std(returns) * np.sqrt(252) * 100
            
            # 计算最大回撤
            cumulative_returns = np.cumprod(1 + np.array(returns))
            peak = np.maximum.accumulate(cumulative_returns)
            drawdown = (cumulative_returns - peak) / peak
            max_drawdown = np.min(drawdown) * 100
            
            # 计算贝塔系数（需要市场基准数据）
            market_returns = fund_data.get('market_returns', returns)  # 默认用自身
            if len(market_returns) == len(returns):
                covariance = np.cov(returns, market_returns)[0, 1]
                market_variance = np.var(market_returns)
                beta = covariance / market_variance if market_variance > 0 else 1
            else:
                beta = 1.0
            
            # 波动率评分
            if volatility < self.thresholds["volatility"]["low"]:
                vol_score = 20
            elif volatility < self.thresholds["volatility"]["medium"]:
                vol_score = 40
            elif volatility < self.thresholds["volatility"]["high"]:
                vol_score = 60
            else:
                vol_score = 80
            
            # 最大回撤评分
            if abs(max_drawdown) < self.thresholds["max_drawdown"]["low"]:
                drawdown_score = 20
            elif abs(max_drawdown) < self.thresholds["max_drawdown"]["medium"]:
                drawdown_score = 40
            elif abs(max_drawdown) < self.thresholds["max_drawdown"]["high"]:
                drawdown_score = 60
            else:
                drawdown_score = 80
            
            # 贝塔系数评分
            if beta < 0.8:
                beta_score = 20
            elif beta < 1.2:
                beta_score = 50
            else:
                beta_score = 80
            
            # 加权计算市场风险总分
            market_risk_score = (vol_score * 0.4 + 
                                drawdown_score * 0.4 + 
                                beta_score * 0.2)
            
            return {
                "score": market_risk_score,
                "metrics": {
                    "annualized_volatility": volatility,
                    "max_drawdown": max_drawdown,
                    "beta": beta
                },
                "breakdown": {
                    "volatility_score": vol_score,
                    "drawdown_score": drawdown_score,
                    "beta_score": beta_score
                }
            }
            
        except Exception as e:
            print(f"计算市场风险时出错: {e}")
            return {"score": 50, "metrics": {}, "breakdown": {}}
    
    def calculate_fund_risk(self, fund_data):
        """
        计算基金特有风险评分
        
        Args:
            fund_data: 基金数据字典
            
        Returns:
            基金风险评分(0-100分)
        """
        try:
            returns = fund_data.get('returns', [])
            if len(returns) < 30:
                return {"score": 50, "metrics": {}, "breakdown": {}}
            
            # 计算夏普比率（假设无风险利率3%）
            excess_returns = np.array(returns) - 0.03/252
            sharpe_ratio = np.mean(excess_returns) / np.std(returns) * np.sqrt(252)
            
            # 计算索提诺比率
            negative_returns = [r for r in returns if r < 0]
            downside_std = np.std(negative_returns) if negative_returns else 0.01
            sortino_ratio = np.mean(excess_returns) / downside_std * np.sqrt(252)
            
            # 计算信息比率（需要基准收益）
            benchmark_returns = fund_data.get('benchmark_returns', returns)
            active_returns = np.array(returns) - np.array(benchmark_returns)
            information_ratio = np.mean(active_returns) / np.std(active_returns) * np.sqrt(252)
            
            # 夏普比率评分
            if sharpe_ratio > 1.5:
                sharpe_score = 20
            elif sharpe_ratio > 1.0:
                sharpe_score = 40
            elif sharpe_ratio > 0.5:
                sharpe_score = 60
            elif sharpe_ratio > 0:
                sharpe_score = 70
            else:
                sharpe_score = 90
            
            # 索提诺比率评分
            if sortino_ratio > 2.0:
                sortino_score = 20
            elif sortino_ratio > 1.0:
                sortino_score = 40
            elif sortino_ratio > 0.5:
                sortino_score = 60
            elif sortino_ratio > 0:
                sortino_score = 70
            else:
                sortino_score = 90
            
            # 信息比率评分
            if information_ratio > 0.5:
                ir_score = 30
            elif information_ratio > 0:
                ir_score = 50
            else:
                ir_score = 70
            
            # 基金规模评分
            fund_size = fund_data.get('fund_size', 1000000000)  # 默认10亿
            if fund_size > 5000000000:  # 50亿以上
                size_score = 30
            elif fund_size > 1000000000:  # 10亿以上
                size_score = 50
            elif fund_size > 500000000:  # 5亿以上
                size_score = 60
            else:
                size_score = 80
            
            # 加权计算基金风险总分
            fund_risk_score = (sharpe_score * 0.3 + 
                              sortino_score * 0.3 + 
                              ir_score * 0.2 + 
                              size_score * 0.2)
            
            return {
                "score": fund_risk_score,
                "metrics": {
                    "sharpe_ratio": sharpe_ratio,
                    "sortino_ratio": sortino_ratio,
                    "information_ratio": information_ratio,
                    "fund_size": fund_size
                },
                "breakdown": {
                    "sharpe_score": sharpe_score,
                    "sortino_score": sortino_score,
                    "ir_score": ir_score,
                    "size_score": size_score
                }
            }
            
        except Exception as e:
            print(f"计算基金风险时出错: {e}")
            return {"score": 50, "metrics": {}, "breakdown": {}}
    
    def calculate_liquidity_risk(self, fund_data):
        """
        计算流动性风险评分
        
        Args:
            fund_data: 基金数据字典
            
        Returns:
            流动性风险评分(0-100分)
        """
        try:
            # 获取流动性指标
            avg_daily_volume = fund_data.get('avg_daily_volume', 5000000)  # 默认500万
            bid_ask_spread = fund_data.get('bid_ask_spread', 0.002)  # 默认0.2%
            redemption_frequency = fund_data.get('redemption_frequency', 'T+1')  # 默认T+1
            
            # 日均成交量评分
            if avg_daily_volume >= self.thresholds["liquidity"]["low"]:
                volume_score = 20
            elif avg_daily_volume >= self.thresholds["liquidity"]["medium"]:
                volume_score = 40
            elif avg_daily_volume >= self.thresholds["liquidity"]["high"]:
                volume_score = 60
            else:
                volume_score = 80
            
            # 买卖价差评分
            if bid_ask_spread < 0.001:  # <0.1%
                spread_score = 20
            elif bid_ask_spread < 0.002:  # <0.2%
                spread_score = 40
            elif bid_ask_spread < 0.005:  # <0.5%
                spread_score = 60
            else:
                spread_score = 80
            
            # 赎回频率评分
            redemption_scores = {
                'T+0': 30,
                'T+1': 50,
                'T+2': 60,
                'T+3': 70,
                'T+4': 80,
                'T+5+': 90
            }
            redemption_score = redemption_scores.get(redemption_frequency, 70)
            
            # 加权计算流动性风险总分
            liquidity_risk_score = (volume_score * 0.5 + 
                                   spread_score * 0.3 + 
                                   redemption_score * 0.2)
            
            return {
                "score": liquidity_risk_score,
                "metrics": {
                    "avg_daily_volume": avg_daily_volume,
                    "bid_ask_spread": bid_ask_spread,
                    "redemption_frequency": redemption_frequency
                },
                "breakdown": {
                    "volume_score": volume_score,
                    "spread_score": spread_score,
                    "redemption_score": redemption_score
                }
            }
            
        except Exception as e:
            print(f"计算流动性风险时出错: {e}")
            return {"score": 50, "metrics": {}, "breakdown": {}}
    
    def calculate_management_risk(self, fund_data):
        """
        计算管理风险评分
        
        Args:
            fund_data: 基金数据字典
            
        Returns:
            管理风险评分(0-100分)
        """
        try:
            # 获取管理指标
            manager_tenure = fund_data.get('manager_tenure', 3)  # 默认3年
            team_stability = fund_data.get('team_stability', 0.8)  # 默认80%稳定
            strategy_consistency = fund_data.get('strategy_consistency', 0.7)  # 默认70%一致
            style_drift = fund_data.get('style_drift', 0.3)  # 默认30%漂移
            
            # 基金经理任职年限评分
            if manager_tenure >= 10:
                tenure_score = 20
            elif manager_tenure >= 5:
                tenure_score = 40
            elif manager_tenure >= 3:
                tenure_score = 60
            elif manager_tenure >= 1:
                tenure_score = 70
            else:
                tenure_score = 90
            
            # 团队稳定性评分
            if team_stability >= 0.9:
                team_score = 30
            elif team_stability >= 0.8:
                team_score = 50
            elif team_stability >= 0.7:
                team_score = 60
            elif team_stability >= 0.6:
                team_score = 70
            else:
                team_score = 90
            
            # 策略一致性评分
            if strategy_consistency >= 0.9:
                strategy_score = 30
            elif strategy_consistency >= 0.8:
                strategy_score = 50
            elif strategy_consistency >= 0.7:
                strategy_score = 60
            elif strategy_consistency >= 0.6:
                strategy_score = 70
            else:
                strategy_score = 90
            
            # 风格漂移评分
            if style_drift <= 0.1:
                drift_score = 30
            elif style_drift <= 0.2:
                drift_score = 50
            elif style_drift <= 0.3:
                drift_score = 60
            elif style_drift <= 0.4:
                drift_score = 70
            else:
                drift_score = 90
            
            # 加权计算管理风险总分
            management_risk_score = (tenure_score * 0.3 + 
                                    team_score * 0.3 + 
                                    strategy_score * 0.2 + 
                                    drift_score * 0.2)
            
            return {
                "score": management_risk_score,
                "metrics": {
                    "manager_tenure": manager_tenure,
                    "team_stability": team_stability,
                    "strategy_consistency": strategy_consistency,
                    "style_drift": style_drift
                },
                "breakdown": {
                    "tenure_score": tenure_score,
                    "team_score": team_score,
                    "strategy_score": strategy_score,
                    "drift_score": drift_score
                }
            }
            
        except Exception as e:
            print(f"计算管理风险时出错: {e}")
            return {"score": 50, "metrics": {}, "breakdown": {}}
    
    def calculate_operational_risk(self, fund_data):
        """
        计算操作风险评分
        
        Args:
            fund_data: 基金数据字典
            
        Returns:
            操作风险评分(0-100分)
        """
        try:
            # 获取操作风险指标
            custodian_bank = fund_data.get('custodian_bank', '大型银行')  # 托管行
            audit_frequency = fund_data.get('audit_frequency', '年度')  # 审计频率
            compliance_record = fund_data.get('compliance_record', 0.9)  # 合规记录
            system_reliability = fund_data.get('system_reliability', 0.95)  # 系统可靠性
            
            # 托管行评分
            custodian_scores = {
                '国有大行': 20,
                '股份制银行': 40,
                '城商行': 60,
                '其他': 80
            }
            custodian_score = custodian_scores.get(custodian_bank, 60)
            
            # 审计频率评分
            audit_scores = {
                '季度': 30,
                '半年度': 40,
                '年度': 60,
                '两年一次': 80
            }
            audit_score = audit_scores.get(audit_frequency, 60)
            
            # 合规记录评分
            if compliance_record >= 0.95:
                compliance_score = 30
            elif compliance_record >= 0.9:
                compliance_score = 50
            elif compliance_record >= 0.8:
                compliance_score = 60
            elif compliance_record >= 0.7:
                compliance_score = 70
            else:
                compliance_score = 90
            
            # 系统可靠性评分
            if system_reliability >= 0.99:
                system_score = 30
            elif system_reliability >= 0.95:
                system_score = 50
            elif system_reliability >= 0.9:
                system_score = 60
            elif system_reliability >= 0.85:
                system_score = 70
            else:
                system_score = 90
            
            # 加权计算操作风险总分
            operational_risk_score = (custodian_score * 0.3 + 
                                     audit_score * 0.2 + 
                                     compliance_score * 0.3 + 
                                     system_score * 0.2)
            
            return {
                "score": operational_risk_score,
                "metrics": {
                    "custodian_bank": custodian_bank,
                    "audit_frequency": audit_frequency,
                    "compliance_record": compliance_record,
                    "system_reliability": system_reliability
                },
                "breakdown": {
                    "custodian_score": custodian_score,
                    "audit_score": audit_score,
                    "compliance_score": compliance_score,
                    "system_score": system_score
                }
            }
            
        except Exception as e:
            print(f"计算操作风险时出错: {e}")
            return {"score": 50, "metrics": {}, "breakdown": {}}
    
    def calculate_overall_risk_score(self, fund_data):
        """
        计算综合风险评分
        
        Args:
            fund_data: 基金数据字典
            
        Returns:
            综合风险评分结果字典
        """
        # 计算各项风险评分
        market_risk = self.calculate_market_risk(fund_data)
        fund_risk = self.calculate_fund_risk(fund_data)
        liquidity_risk = self.calculate_liquidity_risk(fund_data)
        management_risk = self.calculate_management_risk(fund_data)
        operational_risk = self.calculate_operational_risk(fund_data)
        
        # 加权计算总分
        total_score = (
            market_risk["score"] * self.weights["market_risk"] +
            fund_risk["score"] * self.weights["fund_risk"] +
            liquidity_risk["score"] * self.weights["liquidity_risk"] +
            management_risk["score"] * self.weights["management_risk"] +
            operational_risk["score"] * self.weights["operational_risk"]
        )
        
        # 确定风险等级
        risk_level = self.determine_risk_level(total_score)
        
        # 生成详细报告
        detailed_report = {
            "total_score": round(total_score, 2),
            "risk_level": risk_level,
            "category_scores": {
                "market_risk": round(market_risk["score"], 2),
                "fund_risk": round(fund_risk["score"], 2),
                "liquidity_risk": round(liquidity_risk["score"], 2),
                "management_risk": round(management_risk["score"], 2),
                "operational_risk": round(operational_risk["score"], 2)
            },
            "detailed_metrics": {
                "market_risk_metrics": market_risk["metrics"],
                "fund_risk_metrics": fund_risk["metrics"],
                "liquidity_risk_metrics": liquidity_risk["metrics"],
                "management_risk_metrics": management_risk["metrics"],
                "operational_risk_metrics": operational_risk["metrics"]
            },
            "score_breakdown": {
                "market_risk_breakdown": market_risk.get("breakdown", {}),
                "fund_risk_breakdown": fund_risk.get("breakdown", {}),
                "liquidity_risk_breakdown": liquidity_risk.get("breakdown", {}),
                "management_risk_breakdown": management_risk.get("breakdown", {}),
                "operational_risk_breakdown": operational_risk.get("breakdown", {})
            }
        }
        
        return detailed_report
    
    def determine_risk_level(self, score):
        """
        根据分数确定风险等级
        
        Args:
            score: 风险评分(0-100)
            
        Returns:
            风险等级字符串
        """
        if score <= 20:
            return "低风险"
        elif score <= 40:
            return "中低风险"
        elif score <= 60:
            return "中等风险"
        elif score <= 80:
            return "中高风险"
        else:
            return "高风险"
    
    def generate_recommendation(self, risk_report, investor_profile=None):
        """
        根据风险评估生成投资建议
        
        Args:
            risk_report: 风险评估报告
            investor_profile: 投资者画像（可选）
            
        Returns:
            投资建议字典
        """
        risk_level = risk_report["risk_level"]
        total_score = risk_report["total_score"]
        
        # 基础建议
        if risk_level == "低风险":
            recommendation = {
                "suitability": "适合所有类型投资者",
                "position_limit": "单只基金不超过总资产的30%",
                "holding_period": "建议持有6个月以上",
                "risk_control": "定期审查，设置-10%止损"
            }
        elif risk_level == "中低风险":
            recommendation = {
                "suitability": "适合保守型和稳健型投资者",
                "position_limit": "单只基金不超过总资产的25%",
                "holding_period": "建议持有1年以上",
                "risk_control": "每月审查，设置-15%止损"
            }
        elif risk_level == "中等风险":
            recommendation = {
                "suitability": "适合稳健型和平衡型投资者",
                "position_limit": "单只基金不超过总资产的20%",
                "holding_period": "建议持有2年以上",
                "risk_control": "每季度审查，设置-20%止损"
            }
        elif risk_level == "中高风险":
            recommendation = {
                "suitability": "适合平衡型和成长型投资者",
                "position_limit": "单只基金不超过总资产的15%",
                "holding_period": "建议持有3年以上",
                "risk_control": "密切监控，设置-25%止损"
            }
        else:  # 高风险
            recommendation = {
                "suitability": "仅适合进取型投资者",
                "position_limit": "单只基金不超过总资产的10%",
                "holding_period": "建议持有5年以上",
                "risk_control": "实时监控，设置-30%止损"
            }
        
        # 如果有投资者画像，进行匹配度分析
        if investor_profile:
            investor_risk = investor_profile.get("risk_tolerance", "中等风险")
            
            # 风险匹配度评分
            risk_match_scores = {
                ("保守型", "低风险"): 100,
                ("保守型", "中低风险"): 80,
                ("保守型", "中等风险"): 60,
                ("稳健型", "低风险"): 90,
                ("稳健型", "中低风险"): 95,
                ("稳健型", "中等风险"): 85,
                ("稳健型", "中高风险"): 65,
                ("平衡型", "中低风险"): 85,
                ("平衡型", "中等风险"): 95,
                ("平衡型", "中高风险"): 85,
                ("平衡型", "高风险"): 65,
                ("成长型", "中等风险"): 85,
                ("成长型", "中高风险"): 95,
                ("成长型", "高风险"): 85,
                ("进取型", "中高风险"): 85,
                ("进取型", "高风险"): 95
            }
            
            match_score = risk_match_scores.get((investor_risk, risk_level), 50)
            
            recommendation.update({
                "investor_match_score": match_score,
                "investor_suitability": f"与{investor_risk}投资者匹配度：{match_score}分",
                "match_analysis": self._generate_match_analysis(investor_risk, risk_level, match_score)
            })
        
        return recommendation
    
    def _generate_match_analysis(self, investor_risk, fund_risk, match_score):
        """生成匹配度分析"""
        if match_score >= 90:
            return "完美匹配，基金风险特征与投资者风险偏好高度一致。"
        elif match_score >= 80:
            return "良好匹配，基金风险特征适合投资者风险偏好。"
        elif match_score >= 70:
            return "基本匹配，但需要关注特定风险因素。"
        elif match_score >= 60:
            return "部分匹配，建议谨慎投资并加强风险控制。"
        else:
            return "匹配度较低，可能不适合该投资者，建议寻找更合适的产品。"


# 使用示例
if __name__ == "__main__":
    # 示例基金数据
    example_fund_data = {
        "returns": np.random.randn(252) * 0.01,  # 252个交易日，日收益
        "market_returns": np.random.randn(252) * 0.008,
        "benchmark_returns": np.random.randn(252) * 0.009,
        "avg_daily_volume": 8000000,  # 800万
        "bid_ask_spread": 0.0015,  # 0.15%
        "redemption_frequency": "T+1",
        "fund_size": 3000000000,  # 30亿
        "manager_tenure": 4.5,  # 4.5年
        "team_stability": 0.85,  # 85%
        "strategy_consistency": 0.88,  # 88%
        "style_drift": 0.25,  # 25%
        "custodian_bank": "国有大行",
        "audit_frequency": "年度",
        "compliance_record": 0.92,  # 92%
        "system_reliability": 0.98  # 98%
    }
    
    # 示例投资者画像
    example_investor = {
        "risk_tolerance": "稳健型",
        "investment_horizon": "3-5年",
        "investment_goal": "资本增值"
    }
    
    # 创建评分器
    scorer = FundRiskScorer()
    
    # 计算风险评分
    risk_report = scorer.calculate_overall_risk_score(example_fund_data)
    
    # 生成投资建议
    recommendation = scorer.generate_recommendation(risk_report, example_investor)
    
    # 打印结果
    print("="*60)
    print("基金风险评估报告")
    print("="*60)
    print(f"综合风险评分: {risk_report['total_score']:.2f}")
    print(f"风险等级: {risk_report['risk_level']}")
    print("\n分类风险评分:")
    for category, score in risk_report["category_scores"].items():
        print(f"  {category}: {score:.2f}")
    
    print("\n投资建议:")
    for key, value in recommendation.items():
        print(f"  {key}: {value}")
    
    print("="*60)