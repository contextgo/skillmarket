---
name: skill-vetter
description: 技能审查工具，检查技能的安全性、合规性和依赖完整性
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["grep", "node"] },
      },
  }
---

# Skill Vetter 技能审查工具

## 功能
检查第三方技能的安全性，避免恶意代码和不安全操作

## 使用方法
### 检查单个技能
```bash
skill-vetter check <技能目录路径>
```
示例：
```
skill-vetter check /Users/mac/.openclaw/workspace/skills/find-skill
```

### 批量检查所有技能
```bash
skill-vetter check-all
```

### 检查项说明
1. ✅ 代码安全性：检查是否包含rm -rf /、curl | bash等危险命令
2. ✅ 依赖完整性：检查依赖的二进制文件是否已安装
3. ✅ 权限合理性：检查是否要求不必要的sudo/root权限
4. ✅ 隐私合规：检查是否有数据外发的可疑操作

## 安全建议
安装第三方技能前务必先通过vetter检查，避免恶意代码执行风险
