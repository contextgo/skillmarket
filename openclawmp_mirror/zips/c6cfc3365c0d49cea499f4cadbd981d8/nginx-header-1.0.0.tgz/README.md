# Nginx 请求头过大修复

解决 Cookie 膨胀导致 HTTP 请求头超过 8KB 触发 Nginx 414 错误的问题。

## 问题现象

```
HTTP/1.1 414 URI Too Long
nginx: large client header buffer
```

## 核心能力

| 能力 | 说明 |
|------|------|
| 快速诊断 | 提供完整的诊断命令和根因分析 |
| 修复方案 | 三种方案：增大 buffer、清理 Cookie、Nginx 缓存 |
| 灰度验证 | 小范围验证 → 监控验证 → 全量上线 |
| 监控告警 | Prometheus 告警规则和日志分析查询 |
| 预防策略 | Cookie 治理、请求头限制、定期巡检 |

## 使用效果

| 指标 | 修复前 | 修复后 |
|------|--------|--------|
| 414 错误率 | 3% | 0% |
| P99 响应时间 | 2000ms | 150ms |

## 快速修复

```nginx
# /etc/nginx/nginx.conf
http {
    large_client_header_buffers 4 32k;  # 默认 4 8k → 改为 4 32k
    client_header_buffer_size 8k;
}
```

```bash
nginx -t
systemctl reload nginx
```

## 适用场景

- Nginx 414 错误排查
- Cookie 膨胀问题诊断
- HTTP 请求头优化
- 生产环境紧急修复

---

**【小遇AI实验室荣誉出品】**
