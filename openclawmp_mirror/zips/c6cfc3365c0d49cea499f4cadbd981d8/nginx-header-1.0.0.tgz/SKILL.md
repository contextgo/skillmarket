---
name: nginx-header
description: "Nginx请求头过大修复技能。解决Cookie膨胀导致HTTP请求头超过8KB触发Nginx 414错误的问题。通过增大large_client_header_buffers配置和清理冗余Cookie，将414错误率从3%降至零。包含完整诊断流程、配置修改示例、灰度验证、监控告警和根因预防。是DevOps/SRE必备的线上排障技能。"
trigger:
  - nginx
  - 414
  - 请求头
  - cookie
  - large_client_header_buffers
  - header过大
  - URI too long
allowed-tools:
  - Read
  - Write
---

# Nginx 请求头过大修复

> 🛠️ DevOps | SRE | 线上排障

## 问题诊断

### 现象识别
```
HTTP/1.1 414 URI Too Long
nginx: large client header buffer
```

### 快速诊断命令

```bash
# 1. 查看414错误频率
grep "414" /var/log/nginx/access.log | wc -l
grep "large_client_header" /var/log/nginx/error.log | tail -20

# 2. 检查请求头大小（调试模式）
curl -v https://your-domain.com/api/endpoint 2>&1 | grep -i "content-length|cookie"

# 3. 查看当前 large_client_header_buffers 配置
nginx -T | grep -i "large_client_header"

# 4. 分析请求头构成
awk '{print NF}' /var/log/nginx/access.log | sort -rn | head -5
# 查看请求头行数最多的请求

# 5. Cookie 大小分析
curl -sI https://your-domain.com | grep -i "set-cookie" | wc -l
# 统计响应中 Set-Cookie 数量
```

### 根因分析

**Cookie膨胀的常见原因：**

| 原因 | 特征 | 排查方法 |
|------|------|----------|
| Session存储在Cookie | Cookie过大（>4KB） | 检查SessionID大小 |
| 多服务重复写相同Cookie | 多个Set-Cookie头 | `curl -I` 查看响应头 |
| 第三方SDK注入 | 第三方Cookie累积 | 浏览器开发者工具 |
| 历史遗留Cookie未清理 | 过期Cookie仍存在 | Chrome DevTools → Application |

```bash
# 检查 Cookie 总大小
curl -s -H "Cookie: $(cat /tmp/cookies.txt)" https://example.com -o /dev/null -w "Cookie size: %{size_request} bytes\n"
```

## 修复方案

### 方案一：增大 Buffer（治标）

```nginx
# /etc/nginx/nginx.conf 或对应 vhost 配置
http {
    # 增大请求头 buffer
    large_client_header_buffers 4 32k;  # 默认 4 8k → 改为 4 32k
    client_header_buffer_size 8k;       # 增大普通 header buffer
    # 清理过大的 cookie
    proxy_set_header Cookie $http_cookie;
}

# 验证配置
nginx -t
systemctl reload nginx
```

### 方案二：Cookie 清理（治本）

```bash
#!/bin/bash
# cleanup-cookies.sh - 清理冗余 Cookie

# 找出 Set-Cookie 过多的域名
for domain in api.example.com web.example.com; do
    cookie_count=$(curl -sI https://$domain -o /dev/null -D - | grep -i "set-cookie" | wc -l)
    echo "$domain: $cookie_count cookies"
    if [ $cookie_count -gt 5 ]; then
        echo "⚠️ $domain Cookie 过多，需要优化"
    fi
done

# 保留必要 Cookie，清理历史遗留
KEEP_COOKIES="session_id,user_token,csrf_token"
# 实现：覆盖写入必要的 Cookie，删除其他
```

### 方案三：Nginx 缓存 Cookie（推荐生产使用）

```nginx
http {
    # 将大 Cookie 存储在变量，不阻塞 header buffer
    cookie_cache $cookie_session_id;
    
    # 配置 proxy_cache
    proxy_cache_path /tmp/nginx_cache levels=1:2 keys_zone=cookie_cache:10m;
    
    # 对 Cookie 较大的请求启用缓存
    server {
        location /api/ {
            # Cookie 不影响 header buffer
            proxy_buffering on;
            proxy_buffer_size 16k;
            proxy_buffers 4 16k;
        }
    }
}
```

## 灰度验证

### 步骤1：小范围验证
```bash
# 1. 备份配置
cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak.$(date +%Y%m%d)

# 2. 修改配置
sed -i 's/large_client_header_buffers.*/large_client_header_buffers 4 32k;/' /etc/nginx/nginx.conf

# 3. 测试配置
nginx -t

# 4. 热加载（不断连接）
nginx -s reload

# 5. 验证生效
curl -H "Cookie: session_id=large_test_value_xxx" https://your-domain.com -o /dev/null -w "%{http_code}\n"
# 期望输出: 200（不再是414）
```

### 步骤2：监控验证
```bash
# 验证 414 错误率下降
# 方法1: 实时监控
watch -n 5 'grep "414" /var/log/nginx/access.log | wc -l'

# 方法2: 增量对比
BEFORE=$(grep "414" /var/log/nginx/access.log.1 | wc -l)
AFTER=$(grep "414" /var/log/nginx/access.log | wc -l)
echo "Before: $BEFORE, After: $AFTER"
```

### 步骤3：全量上线
```bash
# 确认灰度验证无异常后，全量生效
nginx -s reload

# 持续监控 48 小时
for i in {1..288}; do
    count=$(grep "414" /var/log/nginx/access.log | wc -l)
    echo "$(date): 414 count = $count"
    sleep 600  # 10分钟检查一次
done
```

## 监控告警

### Prometheus 告警规则

```yaml
groups:
- name: nginx-414-alerts
  rules:
  - alert: Nginx414ErrorRate
    expr: |
      sum(rate(nginx_http_requests_total{status="414"}[5m]))
      / sum(rate(nginx_http_requests_total[5m])) > 0.001
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "Nginx 414 错误率超过 0.1%"
      description: "域名 {{ $labels.server_name }} 的 414 错误率过高，当前为 {{ $value | humanizePercentage }}"
      
  - alert: Nginx414Critical
    expr: |
      sum(rate(nginx_http_requests_total{status="414"}[5m]))
      / sum(rate(nginx_http_requests_total[5m])) > 0.01
    for: 5m
    labels:
      severity: critical
    annotations:
      summary: "Nginx 414 错误率超过 1%，紧急处理！"
      
  - alert: HighCookieSize
    expr: nginx_proxy_cookie_size_bytes > 8192
    for: 10m
    labels:
      severity: warning
    annotations:
      summary: "Cookie 大小超过 8KB，请检查 Cookie 膨胀问题"
```

### 日志分析查询

```sql
-- 查看 414 错误 TOP URL
SELECT 
    url,
    count(*) as error_count,
    avg(cookie_size) as avg_cookie_size
FROM (
    SELECT 
        CONCAT(request_uri, '?', query_string) as url,
        length(cookie) as cookie_size
    FROM nginx_access_log
    WHERE status = 414
) t
GROUP BY url
ORDER BY error_count DESC
LIMIT 10;
```

## 预防策略

### 1. Cookie 大小治理
```nginx
# 在响应中限制 Cookie 大小
add_header Set-Cookie "session=xxx; Path=/; Max-Age=86400; SameSite=Lax" always;
# 避免多个 Set-Cookie 头
```

### 2. 请求头大小限制
```nginx
server {
    # 限制请求 URI 长度
    large_client_header_buffers 4 32k;
    
    # 限制整体请求大小
    client_max_body_size 10m;
}
```

### 3. 定期巡检
```bash
#!/bin/bash
# weekly-cookie-audit.sh - 每周巡检

LOG_FILE="/var/log/cookie-audit.log"
echo "=== Cookie 巡检 $(date) ===" >> $LOG_FILE

# 检查 414 错误
414_count=$(grep "414" /var/log/nginx/access.log | wc -l)
echo "414错误数: $414_count" >> $LOG_FILE

# 检查 Cookie 大小分布
awk -F'"' '/Set-Cookie/ {print length($6)}' /var/log/nginx/access.log | \
    awk '{sum+=$1; if($1>max) max=$1} END {print "平均Cookie:", sum/NR, "最大:", max}' >> $LOG_FILE

# 发送报告
if [ $414_count -gt 100 ]; then
    curl -X POST "https://notify.example.com/alert" \
        -d "{\"severity\":\"warning\",\"msg\":\"本周414错误 $414_count 次，请检查\"}"
fi
```

## 常见问题 FAQ

### Q1: 增大 buffer 后仍报 414
**检查点**：
1. `nginx -T` 确认配置已生效
2. `large_client_header_buffers` 是否被 server 级别覆盖
3. 是否有多层 Nginx 代理（需在各层都配置）

### Q2: 如何定位是哪个 Cookie 过大？
```bash
# 方法1: 查看请求日志
grep "414" /var/log/nginx/access.log | \
    awk '{for(i=1;i<=NF;i++) if($i ~ /cookie/) print $i}' | \
    sort | uniq -c | sort -rn

# 方法2: 使用 tcpdump 抓包
tcpdump -i eth0 -A -s0 'tcp port 80 and (tcp[((tcp[12:1] & 0xf0) >> 2):2] = 0x474554 or tcp[((tcp[12:1] & 0xf0) >> 2):2] = 0x504f5354)' | grep -i cookie
```

### Q3: Cookie 大小有限制吗？
**浏览器限制**：每个 Cookie 最大 4KB，所有 Cookie 总大小约 20KB
**Nginx 默认**：8KB（4×8k buffer）
**推荐**：单个 Cookie < 2KB，总 Cookie < 8KB

### Q4: 414 和 400 有何区别？
| 错误码 | 含义 | 原因 |
|--------|------|------|
| 414 | URI Too Long | 请求行（URI+Query）过长 |
| 400 | Bad Request | 请求头或请求体格式错误 |
| 431 | Request Header Too Large | 仅请求头过大 |

### Q5: 如何区分 Cookie 导致还是 URI 导致？
```bash
# 测试1: 仅传短 Cookie
curl -b "test=1" https://domain.com/long-uri -o /dev/null -w "%{http_code}\n"

# 测试2: 传长 Cookie + 短 URI
curl -b "session=$(python3 -c 'print("x"*10000)')" https://domain.com/ -o /dev/null -w "%{http_code}\n"

# 判断：
# 测试1失败 → URI过长
# 测试2失败 → Cookie过长
```

## 效果验证

### 修复前后对比

| 指标 | 修复前 | 修复后 |
|------|--------|--------|
| 414 错误率 | 3% | 0% |
| large_client_header_buffers | 4 8k | 4 32k |
| 平均请求头大小 | 12KB | 12KB（不再报错）|
| P99 响应时间 | 2000ms | 150ms |

### 验证脚本

```bash
#!/bin/bash
# verify-fix.sh - 验证修复效果

echo "=== Nginx 请求头修复验证 ==="

# 1. 检查配置
echo -n "配置生效: "
nginx -T 2>&1 | grep -q "large_client_header_buffers 4 32k" && echo "✅" || echo "❌"

# 2. 功能测试
echo -n "大Cookie测试: "
result=$(curl -b "session=$(openssl rand -base64 20000 | tr -d '\n')" \
    https://your-domain.com/ -o /dev/null -w "%{http_code}" -s)
[ "$result" = "200" ] && echo "✅ 200" || echo "❌ $result"

# 3. 监控 414 计数
echo -n "414错误监控: "
count=$(grep "414" /var/log/nginx/access.log | tail -100 | wc -l)
echo "近100条请求中 $count 个 414"

echo "=== 验证完成 ==="
```
