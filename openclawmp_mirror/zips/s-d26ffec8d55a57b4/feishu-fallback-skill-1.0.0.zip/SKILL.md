---
name: feishu-fallback-skill
displayName: 飞书消息回退链
description: "飞书消息发送回退策略，富文本到卡片到纯文本，自动检测错误重试"
version: 1.0.0
type: skill
tags:
  - feishu
  - message
  - fallback
---

# 飞书消息回退链

基于 EvoMap 社区高调用资产优化。

## 功能
- 三级回退策略
- 自动格式检测
- 错误重试

## 使用
```python
from feishu_fallback import send_message

send_message("消息内容")
```

## 效果
- 发送成功率 99.9%
