#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
会话事实提取脚本（Mem0 启发）
从对话历史中提取离散事实，用于记忆系统

完全本地化，不依赖 Mem0 官方 API
"""

import json
import os
import sys
import requests
from datetime import datetime

# 编码设置
sys.stdout.reconfigure(encoding='utf-8')

# 从环境变量读取 API Key
DASHSCOPE_API_KEY = os.environ.get('DASHSCOPE_API_KEY')
if not DASHSCOPE_API_KEY:
    print("❌ 错误：请设置环境变量 DASHSCOPE_API_KEY", file=sys.stderr)
    sys.exit(1)

# 硅基流动 API 配置
SILICONFLOW_API_URL = "https://api.siliconflow.cn/v1/chat/completions"
EMBEDDING_API_URL = "https://api.siliconflow.cn/v1/embeddings"
EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-8B"
LLM_MODEL = "Qwen/Qwen2.5-72B-Instruct"  # 硅基流动免费模型

def get_headers():
    """获取请求头"""
    return {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json"
    }

def extract_facts(session_history: str) -> list:
    """
    使用 LLM 从会话历史中提取事实
    
    ⚠️ 禁止使用模拟模式 - 必须真实调用 API
    """
    prompt = f"""你是一个专业的记忆提取助手。请从以下对话中提取值得记忆的陈述性事实。

**提取范围**：
1. **用户偏好**：如"喜欢科幻电影"、"咖啡依赖者"
2. **重要决策**：如"决定使用硅基流动向量 API"
3. **明确规则**：如"禁止使用🦞emoji"、"必须使用机器人推送"
4. **配置变更**：如"Heartbeat 状态追踪机制设计完成"
5. **实体关系**：如"约翰是用户的朋友"、"约翰有一只狗叫汤米"

**输出要求**：
- 每条事实必须是陈述句，简洁明了
- 置信度 0.0-1.0，表示你对该事实的把握
- 类别必须是：偏好、决策、规则、配置、关系 之一
- 如果对话中没有值得记忆的事实，返回空数组 []

**输出格式**（严格的 JSON 数组）：
```json
[
  {{
    "content": "用户喜欢科幻电影，尤其是《星际穿越》",
    "category": "偏好",
    "confidence": 0.95,
    "source_messages": ["msg_001", "msg_002"],
    "timestamp": "2026-03-16T11:00:00+08:00"
  }}
]
```

**对话历史**：
{session_history[:15000]}
"""
    
    payload = {
        "model": LLM_MODEL,
        "messages": [
            {
                "role": "system",
                "content": "你是一个专业的记忆提取助手。输出必须是严格的 JSON 格式。"
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 2000
    }
    
    try:
        # 脱敏显示 API Key
        masked_key = f"{DASHSCOPE_API_KEY[:8]}...{DASHSCOPE_API_KEY[-6:]}" if len(DASHSCOPE_API_KEY) > 14 else "[REDACTED]"
        print(f"🔑 使用 API Key: {masked_key}")
        print(f"🌐 调用硅基流动 API: {SILICONFLOW_API_URL}")
        print(f"🤖 使用模型：{LLM_MODEL}")
        
        response = requests.post(
            SILICONFLOW_API_URL,
            headers=get_headers(),
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        
        result = response.json()
        content = result['choices'][0]['message']['content']
        
        # 解析 JSON（处理可能的 markdown 代码块）
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        
        facts = json.loads(content)
        
        # 验证格式
        validated_facts = []
        for fact in facts:
            if all(key in fact for key in ['content', 'category', 'confidence']):
                fact['timestamp'] = datetime.now().astimezone().isoformat()
                validated_facts.append(fact)
        
        return validated_facts
        
    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP 错误：{e}", file=sys.stderr)
        print(f"   状态码：{e.response.status_code}", file=sys.stderr)
        print(f"   响应内容：{e.response.text[:500]}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"❌ 提取失败：{e}", file=sys.stderr)
        return []

def main():
    """主函数"""
    print("=" * 60)
    print("📍 会话事实提取（Mem0 启发·完全本地化）")
    print("=" * 60)
    print(f"时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    # 读取会话历史
    if len(sys.argv) < 2:
        print("用法：python extract_session_facts.py <session_file>", file=sys.stderr)
        print("示例：python extract_session_facts.py memory/2026-03-16.md", file=sys.stderr)
        sys.exit(1)
    
    session_file = sys.argv[1]
    
    if not os.path.exists(session_file):
        print(f"❌ 文件不存在：{session_file}", file=sys.stderr)
        sys.exit(1)
    
    print(f"📖 读取会话：{session_file}")
    with open(session_file, 'r', encoding='utf-8') as f:
        session_history = f.read()
    
    print(f"📊 会话长度：{len(session_history)} 字符")
    print()
    
    # 提取事实
    print("🔍 正在提取事实...")
    facts = extract_facts(session_history)
    
    if not facts:
        print("✅ 未发现值得记忆的事实")
        return
    
    print(f"✅ 提取到 {len(facts)} 条事实")
    print()
    
    # 按类别分组统计
    categories = {}
    for fact in facts:
        cat = fact.get('category', '未知')
        categories[cat] = categories.get(cat, 0) + 1
    
    print("📊 事实分类统计：")
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        print(f"  {cat}: {count} 条")
    print()
    
    # 输出事实列表（JSON 格式，便于其他脚本读取）
    print("📝 事实列表：")
    print(json.dumps(facts, ensure_ascii=False, indent=2))
    print()
    
    # 保存到临时文件（供决策脚本使用）
    output_file = session_file.replace('.md', '_facts.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(facts, f, ensure_ascii=False, indent=2)
    
    print(f"💾 事实已保存：{output_file}")
    print()
    
    # 显示人类可读版本
    print("=" * 60)
    print("📋 人类可读版本")
    print("=" * 60)
    for i, fact in enumerate(facts, 1):
        print(f"{i}. [{fact['category']}] {fact['content']} (置信度：{fact['confidence']:.0%})")
    
    print()
    print("=" * 60)
    print("✅ 提取完成")
    print("=" * 60)

if __name__ == '__main__':
    main()
