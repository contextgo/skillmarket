#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆更新决策脚本（Mem0 启发）
决策：ADD / UPDATE / DELETE / NOOP

完全本地化，不依赖 Mem0 官方 API
"""

import json
import os
import sys
import requests
from datetime import datetime

# 编码设置
sys.stdout.reconfigure(encoding='utf-8')

# 从环境变量读取 API Key
DASHSCOPE_API_KEY = os.environ.get('DASHSCOPE_API_KEY')
if not DASHSCOPE_API_KEY:
    print("❌ 错误：请设置环境变量 DASHSCOPE_API_KEY", file=sys.stderr)
    sys.exit(1)

# 硅基流动 API 配置
SILICONFLOW_API_URL = "https://api.siliconflow.cn/v1/chat/completions"
EMBEDDING_API_URL = "https://api.siliconflow.cn/v1/embeddings"
LLM_MODEL = "bailian/qwen3.5-plus"
EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-8B"

def get_headers():
    """获取请求头"""
    return {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json"
    }

def get_embedding(text: str) -> list:
    """
    获取文本的向量嵌入
    
    Args:
        text: 输入文本
    
    Returns:
        向量嵌入（list of floats）
    """
    payload = {
        "model": EMBEDDING_MODEL,
        "input": text,
        "encoding_format": "float"
    }
    
    try:
        response = requests.post(
            EMBEDDING_API_URL,
            headers=get_headers(),
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        
        result = response.json()
        return result['data'][0]['embedding']
        
    except Exception as e:
        print(f"❌ 向量化失败：{e}", file=sys.stderr)
        return []

def cosine_similarity(vec1: list, vec2: list) -> float:
    """
    计算余弦相似度
    
    Args:
        vec1: 向量 1
        vec2: 向量 2
    
    Returns:
        相似度（0.0-1.0）
    """
    if not vec1 or not vec2:
        return 0.0
    
    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    norm1 = sum(a * a for a in vec1) ** 0.5
    norm2 = sum(b * b for b in vec2) ** 0.5
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return dot_product / (norm1 * norm2)

def search_similar_memories(new_fact: str, existing_memories: list, limit: int = 5) -> list:
    """
    向量搜索相似记忆
    
    Args:
        new_fact: 新事实
        existing_memories: 现有记忆列表（每条记忆是字典，包含 'content' 和 'embedding'）
        limit: 返回数量
    
    Returns:
        相似记忆列表（top N）
    """
    # 获取新事实的向量
    new_embedding = get_embedding(new_fact)
    if not new_embedding:
        return []
    
    # 计算相似度
    similarities = []
    for memory in existing_memories:
        if 'embedding' not in memory:
            # 如果没有预计算的向量，现场计算
            memory['embedding'] = get_embedding(memory.get('content', ''))
        
        sim = cosine_similarity(new_embedding, memory['embedding'])
        similarities.append({
            **memory,
            'similarity': sim
        })
    
    # 排序并返回 top N
    similarities.sort(key=lambda x: -x['similarity'])
    return similarities[:limit]

def decide_update(new_fact: dict, similar_memories: list) -> dict:
    """
    决策新事实的处理方式
    
    Args:
        new_fact: 新事实（已提取）
        similar_memories: 相似记忆（top 5，向量搜索得到）
    
    Returns:
        决策结果：
        {
            "decision": "ADD|UPDATE|DELETE|NOOP",
            "reason": "决策理由",
            "target_memory": "目标记忆 ID（如 UPDATE）",
            "confidence": 0.0-1.0
        }
    """
    # 特殊情况：没有相似记忆 → 直接 ADD
    if not similar_memories:
        return {
            "decision": "ADD",
            "reason": "没有相似记忆，是新事实",
            "target_memory": None,
            "confidence": 0.95
        }
    
    # 最高相似度
    max_similarity = max(m.get('similarity', 0) for m in similar_memories)
    
    # 规则：相似度 > 0.9 → NOOP（已存在）
    if max_similarity > 0.9:
        return {
            "decision": "NOOP",
            "reason": f"事实已存在（相似度：{max_similarity:.1%}）",
            "target_memory": None,
            "confidence": 0.9
        }
    
    # 规则：相似度 0.7-0.9 → UPDATE（更新旧记忆）
    if max_similarity > 0.7:
        most_similar = max(similar_memories, key=lambda x: x.get('similarity', 0))
        return {
            "decision": "UPDATE",
            "reason": f"事实更新了旧记忆（相似度：{most_similar['similarity']:.1%}）",
            "target_memory": most_similar.get('id'),
            "confidence": 0.85
        }
    
    # 规则：相似度 < 0.7 → LLM 决策（可能是 ADD 或 DELETE）
    prompt = f"""你是一个记忆管理助手。请决策新事实的处理方式。

**新事实**：
内容：{new_fact['content']}
类别：{new_fact.get('category', '未知')}
置信度：{new_fact.get('confidence', 0.0):.0%}

**相似记忆**（向量搜索 top 5）：
{json.dumps([
    {
        'content': m.get('content', ''),
        'similarity': m.get('similarity', 0),
        'category': m.get('category', '')
    }
    for m in similar_memories
], ensure_ascii=False, indent=2)}

**决策规则**：
- **ADD**: 新事实，与现有记忆无冲突，需要添加
- **UPDATE**: 新事实更新了旧记忆（如偏好变化、规则更新）
- **DELETE**: 新事实与旧记忆矛盾，需要删除旧记忆
- **NOOP**: 事实已存在，无需操作

**输出格式**（严格的 JSON 对象）：
```json
{{
  "decision": "ADD",
  "reason": "新事实，与现有记忆无冲突",
  "target_memory": null,
  "confidence": 0.95
}}
```
"""
    
    payload = {
        "model": LLM_MODEL,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 500
    }
    
    try:
        response = requests.post(
            SILICONFLOW_API_URL,
            headers=get_headers(),
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        
        result = response.json()
        content = result['choices'][0]['message']['content']
        
        # 解析 JSON（处理可能的 markdown 代码块）
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        
        decision = json.loads(content)
        
        # 验证格式
        if all(key in decision for key in ['decision', 'reason']):
            return decision
        else:
            # 默认决策
            return {
                "decision": "ADD",
                "reason": "LLM 决策失败，默认添加",
                "target_memory": None,
                "confidence": 0.5
            }
        
    except Exception as e:
        print(f"❌ LLM 决策失败：{e}", file=sys.stderr)
        # 默认决策
        return {
            "decision": "ADD",
            "reason": f"LLM 决策失败：{e}，默认添加",
            "target_memory": None,
            "confidence": 0.5
        }

def load_existing_memories(memory_file: str) -> list:
    """
    加载现有记忆
    
    Args:
        memory_file: 记忆文件路径（Markdown 或 JSON）
    
    Returns:
        记忆列表
    """
    if not os.path.exists(memory_file):
        return []
    
    # 尝试加载 JSON 缓存
    json_cache = memory_file.replace('.md', '.json')
    if os.path.exists(json_cache):
        with open(json_cache, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    # TODO: 解析 Markdown 文件，提取记忆
    # 简化版本：返回空列表
    return []

def main():
    """主函数"""
    print("=" * 60)
    print("📍 记忆更新决策（Mem0 启发·完全本地化）")
    print("=" * 60)
    print(f"时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    # 读取参数
    if len(sys.argv) < 3:
        print("用法：python memory_decision.py <fact_file> <memory_file>", file=sys.stderr)
        print("示例：python memory_decision.py facts.json memory/people/南宫明.md", file=sys.stderr)
        sys.exit(1)
    
    fact_file = sys.argv[1]
    memory_file = sys.argv[2]
    
    # 读取新事实
    if not os.path.exists(fact_file):
        print(f"❌ 文件不存在：{fact_file}", file=sys.stderr)
        sys.exit(1)
    
    print(f"📖 读取事实：{fact_file}")
    with open(fact_file, 'r', encoding='utf-8') as f:
        facts = json.load(f)
    
    # 加载现有记忆
    print(f"📖 读取记忆：{memory_file}")
    existing_memories = load_existing_memories(memory_file)
    print(f"📊 现有记忆：{len(existing_memories)} 条")
    print()
    
    # 对每个事实进行决策
    decisions = []
    for fact in facts:
        print(f"🔍 决策事实：{fact['content'][:50]}...")
        
        # 向量搜索相似记忆
        similar = search_similar_memories(
            fact['content'],
            existing_memories,
            limit=5
        )
        
        # LLM 决策
        decision = decide_update(fact, similar)
        decision['fact'] = fact
        
        decisions.append(decision)
        
        # 显示决策结果
        print(f"  📋 决策：{decision['decision']}")
        print(f"  💡 理由：{decision['reason']}")
        print(f"  🎯 置信度：{decision['confidence']:.0%}")
        print()
    
    # 统计决策分布
    decision_counts = {}
    for d in decisions:
        dec = d['decision']
        decision_counts[dec] = decision_counts.get(dec, 0) + 1
    
    print("📊 决策统计：")
    for dec, count in sorted(decision_counts.items()):
        print(f"  {dec}: {count} 条")
    print()
    
    # 保存决策结果
    output_file = fact_file.replace('_facts.json', '_decisions.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(decisions, f, ensure_ascii=False, indent=2)
    
    print(f"💾 决策已保存：{output_file}")
    print()
    
    # 显示人类可读版本
    print("=" * 60)
    print("📋 决策汇总")
    print("=" * 60)
    for i, d in enumerate(decisions, 1):
        print(f"{i}. [{d['decision']}] {d['fact']['content'][:50]}...")
        print(f"   理由：{d['reason']}")
        print()
    
    print("=" * 60)
    print("✅ 决策完成")
    print("=" * 60)

if __name__ == '__main__':
    main()
