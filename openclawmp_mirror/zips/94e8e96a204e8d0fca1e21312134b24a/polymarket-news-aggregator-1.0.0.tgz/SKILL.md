---
name: polymarket-news-aggregator
description: "Hourly automated news aggregation and signal detection for Polymarket prediction markets"
version: 1.0.0
tags:
  - polymarket
  - news
  - prediction-market
  - automation
  - trading
---

# Polymarket News Aggregator

Automatically aggregates news from 6+ sources every hour, scores signals against active Polymarket markets, and generates actionable trading recommendations.

## When to Use

- User asks about Polymarket market analysis
- User wants to monitor specific prediction markets
- User needs automated news-to-signal processing

## How It Works

### 1. News Aggregation

Aggregate from these sources using their RSS feeds or APIs:
- CoinDesk (crypto price/macro news)
- CoinTelegraph (market analysis)
- Decrypt (regulatory/institutional news)
- CryptoSlate (on-chain metrics)
- The Block (breaking news)
- Reuters/Bloomberg (geopolitical/macro)

### 2. Signal Scoring

For each news article, score relevance against active markets:

```
Signal Score = Keyword Match (0-30) + Context Relevance (0-30) + Source Authority (0-20) + Recency (0-20)
```

**Keyword categories:**
- Price targets: "$100k", "$5000", "$90", specific price mentions
- Events: "sanctions", "rate cut", "regulation", "ban", "approve"
- Entities: "SEC", "Fed", "OPEC", "Iran", specific company/government names
- Market-specific: Market question keywords extracted from Polymarket slug

### 3. Confidence Thresholds

| Score | Confidence | Action |
|-------|-----------|--------|
| 60+ | High | Alert immediately, recommend position |
| 40-59 | Medium | Log and monitor for 2+ consecutive rounds |
| 20-39 | Low | Track only, no action |

### 4. Output Format

Generate a structured report:
```
📊 Polymarket Signal Report [timestamp]
━━━━━━━━━━━━━━━━━━━━━━━━━━
📰 News Sources: X/6 successful
📰 Articles Processed: XXX
🎯 High-Confidence Matches: XX

🏆 Top Signals:
1. [Market Name] - XX.X% confidence
   - Signal: [brief description]
   - Sources: [count] articles
   - Trend: ↑/↓/→ (vs previous round)
```

## Configuration

- Cron schedule: Every hour
- Minimum sources required: 4/6 for report validity
- Rate limiting: 2-second delay between source requests
- Error handling: Skip failed sources, continue with available
- State persistence: Save results to workspace/pending_publish/
