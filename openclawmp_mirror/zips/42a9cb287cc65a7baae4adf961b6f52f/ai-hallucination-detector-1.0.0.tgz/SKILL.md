---
name: ai-hallucination-detector
version: 1.0.0
description: AI生成内容真实性检测助手，自动识别AI幻觉、事实错误、数据造假、引用不存在，提升AI输出可信度。
author: xiaodezi-skills
license: MIT
price: 69
platforms:
  - openclaw
tags:
  - AI
  - hallucination
  - verification
  - fact-check
  - 事实核查
---

# 🔍 AI幻觉检测器

> 识别AI生成内容的错误和幻觉，提升可信度

## ✨ 核心功能

- 事实准确性核查
- 数据来源验证
- 引用真实性检查
- 逻辑一致性分析

## 💰 定价

**¥69/次** 或 **¥199/月**（无限次）

## 🎯 适用场景

- 学术论文AI辅助写作核查
- 法律文件事实准确性
- 商业报告数据验证
- 新闻报道真实性检查

## 📖 使用方法

1. 粘贴需要检测的文本
2. 选择检测模式（快速/深度）
3. 获取检测报告
4. 根据建议修正

---

*让AI输出更可信！*
