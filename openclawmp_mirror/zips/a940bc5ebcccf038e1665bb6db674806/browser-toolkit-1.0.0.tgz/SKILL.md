---
name: browser-toolkit
display-name: 浏览器工具箱
description: 综合浏览器操作方案：支持 OpenClaw 内置 browser 工具（自动化操控）和系统浏览器直接打开（Edge优先）。包含网页读取、点击输入、截图、PDF导出，以及快速在本地 Edge/Chrome 中打开链接。
version: 1.0.0
author: 君宝
tags: browser, automation, chrome, edge, web, scraping, screenshot, system-browser
---

# 浏览器工具箱

综合浏览器操作方案，支持两种模式：
1. **OpenClaw browser 工具** - 自动化操控隔离浏览器或 Chrome 扩展
2. **系统浏览器直接打开** - 快速在本地 Edge/Chrome 中打开链接（Edge 优先）

---

# 🌐 模式一：OpenClaw Browser 工具（自动化）

使用 OpenClaw 的 `browser` 工具操控真实浏览器，像人一样浏览网页。

## 两种子模式

| 模式 | 说明 | 适用场景 |
|------|------|----------|
| `openclaw` | Agent 专属隔离浏览器，不碰个人 Chrome | 日常爬取、截图、安全操作 |
| `chrome` | Chrome 扩展接管真实标签页，可用已有登录态 | 需要登录态的操作（X、后台等） |

## 核心操作

### 打开页面
```
browser(action=open, targetUrl="https://example.com")
```

### 读取页面内容
```
browser(action=snapshot)
```

### 点击元素
```
browser(action=act, request={kind: "click", ref: "e12"})
```

### 输入文字
```
browser(action=act, request={kind: "type", ref: "e15", text: "内容", submit: true})
```

### 截图
```
browser(action=screenshot)                    # 可视区域
browser(action=screenshot, fullPage=true)     # 全页面
```

### 导出 PDF
```
browser(action=pdf)
```

---

# 🖥️ 模式二：系统浏览器直接打开（Edge优先）

快速在本地浏览器打开网页，无需自动化。

## 使用方法

```powershell
# Edge 优先
& "scripts/open-in-system-browser.ps1" -Url "https://example.com" -Browser "edge"

# Chrome
& "scripts/open-in-system-browser.ps1" -Url "https://example.com" -Browser "chrome"

# 默认浏览器
& "scripts/open-in-system-browser.ps1" -Url "https://example.com" -Browser "default"
```

---

# 最佳实践

- **需要自动化** → 用 OpenClaw Browser 工具
- **快速打开网页** → 用系统浏览器（Edge 优先）
- **需要登录态** → 用 chrome 模式
- **安全操作** → 用 openclaw 隔离模式

---

# 安全提醒

- chrome 模式会暴露登录态，谨慎使用
- 敏感操作（转账、发布等）建议人工确认
