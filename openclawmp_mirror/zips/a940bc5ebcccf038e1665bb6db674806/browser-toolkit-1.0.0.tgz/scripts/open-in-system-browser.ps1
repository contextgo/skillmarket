# 在系统浏览器中打开 URL (Edge优先)
param(
    [Parameter(Mandatory=$true)]
    [string]$Url,
    
    [string]$Browser = "edge"  # edge, chrome, default
)

# 验证 URL
if (-not ($Url -match '^https?://')) {
    Write-Error "无效的 URL。必须以 http:// 或 https:// 开头"
    exit 1
}

function Get-EdgePath {
    $paths = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
    )
    foreach ($path in $paths) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Get-ChromePath {
    $paths = @(
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($path in $paths) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

try {
    switch ($Browser.ToLower()) {
        "edge" {
            $edgePath = Get-EdgePath
            if ($edgePath) {
                Start-Process $edgePath -ArgumentList $Url
                Write-Output "已在 Edge 中打开: $Url"
            } else {
                Start-Process $Url
                Write-Output "已在默认浏览器中打开: $Url"
            }
        }
        "chrome" {
            $chromePath = Get-ChromePath
            if ($chromePath) {
                Start-Process $chromePath -ArgumentList $Url
                Write-Output "已在 Chrome 中打开: $Url"
            } else {
                Start-Process $Url
                Write-Output "已在默认浏览器中打开: $Url"
            }
        }
        default {
            Start-Process $Url
            Write-Output "已在默认浏览器中打开: $Url"
        }
    }
} catch {
    Write-Error "打开 URL 失败: $_"
    exit 1
}
