---
name: security-audit
description: 安全审计助手。用于制定安全审计清单、检查系统安全、生成安全报告。当需要进行安全审计、检查系统安全时触发。
---

# 安全审计助手

## 安全审计分类

| 类型 | 频率 | 范围 |
|------|------|------|
| 日常审计 | 每日 | 日志/告警 |
| 定期审计 | 每月/每季 | 全面检查 |
| 专项审计 | 按需 | 特定领域 |
| 渗透测试 | 每年 | 攻击测试 |

## 安全审计清单

### 账号安全
```markdown
## 账号审计
- [ ] 检查弱密码账号
- [ ] 检查冗余账号
- [ ] 检查权限分配
- [ ] 检查账号有效期
- [ ] 检查登录日志

检查标准：
| 项目 | 标准 | 检查方法 |
|------|------|----------|
| 密码复杂度 | 8位以上，含大小写字母、数字、特殊字符 | 抽查密码策略 |
| 账号清理 | 离职账号24小时内禁用 | 对比离职清单 |
| 权限最小化 | 按需分配权限 | 权限审计 |
| 管理员数量 | 不超过5人 | 账号统计 |
```

### 服务器安全
```markdown
## 服务器审计
- [ ] 检查系统更新
- [ ] 检查开放端口
- [ ] 检查防火墙规则
- [ ] 检查SSH配置
- [ ] 检查日志审计

检查命令：
# 查看开放端口
netstat -tlnp

# 检查防火墙规则
iptables -L -n

# 检查SSH配置
cat /etc/ssh/sshd_config

# 检查系统更新
yum check-update 或 apt-get upgrade
```

### 应用安全
```markdown
## 应用审计
- [ ] 检查敏感接口
- [ ] 检查认证机制
- [ ] 检查会话管理
- [ ] 检查输入校验
- [ ] 检查依赖漏洞

OWASP检查项：
1. SQL注入防护
2. XSS防护
3. CSRF防护
4. 敏感数据加密
5. 安全Headers
```

### 数据库安全
```markdown
## 数据库审计
- [ ] 检查数据库用户
- [ ] 检查权限分配
- [ ] 检查审计日志
- [ ] 检查敏感数据加密
- [ ] 检查备份加密

检查SQL：
-- 查看用户列表
SELECT user, host FROM mysql.user;

-- 查看权限
SHOW GRANTS FOR 'user'@'host';

-- 查看敏感数据
SELECT * FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'dbname' 
AND COLUMN_NAME LIKE '%password%';
```

## 安全审计报告模板

```markdown
# 安全审计报告

审计周期：YYYY-MM-DD 至 YYYY-MM-DD
审计类型：定期审计
审计范围：全系统
审计人：XXX
审计日期：YYYY-MM-DD

---

## 一、审计概况

| 项目 | 数量/状态 |
|------|------------|
| 审计系统 | XX个 |
| 发现问题 | XX个 |
| 高风险 | XX个 |
| 中风险 | XX个 |
| 低风险 | XX个 |

---

## 二、审计范围

### 2.1 审计对象
- 服务器：XX台
- 应用系统：XX个
- 数据库：XX个
- 网络设备：XX台

### 2.2 审计内容
- 账号与权限
- 系统配置
- 应用安全
- 数据安全
- 日志审计

---

## 三、问题汇总

### 3.1 高风险问题

| 序号 | 问题描述 | 系统 | 风险等级 | 建议 |
|------|----------|------|----------|------|
| 1 | xxx | xxx | 高 | xxx |
| 2 | xxx | xxx | 高 | xxx |

### 3.2 中风险问题

| 序号 | 问题描述 | 系统 | 风险等级 | 建议 |
|------|----------|------|----------|------|
| 1 | xxx | xxx | 中 | xxx |

### 3.3 低风险问题

| 序号 | 问题描述 | 系统 | 风险等级 | 建议 |
|------|----------|------|----------|------|
| 1 | xxx | xxx | 低 | xxx |

---

## 四、问题详情

### 问题1：xxx
**描述**：xxx

**现状**：xxx

**风险**：xxx

**建议**：xxx

**修复计划**：
- 修复时间：YYYY-MM-DD
- 修复人：@xxx

---

## 五、整改建议

### 5.1 立即整改（1周内）
1. xxx
2. xxx

### 5.2 短期整改（1个月内）
1. xxx

### 5.3 长期整改（3个月内）
1. xxx

---

## 六、下次审计计划
- 审计时间：YYYY-MM-DD
- 审计范围：xxx
```

## 安全检查命令

```bash
#!/bin/bash
# 服务器安全检查脚本

echo "=== 安全检查报告 ==="
echo "检查时间：$(date)"
echo ""

# 1. 检查系统用户
echo "【1. 用户检查】"
echo "特权用户："
awk -F: '$3==0 {print}' /etc/passwd
echo ""

# 2. 检查密码策略
echo "【2. 密码策略检查】"
grep "^PASS_MIN_LEN" /etc/login.defs
echo ""

# 3. 检查开放端口
echo "【3. 端口检查】"
netstat -tlnp | grep LISTEN
echo ""

# 4. 检查防火墙
echo "【4. 防火墙检查】"
if command -v iptables &> /dev/null; then
    iptables -L -n | head -20
else
    echo "防火墙未启用或未安装"
fi
echo ""

# 5. 检查SSH配置
echo "【5. SSH安全检查】"
echo "禁止密码登录："
grep "^PasswordAuthentication" /etc/ssh/sshd_config
echo "禁止ROOT登录："
grep "^PermitRootLogin" /etc/ssh/sshd_config
echo ""

# 6. 检查日志配置
echo "【6. 日志审计检查】"
grep -E "^(auth|authpriv)\.\*" /etc/rsyslog.conf
echo ""

# 7. 检查最近登录
echo "【7. 异常登录检查】"
last -10
echo ""

echo "=== 检查完成 ==="
```

## 常用安全工具

| 工具 | 用途 |
|------|------|
| nmap | 端口扫描 |
| nessus | 漏洞扫描 |
| sqlmap | SQL注入检测 |
| Burp Suite | Web渗透测试 |
| Wireshark | 网络抓包 |
| AIDE | 文件完整性检测 |
