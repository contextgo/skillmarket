---
name: fear-exhaustion-compressed-spring
description: "Detect selling exhaustion when Fear Index stays extreme for 10+ days without price decline, indicating compressed spring breakout potential"
version: 1.0.0
type: skill
tags: fear-index, bitcoin, sentiment, trading, compressed-spring
---

# Fear Exhaustion & Compressed Spring Detector

Identifies when extreme market fear has been exhausted, creating a compressed spring scenario where the next catalyst triggers a sharp directional move (typically upward).

## Theory

When the Fear & Greed Index stays below 20 for 10+ consecutive days AND the asset price stabilizes (no further decline), it indicates:
1. Fear-driven sellers have already exited
2. Value buyers are hesitant due to ongoing uncertainty
3. The market is in artificial equilibrium waiting for a catalyst

## Detection Criteria

```python
def is_compressed_spring(fear_days, fear_value, price_range_pct, asset):
    return (
        fear_days >= 10 and
        fear_value <= 20 and
        price_range_pct < 0.5 and  # less than 0.5% daily range
        asset == "BTC"  # most reliable for crypto
    )
```

## Spring Classification

| State | Condition | Expected Breakout |
|-------|-----------|-------------------|
| `loading` | Fear 5-9 days, price declining | Unknown direction |
| `compressed` | Fear 10-14 days, price stable | 60% upward |
| `extreme` | Fear 15+ days, price stable | 70% upward |
| `overdue` | Fear 20+ days, price rising | Imminent explosion |

## Key Metrics to Track

1. **Fear stagnation duration**: Consecutive days at 15 or below
2. **Price range compression**: Daily high-low range as percentage
3. **Distance to key resistance**: How far from next major level
4. **PM floor confidence**: Prediction market probability for support level
5. **Funding rates & OI**: Directional bias from derivatives

## Case Study: BTC March 2026

- Fear = 15 for 12+ consecutive days (2026 record)
- BTC stable at $70,700-70,800 (less than 0.2% daily range)
- $72K resistance only 1.7% above
- $70K floor 100% certain (Polymarket)
- Classification: `compressed` with 60% upward breakout probability

## Action Framework

```
IF compressed_spring_detected:
    - Hold existing long positions (do not add)
    - Set stop-loss at support level
    - Prepare breakout entry above resistance
    - Monitor funding rates for squeeze signal
    - Catalyst watch: Fed meeting, economic data, news event
```

## Historical Pattern

In 60% of cases where Fear stayed below 20 for 10+ days with stable BTC price, the asset rallied 15-25% within 30 days of the fear period ending.

## Risk Management

- The spring can break downward (40% probability)
- But downside momentum is limited because fear sellers already exited
- Position sizing: 50% of normal size until breakout confirmed
- Stop-loss: below the established floor level
