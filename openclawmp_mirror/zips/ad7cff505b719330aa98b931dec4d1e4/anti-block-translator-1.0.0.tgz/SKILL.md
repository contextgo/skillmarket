---
name: anti-block-translator
description: 反拦截网页翻译器。使用 Playwright 注入 Google 翻译脚本，绕过 Cloudflare 等反爬机制，将英文网页翻译为中文并保留原样式截图
version: 1.0.0
type: skill
tags: translator, screenshot, playwright, cloudflare, bypass, web, google-translate
---

# 反拦截网页翻译器 (Anti-Block Translator)

使用 Playwright 注入 Google 翻译脚本，绕过 Cloudflare 等反爬机制，将英文网页翻译为中文并保留原样式截图。

## 核心能力

- ✅ **绕过 Cloudflare 拦截** — 直接访问原网页，不触发反爬
- ✅ **保留原网页样式** — 翻译后布局、图片、格式完全保留
- ✅ **全自动翻译** — 无需手动操作，注入脚本自动完成
- ✅ **高质量截图** — 支持全页截图或指定区域

## 适用场景

- 威胁情报报告 — 翻译国外安全媒体文章并截图存档
- 新闻监控 — 自动翻译并保存外文新闻页面
- 竞品分析 — 翻译国外产品页面保留样式参考
- 学术研究 — 翻译并保存外文资料页面

## 工作原理

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  访问原网页      │ ──▶ │  注入Google翻译   │ ──▶ │  改写DOM属性    │
│  (绕过Cloudflare)│     │  脚本            │     │  激活中文显示   │
└─────────────────┘     └──────────────────┘     └─────────────────┘
                                                          │
                                                          ▼
                                                   ┌─────────────────┐
                                                   │  截图保存       │
                                                   │  (保留原样式)   │
                                                   └─────────────────┘
```

**技术要点：**

1. **Playwright 绕过检测** — 使用真实浏览器内核，模拟人类访问行为
2. **DOM 注入翻译** — 在页面内直接执行 Google 翻译脚本，不走翻译 URL
3. **属性改写激活** — 修改 `lang` 属性和添加 `translated-ltr` class 触发中文 CSS
4. **清理干扰元素** — 移除翻译工具栏和 iframe，保持页面整洁

## 使用方法

### 基础用法 — 翻译并截图

```javascript
// 使用 browser 工具执行
const result = await browser.act({
  kind: 'evaluate',
  fn: `
    // 1. 访问原网页
    await page.goto('https://example.com/article', { waitUntil: 'networkidle' });
    
    // 2. 注入 Google 翻译脚本
    await page.evaluate(() => {
      const script = document.createElement('script');
      script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      document.head.appendChild(script);
      
      window.googleTranslateElementInit = function() {
        new google.translate.TranslateElement({
          pageLanguage: 'en',
          includedLanguages: 'zh-CN',
          autoDisplay: false
        }, 'google_translate_element');
      };
      
      const div = document.createElement('div');
      div.id = 'google_translate_element';
      div.style.display = 'none';
      document.body.appendChild(div);
    });
    
    // 3. 等待并触发翻译
    await new Promise(r => setTimeout(r, 4000));
    await page.evaluate(() => {
      const select = document.querySelector('.goog-te-combo');
      if (select) {
        select.value = 'zh-CN';
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
    
    // 4. 等待翻译完成
    await new Promise(r => setTimeout(r, 6000));
    
    // 5. 激活中文显示
    await page.evaluate(() => {
      document.documentElement.setAttribute('lang', 'zh-CN');
      document.documentElement.classList.add('translated-ltr');
      
      // 清理翻译工具栏
      const toolbar = document.querySelector('[role="toolbar"]');
      if (toolbar) toolbar.remove();
      
      document.querySelectorAll('iframe').forEach(el => {
        if (el.src && el.src.includes('translate')) el.remove();
      });
    });
    
    // 6. 截图
    await page.screenshot({ path: 'translated.png', fullPage: true });
    return '翻译截图完成: translated.png';
  `
});
```

### PowerShell 完整脚本

```powershell
# 保存为 translate-page.ps1
param(
    [Parameter(Mandatory=$true)]
    [string]$Url,
    
    [string]$OutputPath = "translated.png",
    [int]$ViewportWidth = 1920,
    [int]$ViewportHeight = 1080
)

$script = @"
const { chromium } = require('playwright');

(async () => {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
        viewport: { width: $ViewportWidth, height: $ViewportHeight }
    });
    
    try {
        // 1. 访问原网页（绕过 Cloudflare）
        console.log('访问: $Url');
        await page.goto('$Url', { waitUntil: 'networkidle', timeout: 60000 });
        
        // 2. 注入 Google 翻译脚本
        console.log('注入翻译脚本...');
        await page.evaluate(() => {
            const script = document.createElement('script');
            script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            document.head.appendChild(script);
            
            window.googleTranslateElementInit = function() {
                new google.translate.TranslateElement({
                    pageLanguage: 'en',
                    includedLanguages: 'zh-CN',
                    autoDisplay: false
                }, 'google_translate_element');
            };
            
            const div = document.createElement('div');
            div.id = 'google_translate_element';
            div.style.display = 'none';
            document.body.appendChild(div);
        });
        
        // 3. 等待脚本加载并触发翻译
        await new Promise(r => setTimeout(r, 4000));
        await page.evaluate(() => {
            const select = document.querySelector('.goog-te-combo');
            if (select) {
                select.value = 'zh-CN';
                select.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
        
        // 4. 等待翻译完成
        console.log('等待翻译完成...');
        await new Promise(r => setTimeout(r, 6000));
        
        // 5. 激活中文显示
        await page.evaluate(() => {
            const html = document.documentElement;
            html.setAttribute('lang', 'zh-CN');
            html.classList.add('translated-ltr');
            
            // 移除翻译工具栏
            const toolbar = document.querySelector('[role="toolbar"]');
            if (toolbar) toolbar.remove();
            
            // 移除翻译 iframe
            document.querySelectorAll('iframe').forEach(el => {
                if (el.src && el.src.includes('translate')) el.remove();
            });
            
            // 移除顶部横幅
            const banner = document.querySelector('.goog-te-banner-frame');
            if (banner) banner.remove();
        });
        
        // 6. 截图
        console.log('截图保存...');
        await page.screenshot({ path: '$OutputPath', fullPage: true });
        console.log('完成: $OutputPath');
        
    } catch (err) {
        console.error('错误:', err.message);
        process.exit(1);
    } finally {
        await browser.close();
    }
})();
"@

$script | node -
```

**使用：**
```powershell
.\translate-page.ps1 -Url "https://thehackernews.com/2024/03/article.html" -OutputPath "译文.png"
```

## 关键参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `waitUntil: 'networkidle'` | 等待网络空闲再执行 | 推荐 |
| `timeout: 60000` | 页面加载超时时间 | 60秒 |
| `sleep 4000` | 等待翻译脚本加载 | 4秒 |
| `sleep 6000` | 等待翻译完成 | 6秒 |
| `fullPage: true` | 截取完整页面 | 是 |

## 常见问题

### Q1: 翻译没生效？

**检查点：**
1. 网页是否完全加载（`networkidle`）
2. 翻译脚本是否成功注入（检查 `.goog-te-combo` 元素）
3. 等待时间是否足够（某些页面需要更长时间）

**调试方法：**
```javascript
// 添加调试输出
const hasSelect = await page.evaluate(() => !!document.querySelector('.goog-te-combo'));
console.log('翻译选择器存在:', hasSelect);
```

### Q2: 截图有翻译工具栏？

**确保清理代码执行：**
```javascript
// 移除所有可能的干扰元素
await page.evaluate(() => {
    document.querySelectorAll('[role="toolbar"], .goog-te-banner-frame, iframe[src*="translate"]').forEach(el => el.remove());
});
```

### Q3: 某些网站还是失败？

**可能原因：**
- 网站有更强的反爬机制（如 DataDome、PerimeterX）
- 页面是动态加载（SPA），需要额外等待
- 网站屏蔽了 Google 翻译脚本

**解决方案：**
- 增加随机延迟模拟人类行为
- 使用 stealth 插件隐藏 Playwright 特征
- 考虑使用其他翻译方案（如 DeepL API）

### Q4: 翻译质量不佳？

Google 翻译对技术文档的翻译可能不够专业。建议：
- 关键术语在报告中注明英文原文
- 对重要段落进行人工校对
- 使用专业术语表进行后处理

## 依赖要求

- **Node.js** >= 14
- **Playwright**: `npm install playwright`
- **Chromium**: `npx playwright install chromium`

## 与直接访问 Google 翻译 URL 对比

| 方案 | 优点 | 缺点 |
|------|------|------|
| **本方案（DOM注入）** | 绕过 Cloudflare、保留原样式、稳定可靠 | 需要 Playwright、执行时间稍长 |
| **Google翻译URL** | 简单直接 | 不稳定、样式丢失、易被拦截 |
| **手动截图** | 最可靠 | 完全手动、无法自动化 |

## 安全提示

- 本工具仅用于合法的信息收集和翻译需求
- 尊重网站的 robots.txt 和使用条款
- 不要用于大规模爬取或商业用途
- 注意数据隐私，敏感内容谨慎处理

## 更新日志

**v1.0.0** (2026-03-26)
- 初始版本，从威胁情报技能中提取
- 支持 Cloudflare 绕过和 Google 翻译注入
- 提供 PowerShell 完整脚本

## 致谢

本技能的核心方法源自威胁情报分析工作中的实践总结，感谢 OpenClaw 社区的反馈和优化建议。
