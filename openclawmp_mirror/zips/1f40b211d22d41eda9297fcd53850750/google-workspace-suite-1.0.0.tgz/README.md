# Google Workspace 全家桶

Google Workspace 全家桶集成技能包——让 AI Agent 全面接管你的 Google 办公生态。

## 描述

这是一套完整的 Google Workspace 集成操作指令，涵盖 Gmail 邮件收发、Calendar 日历管理、Drive 文件存储、Sheets 数据表格、Docs 文档编辑以及 Contacts 联系人管理。所有操作基于标准 CLI 工具（gcloud、gsutil）和 REST API（curl），无需安装额外依赖，Agent 即可通过系统命令直接调用。

## 它能做什么

- **Gmail 管理**：读取、搜索、发送邮件，下载附件，管理标签，设置过滤规则
- **Calendar 操作**：创建/更新/删除事件，查找空闲时间，设置循环会议，管理参会者
- **Drive 文件管理**：上传/下载/搜索文件，创建文件夹，管理共享权限，查询存储空间
- **Sheets 数据操作**：读写表格数据，批量更新，设置格式和图表，数据筛选排序
- **Docs 文档编辑**：创建文档，插入文本/表格/列表，设置样式，导出为多种格式
- **Contacts 联系人**：搜索/创建/更新联系人，管理联系人组
- **批量操作**：批量发送个性化邮件，批量创建日历事件，CSV 数据导入表格
- **跨服务联动**：实现邮件→表格→日历的自动化工作流

## 核心特性

- ✅ 完整的 OAuth2 认证流程与 Token 自动刷新机制
- ✅ 所有操作均为真实可执行的 curl/gcloud 命令
- ✅ 支持批量操作（批量邮件、批量事件、批量数据更新）
- ✅ 完善的错误处理与重试策略（指数退避）
- ✅ API 速率限制参考与最佳实践
- ✅ 安全凭证管理与最小权限 Scope 原则
- ✅ 支持中文内容处理（邮件主题、文档内容）

## 适用场景

| 场景 | 说明 |
|------|------|
| **邮件自动处理** | 自动搜索特定邮件，提取信息写入表格，发送回复 |
| **会议自动安排** | 根据项目时间线批量创建会议，自动查找空闲时段 |
| **报告自动生成** | 从 Sheets 读取数据，生成 Docs 文档或 PDF 报告 |
| **文件批量管理** | 按规则整理 Drive 文件，批量设置共享权限 |
| **数据采集与分析** | 从多个来源收集数据写入 Sheets，自动生成图表 |
| **团队协作** | 创建共享文件夹，批量邀请团队成员，同步日历 |
| **客户关系管理** | 维护联系人列表，发送跟进邮件，记录交互历史 |

## 配置要求

1. **Google Cloud 项目**：需要创建 Google Cloud 项目并启用相关 API
2. **OAuth2 凭证**：需要创建 OAuth 2.0 Client ID（Desktop App 类型）
3. **所需工具**：`curl`、`jq`、`base64`（系统通常已预装）
4. **可选工具**：`gcloud` CLI（推荐安装，简化认证流程）

## 快速开始

```bash
# 1. 安装 gcloud CLI
curl https://sdk.cloud.google.com | bash

# 2. 登录并创建项目
gcloud init
gcloud services enable gmail.googleapis.com calendar-json.googleapis.com drive.googleapis.com sheets.googleapis.com docs.googleapis.com people.googleapis.com

# 3. 创建 OAuth2 凭证，获取 CLIENT_ID、CLIENT_SECRET、REFRESH_TOKEN

# 4. 设置环境变量
export GOOGLE_CLIENT_ID="your_client_id"
export GOOGLE_CLIENT_SECRET="your_client_secret"
export GOOGLE_REFRESH_TOKEN="your_refresh_token"
export GOOGLE_TOKEN=$(curl -s -X POST https://oauth2.googleapis.com/token \
    -d "client_id=${GOOGLE_CLIENT_ID}" \
    -d "client_secret=${GOOGLE_CLIENT_SECRET}" \
    -d "refresh_token=${GOOGLE_REFRESH_TOKEN}" \
    -d "grant_type=refresh_token" | jq -r .access_token)

# 5. 开始使用
curl -s "https://www.googleapis.com/gmail/v1/users/me/messages?maxResults=5" \
    -H "Authorization: Bearer ${GOOGLE_TOKEN}" | jq .
```

## 作者

知白守黑1024
