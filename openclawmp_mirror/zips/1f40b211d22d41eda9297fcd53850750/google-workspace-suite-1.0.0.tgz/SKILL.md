---
name: google-workspace-suite
description: Google Workspace 全家桶集成技能包，涵盖 Gmail、Calendar、Drive、Sheets、Docs、Contacts 的完整操作指南，支持 OAuth2 认证、批量操作和错误处理。
---

# Google Workspace 全家桶集成技能

本技能提供一套完整的 Google Workspace 操作指令，使 Agent 能够通过 CLI 工具和 API 调用高效管理 Google 生态中的各项服务。所有操作基于标准 CLI（gcloud、gsutil）和 REST API（curl），无需安装额外依赖。

---

## 目录

1. [前置条件与 OAuth2 配置](#1-前置条件与-oauth2-配置)
2. [Gmail 操作](#2-gmail-操作)
3. [Google Calendar 操作](#3-google-calendar-操作)
4. [Google Drive 操作](#4-google-drive-操作)
5. [Google Sheets 操作](#5-google-sheets-操作)
6. [Google Docs 操作](#6-google-docs-操作)
7. [Google Contacts 操作](#7-google-contacts-操作)
8. [批量操作模板](#8-批量操作模板)
9. [错误处理与重试策略](#9-错误处理与重试策略)
10. [安全最佳实践](#10-安全最佳实践)

---

## 1. 前置条件与 OAuth2 配置

### 1.1 创建 Google Cloud 项目

```bash
# 安装 gcloud CLI（如尚未安装）
# macOS
brew install google-cloud-sdk
# Linux
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

```bash
# 初始化 gcloud 并登录
gcloud init
gcloud auth login

# 创建新项目（或使用已有项目）
PROJECT_ID="my-workspace-agent-$(date +%s)"
gcloud projects create $PROJECT_ID --name="Workspace Agent"
gcloud config set project $PROJECT_ID
```

### 1.2 启用 API 服务

```bash
# 批量启用所需的 Google Workspace API
gcloud services enable gmail.googleapis.com
gcloud services enable calendar-json.googleapis.com
gcloud services enable drive.googleapis.com
gcloud services enable sheets.googleapis.com
gcloud services enable docs.googleapis.com
gcloud services enable people.googleapis.com
gcloud services enable admin-directory.googleapis.com
```

### 1.3 创建 OAuth2 凭证

在 Google Cloud Console 中创建 OAuth 2.0 凭证：

1. 进入 **APIs & Services → Credentials**
2. 点击 **Create Credentials → OAuth client ID**
3. 选择 **Desktop app** 作为应用类型
4. 记录生成的 `CLIENT_ID` 和 `CLIENT_SECRET`

```bash
# 通过 gcloud CLI 创建 OAuth 凭证
gcloud alpha iap oauth-clients create my-workspace-client \
    --display-name="Workspace Agent CLI"
```

### 1.4 获取和刷新 Access Token

```bash
# 方法一：使用 gcloud 自动获取 token
ACCESS_TOKEN=$(gcloud auth print-access-token)

# 方法二：手动 OAuth2 流程获取 token
# 步骤 1：构造授权 URL
AUTH_URL="https://accounts.google.com/o/oauth2/v2/auth?client_id=${CLIENT_ID}&redirect_uri=urn:ietf:wg:oauth:2.0:oob&response_type=code&scope=https://www.googleapis.com/auth/gmail.compose https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/documents https://www.googleapis.com/auth/contacts.readonly"

# 步骤 2：用户在浏览器中打开 AUTH_URL，授权后获得 authorization_code

# 步骤 3：用 authorization_code 换取 access_token 和 refresh_token
curl -s -X POST https://oauth2.googleapis.com/token \
    -d "code=${AUTH_CODE}" \
    -d "client_id=${CLIENT_ID}" \
    -d "client_secret=${CLIENT_SECRET}" \
    -d "redirect_uri=urn:ietf:wg:oauth:2.0:oob" \
    -d "grant_type=authorization_code" | jq .

# 步骤 4：保存返回的 refresh_token，用于后续自动刷新
# 刷新 token 的命令：
curl -s -X POST https://oauth2.googleapis.com/token \
    -d "client_id=${CLIENT_ID}" \
    -d "client_secret=${CLIENT_SECRET}" \
    -d "refresh_token=${REFRESH_TOKEN}" \
    -d "grant_type=refresh_token" | jq -r .access_token
```

### 1.5 Token 环境变量管理

```bash
# 建议将凭证存储在环境变量中
export GOOGLE_CLIENT_ID="your_client_id.apps.googleusercontent.com"
export GOOGLE_CLIENT_SECRET="your_client_secret"
export GOOGLE_REFRESH_TOKEN="your_refresh_token"

# 定义便捷函数：自动获取有效 token
get_google_token() {
    local token_response=$(curl -s -X POST https://oauth2.googleapis.com/token \
        -d "client_id=${GOOGLE_CLIENT_ID}" \
        -d "client_secret=${GOOGLE_CLIENT_SECRET}" \
        -d "refresh_token=${GOOGLE_REFRESH_TOKEN}" \
        -d "grant_type=refresh_token")
    echo "$token_response" | jq -r .access_token
}

export GOOGLE_TOKEN=$(get_google_token)
```

### 1.6 API 请求基础封装

```bash
# 定义通用 Google API 请求函数
google_api() {
    local method=$1
    local url=$2
    local data=$3
    local content_type="application/json"

    # 检查 token 是否过期，自动刷新
    local token=${GOOGLE_TOKEN}
    local expire_check=$(curl -s -o /dev/null -w "%{http_code}" \
        -H "Authorization: Bearer $token" "https://www.googleapis.com/oauth2/v2/userinfo")
    if [ "$expire_check" = "401" ]; then
        export GOOGLE_TOKEN=$(get_google_token)
        token=$GOOGLE_TOKEN
    fi

    if [ -z "$data" ]; then
        curl -s -X "$method" "$url" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: $content_type"
    else
        curl -s -X "$method" "$url" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: $content_type" \
            -d "$data"
    fi
}
```

---

## 2. Gmail 操作

### 2.1 读取邮件列表

```bash
# 获取收件箱邮件列表（最新 10 封）
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages?maxResults=10&labelIds=INBOX"

# 搜索特定主题的邮件
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages?q=subject:%22项目周报%22&maxResults=5"

# 搜索未读邮件
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages?q=is:unread&maxResults=20"

# 搜索特定发件人的附件邮件
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages?q=from:boss@company.com+has:attachment"

# 搜索特定日期范围的邮件
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages?q=after:2024/01/01+before:2024/12/31"
```

### 2.2 读取邮件详情

```bash
# 读取邮件完整内容（含 headers 和 body）
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}?format=full"

# 仅读取邮件元数据（headers）
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date"

# 提取邮件正文（自动解码 base64）
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}?format=full" \
    | jq -r '.payload.parts[] | select(.mimeType == "text/plain") | .body.data' \
    | base64 -d
```

### 2.3 发送邮件

```bash
# 发送纯文本邮件
send_email() {
    local to=$1
    local subject=$2
    local body=$3

    local encoded_subject=$(echo "$subject" | base64)
    local encoded_body=$(echo "$body" | base64)

    local raw=$(printf "To: %s\r\nSubject: =?utf-8?B?%s?=\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n%s" \
        "$to" "$encoded_subject" "$body" | base64 -w0)

    google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/send" \
        "{\"raw\": \"${raw}\"}"
}

# 使用示例
send_email "colleague@example.com" "会议通知" "明天下午3点在3号会议室召开项目进度会议，请准时参加。"
```

```bash
# 发送 HTML 格式邮件（带内联样式）
send_html_email() {
    local to=$1
    local subject=$2
    local html_body=$3

    local raw=$(printf "To: %s\r\nSubject: %s\r\nContent-Type: text/html; charset=utf-8\r\n\r\n%s" \
        "$to" "$subject" "$html_body" | base64 -w0)

    google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/send" \
        "{\"raw\": \"${raw}\"}"
}

# 示例：发送带表格的邮件
send_html_email "team@example.com" "本周销售数据汇总" '
<html>
<body>
<h2>📊 本周销售数据汇总</h2>
<table border="1" cellpadding="8">
<tr style="background:#f0f0f0"><th>产品</th><th>销量</th><th>营收</th></tr>
<tr><td>产品A</td><td>150</td><td>¥45,000</td></tr>
<tr><td>产品B</td><td>89</td><td>¥31,150</td></tr>
</table>
<p style="color:#666">数据截止至 ' $(date +%Y-%m-%d) '</p>
</body>
</html>'
```

### 2.4 发送带附件的邮件

```bash
# 发送带附件的邮件
send_email_with_attachment() {
    local to=$1
    local subject=$2
    local body=$3
    local file_path=$4

    local boundary="boundary_"$(date +%s)
    local file_name=$(basename "$file_path")
    local file_mime=$(file --mime-type -b "$file_path")
    local file_data=$(base64 -w0 "$file_path")

    local raw=$(printf "To: %s\r\nSubject: %s\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=%s\r\n\r\n--%s\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n%s\r\n\r\n--%s\r\nContent-Type: %s; name=\"%s\"\r\nContent-Disposition: attachment; filename=\"%s\"\r\nContent-Transfer-Encoding: base64\r\n\r\n%s\r\n\r\n--%s--" \
        "$to" "$subject" "$boundary" "$boundary" "$body" "$boundary" "$file_mime" "$file_name" "$file_name" "$file_data" "$boundary" | base64 -w0)

    google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/send" \
        "{\"raw\": \"${raw}\"}"
}

# 示例：发送报告附件
send_email_with_attachment "manager@example.com" "月度报告" "请查收附件中的月度报告。" "/path/to/monthly_report.pdf"
```

### 2.5 下载邮件附件

```bash
# 下载邮件中的附件
download_attachment() {
    local message_id=$1
    local attachment_id=$2
    local output_path=$3

    google_api GET \
        "https://www.googleapis.com/gmail/v1/users/me/messages/${message_id}/attachments/${attachment_id}" \
        | jq -r '.data' | base64 -d > "$output_path"

    echo "附件已保存到: $output_path"
}

# 获取邮件的所有附件信息
google_api GET "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}?format=full" \
    | jq '[.payload.parts[] | {filename: .filename, mimeType: .mimeType, attachmentId: .body.attachmentId}]'
```

### 2.6 邮件管理操作

```bash
# 标记邮件为已读
google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}/modify" \
    '{"removeLabelIds": ["UNREAD"]}'

# 归档邮件（从收件箱移除）
google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}/modify" \
    '{"removeLabelIds": ["INBOX"]}'

# 将邮件添加到指定标签
google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}/modify" \
    '{"addLabelIds": ["IMPORTANT", "STARRED"]}'

# 删除邮件（移到回收站）
google_api POST "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}/trash"

# 永久删除邮件
google_api DELETE "https://www.googleapis.com/gmail/v1/users/me/messages/${MESSAGE_ID}"

# 创建新标签
google_api POST "https://www.googleapis.com/gmail/v1/users/me/labels" \
    '{"name": "项目/X项目", "labelListVisibility": "labelShow", "messageListVisibility": "show"}'

# 获取所有标签列表
google_api GET "https://www.googleapis.com/gmail/v1/users/me/labels"
```

### 2.7 Gmail 筛选器与自动回复

```bash
# 添加过滤规则：自动将特定发件人的邮件标星
google_api POST "https://www.googleapis.com/gmail/v1/users/me/settings/filters" \
    '{
        "criteria": {
            "from": "important-client@example.com"
        },
        "action": {
            "addLabelIds": ["STARRED"],
            "addLabelIds": ["INBOX"]
        }
    }'

# 设置自动回复（休假回复）
google_api PUT "https://www.googleapis.com/gmail/v1/users/me/settings/autoForwarding" \
    '{
        "enabled": true,
        "responseBody": "感谢您的来信。我目前不在办公室，将于 X 月 X 日返回。紧急事务请联系 xxx@company.com。",
        "startTimeSec": '"$(date -d "+1 day" +%s)"',
        "endTimeSec": '"$(date -d "+7 days" +%s)"'
    }'
```

---

## 3. Google Calendar 操作

### 3.1 查看日历事件

```bash
# 获取今天的日历事件
TODAY=$(date +%Y-%m-%d)
google_api GET "https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${TODAY}T00:00:00Z&timeMax=${TODAY}T23:59:59Z&singleEvents=true&orderBy=startTime"

# 获取本周的所有事件
START_OF_WEEK=$(date -d "monday" +%Y-%m-%d)
END_OF_WEEK=$(date -d "sunday" +%Y-%m-%d)
google_api GET "https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${START_OF_WEEK}T00:00:00Z&timeMax=${END_OF_WEEK}T23:59:59Z&singleEvents=true&orderBy=startTime"

# 查看特定日历的事件
google_api GET "https://www.googleapis.com/calendar/v3/calendars/${CALENDAR_ID}/events?maxResults=10"

# 获取即将到来的事件（最多5个）
google_api GET "https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=$(date -u +%Y-%m-%dT%H:%M:%SZ)&maxResults=5&singleEvents=true&orderBy=startTime"
```

### 3.2 创建日历事件

```bash
# 创建简单事件
create_event() {
    local title=$1
    local start_time=$2  # 格式: 2024-01-15T10:00:00+08:00
    local end_time=$3
    local description=$4
    local location=$5

    local payload=$(jq -n \
        --arg summary "$title" \
        --arg start "$start_time" \
        --arg end "$end_time" \
        --arg desc "$description" \
        --arg loc "$location" \
        '{
            summary: $summary,
            location: $loc,
            description: $desc,
            start: {dateTime: $start, timeZone: "Asia/Shanghai"},
            end: {dateTime: $end, timeZone: "Asia/Shanghai"},
            reminders: {
                useDefault: false,
                overrides: [
                    {method: "popup", minutes: 30},
                    {method: "email", minutes: 60}
                ]
            }
        }')

    google_api POST "https://www.googleapis.com/calendar/v3/calendars/primary/events" "$payload"
}

# 使用示例
create_event "产品需求评审会议" \
    "2024-03-20T14:00:00+08:00" \
    "2024-03-20T15:30:00+08:00" \
    "讨论 Q2 产品路线图和优先级排序" \
    "线上 - 腾讯会议 888-6666"
```

```bash
# 创建全天事件
google_api POST "https://www.googleapis.com/calendar/v3/calendars/primary/events" '{
    "summary": "公司团建活动",
    "start": {"date": "2024-04-15"},
    "end": {"date": "2024-04-16"},
    "colorId": "2"
}'

# 创建循环事件（每周一上午站会）
google_api POST "https://www.googleapis.com/calendar/v3/calendars/primary/events" '{
    "summary": "周会 - 项目进度同步",
    "start": {"dateTime": "2024-01-08T09:30:00+08:00", "timeZone": "Asia/Shanghai"},
    "end": {"dateTime": "2024-01-08T10:00:00+08:00", "timeZone": "Asia/Shanghai"},
    "recurrence": ["RRULE:FREQ=WEEKLY;BYDAY=MO;UNTIL=20241231T235959Z"],
    "reminders": {
        "useDefault": false,
        "overrides": [{"method": "popup", "minutes": 15}]
    }
}'

# 创建带参会者的事件
google_api POST "https://www.googleapis.com/calendar/v3/calendars/primary/events" '{
    "summary": "技术方案评审",
    "start": {"dateTime": "2024-03-20T10:00:00+08:00", "timeZone": "Asia/Shanghai"},
    "end": {"dateTime": "2024-03-20T11:00:00+08:00", "timeZone": "Asia/Shanghai"},
    "attendees": [
        {"email": "dev1@example.com"},
        {"email": "dev2@example.com"},
        {"email": "pm@example.com"}
    ],
    "conferenceData": {
        "createRequest": {
            "requestId": "meet-'$(date +%s)'",
            "conferenceSolutionKey": {"type": "hangoutsMeet"}
        }
    },
    "guestsCanModify": false,
    "guestsCanInviteOthers": false
}'
```

### 3.3 更新和删除事件

```bash
# 更新事件标题和时间
google_api PUT "https://www.googleapis.com/calendar/v3/calendars/primary/events/${EVENT_ID}" '{
    "summary": "【已延期】产品需求评审会议",
    "start": {"dateTime": "2024-03-21T14:00:00+08:00", "timeZone": "Asia/Shanghai"},
    "end": {"dateTime": "2024-03-21T15:30:00+08:00", "timeZone": "Asia/Shanghai"}
}'

# 取消事件（给所有参会者发送取消通知）
google_api DELETE "https://www.googleapis.com/calendar/v3/calendars/primary/events/${EVENT_ID}?sendNotifications=true"
```

### 3.4 查找空闲时间

```bash
# 查找两个或多个日历的空闲时间段
google_api POST "https://www.googleapis.com/calendar/v3/freeBusy" '{
    "timeMin": "2024-03-20T00:00:00+08:00",
    "timeMax": "2024-03-20T23:59:59+08:00",
    "timeZone": "Asia/Shanghai",
    "items": [
        {"id": "primary"},
        {"id": "colleague@example.com"}
    ]
}'
```

---

## 4. Google Drive 操作

### 4.1 搜索文件

```bash
# 列出最近的文件（最多 20 个）
google_api GET "https://www.googleapis.com/drive/v3/files?pageSize=20&orderBy=modifiedTime desc&fields=files(id,name,mimeType,size,modifiedTime,ownedByMe)"

# 搜索特定名称的文件
google_api GET "https://www.googleapis.com/drive/v3/files?q=name+contains+%22项目报告%22&fields=files(id,name,mimeType)"

# 搜索特定类型的文件（仅 PDF）
google_api GET "https://www.googleapis.com/drive/v3/files?q=mimeType=%27application/pdf%27&fields=files(id,name,size)"

# 搜索特定文件夹中的文件
FOLDER_ID="your_folder_id"
google_api GET "https://www.googleapis.com/drive/v3/files?q=%27${FOLDER_ID}%27+in+parents&fields=files(id,name,mimeType)"

# 搜索最近 7 天修改的文件
google_api GET "https://www.googleapis.com/drive/v3/files?q=modifiedTime>%27$(date -d '7 days ago' -u +%Y-%m-%dT%H:%M:%SZ)%27&fields=files(id,name,modifiedTime)"

# 搜索共享给我的文件
google_api GET "https://www.googleapis.com/drive/v3/files?q=sharedWithMe=true&fields=files(id,name,ownerNames,mimeType)"

# 搜索星标文件
google_api GET "https://www.googleapis.com/drive/v3/files?q=starred=true&fields=files(id,name,mimeType)"
```

### 4.2 上传文件

```bash
# 上传小文件（< 5MB，使用 multipart）
upload_file() {
    local file_path=$1
    local folder_id=$2  # 可选，目标文件夹 ID
    local mime_type=$(file --mime-type -b "$file_path")
    local file_name=$(basename "$file_path")

    local metadata='{"name":"'"$file_name"'","mimeType":"'"$mime_type"''
    if [ -n "$folder_id" ]; then
        metadata+=',"parents":["'"$folder_id"'"]'
    fi
    metadata+='}'

    local boundary="boundary_$(date +%s)"
    local binary_data=$(base64 -w0 "$file_path")

    # 使用 resumable upload API 更可靠
    curl -s -X POST "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable" \
        -H "Authorization: Bearer ${GOOGLE_TOKEN}" \
        -H "Content-Type: application/json" \
        -H "X-Upload-Content-Type: ${mime_type}" \
        -H "X-Upload-Content-Length: $(stat -f%z "$file_path" 2>/dev/null || stat -c%s "$file_path")" \
        -d "$metadata" \
        -D - | head -20  # 获取 upload URL
}

# 上传大文件（使用 resumable upload）
upload_large_file() {
    local file_path=$1
    local folder_id=$2
    local mime_type=$(file --mime-type -b "$file_path")
    local file_name=$(basename "$file_path")
    local file_size=$(stat -f%z "$file_path" 2>/dev/null || stat -c%s "$file_path")

    # Step 1: 发起 resumable upload session
    local metadata='{"name":"'"$file_name"''
    if [ -n "$folder_id" ]; then
        metadata+=',"parents":["'"$folder_id"'"]'
    fi
    metadata+='}'

    local upload_url=$(curl -s -X POST \
        "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable" \
        -H "Authorization: Bearer ${GOOGLE_TOKEN}" \
        -H "Content-Type: application/json" \
        -H "X-Upload-Content-Length: ${file_size}" \
        -d "$metadata" \
        -D - 2>/dev/null | grep -i "^location:" | tr -d '\r' | awk '{print $2}')

    # Step 2: 上传文件内容
    curl -s -X PUT "$upload_url" \
        -H "Authorization: Bearer ${GOOGLE_TOKEN}" \
        -H "Content-Type: ${mime_type}" \
        -H "Content-Length: ${file_size}" \
        --data-binary @"$file_path"
}
```

### 4.3 下载文件

```bash
# 下载文件（通过 exportLink 或 webContentLink）
download_file() {
    local file_id=$1
    local output_path=$2

    # 获取文件信息
    local file_info=$(google_api GET "https://www.googleapis.com/drive/v3/files/${file_id}?fields=name,mimeType,webContentLink")
    local file_name=$(echo "$file_info" | jq -r .name)

    # 下载文件
    curl -s -L -o "$output_path" \
        "https://www.googleapis.com/drive/v3/files/${file_id}?alt=media" \
        -H "Authorization: Bearer ${GOOGLE_TOKEN}"

    echo "文件已下载: ${output_path}/${file_name}"
}

# 导出 Google Docs/Sheets 为指定格式
export_file() {
    local file_id=$1
    local mime_type=$2  # 如 application/pdf
    local output=$3

    curl -s -L -o "$output" \
        "https://www.googleapis.com/drive/v3/files/${file_id}/export?mimeType=${mime_type}" \
        -H "Authorization: Bearer ${GOOGLE_TOKEN}"
}

# 常用导出格式
# PDF:      application/pdf
# DOCX:     application/vnd.openxmlformats-officedocument.wordprocessingml.document
# XLSX:     application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
# CSV:      text/csv
# TXT:      text/plain
# HTML:     text/html
```

### 4.4 文件和文件夹管理

```bash
# 创建文件夹
google_api POST "https://www.googleapis.com/drive/v3/files" \
    '{"name":"新项目文件夹","mimeType":"application/vnd.google-apps.folder"}'

# 在指定文件夹内创建子文件夹
google_api POST "https://www.googleapis.com/drive/v3/files" \
    '{"name":"子文件夹","mimeType":"application/vnd.google-apps.folder","parents":["'"${PARENT_FOLDER_ID}"'"]}'

# 移动文件到指定文件夹
google_api PATCH "https://www.googleapis.com/drive/v3/files/${FILE_ID}?addParents=${FOLDER_ID}&removeParents=root"

# 复制文件
google_api POST "https://www.googleapis.com/drive/v3/files/${FILE_ID}/copy" \
    '{"name":"副本 - 原文件名"}'

# 重命名文件
google_api PATCH "https://www.googleapis.com/drive/v3/files/${FILE_ID}" \
    '{"name":"新文件名.pdf"}'

# 删除文件（移到回收站）
google_api DELETE "https://www.googleapis.com/drive/v3/files/${FILE_ID}"

# 永久删除文件
google_api DELETE "https://www.googleapis.com/drive/v3/files/${FILE_ID}?supportsAllDrives=true"

# 共享文件（添加编辑权限）
google_api POST "https://www.googleapis.com/drive/v3/files/${FILE_ID}/permissions" \
    '{"role":"writer","type":"user","emailAddress":"collaborator@example.com"}'

# 设置文件为「任何知道链接的人都可以查看」
google_api POST "https://www.googleapis.com/drive/v3/files/${FILE_ID}/permissions" \
    '{"role":"reader","type":"anyone"}'

# 查看文件的权限列表
google_api GET "https://www.googleapis.com/drive/v3/files/${FILE_ID}/permissions?fields=permissions(id,emailAddress,role,type)"
```

### 4.5 Drive 存储空间查询

```bash
# 查看存储空间使用情况
google_api GET "https://www.googleapis.com/drive/v3/about?fields=user,storageQuota" | jq '{
    user: .user.emailAddress,
    limit: (.storageQuota.limit | tonumber / 1073741824 | floor | tostring + " GB"),
    usage: (.storageQuota.usage | tonumber / 1073741824 | . * 100 | floor / 100 | tostring + " GB"),
    usageInDrive: (.storageQuota.usageInDrive | tonumber / 1073741824 | . * 100 | floor / 100 | tostring + " GB"),
    usageInDriveTrash: (.storageQuota.usageInDriveTrash | tonumber / 1073741824 | . * 100 | floor / 100 | tostring + " GB")
}'
```

---

## 5. Google Sheets 操作

### 5.1 读取表格数据

```bash
# 读取整个工作表
google_api GET \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Sheet1"

# 读取指定范围
google_api GET \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Sheet1!A1:D10"

# 读取数据并格式化输出（去除引号，对齐列）
google_api GET \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Sheet1" \
    | jq -r '.values[] | @tsv' | column -t -s $'\t'

# 读取表格元数据（工作表名称列表）
google_api GET \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}?fields=sheets.properties"

# 读取带公式计算的单元格
google_api GET \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Sheet1!A1:B2?valueRenderOption=FORMULA"
```

### 5.2 写入数据

```bash
# 向指定范围写入数据
write_to_sheet() {
    local range=$1
    local values=$2  # JSON 数组格式 [["值1","值2"],["值3","值4"]]

    google_api PUT \
        "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED" \
        "{\"values\": ${values}}"
}

# 示例：写入单行数据
write_to_sheet "Sheet1!A1:C1" '[["姓名","年龄","城市"]]'

# 示例：写入多行数据
write_to_sheet "Sheet1!A2:D5" '[
    ["张三",28,"北京","工程师"],
    ["李四",32,"上海","产品经理"],
    ["王五",25,"深圳","设计师"],
    ["赵六",30,"杭州","运营"]
]'

# 追加数据到表格末尾
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Sheet1!A1:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS" \
    '{"values": [["新增数据1","新增数据2","新增数据3"]]}'
```

### 5.3 批量更新

```bash
# 批量更新多个范围
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values:batchUpdate" \
    '{
        "valueInputOption": "USER_ENTERED",
        "data": [
            {"range": "Sheet1!A1", "values": [["更新后的标题"]]},
            {"range": "Sheet2!B5", "values": [["更新后的值"]]},
            {"range": "Summary!A1:A3", "values": [["总计"],["100"],["200"]]}
        ]
    }'

# 批量读取多个范围
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values:batchGet?ranges=Sheet1!A1:D10&ranges=Sheet2!A1:A5&majorDimension=ROWS"
```

### 5.4 格式化和样式设置

```bash
# 设置单元格格式
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate" \
    '{
        "requests": [
            {
                "updateCells": {
                    "range": {"sheetId": 0, "startRowIndex": 0, "endRowIndex": 1},
                    "rows": [{
                        "values": [{
                            "userEnteredFormat": {
                                "backgroundColor": {"red": 0.2, "green": 0.6, "blue": 0.9},
                                "textFormat": {"bold": true, "color": {"red": 1, "green": 1, "blue": 1}}
                            }
                        }]
                    }],
                    "fields": "userEnteredFormat.backgroundColor,userEnteredFormat.textFormat"
                }
            },
            {
                "updateDimensionProperties": {
                    "range": {"sheetId": 0, "dimension": "COLUMNS", "startIndex": 0, "endIndex": 4},
                    "properties": {"pixelSize": 150},
                    "fields": "pixelSize"
                }
            }
        ]
    }'

# 添加边框
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate" \
    '{
        "requests": [{
            "updateBorders": {
                "range": {"sheetId": 0, "startRowIndex": 0, "endRowIndex": 10, "startColumnIndex": 0, "endColumnIndex": 4},
                "top": {"style": "SOLID", "width": 1, "color": {"red": 0, "green": 0, "blue": 0}},
                "bottom": {"style": "SOLID", "width": 1, "color": {"red": 0, "green": 0, "blue": 0}},
                "left": {"style": "SOLID", "width": 1, "color": {"red": 0, "green": 0, "blue": 0}},
                "right": {"style": "SOLID", "width": 1, "color": {"red": 0, "green": 0, "blue": 0}},
                "innerHorizontal": {"style": "SOLID", "width": 1, "color": {"red": 0.8, "green": 0.8, "blue": 0.8}},
                "innerVertical": {"style": "SOLID", "width": 1, "color": {"red": 0.8, "green": 0.8, "blue": 0.8}}
            }
        }]
    }'
```

### 5.5 创建图表

```bash
# 在表格中创建柱状图
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate" \
    '{
        "requests": [{
            "addChart": {
                "chart": {
                    "spec": {
                        "title": "月度销售趋势",
                        "basicChart": {
                            "chartType": "COLUMN",
                            "headerCount": 1,
                            "domains": [{"range": {"sourceRange": {"sources": [{"sheetId": 0, "startRowIndex": 0, "endRowIndex": 13, "startColumnIndex": 0, "endColumnIndex": 1}]}}}],
                            "series": [{"series": {"sourceRange": {"sources": [{"sheetId": 0, "startRowIndex": 0, "endRowIndex": 13, "startColumnIndex": 2, "endColumnIndex": 3}]}}, "targetAxis": "LEFT_AXIS"}],
                            "legendPosition": "BOTTOM_LEGEND"
                        }
                    },
                    "position": {"overlayPosition": {"anchorCell": {"rowIndex": 0, "columnIndex": 5}}}
                }
            }
        }]
    }'
```

### 5.6 数据筛选与排序

```bash
# 添加筛选器
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate" \
    '{
        "requests": [{
            "setBasicFilter": {
                "filter": {
                    "range": {"sheetId": 0, "startRowIndex": 0, "endRowIndex": 100, "startColumnIndex": 0, "endColumnIndex": 5},
                    "sortSpecs": [{"dimensionIndex": 2, "sortOrder": "DESCENDING"}],
                    "filterSpecs": [{"filterCriteria": {"hiddenValues": ["已完成"]}}]
                }
            }
        }]
    }'

# 对数据排序
google_api POST \
    "https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}:batchUpdate" \
    '{
        "requests": [{
            "sortRange": {
                "range": {"sheetId": 0, "startRowIndex": 1, "endRowIndex": 100},
                "sortSpecs": [
                    {"dimensionIndex": 2, "sortOrder": "ASCENDING"},
                    {"dimensionIndex": 0, "sortOrder": "DESCENDING"}
                ]
            }
        }]
    }'
```

---

## 6. Google Docs 操作

### 6.1 创建文档

```bash
# 创建空白 Google 文档
google_api POST "https://docs.googleapis.com/v1/documents" \
    '{"title":"项目需求文档"}'

# 创建文档时带有初始内容
google_api POST "https://docs.googleapis.com/v1/documents" '{
    "title": "会议纪要模板",
    "body": {
        "content": [
            {
                "paragraph": {
                    "elements": [{"textRun": {"content": "会议纪要\n"}}],
                    "paragraphStyle": {"namedStyleType": "HEADING_1"}
                }
            },
            {
                "paragraph": {
                    "elements": [{"textRun": {"content": "日期：\n"}}]
                }
            },
            {
                "paragraph": {
                    "elements": [{"textRun": {"content": "参会人员：\n"}}]
                }
            },
            {
                "paragraph": {
                    "elements": [{"textRun": {"content": "议题：\n"}}]
                }
            }
        ]
    }
}'
```

### 6.2 编辑文档内容

```bash
# 在文档末尾追加文本
google_api POST "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}:batchUpdate" \
'{
    "requests": [
        {
            "insertText": {
                "location": {"index": 1},
                "text": "第一章 项目概述\n\n本文档描述了项目的整体规划和技术方案。\n"
            }
        },
        {
            "updateTextStyle": {
                "range": {"startIndex": 1, "endIndex": 9},
                "textStyle": {"bold": true, "fontSize": {"magnitude": 18, "unit": "PT"}},
                "fields": "bold,fontSize"
            }
        }
    ]
}'

# 插入标题
google_api POST "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}:batchUpdate" \
'{
    "requests": [{
        "insertText": {
            "location": {"index": 1},
            "text": "技术架构设计\n"
        }
    },{
        "updateParagraphStyle": {
            "range": {"startIndex": 1, "endIndex": 8},
            "paragraphStyle": {"namedStyleType": "HEADING_2"},
            "fields": "namedStyleType"
        }
    }]
}'

# 插入项目符号列表
google_api POST "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}:batchUpdate" \
'{
    "requests": [{
        "insertText": {
            "location": {"index": 50},
            "text": "功能需求：\n• 用户注册与登录\n• 商品浏览与搜索\n• 购物车管理\n• 订单处理\n• 支付集成\n"
        }
    }]
}'

# 插入表格
google_api POST "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}:batchUpdate" \
'{
    "requests": [{
        "insertTable": {
            "rows": 4,
            "columns": 3,
            "location": {"index": 100}
        }
    }]
}'

# 修改表格内容
google_api POST "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}:batchUpdate" \
'{
    "requests": [
        {"insertText": {"location": {"index": 101}, "text": "需求编号"}},
        {"insertText": {"location": {"index": 105}, "text": "需求描述"}},
        {"insertText": {"location": {"index": 109}, "text": "优先级"}},
        {"insertText": {"location": {"index": 114}, "text": "REQ-001"}},
        {"insertText": {"location": {"index": 118}, "text": "用户登录功能"}},
        {"insertText": {"location": {"index": 122}, "text": "高"}},
        {"insertText": {"location": {"index": 127}, "text": "REQ-002"}},
        {"insertText": {"location": {"index": 131}, "text": "商品搜索"}},
        {"insertText": {"location": {"index": 135}, "text": "中"}}
    ]
}'
```

### 6.3 导出文档

```bash
# 导出为 PDF
curl -s -L -o "document.pdf" \
    "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}/export?mimeType=application/pdf" \
    -H "Authorization: Bearer ${GOOGLE_TOKEN}"

# 导出为 DOCX
curl -s -L -o "document.docx" \
    "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}/export?mimeType=application/vnd.openxmlformats-officedocument.wordprocessingml.document" \
    -H "Authorization: Bearer ${GOOGLE_TOKEN}"

# 导出为 HTML
curl -s -L -o "document.html" \
    "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}/export?mimeType=text/html" \
    -H "Authorization: Bearer ${GOOGLE_TOKEN}"

# 导出为纯文本
curl -s -L -o "document.txt" \
    "https://docs.googleapis.com/v1/documents/${DOCUMENT_ID}/export?mimeType=text/plain" \
    -H "Authorization: Bearer ${GOOGLE_TOKEN}"
```

---

## 7. Google Contacts 操作

### 7.1 搜索联系人

```bash
# 搜索所有联系人
google_api GET "https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers,organizations" \
    | jq '.connections[] | {name: .names[0].displayName, email: .emailAddresses[0].value}'

# 按名称搜索联系人
google_api GET "https://people.googleapis.com/v1/people/me:searchContacts?query=张三&readMask=names,emailAddresses,phoneNumbers"

# 获取联系人详情
google_api GET "https://people.googleapis.com/v1/people/${CONTACT_RESOURCE_NAME}?personFields=names,emailAddresses,phoneNumbers,organizations,addresses,urls"
```

### 7.2 创建联系人

```bash
# 创建新联系人
google_api POST "https://people.googleapis.com/v1/people:createContact" \
'{
    "names": [{"givenName": "新", "familyName": "同事"}],
    "emailAddresses": [{"value": "newcolleague@example.com", "type": "work"}],
    "phoneNumbers": [{"value": "+86 138 0000 0000", "type": "mobile"}],
    "organizations": [{"name": "ABC 科技有限公司", "title": "前端工程师"}]
}'
```

### 7.3 更新联系人

```bash
# 更新联系人信息
google_api POST "https://people.googleapis.com/v1/people/${CONTACT_RESOURCE_NAME}:updateContact?updatePersonFields=emailAddresses,phoneNumbers" \
'{
    "emailAddresses": [
        {"value": "newemail@example.com", "type": "work"},
        {"value": "personal@gmail.com", "type": "home"}
    ],
    "phoneNumbers": [{"value": "+86 139 9999 9999", "type": "mobile"}]
}'
```

### 7.4 创建联系人组

```bash
# 创建联系人组
google_api POST "https://people.googleapis.com/v1/contactGroups" \
    '{"contactGroup": {"name": "项目组成员"}}'

# 向组中添加成员
google_api POST "https://people.googleapis.com/v1/contactGroups/${GROUP_ID}/members:modify" \
    '{"resourceNamesToAdd": ["people/c123456", "people/c789012"]}'
```

---

## 8. 批量操作模板

### 8.1 批量发送邮件

```bash
# 从 CSV 文件批量发送个性化邮件
batch_send_emails() {
    local csv_file=$1
    local subject_template=$2
    local body_template=$3

    while IFS=',' read -r name email company; do
        [ -z "$name" ] && continue

        local subject=$(echo "$subject_template" | sed "s/{{NAME}}/$name/g")
        local body=$(echo "$body_template" | sed "s/{{NAME}}/$name/g" | sed "s/{{COMPANY}}/$company/g")

        echo "发送邮件给: $name <$email>"
        send_email "$email" "$subject" "$body"

        sleep 2  # 避免触发频率限制
    done < "$csv_file"
}

# CSV 文件格式 (recipients.csv):
# 姓名,邮箱,公司
# 张三,zhangsan@example.com,ABC科技
# 李四,lisi@example.com,XYZ集团

# 使用示例
batch_send_emails "recipients.csv" \
    "{{NAME}}，您好！邀请参加技术分享会" \
    "亲爱的{{NAME}}，\n\n{{COMPANY}}的技术团队诚挚邀请您参加本月的技术分享会...\n\n时间：3月25日 14:00\n地点：线上会议\n\n期待您的参与！"
```

### 8.2 批量创建日历事件

```bash
# 从 JSON 配置批量创建会议
batch_create_events() {
    local config_file=$1

    jq -c '.events[]' "$config_file" | while read -r event; do
        local title=$(echo "$event" | jq -r .title)
        local start=$(echo "$event" | jq -r .start)
        local end=$(echo "$event" | jq -r .end)
        local desc=$(echo "$event" | jq -r .description)

        echo "创建事件: $title ($start)"
        create_event "$title" "$start" "$end" "$desc" ""

        sleep 1
    done
}

# 配置文件格式 (events.json):
# {
#   "events": [
#     {"title": "Sprint Review", "start": "2024-03-25T10:00:00+08:00", "end": "2024-03-25T11:00:00+08:00", "description": "Sprint 12 回顾"},
#     {"title": "架构设计讨论", "start": "2024-03-25T14:00:00+08:00", "end": "2024-03-25T15:30:00+08:00", "description": "微服务架构方案评审"},
#     {"title": "客户需求对接", "start": "2024-03-26T09:00:00+08:00", "end": "2024-03-26T10:00:00+08:00", "description": "与客户方讨论二期需求"}
#   ]
# }
```

### 8.3 批量更新 Google Sheets

```bash
# 将 CSV 数据批量导入 Google Sheets
import_csv_to_sheet() {
    local csv_file=$1
    local spreadsheet_id=$2
    local sheet_name=$3

    # 读取 CSV 并转为 JSON 数组
    local values=$(jq -R -s \
        'split("\n") | map(select(length > 0)) | map(split(","))' \
        "$csv_file")

    google_api PUT \
        "https://sheets.googleapis.com/v4/spreadsheets/${spreadsheet_id}/values/${sheet_name}?valueInputOption=USER_ENTERED" \
        "{\"values\": ${values}}"
}

# 批量更新多个 Sheet
batch_update_sheets() {
    local config_file=$1
    local spreadsheet_id=$2

    local data=$(jq -c '.sheets[]' "$config_file")
    local batch_data="["

    echo "$data" | while IFS= read -r sheet; do
        local name=$(echo "$sheet" | jq -r .name)
        local csv=$(echo "$sheet" | jq -r .csvFile)
        local range=$(echo "$sheet" | jq -r .range)

        local values=$(jq -R -s 'split("\n") | map(select(length > 0)) | map(split(","))' "$csv")

        echo "{\"range\": \"${range}\", \"values\": ${values}}"
    done | jq -s .
}
```

### 8.4 跨服务联动：邮件 → 表格 → 日历

```bash
# 完整工作流：从邮件中提取信息 → 写入表格 → 创建日历事件
email_to_workflow() {
    local query=$1

    # Step 1: 搜索相关邮件
    local messages=$(google_api GET \
        "https://www.googleapis.com/gmail/v1/users/me/messages?q=${query}&maxResults=5")

    local message_ids=$(echo "$messages" | jq -r '.messages[].id')
    local row_num=1

    for msg_id in $message_ids; do
        # Step 2: 提取邮件详情
        local msg=$(google_api GET \
            "https://www.googleapis.com/gmail/v1/users/me/messages/${msg_id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date")

        local subject=$(echo "$msg" | jq -r '.payload.headers[] | select(.name=="Subject") | .value')
        local from=$(echo "$msg" | jq -r '.payload.headers[] | select(.name=="From") | .value')
        local date=$(echo "$msg" | jq -r '.payload.headers[] | select(.name=="Date") | .value')

        # Step 3: 写入 Google Sheets
        write_to_sheet "Tracker!A${row_num}:D${row_num}" \
            "[[\"${date}\",\"${from}\",\"${subject}\",\"待处理\"]]"

        row_num=$((row_num + 1))
    done

    echo "已处理 $(echo "$messages" | jq '.messages | length') 封邮件"
}
```

---

## 9. 错误处理与重试策略

### 9.1 API 错误处理

```bash
# 带错误处理的 API 请求函数
google_api_safe() {
    local method=$1
    local url=$2
    local data=$3
    local max_retries=3
    local retry_delay=2

    for i in $(seq 1 $max_retries); do
        local response=$(google_api "$method" "$url" "$data")
        local error=$(echo "$response" | jq -r '.error.message // empty')

        if [ -z "$error" ]; then
            echo "$response"
            return 0
        fi

        local status_code=$(echo "$response" | jq -r '.error.code')

        case $status_code in
            401)
                echo "Token 过期，自动刷新..." >&2
                export GOOGLE_TOKEN=$(get_google_token)
                sleep 1
                ;;
            403)
                echo "权限不足: $error" >&2
                return 1
                ;;
            404)
                echo "资源不存在: $error" >&2
                return 1
                ;;
            429)
                local retry_after=$(echo "$response" | jq -r '.error.errors[0].extendedHelp // "2"')
                echo "请求频率限制，等待 ${retry_after} 秒后重试 ($i/$max_retries)..." >&2
                sleep "$retry_after"
                ;;
            500|502|503)
                echo "服务端错误 ($status_code)，${retry_delay} 秒后重试 ($i/$max_retries)..." >&2
                sleep "$retry_delay"
                retry_delay=$((retry_delay * 2))
                ;;
            *)
                echo "未知错误 ($status_code): $error" >&2
                return 1
                ;;
        esac
    done

    echo "超过最大重试次数 ($max_retries)" >&2
    return 1
}
```

### 9.2 Google API 常见错误码速查

| 错误码 | 含义 | 处理方式 |
|--------|------|----------|
| 400 | 请求参数错误 | 检查请求格式和参数 |
| 401 | 未授权/Token 过期 | 刷新 access_token |
| 403 | 权限不足 | 检查 API scope 和 IAM 权限 |
| 404 | 资源不存在 | 检查文件/事件 ID 是否正确 |
| 409 | 资源冲突 | 文件名冲突或并发修改 |
| 429 | 请求过于频繁 | 添加延迟，使用指数退避 |
| 500 | 服务器内部错误 | 稍后重试 |
| 503 | 服务不可用 | 稍后重试 |

---

## 10. 安全最佳实践

### 10.1 凭证安全

```bash
# 凭证存储在安全的文件中（设置严格权限）
mkdir -p ~/.google-credentials
chmod 700 ~/.google-credentials

# 存储凭证（不要提交到版本控制）
cat > ~/.google-credentials/workspace-agent.conf << 'EOF'
GOOGLE_CLIENT_ID=your_client_id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your_client_secret
GOOGLE_REFRESH_TOKEN=your_refresh_token
EOF
chmod 600 ~/.google-credentials/workspace-agent.conf

# 加载凭证
source ~/.google-credentials/workspace-agent.conf
export GOOGLE_TOKEN=$(get_google_token)
```

### 10.2 API Scope 最小化原则

```bash
# 仅申请需要的最小权限范围
# 邮件只读: https://www.googleapis.com/auth/gmail.readonly
# 邮件读写: https://www.googleapis.com/auth/gmail.compose
# 邮件完全控制: https://www.googleapis.com/auth/gmail.modify
# 日历只读: https://www.googleapis.com/auth/calendar.readonly
# 日历读写: https://www.googleapis.com/auth/calendar
# Drive 只读: https://www.googleapis.com/auth/drive.readonly
# Drive 文件: https://www.googleapis.com/auth/drive.file
# Sheets 只读: https://www.googleapis.com/auth/spreadsheets.readonly
# Sheets 读写: https://www.googleapis.com/auth/spreadsheets
# Docs 只读: https://www.googleapis.com/auth/documents.readonly
# Docs 读写: https://www.googleapis.com/auth/documents
```

### 10.3 速率限制参考

- Gmail API: 250 quota units/second, 1,000,000/day
- Calendar API: 500 requests/second per project
- Drive API: 20,000 requests/100 seconds per user
- Sheets API: 300 requests/minute per project
- Docs API: 300 requests/minute per project
- People API: 300 requests/minute per project

对于批量操作，建议：
1. 每次请求间隔至少 100ms
2. 使用批量 API（batchUpdate, batchGet）
3. 监控 quota 使用情况

### 10.4 敏感数据操作注意事项

1. 发送邮件前始终确认收件人地址
2. 处理含敏感信息的文件时，使用最小权限 scope
3. 定期轮换 OAuth2 凭证
4. 日志中不记录 access_token 和敏感数据
5. 使用 API Key 替代 OAuth Token 进行公开数据的只读操作
