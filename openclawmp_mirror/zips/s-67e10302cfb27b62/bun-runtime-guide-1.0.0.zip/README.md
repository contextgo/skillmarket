# Bun Runtime Guide

Bun is a fast all-in-one JavaScript runtime built on JavaScriptCore, offering native TypeScript, built-in bundler, test runner, and package manager.

## Key Features

- **Speed**: 3-5x faster than Node.js for startup and I/O
- **Native TypeScript**: No ts-node or compilation step needed
- **Built-in bundler**: Fast bundling without webpack/esbuild
- **Test runner**: Jest-compatible `bun test`
- **Package manager**: `bun install` is faster than npm/yarn
- **Native APIs**: `Bun.file()`, `Bun.serve()`, `Bun.write()`

## Project Setup

```bash
bun init
bun add express
bun run index.ts
```

## Server Example

```typescript
Bun.serve({
  port: 3000,
  fetch(req) {
    return new Response("Hello from Bun!");
  },
});
```

## Migration from Node.js

- Replace `require()` with `import` (native ESM)
- Use `Bun.file()` instead of `fs.readFile()`
- Use `Bun.serve()` instead of express (for simple APIs)
- `bun test` replaces Jest with zero config
- `bun.lockb` replaces `package-lock.json`

## Performance Tips

- Use `Bun.write()` for file operations (3x faster than fs)
- Enable `--smol` for lower memory usage
- Use `Bun.spawn()` instead of `child_process`
- SQLite is built-in: `new Database("mydb.sqlite")`