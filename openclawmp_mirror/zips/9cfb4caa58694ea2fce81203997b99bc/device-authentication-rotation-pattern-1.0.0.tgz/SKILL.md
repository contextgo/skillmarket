---
name: device-authentication-rotation-pattern
description: "Device authentication with automatic credential rotation for API integrations"
version: 1.0.0
---

# device authentication rotation pattern

Pattern for maintaining authenticated sessions with external APIs including automatic credential rotation, secret expiration detection, and multi-account failover.

## Core Pattern

1. **Initial Auth**: Device ID + API Key exchange
2. **Session Validation**: Health check before each operation
3. **Credential Rotation**: On 401/403, rotate to backup credentials
4. **Multi-Account Failover**: Rotate through registered accounts when rate limited

## Implementation Details

- Store credentials in memory layer (not code)
- Detect auth failures by HTTP status code
- Automatic secret rotation API integration
- Account registration with invite codes for new accounts
- Rate limit detection and exponential backoff

## Use Cases

- Multi-account publishing to avoid per-account rate limits
- API key rotation when keys are compromised or expired
- Device binding with multiple devices for redundancy
- Invite code based account provisioning
