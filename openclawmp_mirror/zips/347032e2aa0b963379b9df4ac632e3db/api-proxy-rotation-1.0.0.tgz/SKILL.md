---
name: api-proxy-rotation
description: "多代理轮转策略，解决 API 访问限制和网络不稳定问题"
version: 1.0.0
tags: [api, proxy, rotation, resilience, networking]
---

# API 代理轮转策略

## 问题

API 调用常遇到：Rate Limit、IP 封禁、网络不稳定、地理限制。

## 解决方案：代理池 + 轮转

```python
import random, time
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ProxyConfig:
    url: str           # http://ip:port 或 socks5://ip:port
    region: str        # us, jp, sg, etc.
    priority: int = 1  # 1=最高
    fail_count: int = 0
    last_fail: float = 0
    cooldown: int = 300  # 失败后冷却秒数

class ProxyRotator:
    def __init__(self, proxies: List[ProxyConfig]):
        self.proxies = proxies
        self.current_index = 0
    
    def get_proxy(self) -> Optional[ProxyConfig]:
        now = time.time()
        available = [
            p for p in self.proxies
            if now - p.last_fail > p.cooldown
        ]
        if not available:
            return None  # 所有代理都在冷却
        # 加权随机（优先级越高越常被选）
        weights = [p.priority for p in available]
        return random.choices(available, weights=weights, k=1)[0]
    
    def report_success(self, proxy: ProxyConfig):
        proxy.fail_count = 0
    
    def report_failure(self, proxy: ProxyConfig):
        proxy.fail_count += 1
        proxy.last_fail = time.time()
        # 连续失败增加冷却时间
        proxy.cooldown = min(300 * (2 ** proxy.fail_count), 3600)

# 使用
proxies = [
    ProxyConfig(url="http://127.0.0.1:7890", region="local", priority=10),
    ProxyConfig(url="socks5://proxy1:1080", region="us", priority=5),
]
rotator = ProxyRotator(proxies)

proxy = rotator.get_proxy()
try:
    resp = requests.get(url, proxies={"https": proxy.url}, timeout=15)
    rotator.report_success(proxy)
except Exception:
    rotator.report_failure(proxy)
    proxy = rotator.get_proxy()  # 换一个
```

## WSL2 特殊处理

WSL2 中 `host.docker.internal` 不可用，需替换为 `127.0.0.1`：
```bash
# Docker 容器内访问宿主机代理
--env HTTP_PROXY=http://host.docker.internal:7890
# 替换为实际 IP
docker inspect -f '{{range.NetworkSettings.Networks}}{{.Gateway}}{{end}}' <container>
```

## Rate Limit 友好

```python
class RateLimiter:
    def __init__(self, max_per_minute=30):
        self.max = max_per_minute
        self.requests = []
    
    def wait(self):
        now = time.time()
        self.requests = [t for t in self.requests if now - t < 60]
        if len(self.requests) >= self.max:
            sleep_time = 60 - (now - self.requests[0]) + 0.1
            time.sleep(sleep_time)
        self.requests.append(time.time())
```

## 实战经验

- 本地代理优先（延迟最低）
- 免费代理不稳定，需要容错
- EvoMap API 建议 16s 间隔（~4次/分钟）
- 429 响应一定要读 Retry-After 头
