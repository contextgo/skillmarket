---
name: openclaw-cron-guard
description: "Add guardrails to OpenClaw cron jobs with dedupe, anti-spam limits, graceful fallback, and clear acceptance checks."
version: 1.0.0
type: skill
displayName: "OpenClaw Cron Guardrails"
tags: "openclaw, cron, automation, safety"
---

# OpenClaw Cron 护栏模板

本技能用于给 OpenClaw 定时任务建立“安全护栏”，降低重复发送、异常风暴和隐性失败的概率。

## 适用场景

- 每日/每周自动摘要
- 定时巡检与提醒
- 会对外发送消息的自动流程

## 护栏目标

1. **防重**：同一窗口内不重复发送。
2. **限流**：异常时不连续刷屏。
3. **可降级**：上游失败时输出“可读失败结果”，不中断整条链路。
4. **可验收**：每个任务都有明确成功判据。

## 推荐参数

- `session=isolated`：隔离执行上下文，减少污染。
- `delivery=announce`：只在需要时发送结果。
- 任务消息中写清楚：输入源、去重键、失败回退策略。

## 标准模板（可直接改）

```text
你是 OpenClaw 定时任务执行器。

目标：生成一次日报并发送。

约束：
1) 先读取今日状态文件，若已发送则直接退出并说明“已发送，跳过”。
2) 失败时输出简短错误摘要与下一步修复命令，不要重试超过 1 次。
3) 不得发送敏感信息（token、apiKey）。

输出格式：
- 结论
- 依据
- 风险
- 执行步骤
```

## 防重实现建议

使用本地状态文件（如 `memory/cron-state.md`）记录：

- `job_name`
- `last_success_at`
- `last_payload_hash`

发送前检查：

- 若 `last_payload_hash` 与本次相同且时间窗口未过，跳过发送。

## 失败降级模板

当上游抓取失败时，不直接中断，改为：

- 输出“本次数据源不可用（待验证）”
- 给出下一步命令（如重新抓取、切换备用源）
- 保留任务成功退出，避免 cron 风暴重试

## 发布前自测清单

1. 人工执行一次任务消息（不通过 cron）
2. 验证去重逻辑生效（连续跑两次不重复发送）
3. 验证失败路径有降级输出
4. 验证输出中无敏感信息

## 验收标准

- 连续 3 次执行无重复推送
- 上游异常时可输出降级结果
- 日志可追踪关键判定点
