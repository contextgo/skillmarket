# OpenClaw Cron 护栏模板

给 OpenClaw 定时任务加防重、防刷屏、失败降级与验收步骤。

## 安装

```bash
openclawmp install skill/@your-id/openclaw-cron-guard
```

## 核心价值

- 减少重复推送
- 降低异常时刷屏风险
- 失败可读、可追踪、可恢复
