## v7.2 新增: 交付验证层 (Execution Verification Layer)

> **新增4个验证Agent**，确保协作产出真实可交付

---

## v7.1 新增: 可执行架构

### 快速执行模板

```python
# 1行启动协作
from collaboration import MultiAgentCollaboration

collab = MultiAgentCollaboration()
result = await collab.run_until_convergence(
    task="生成AI行业深度报告",
    level="L3"
)
# 自动选择拓扑、执行、收敛、输出
```

---

## v7.2 新增: 交付验证层 (Execution Verification Layer)

> **新增4个验证Agent**，确保协作产出真实可交付

### 新增Agent概览

| Agent | 职责 | 触发时机 | 失败处理 |
|-------|------|----------|----------|
| **执行验证Agent** | 检查是否生成可执行文件 | 代码生成任务完成后 | 触发代码修复迭代 |
| **现实检查Agent** | 验证设计是否可行 | 架构/方案设计后 | 触发方案重构 |
| **交付物清单Agent** | 明确列出创建的文件路径 | 任务完成前 | 阻止交付直到清单完整 |
| **自检Agent** | 验证所有声称的文件存在 | 最终输出前 | 标记缺失并回退 |

---

### 执行验证Agent (Execution Validator)

```typescript
class ExecutionValidatorAgent {
  role = "执行验证";
  capabilities = ["代码分析", "依赖检查", "运行测试"];
  
  async validate(state: CollaborationState): Promise<ValidationResult> {
    const artifacts = state.task.intermediate['code_generation'];
    
    // 1. 文件存在性检查
    const fileChecks = await Promise.all(
      artifacts.files.map(async (file) => ({
        path: file.path,
        exists: await fs.exists(file.path),
        size: await fs.size(file.path),
        readable: await fs.readable(file.path)
      }))
    );
    
    // 2. 语法/编译检查
    const syntaxChecks = await Promise.all(
      artifacts.codeFiles.map(async (file) => {
        const result = await this.checkSyntax(file);
        return {
          file: file.path,
          valid: result.valid,
          errors: result.errors,
          warnings: result.warnings
        };
      })
    );
    
    // 3. 依赖完整性检查
    const dependencyCheck = await this.validateDependencies(
      artifacts.dependencies,
      artifacts.packageFile
    );
    
    // 4. 可执行性测试 (沙箱运行)
    const executionTest = await this.runSandboxTest(
      artifacts.entryPoint,
      artifacts.testCases
    );
    
    // 5. 生成验证报告
    const report = {
      overall: this.calculateOverallScore(fileChecks, syntaxChecks, dependencyCheck, executionTest),
      details: {
        files: fileChecks,
        syntax: syntaxChecks,
        dependencies: dependencyCheck,
        execution: executionTest
      },
      recommendations: this.generateRecommendations(...)
    };
    
    return {
      passed: report.overall >= 0.8,
      score: report.overall,
      report,
      action: report.overall >= 0.8 ? 'proceed' : 'retry'
    };
  }
  
  // 检查点: 如果验证失败，触发代码修复迭代
  onFailure(state: CollaborationState, result: ValidationResult) {
    state.checkpoints.pending = 'code_fix';
    state.agents['code_generator'].assignments.push({
      type: 'fix',
      issues: result.report.details,
      priority: 'high'
    });
    return { action: 'retry', target: 'code_generation' };
  }
}
```

**验证维度**:
1. **文件完整性**: 所有声明的文件是否实际创建
2. **语法正确性**: 代码是否能通过编译/解析
3. **依赖完整性**: 所有import/require是否能解析
4. **可执行性**: 入口文件是否能成功运行
5. **测试通过**: 基本功能测试是否通过

---

### 现实检查Agent (Reality Check Agent)

```typescript
class RealityCheckAgent {
  role = "现实可行性验证";
  capabilities = ["技术可行性分析", "资源评估", "约束检查"];
  
  async validate(state: CollaborationState): Promise<ValidationResult> {
    const design = state.task.intermediate['design_output'];
    
    // 1. 技术可行性检查
    const techFeasibility = await this.checkTechFeasibility({
      technologies: design.technologies,
      integrations: design.integrations,
      architecture: design.architecture
    });
    
    // 2. 资源约束检查
    const resourceConstraints = await this.checkResourceConstraints({
      compute: design.computeRequirements,
      storage: design.storageRequirements,
      budget: design.budgetEstimate,
      timeline: design.timeline
    });
    
    // 3. 外部依赖检查
    const externalDeps = await this.checkExternalDependencies({
      apis: design.apiDependencies,
      services: design.thirdPartyServices,
      licenses: design.licenseRequirements
    });
    
    // 4. 风险评估
    const riskAssessment = await this.assessRisks({
      technicalRisks: design.technicalRisks,
      businessRisks: design.businessRisks,
      complianceRisks: design.complianceRisks
    });
    
    // 5. 生成可行性报告
    const report = {
      feasible: techFeasibility.feasible && 
                resourceConstraints.feasible && 
                externalDeps.available,
      score: this.calculateFeasibilityScore(...),
      concerns: this.compileConcerns(techFeasibility, resourceConstraints, externalDeps),
      mitigations: this.suggestMitigations(...),
      goNoGo: this.makeRecommendation(...)
    };
    
    return {
      passed: report.feasible && report.score >= 0.7,
      score: report.score,
      report,
      action: report.feasible ? 'proceed' : 'replan'
    };
  }
  
  // 检查点: 如果不可行，触发方案重构
  onFailure(state: CollaborationState, result: ValidationResult) {
    state.checkpoints.pending = 'design_replan';
    state.agents['architect'].assignments.push({
      type: 'replan',
      issues: result.report.concerns,
      constraints: result.report.mitigations
    });
    return { action: 'replan', target: 'design_phase' };
  }
}
```

**检查维度**:
1. **技术可行性**: 所用技术是否成熟可用
2. **资源可行性**: 计算/存储/预算/时间是否充足
3. **外部依赖**: API/服务/许可是否可获取
4. **合规性**: 是否符合法规/标准/政策
5. **风险可控**: 主要风险是否有缓解方案

---

### 交付物清单Agent (Deliverable Manifest Agent)

```typescript
class DeliverableManifestAgent {
  role = "交付物清单管理";
  capabilities = ["路径追踪", "清单生成", "完整性检查"];
  
  // 在整个协作过程中持续追踪
  track(state: CollaborationState, event: AgentEvent) {
    if (event.type === 'file_created') {
      state.deliverables.push({
        path: event.filePath,
        type: event.fileType,
        createdBy: event.agentId,
        timestamp: event.timestamp,
        description: event.description,
        verified: false
      });
    }
    
    if (event.type === 'claim_made') {
      state.claims.push({
        claim: event.claim,
        agent: event.agentId,
        expectedDeliverable: event.expectedPath,
        verified: false
      });
    }
  }
  
  async generateManifest(state: CollaborationState): Promise<Manifest> {
    // 1. 收集所有交付物
    const deliverables = state.deliverables;
    
    // 2. 分类整理
    const categorized = {
      code: deliverables.filter(d => this.isCodeFile(d)),
      docs: deliverables.filter(d => this.isDocFile(d)),
      config: deliverables.filter(d => this.isConfigFile(d)),
      assets: deliverables.filter(d => this.isAssetFile(d)),
      other: deliverables.filter(d => !this.isCategorized(d))
    };
    
    // 3. 生成清单文档
    const manifest = {
      project: state.session.id,
      generatedAt: Date.now(),
      totalFiles: deliverables.length,
      categories: categorized,
      fileTree: this.generateFileTree(deliverables),
      summary: {
        codeFiles: categorized.code.length,
        docFiles: categorized.docs.length,
        configFiles: categorized.config.length,
        totalSize: this.calculateTotalSize(deliverables)
      },
      verificationStatus: 'pending'
    };
    
    // 4. 写入清单文件
    await this.writeManifestFile(manifest, state.workingDir);
    
    return manifest;
  }
  
  // 在最终输出前强制检查
  async preDeliveryCheck(state: CollaborationState): Promise<CheckResult> {
    const manifest = await this.generateManifest(state);
    
    // 检查是否有未记录的交付物声明
    const unverifiedClaims = state.claims.filter(c => !c.verified);
    
    // 检查清单完整性
    const completeness = this.checkCompleteness(manifest, state.task.requirements);
    
    return {
      canDeliver: unverifiedClaims.length === 0 && completeness.complete,
      manifest,
      issues: [
        ...unverifiedClaims.map(c => `未验证声明: ${c.claim}`),
        ...completeness.missing.map(m => `缺失交付物: ${m}`)
      ],
      action: (unverifiedClaims.length === 0 && completeness.complete) ? 'proceed' : 'block'
    };
  }
}
```

**清单内容**:
1. **完整文件列表**: 所有创建的文件及其路径
2. **分类视图**: 按代码/文档/配置/资源分类
3. **文件树**: 目录结构可视化
4. **元数据**: 创建者、时间、大小、描述
5. **验证状态**: 每个文件的验证状态

---

### 自检Agent (Self-Check Agent)

```typescript
class SelfCheckAgent {
  role = "最终自检";
  capabilities = ["存在性验证", "内容校验", "交叉验证"];
  
  async performFinalCheck(state: CollaborationState): Promise<CheckResult> {
    const results = {
      fileExistence: [],
      contentIntegrity: [],
      claimVerification: [],
      crossReferences: []
    };
    
    // 1. 验证所有声称的文件存在
    for (const claim of state.claims) {
      const exists = await fs.exists(claim.expectedDeliverable);
      results.fileExistence.push({
        claim: claim.claim,
        path: claim.expectedDeliverable,
        exists,
        status: exists ? 'verified' : 'missing'
      });
    }
    
    // 2. 验证清单中的文件
    const manifest = state.task.intermediate['manifest'];
    for (const file of manifest.categories.all) {
      const exists = await fs.exists(file.path);
      const readable = exists ? await fs.readable(file.path) : false;
      const size = exists ? await fs.size(file.path) : 0;
      
      results.contentIntegrity.push({
        path: file.path,
        exists,
        readable,
        size,
        nonEmpty: size > 0,
        status: (exists && readable && size > 0) ? 'valid' : 'invalid'
      });
    }
    
    // 3. 交叉验证引用
    for (const doc of state.deliverables.filter(d => d.type === 'doc')) {
      const content = await fs.readFile(doc.path);
      const references = this.extractReferences(content);
      
      for (const ref of references) {
        const refExists = await fs.exists(ref.path);
        results.crossReferences.push({
          source: doc.path,
          reference: ref.path,
          exists: refExists,
          status: refExists ? 'valid' : 'broken'
        });
      }
    }
    
    // 4. 生成自检报告
    const allChecks = [
      ...results.fileExistence,
      ...results.contentIntegrity,
      ...results.crossReferences
    ];
    
    const passed = allChecks.every(c => c.status === 'verified' || c.status === 'valid');
    const failed = allChecks.filter(c => c.status === 'missing' || c.status === 'invalid' || c.status === 'broken');
    
    return {
      passed,
      score: (allChecks.length - failed.length) / allChecks.length,
      summary: {
        total: allChecks.length,
        passed: allChecks.length - failed.length,
        failed: failed.length
      },
      failures: failed,
      report: results,
      action: passed ? 'deliver' : 'rollback'
    };
  }
  
  // 如果自检失败，触发回退
  onFailure(state: CollaborationState, result: CheckResult) {
    state.checkpoints.pending = 'fix_missing';
    
    // 根据失败类型分配修复任务
    for (const failure of result.failures) {
      if (failure.status === 'missing') {
        state.agents['executor'].assignments.push({
          type: 'create_missing',
          path: failure.path,
          reason: failure.claim || 'referenced in manifest'
        });
      }
    }
    
    return { action: 'rollback', target: 'last_stable_checkpoint' };
  }
}
```

**自检维度**:
1. **存在性**: 所有声称的文件是否真实存在
2. **可读性**: 文件是否能被正常读取
3. **非空性**: 文件是否有实际内容
4. **引用完整性**: 文档中的引用是否指向存在的文件
5. **一致性**: 清单、声明、实际文件是否一致

---

### 4个Agent的协作流程

```
协作执行流程:

[任务执行] → [中间产出]
                ↓
        ┌───────┴───────┐
        │               │
        ▼               ▼
[执行验证Agent]   [现实检查Agent]
(代码/可执行性)   (设计可行性)
        │               │
        └───────┬───────┘
                ▼
        [交付物清单Agent]
        (持续追踪所有文件)
                │
                ▼
        [最终产出准备]
                │
                ▼
        [自检Agent]
        (最终验证)
                │
        ┌───────┴───────┐
        │               │
        ▼               ▼
    [通过]          [失败]
        │               │
        ▼               ▼
    [交付]      [触发修复/回退]
```

**集成到现有拓扑**:

**Pipeline模式**:
```
Stage 1: 研究 → Stage 2: 写作 → Stage 3: 审核
                                            ↓
                              [交付物清单Agent] (持续追踪)
                                            ↓
                                    [自检Agent] (最终检查)
                                            ↓
                                          输出
```

**Hub-Spoke模式**:
```
                    Hub (协调)
                      │
        ┌─────────────┼─────────────┐
        │             │             │
        ▼             ▼             ▼
   [执行验证]    [现实检查]    [交付物清单]
        │             │             │
        └─────────────┴─────────────┘
                      │
                      ▼
                [自检Agent]
                      │
                      ▼
                    输出
```

---

## 完整可执行代码

**详见附录**: `v71_implementation.md`
包含:
- StateMachine类完整实现
- Pipeline/Hub-Spoke/Mesh/Hybrid执行器
- ConvergenceDetector收敛检测
- QualityEvaluator质量评估(8维度)
- SmartCheckpoint智能检查点
- **v7.2新增**: 4个验证Agent完整实现
- 可视化状态展示

---

## 原v7架构 (保留参考)

> 以下内容为v7架构设计，供理解框架原理。

---

## 快速选择 (用户视角)

```
"快速生成报告" → L1 Pipeline (链式，20分钟)
"多方分析决策" → L2 Hub-Spoke (星形，45分钟)
"深度研究报告" → L3 Hybrid (混编，120分钟)
"创意头脑风暴" → L3 Mesh (网状，待定)
```

---

## 核心架构

### 状态机定义

```typescript
// v7 State Machine Core
interface CollaborationState {
  // 会话级
  session: {
    id: string;
    level: 'L1' | 'L2' | 'L3';
    topology: 'pipeline' | 'hub-spoke' | 'mesh' | 'hybrid';
    iteration: number;
    maxIterations: number;
    status: 'planning' | 'executing' | 'reviewing' | 'completed' | 'failed';
  };
  
  // Agent状态集合
  agents: {
    [agentId: string]: {
      role: string;
      status: 'idle' | 'working' | 'waiting' | 'completed';
      assignments: Task[];
      capabilities: string[];
    }
  };
  
  // 任务与产出
  task: {
    input: string;
    output?: string;
    intermediate: {
      [stage: string]: {
        content: string;
        qualityScore: number;
        timestamp: number;
      }
    };
  };
  
  // 质量评估
  quality: {
    dimensions: {
      [dimension: string]: {
        current: number;
        previous: number;
        threshold: number;
        converged: boolean;
      }
    };
    overall: number;
    stability: boolean;  // 连续2轮变化<5%
  };
  
  // 检查点
  checkpoints: {
    completed: string[];
    pending?: string;
    humanFeedback?: string;
  };
}
```

### 拓扑执行器

```typescript
// Pipeline 执行器
class PipelineExecutor {
  async execute(state: CollaborationState):
    // 顺序执行各阶段
    for stage in stages:
      result = await agent.execute(stage.task);
      
      // 质量守门
      quality = evaluate(result);
      if quality < threshold:
        // 触发修正
        return { action: 'retry', stage, feedback };
      
      state.task.intermediate[stage.name] = result;
    
    return { action: 'complete', output: finalResult };

// Hub-Spoke 执行器
class HubSpokeExecutor {
  async execute(state: CollaborationState):
    // 并行分派到各Spoke
    const spokeResults = await Promise.all(
      spokes.map(spoke => 
        agent.execute(spoke.assignment)
      )
    );
    
    // 中心聚合
    const consensus = await hub.consolidate(spokeResults);
    
    // 冲突检测与协商
    if (consensus.conflicts.length > 0):
      const resolved = await negotiate(consensus.conflicts);
      return { action: 'iterate', resolved };
    
    return { action: 'complete', output: consensus };

// Mesh 执行器
class MeshExecutor {
  async execute(state: CollaborationState):
    // 多轮协商
    for round = 0 to maxRounds:
      // 所有Agent同时提案
      const proposals = await Promise.all(
        agents.map(agent => agent.propose())
      );
      
      // 交叉评审
      const reviews = await Promise.all(
        agents.map(agent => 
          agent.review(proposals.filter(p => p.agent !== agent))
        )
      );
      
      // 收敛检测
      if (isConverged(proposals, reviews)):
        return { action: 'complete', output: mergeProposals(proposals) };
    
    return { action: 'timeout', partial: mergeProposals(proposals) };
```

---

## v7.2 验证层触发机制

### 触发条件矩阵

| Agent | 触发条件 | 优先级 | 阻塞性 |
|-------|----------|--------|--------|
| 执行验证Agent | 任务包含代码生成 | P0 | 是 |
| 现实检查Agent | 任务涉及架构/方案设计 | P1 | 是 |
| 交付物清单Agent | 所有任务 | P0 | 否 (持续运行) |
| 自检Agent | 最终交付前 | P0 | 是 |

### 触发时机图

```
任务开始
    │
    ▼
[交付物清单Agent启动] ─────────────────────────────┐
    │ (持续追踪)                                      │
    ▼                                               │
任务执行中...                                        │
    │                                               │
    ├─ 代码生成完成 ──→ [执行验证Agent] ──┐         │
    │         (通过?)                      │         │
    │              ├─ 是 → 继续           │         │
    │              └─ 否 → 修复迭代 ←─────┘         │
    │                                               │
    ├─ 设计完成 ─────→ [现实检查Agent] ──┐          │
    │         (可行?)                     │          │
    │              ├─ 是 → 继续          │          │
    │              └─ 否 → 重构 ←────────┘          │
    │                                               │
    ▼                                               │
准备交付                                           │
    │                                               │
    ▼                                               │
[自检Agent] ──(通过?)──┐                           │
    │                   │                           │
    ├─ 是 → [生成最终清单] ←────────────────────────┘
    │         [交付]
    │
    └─ 否 → [修复缺失] → 回退到检查点
```

### 状态流转

```typescript
// 验证层状态机
interface VerificationState {
  layer: 'execution' | 'reality' | 'manifest' | 'selfcheck';
  status: 'pending' | 'running' | 'passed' | 'failed';
  blockers: string[];
  retries: number;
  maxRetries: number;
}

// 状态流转规则
const transitions = {
  'execution': {
    passed: 'reality',
    failed: 'execution', // 自循环重试
    maxRetriesExceeded: 'human_escalation'
  },
  'reality': {
    passed: 'manifest',
    failed: 'reality',
    maxRetriesExceeded: 'human_escalation'
  },
  'manifest': {
    // 持续运行，不阻塞
    ready: 'selfcheck'
  },
  'selfcheck': {
    passed: 'deliver',
    failed: 'rollback'
  }
};
```

---

## v7 标准协作流程

### Stage 0: 任务分析与拓扑选择

```
输入: "用户任务描述"
↓
【拓扑选择器】
├─ 解析任务特征:
│   ├─ 复杂度: simple/complicated/complex
│   ├─ 多视角需求: yes/no
│   ├─ 创新要求: yes/no
│   └─ 质量要求: draft/standard/formal
│
└─ 推荐拓扑:
    ├─ 流水线 → Pipeline
    ├─ 多视角分析 → Hub-Spoke
    ├─ 创新/共识 → Mesh
    └─ 复杂项目 → Hybrid
↓
输出: { topology, level, maxIterations }
```

### Stage 1: 角色涌现与分配

```
拓扑配置 → 【角色提议器】
├─ 分析任务所需能力:
│   ├─ 信息收集能力
│   ├─ 分析推理能力
│   ├─ 创意生成能力
│   ├─ 批判评估能力
│   └─ 整合输出能力
│
└─ 动态分配Agent角色:
    ├─ Agent A: 研究Agent (信息收集)
    ├─ Agent B: 分析Agent (推理)
    └─ Agent C: 审核Agent (批判)

输出: { agents: { role, capabilities, assignments } }
```

### Stage 2: 协作执行 (核心)

根据拓扑选择执行器:

**Pipeline模式**:
```
迭代轮次 = 0
WHILE 未收敛 AND 迭代 < max:
  FOR 每个阶段 IN 阶段列表:
    分配阶段任务给对应Agent
    执行并获取结果
    
    IF 质量评分 < 阈值:
      触发"回退"到上一阶段 OR "重试"本阶段
      BREAK
    ELSE IF 质量评分明显改进:
      继续下一阶段
    ELSE IF 质量停滞:
      触发"扩展"(增加Agent或调整策略)
  
  一轮结束:
    更新质量评分
    检测收敛
    迭代轮次++
```

**Hub-Spoke模式**:
```
Hub Agent: 任务分解 + 进度协调
FOR 每个Spoke并行执行:
  Spoke_i: 执行分配的子任务
  
All Spokes完成 → Hub聚合:
  IF 结果一致:
    输出共识
  ELSE:
    识别冲突点
    触发协商轮次:
      FOR 冲突点:
        相关Spoke辩论
        Hub裁决 OR 投票决定
    重新聚合直到一致 OR 达到最大协商轮次
```

**Mesh模式**:
```
FOR 协商轮次 = 0 TO maxRounds:
  // 提案阶段
  所有Agent同时生成提案
  
  // 评审阶段
  Agent A评审Agent B和C的提案
  Agent B评审Agent A和C的提案
  Agent C评审Agent A和B的提案
  
  // 更新阶段
  每个Agent根据评审更新自己的提案
  
  // 收敛检测
  IF 提案变化率 < epsilon AND 质量达标:
    收敛，输出整合提案
    BREAK
  
  IF 多轮无进展:
    触发人类介入 OR 强制收敛
```

### Stage 3: 质量评估与收敛检测

```
【质量评估器】
输入: 当前产出
↓
8维度评分:
├─ 数据充实度 (0-10)
├─ 分析深度 (0-10)
├─ 逻辑连贯性 (0-10)
├─ 框架完整性 (0-10)
├─ 可操作性 (0-10)
├─ 数据溯源 (0-10)
├─ 可视化质量 (0-10)
└─ 专业性 (0-10)

综合得分 = average(8维度)

【收敛检测器】
当前评分 Q(t)
上一评分 Q(t-1)

收敛条件:
├─ 综合得分 >= 7.0 (B级以上)
├─ |Q(t) - Q(t-1)| < 0.5 (连续稳定性)
└─ 关键维度得分 >= 6.0

输出: { converged: boolean, action: "continue|complete|escalate" }
```

### Stage 4: 决策与动作

```
收敛检测结果 → 【决策器】

CASE converged:
  TRUE:
    触发人机检查点(如果是L3)
    用户批准后 → 输出最终文档
    记录协作配置到学习系统
    
  FALSE:
    IF 达到maxIterations:
      触发人机检查点询问: 
        "是否继续迭代?"
        "接受当前质量?"
        "切换拓扑?"
    
    IF 质量停滞(连续3轮无提升):
      策略调整:
        ├─ 增加Agent角色
        ├─ 切换交互模式(对话→辩论)
        └─ 触发人类介入
    
    IF 质量下降:
      触发回退(Rollback)到上一稳定状态
      分析失败原因
      调整策略重试

输出: { action, nextState }
```

---

## v7 协作模板 (可直接使用)

### 【L1-Pipeline】快速报告生成

```yaml
collaboration:
  level: L1
  topology: pipeline
  stages:
    - name: research
      role: researcher
      task: "收集关键数据点10-15条"
      qualityGate: 0.6
      
    - name: synthesis
      role: writer
      task: "整合数据为500-1000字初稿"
      qualityGate: 0.5
      
  maxIterations: 2
  timeout: 20min

收敛条件:
  - 数据点完整
  - 初稿通顺
  - 无明显缺失
```

### 【L2-HubSpoke】多方决策分析

```yaml
collaboration:
  level: L2
  topology: hub-spoke
  
  hub:
    role: coordinator
    tasks: ["任务分解", "进度协调", "冲突裁决"]
  
  spokes:
    - name: supporter
      role: advocate
      task: "列出所有支持理由和收益"
      
    - name: critic
      role: devilAdvocate
      task: "列出所有风险和问题"
      
    - name: analyst
      role: analyst
      task: "分析数据可行性和量化指标"
  
  convergence:
    rounds: 3
    strategy: vote
    threshold: majority
    
  maxIterations: 5
  timeout: 45min

收敛条件:
  - 各Spoke输出完整
  - 投票达成共识
  - 保留意见记录
```

### 【L3-Hybrid】深度研究报告

```yaml
collaboration:
  level: L3
  topology: hybrid
  
  stages:
    # Stage 1: Pipeline - 信息流水线
    - topology: pipeline
      phases:
        - name: deep_research
          role: researcher
          task: "多源采集30-50条核心事实"
          qualityGate: 0.8
          
        - name: data_validation
          role: validator
          task: "执行三层幻觉防线检测"
          qualityGate: 0.85
    
    # Stage 2: Hub-Spoke - 多视角分析
    - topology: hub-spoke
      hub: coordinator
      spokes:
        - market_analyst
        - technical_analyst
        - risk_analyst
        - competitive_analyst
      consensus: meritocratic
      
    # Stage 3: Mesh - 共识达成
    - topology: mesh
      agents: [synthesist, critic, editor]
      convergence: debate
      maxRounds: 3
      
    # Stage 4: Pipeline - 质量输出
    - topology: pipeline
      phases:
        - report_writing
        - red_team_review
        - final_editing
        
  checkpoints:
    - after: data_validation
      human: "确认数据质量和框架选择"
    - after: hub-spoke
      human: "确认分析方向是否完整"
    - after: mesh
      human: "确认共识内容"
      
  quality:
    dimensions: 8
    threshold: 7.0
    stabilityRounds: 2
    
  maxIterations: 10
  timeout: 150min

收敛条件:
  - 综合评分>=7.0
  - 连续2轮变化<5%
  - 关键维度无低于6.0
  - 人工最终确认
```

---

### v7.2 新增: 验证层集成到质量保证

```
【防线4】执行验证 (代码任务必检)
检测:
├─ 文件是否真实创建
├─ 代码语法是否正确
├─ 依赖是否完整
├─ 是否能成功运行
└─ 测试是否通过

处理:
├─ 验证失败 → 自动触发修复迭代
├─ 超过3次失败 → 升级人工介入
└─ 验证通过 → 进入下一防线

【防线5】现实检查 (设计任务必检)
检测:
├─ 技术方案是否可行
├─ 资源需求是否满足
├─ 外部依赖是否可用
├─ 合规性是否达标
└─ 风险是否可控

处理:
├─ 不可行 → 触发方案重构
├─ 有风险 → 标记风险并继续
└─ 可行 → 进入下一防线

【防线6】交付物清单 (所有任务)
检测:
├─ 所有创建的文件是否被记录
├─ 清单是否完整准确
├─ 分类是否正确
└─ 元数据是否齐全

处理:
├─ 清单不完整 → 阻止交付
├─ 补充缺失记录 → 继续
└─ 清单完整 → 进入最终防线

【防线7】最终自检 (交付前必检)
检测:
├─ 所有声称文件是否存在
├─ 文件是否可读非空
├─ 引用是否完整
├─ 清单-声明-实际是否一致

处理:
├─ 自检失败 → 回退到修复点
├─ 修复后重检 → 循环直到通过
└─ 自检通过 → 正式交付
```

---

## v7 质量保证 (三层防线)

### 防线1: 数据溯源 (每轮必检)

```
检测:
├─ [✓] 有来源: 在findings.md中找到
├─ [○] 推断: 基于数据的合理推断 → 需标注"AI推断"
└─ [✗] 幻觉: 无法验证 → 必须标记并修正

处理:
├─ [✗] → 立即回退到数据采集阶段
├─ [○] → 记录并提醒用户
└─ [✓] → 通过
```

### 防线2: 逻辑一致性 (迭代中检测)

```
检测:
├─ 百分比之和是否超过100%?
├─ 增长率和绝对值是否匹配?
├─ 章节间数据是否矛盾?
├─ 时间线是否连续?
└─ 因果关系是否合理?

处理:
├─ 发现矛盾 → 标记冲突点 → 触发协商
├─ 发现跳跃 → 补充过渡论证
└─ 无法解决 → 标记风险并降级质量预期
```

### 防线3: 时效性 (L3必检)

```
检测:
├─ 每个数据必须标注采集时间
├─ 过时数据(>6个月)不得当作最新使用
├─ 趋势数据必须说明时间窗口

处理:
├─ 过时数据 → 重新搜索更新
└─ 无法更新 → 明确标注"历史数据"并降低权重
```

---

### v7.2 新增: 验证层失败处理

```
【验证失败处理矩阵】

| 失败类型 | 自动重试 | 人工介入 | 回退策略 |
|----------|----------|----------|----------|
| 执行验证-语法错误 | 3次 | 第4次 | 回退到编码阶段 |
| 执行验证-依赖缺失 | 2次 | 第3次 | 回退到设计阶段 |
| 执行验证-运行失败 | 3次 | 第4次 | 回退到编码阶段 |
| 现实检查-技术不可行 | 1次 | 第2次 | 回退到架构阶段 |
| 现实检查-资源不足 | 0次 | 立即 | 标记风险继续 |
| 自检-文件缺失 | 2次 | 第3次 | 回退到创建阶段 |
| 自检-引用断裂 | 2次 | 第3次 | 回退到文档阶段 |

【验证层升级策略】

Level 1: 自动修复
- 语法错误 → 触发代码修复Agent
- 依赖缺失 → 自动安装/更新依赖
- 简单文件缺失 → 自动重新生成

Level 2: 策略调整
- 多次失败 → 切换实现方案
- 依赖冲突 → 寻找替代方案
- 资源不足 → 调整规模/范围

Level 3: 人工决策
- 技术不可行 → 用户确认是否继续
- 重大风险 → 用户评估接受度
- 多次失败后 → 用户决定终止/继续
```

---

## v7 失败处理机制

### Retry (重试)

```
何时触发:
- Agent执行失败(网络/工具错误)
- 质量评分略低于阈值
- 单次尝试未达预期

策略:
- 最多重试3次
- 每次调整参数或策略
- 记录失败原因
```

### Rollback (回退)

```
何时触发:
- 质量明显下降(本轮<上轮)
- 引入新错误
- 方向偏离

策略:
- 回退到上一稳定检查点
- 分析失败原因
- 调整策略后重试
- 保留失败记录供学习
```

### Replan (重构)

```
何时触发:
- 多次尝试无果
- 当前拓扑明显不适合
- 任务理解偏差

策略:
- 终止当前执行
- 重新分析任务
- 切换拓扑或增加Agent
- 触发人机确认
```

### Escalate (升级)

```
何时触发:
- 达到maxIterations未收敛
- 检测到复杂冲突无法协商
- 需要人类专业知识

策略:
- 暂停执行
- 生成诊断报告
- 提交人工决策
- 根据决策调整或终止
```

---

### v7.2 新增: 验证层状态可视化

```
协作状态: [任务名]

拓扑: [Pipeline|Hub-Spoke|Mesh|Hybrid]  级别: [L1|L2|L3]
迭代: [n/m]  状态: [planning|executing|reviewing|completed|failed]

Agents状态:
├─ [Agent A] [🟢working] [role] [task progress] [quality: x.x]
├─ [Agent B] [🟡waiting] [role] [completed] [quality: x.x]
├─ [执行验证] [✅passed] [代码检查] [3/3文件通过]
├─ [现实检查] [⏳pending] [可行性分析] [等待设计完成]
├─ [交付清单] [🟢active] [持续追踪] [已记录12个文件]
└─ [自检Agent] [⏸️idle] [最终检查] [等待交付准备]

验证层状态:
┌─────────────────────────────────────────┐
│ 防线4: 执行验证     [✅通过]  分数: 0.92  │
│   ├─ 文件完整性:  ✅ 3/3                │
│   ├─ 语法正确性:  ✅ 无错误              │
│   ├─ 依赖完整性:  ✅ 全部解析            │
│   └─ 可执行性:    ✅ 测试通过            │
├─────────────────────────────────────────┤
│ 防线5: 现实检查     [⏳等待]  进度: 60%  │
│   ├─ 技术可行性:  ✅ 已验证              │
│   ├─ 资源约束:    ⏳ 评估中              │
│   └─ 外部依赖:    ⏳ 检查中              │
├─────────────────────────────────────────┤
│ 防线6: 交付清单     [🟢运行]  已记录: 12 │
│   ├─ 代码文件:    5个                    │
│   ├─ 文档文件:    4个                    │
│   ├─ 配置文件:    2个                    │
│   └─ 其他:        1个                    │
├─────────────────────────────────────────┤
│ 防线7: 最终自检     [⏸️未开始]           │
└─────────────────────────────────────────┘

质量趋势:
  迭代1: ████████░░░░░░░░░░░░░░ 40%
  迭代2: ███████████░░░░░░░░░░░ 55%
  迭代3: ██████████████░░░░░░░░ 70% ← 当前
  
收敛预测:
├─ 综合质量: [B级] [预计2轮后收敛]
├─ 验证状态: [⚠️等待现实检查]
└─ 交付准备: [预计10分钟后可交付]

当前动作: [现实检查Agent 评估资源约束...] [预计3分钟后完成]
```

---

## 协作状态可视化 (文本形式)

```
Collaboration v7: [任务名]

拓扑: [Pipeline|Hub-Spoke|Mesh|Hybrid]  级别: [L1|L2|L3]
迭代: [n/m]  状态: [planning|executing|reviewing|completed|failed]

Agents状态:
├─ [Agent A] [🟢working] [role] [task progress] [quality: x.x]
├─ [Agent B] [🟡waiting] [role] [completed] [quality: x.x]
└─ [Agent C] [⏸️idle] [role] [...] [...]

质量趋势:
  迭代1: ████████░░░░░░░░░░░░░░ 40%
  迭代2: ███████████░░░░░░░░░░░ 55%
  迭代3: ██████████████░░░░░░░░ 70% ← 当前
  
收敛预测:
├─ 综合质量: [B级] [预计2轮后收敛]
├─ 稳定性: [⚠️警告] [近2轮变化15% > 10%阈值]
└─ 瓶颈维度: [数据充实度, 可操作性]

当前动作: [Agent B 执行中...] [预计2分钟后完成]
```

---

## 人机协作检查点

### L1检查点 (可选)

```
[检查点: 初稿完成]
━━━━━━━━━━━━━━━━━━━━
产出预览: [500字摘要...]

当前质量: [B-] 预估 [15分钟完成]

选项:
1. [继续] → 进入最终输出
2. [深化] → 升级为L2模式
3. [修改] → 请输入修改意见
━━━━━━━━━━━━━━━━━━━━
```

### L3检查点 (强制)

```
[检查点: Stage 1完成 - 数据质量确认]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

数据质量报告:
├─ 采集来源: 15个
├─ 数据点数: 42条
├─ 验证通过: 39条 (93%)
├─ AI推断: 2条 (已标注)
├─ 疑似幻觉: 1条 (待确认)

幻觉检测详情:
├─ 问题: "市场规模达500亿" - [来源??]
└─ 建议: 重新搜索确认或删除

框架选择: PESTLE分析
├─ 覆盖维度: 政治/经济/社会/技术 ✅
├─ 缺失: 法律/环境 (可选)

选项:
1. [确认并继续] → 进入Stage 2
2. [修正数据质量] → 返回采集
3. [切换框架] → 重新选择
4. [增加维度] → 补充法律/环境

预计剩余时间: 90分钟
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### v7.2 新增: 验证层触发词

```
"生成可执行代码..." → 触发执行验证Agent
"设计方案..." → 触发现实检查Agent  
"确保交付完整..." → 强化交付物清单Agent
"最终检查..." → 触发完整验证层
"生产就绪..." → 启用全部7层防线
```

---

## v7 触发词

```
"深度研究..." → L3 Hybrid
"多方分析..." → L2 Hub-Spoke
"深度协作生成..." → L3 (拓扑自动选择)
"涌现分析..." → L3 Mesh (创新任务)
"质量优先..." → 触发三层防线完整版
"快速草案..." → L1 Pipeline
```

---

## 版本演进

| 版本 | 核心变化 | 适用场景 |
|------|---------|---------|
| v5 | 20种方法，近半不可用 | 归档 |
| v6.0 | 现实对齐，9种模板 | 基础使用 |
| v6.1 | 三级模式(L1/L2/L3) | 当前稳定版 |
| **v7.0** | **六维协作模型** | **高级复杂任务** |
| v7.1 | 学习机制，跨任务记忆 | 进化中 |
| v7.2 | MCP集成，外部Agent | 生态扩展 |

---

### v7.2 版本更新

| 版本 | 核心变化 | 适用场景 |
|------|---------|---------|
| v5 | 20种方法，近半不可用 | 归档 |
| v6.0 | 现实对齐，9种模板 | 基础使用 |
| v6.1 | 三级模式(L1/L2/L3) | 当前稳定版 |
| v7.0 | 六维协作模型 | 高级复杂任务 |
| v7.1 | 可执行代码架构 | 生产环境 |
| **v7.2** | **交付验证层(4个验证Agent)** | **生产级交付** |
| v7.3 | MCP集成，外部Agent | 生态扩展 |

---

**设计哲学**: 从"任务流水线"进化为"认知生态系统" —— 不是执行预定义流程，而是引导智能涌现。

**v7.2核心理念**: 从"产出内容"进化为"交付价值" —— 不仅生成结果，更确保结果真实、可行、完整、可交付。

**一句话**: v7让多Agent从"分工"走向"协作"，从"执行"走向"思考"，从"轮次"走向"收敛"；v7.2让协作从"产出"走向"交付"。