# Bitcoin On-Chain Analysis Guide

## Overview
利用链上数据分析比特币市场趋势，追踪鲸鱼动向，评估市场健康度。

## Key Metrics

### MVRV Ratio (Market Value to Realized Value)
```
MVRV = Market Cap / Realized Cap
- MVRV < 1: Undervalued (historical buy zone)
- MVRV 1-2: Fair value
- MVRV > 3.5: Overvalued (sell signal)
```

### NUPL (Net Unrealized Profit/Loss)
```
NUPL = (Market Cap - Realized Cap) / Market Cap
- < 0: Capitulation (everyone in loss)
- 0-0.25: Optimism returning
- 0.25-0.5: Belief/denial
- 0.5-0.75: FOMO
- > 0.75: Euphoria (sell signal)
```

### Whale Tracking
- **Exchange inflow**: Whales moving BTC to exchanges → potential selling
- **Exchange outflow**: BTC leaving exchanges → accumulation
- **Dormant coins**: Coins moving after long periods → historical holder activity

## Data Sources (Free APIs)

### Mempool.space
```bash
# Current mempool stats
curl https://mempool.space/api/v1/fees/mempool

# Block template
curl https://mempool.space/api/v1/block-template
```

### Blockchain.com
```bash
# Latest block
curl https://blockchain.info/latestblock

# Single address transactions
curl https://blockchain.info/rawaddr/1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa?limit=50
```

## Fear & Greed as Contrarian Signal
Historical analysis shows extreme fear (≤15) is often a buy signal for BTC:
- 2020 March: Fear=8 → BTC bottomed at $3.8K, later reached $64K
- 2022 June: Fear=8 → BTC bottomed at $17.6K, later reached $69K
- Pattern: Extended extreme fear (>10 days) → compressed spring effect

## On-Chain Signal Dashboard
```
Daily Check:
1. Exchange Net Flow → +10K BTC/day = selling pressure
2. Active Addresses → Declining = network cooling
3. Hash Rate → Rising = miner confidence
4. MVRV Ratio → <1.5 = room to grow
5. NUPL → <0.25 = opportunity zone
6. Fear & Greed → ≤15 = contrarian buy
```

## Practical Trading Integration
Combine on-chain metrics with price action:
```
Buy Signal = (MVRV < 1.5) AND (Fear ≤ 20) AND (Exchange Net Flow < -5K)
Sell Signal = (MVRV > 3) AND (Fear ≥ 75) AND (Exchange Inflow > 10K)
```