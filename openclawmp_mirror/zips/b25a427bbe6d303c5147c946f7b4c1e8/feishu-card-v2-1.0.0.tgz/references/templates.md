# 卡片模板示例

## 简洁通知卡片

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "blue",
    "title": {"tag": "plain_text", "content": "通知标题"}
  },
  "body": {
    "elements": [
      {"tag": "markdown", "content": "通知正文内容，支持 **粗体** 和 [链接](https://example.com)。"}
    ]
  }
}
```

## 报告卡片（带数据面板）

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "indigo",
    "title": {"tag": "plain_text", "content": "每日数据报告"},
    "subtitle": {"tag": "plain_text", "content": "2026-02-26"}
  },
  "body": {
    "elements": [
      {
        "tag": "column_set",
        "flex_mode": "bisect",
        "columns": [
          {"tag": "column", "width": "weighted", "weight": 1,
           "elements": [{"tag": "markdown", "content": "**活跃用户**\n12,345"}]},
          {"tag": "column", "width": "weighted", "weight": 1,
           "elements": [{"tag": "markdown", "content": "**新增注册**\n678"}]}
        ]
      },
      {"tag": "hr"},
      {"tag": "markdown", "content": "**趋势**\n- DAU 环比 +5.2%\n- 注册转化率 12.3%\n- 留存率 45.6%"},
      {"tag": "hr"},
      {"tag": "markdown", "content": "*数据来源：Analytics Dashboard*"}
    ]
  }
}
```

## 教程/文档卡片

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "orange",
    "title": {"tag": "plain_text", "content": "使用指南"},
    "subtitle": {"tag": "plain_text", "content": "快速上手"}
  },
  "body": {
    "elements": [
      {"tag": "markdown", "content": "**Step 1 — 准备工作**\n描述第一步操作内容"},
      {"tag": "markdown", "content": "**Step 2 — 核心操作**\n```\n代码示例\n```"},
      {"tag": "markdown", "content": "**Step 3 — 验证结果**\n检查输出是否符合预期"},
      {"tag": "hr"},
      {"tag": "markdown", "content": "**注意事项**\n- 要点一\n- 要点二\n- 要点三"}
    ]
  }
}
```

## 告警卡片

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "red",
    "title": {"tag": "plain_text", "content": "告警：服务异常"},
    "subtitle": {"tag": "plain_text", "content": "严重级别：P1"}
  },
  "body": {
    "elements": [
      {"tag": "markdown", "content": "**时间**：2026-02-26 11:30 CST\n**服务**：api-gateway\n**状态**：响应超时 >5s"},
      {"tag": "hr"},
      {"tag": "markdown", "content": "**影响范围**\n- 全部 API 请求\n- 预计影响用户数：~2000"},
      {"tag": "hr"},
      {"tag": "markdown", "content": "**处置建议**\n1. 检查上游依赖状态\n2. 查看最近部署记录\n3. 考虑回滚最近变更"}
    ]
  }
}
```

## 交互按钮卡片（重要！Schema 2.0）

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "green",
    "title": {"tag": "plain_text", "content": "请选择操作"}
  },
  "body": {
    "elements": [
      {"tag": "markdown", "content": "**选择一个选项继续：**"},
      {"tag": "hr"},
      {"tag": "button", "text": {"tag": "plain_text", "content": "✅ 确认"}, "type": "primary", "value": {"action": "confirm"}},
      {"tag": "button", "text": {"tag": "plain_text", "content": "❌ 取消"}, "type": "default", "value": {"action": "cancel"}}
    ]
  }
}
```

**⚠️ 注意**：Schema 2.0 中按钮必须直接放在 elements 里，不能用 `action` 包裹！
