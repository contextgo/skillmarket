#!/usr/bin/env python3
"""
send_card.py — 飞书卡片消息发送脚本

Usage:
    python3 send_card.py --chat-id <chat_id> --card-file <card.json>
    python3 send_card.py --chat-id <chat_id> --card '<json_string>'
    echo '<json>' | python3 send_card.py --chat-id <chat_id> --stdin

Environment:
    FEISHU_APP_ID       — 飞书应用 App ID
    FEISHU_APP_SECRET   — 飞书应用 App Secret

    If not set, the script will attempt to read from OpenClaw config:
    ~/.openclaw/openclaw.json -> feishu.appId / feishu.appSecret
"""

import argparse
import json
import os
import sys

FEISHU_API = "https://open.feishu.cn"


def load_openclaw_feishu_config():
    """Try to load feishu credentials from OpenClaw config."""
    config_path = os.path.expanduser("~/.openclaw/openclaw.json")
    if not os.path.exists(config_path):
        return None, None
    try:
        with open(config_path) as f:
            config = json.load(f)
        feishu = config.get("channels", {}).get("feishu", {})
        if not feishu:
            feishu = config.get("feishu", {})
        return feishu.get("appId"), feishu.get("appSecret")
    except Exception:
        return None, None


def get_credentials():
    """Get app_id and app_secret from env or config."""
    app_id = os.environ.get("FEISHU_APP_ID")
    app_secret = os.environ.get("FEISHU_APP_SECRET")
    if not app_id or not app_secret:
        app_id, app_secret = load_openclaw_feishu_config()
    if not app_id or not app_secret:
        print("ERROR: FEISHU_APP_ID and FEISHU_APP_SECRET must be set", file=sys.stderr)
        sys.exit(1)
    return app_id, app_secret


def send_card(chat_id, card_dict):
    """Send interactive card message using lark_oapi SDK."""
    try:
        import lark_oapi as lark
        from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody
    except ImportError:
        print("ERROR: lark-oapi not installed. Run: pip install lark-oapi", file=sys.stderr)
        sys.exit(1)
    
    app_id, app_secret = get_credentials()
    client = lark.Client.builder().app_id(app_id).app_secret(app_secret).build()
    
    # Determine receive_id_type based on chat_id format
    receive_id_type = "open_id" if chat_id.startswith("ou_") else "chat_id"
    
    request = CreateMessageRequest.builder() \
        .receive_id_type(receive_id_type) \
        .request_body(
            CreateMessageRequestBody.builder()
            .receive_id(chat_id)
            .msg_type("interactive")
            .content(json.dumps(card_dict))
            .build()
        ).build()
    
    response = client.im.v1.message.create(request)
    if response.code != 0:
        print(f"ERROR: Send failed: {response.msg}", file=sys.stderr)
        sys.exit(1)
    print(json.dumps({"code": 0, "message_id": response.data.message_id}, ensure_ascii=False))
    return response


def main():
    parser = argparse.ArgumentParser(description="Send Feishu interactive card message")
    parser.add_argument("--chat-id", required=True, help="Target chat_id (oc_xxx)")
    parser.add_argument("--card-file", help="Path to card JSON file")
    parser.add_argument("--card", help="Card JSON as string argument")
    parser.add_argument("--stdin", action="store_true", help="Read card JSON from stdin")
    args = parser.parse_args()

    # Load card JSON
    if args.stdin:
        card_str = sys.stdin.read()
    elif args.card_file:
        with open(args.card_file) as f:
            card_str = f.read()
    elif args.card:
        card_str = args.card
    else:
        print("ERROR: Provide --card-file, --card, or --stdin", file=sys.stderr)
        sys.exit(1)

    try:
        card_dict = json.loads(card_str)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    send_card(args.chat_id, card_dict)


if __name__ == "__main__":
    main()
