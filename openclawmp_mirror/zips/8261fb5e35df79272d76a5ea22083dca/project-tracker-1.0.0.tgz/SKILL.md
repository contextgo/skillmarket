---
name: project-tracker
displayName: 广告AE项目追踪器
description: 专为广告AE设计的项目管理工具，帮助您追踪项目进度、控制预算、识别风险
version: 1.0.0
type: skill
category: business
tags: project-management,gantt,budget,risk,advertising
---

# 项目追踪器 (project-tracker)

专为广告AE设计的项目管理工具，帮助您追踪项目进度、控制预算、识别风险。

## 核心功能

### 📋 任务导入 (import-tasks)
支持 JSON/CSV/Excel 格式的任务列表导入，自动解析项目结构。

### 📅 甘特图生成 (generate-gantt)
一键生成项目甘特图（PNG/PDF），清晰展示任务时间轴与依赖关系。

### 💰 预算跟踪 (budget-tracker)
实时计算预算使用率，超支自动预警（>80%提醒，>90%严重）。

### ⚠️ 风险识别 (risk-assessment)
自动检测项目风险：任务延期、资源冲突、预算超支、关键路径阻塞。

## 适用场景

- 广告campaign执行管理
- 多项目资源协调
- 客户进度汇报
- 季度/年度项目复盘

## 快速示例

```bash
# 导入任务数据
project-tracker import-tasks --file tasks.json --format json

# 生成甘特图
project-tracker generate-gantt --output gantt.png --title "Q1品牌campaign"

# 检查预算
project-tracker budget-check --threshold 0.85

# 风险评估
project-tracker risk-assessment --output risks.json
```

## 数据格式

任务JSON示例：
```json
{
  "project_name": "XX品牌春季campaign",
  "start_date": "2025-03-01",
  "tasks": [
    {
      "id": 1,
      "name": "策略简报",
      "start": "2025-03-01",
      "end": "2025-03-05",
      "owner": "张三",
      "budget": 10000,
      "status": "completed",
      "dependencies": []
    },
    {
      "id": 2,
      "name": "创意设计",
      "start": "2025-03-06",
      "end": "2025-03-15",
      "owner": "李四",
      "budget": 15000,
      "status": "in_progress",
      "dependencies": [1]
    }
  ],
  "budget_total": 50000
}
```

## 安装

```bash
cd project-tracker
pip install -r requirements.txt
```
