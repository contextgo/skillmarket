#!/usr/bin/env python3
"""
广告项目追踪器
功能：任务导入、甘特图生成、预算跟踪、风险识别
"""

import typer
from rich.console import Console
from rich.table import Table
from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from datetime import datetime, timedelta
import sys

# 配置中文字体支持（macOS/Heiti TC）
def configure_matplotlib_fonts():
    """配置 matplotlib 中文字体，避免乱码"""
    # 查找系统中可用的中文字体
    chinese_fonts = []
    for f in fm.fontManager.ttflist:
        # Heiti TC, PingFang, SimHei, Microsoft YaHei, STSong 等
        if any(keyword in f.name for keyword in ['Heiti', 'PingFang', 'SimHei', 'Microsoft YaHei', 'STSong', 'AR PL']):
            chinese_fonts.append(f.fname)
    
    if chinese_fonts:
        # 优先使用 Heiti TC (macOS 系统黑体)
        selected_font = chinese_fonts[0]
        plt.rcParams['font.family'] = ['Heiti TC', 'sans-serif']
        plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示为方框的问题
        return selected_font
    else:
        # 降级方案：使用 Pillow 渲染中文（这里保留原有行为，可能还是会乱码）
        return None

# 初始化字体配置
FONT_PATH = configure_matplotlib_fonts()

app = typer.Typer(help="广告项目追踪与风险管理工具")
console = Console()

# 数据文件缓存
PROJECT_DATA = None

def load_project(file_path: Path, fmt: str = "auto") -> dict:
    """加载项目数据"""
    global PROJECT_DATA
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    if fmt == "auto":
        suffix = file_path.suffix.lower()
        if suffix == ".json":
            fmt = "json"
        elif suffix in [".csv", ".tsv"]:
            fmt = "csv"
        elif suffix in [".xlsx", ".xls"]:
            fmt = "excel"
        else:
            raise ValueError(f"无法识别的文件格式: {suffix}")
    
    if fmt == "json":
        with open(file_path, "r", encoding="utf-8") as f:
            PROJECT_DATA = json.load(f)
    elif fmt == "csv":
        df = pd.read_csv(file_path)
        PROJECT_DATA = df.to_dict(orient="records")
        # 转换为标准结构
        PROJECT_DATA = {
            "project_name": "未命名项目",
            "tasks": PROJECT_DATA
        }
    elif fmt == "excel":
        df = pd.read_excel(file_path)
        PROJECT_DATA = df.to_dict(orient="records")
        PROJECT_DATA = {
            "project_name": "未命名项目",
            "tasks": PROJECT_DATA
        }
    else:
        raise ValueError(f"不支持的格式: {fmt}")
    
    # 标准化任务字段
    for task in PROJECT_DATA["tasks"]:
        task.setdefault("status", "pending")
        task.setdefault("budget", 0)
        task.setdefault("dependencies", [])
        # 确保日期为字符串
        if "start" in task and isinstance(task["start"], (datetime, pd.Timestamp)):
            task["start"] = task["start"].strftime("%Y-%m-%d")
        if "end" in task and isinstance(task["end"], (datetime, pd.Timestamp)):
            task["end"] = task["end"].strftime("%Y-%m-%d")
    
    return PROJECT_DATA

@app.command()
def import_tasks(
    file: Path = typer.Option(..., "--file", "-f", help="任务文件路径 (JSON/CSV/Excel)"),
    format: str = typer.Option("auto", "--format", help="文件格式: auto | json | csv | excel")
):
    """
    导入项目任务数据
    
    示例:
        project-tracker import-tasks --file project_tasks.json
        project-tracker import-tasks --file tasks.csv --format csv
    """
    try:
        data = load_project(file, format)
        console.print(f"[green]✅ 成功导入项目: {data.get('project_name', '未命名项目')}[/green]")
        console.print(f"任务数量: {len(data['tasks'])}")
        
        # 显示概览
        total_budget = sum(t.get("budget", 0) for t in data["tasks"])
        console.print(f"总预算: ¥{total_budget:,.0f}")
        
        # 按状态统计
        status_counts = {}
        for task in data["tasks"]:
            status = task.get("status", "pending")
            status_counts[status] = status_counts.get(status, 0) + 1
        
        table = Table(title="任务状态统计")
        table.add_column("状态", style="cyan")
        table.add_column("数量", justify="right", style="magenta")
        for status, count in status_counts.items():
            table.add_row(status, str(count))
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]❌ 导入失败: {e}[/red]")
        raise typer.Exit(1)

@app.command()
def generate_gantt(
    output: Path = typer.Option(..., "--output", "-o", help="输出图片路径 (PNG/PDF)"),
    title: str = typer.Option("项目甘特图", "--title", "-t", help="图表标题"),
    show_dependencies: bool = typer.Option(True, "--dependencies/--no-dependencies", help="显示依赖关系")
):
    """
    生成项目甘特图
    
    需要先 import-tasks 加载数据
    """
    global PROJECT_DATA
    if PROJECT_DATA is None:
        console.print("[yellow]⚠️ 请先使用 import-tasks 加载项目数据[/yellow]")
        raise typer.Exit(1)
    
    tasks = PROJECT_DATA["tasks"]
    
    # 转换为 DataFrame
    df_data = []
    for idx, task in enumerate(tasks):
        start = pd.to_datetime(task["start"])
        end = pd.to_datetime(task["end"])
        duration = (end - start).days + 1
        
        # 颜色映射：不同状态不同颜色
        status = task.get("status", "pending")
        color_map = {
            "completed": "#4CAF50",  # 绿色
            "in_progress": "#2196F3", # 蓝色
            "pending": "#FF9800",    # 橙色
            "delayed": "#F44336"     # 红色
        }
        color = color_map.get(status, "#9E9E9E")
        
        df_data.append({
            "Task": task["name"],
            "Start": start,
            "Finish": end,
            "Duration": duration,
            "Owner": task.get("owner", "未分配"),
            "Status": status,
            "Color": color,
            "ID": task.get("id", idx+1)
        })
    
    df = pd.DataFrame(df_data)
    df = df.sort_values("Start")
    
    # 创建甘特图
    fig, ax = plt.subplots(figsize=(14, len(tasks) * 0.5 + 2))
    
    # 确保字体设置生效（防范某些后端重置）
    ax.set_xlabel("日期", fontsize=10)
    ax.set_title(f"{PROJECT_DATA.get('project_name', '项目')} - {title}", fontsize=14, fontweight="bold", pad=20)
    
    # 绘制条形
    for i, (_, row) in enumerate(df.iterrows()):
        ax.barh(
            y=i,
            width=row["Duration"],
            left=row["Start"],
            color=row["Color"],
            edgecolor="black",
            linewidth=0.5,
            height=0.6
        )
        
        # 添加任务标签
        ax.text(
            row["Start"] - timedelta(days=1),
            i,
            f" {row['Task']} ({row['Owner']})",
            va="center",
            ha="right",
            fontsize=9,
            color="#333"
        )
    
    # 坐标轴设置
    ax.set_yticks(range(len(df)))
    ax.set_yticklabels([f"T{i+1}" for i in range(len(df))])
    ax.invert_yaxis()  # 最早的显示在最上面
    
    # 网格
    ax.grid(axis="x", alpha=0.3)
    
    # 标题与标签
    ax.set_title(f"{PROJECT_DATA.get('project_name', '项目')} - {title}", fontsize=14, fontweight="bold", pad=20)
    ax.set_xlabel("日期", fontsize=10)
    
    # 今日线
    today = pd.Timestamp(datetime.now().date())
    if df["Start"].min() <= today <= df["Finish"].max():
        ax.axvline(x=today, color="red", linestyle="--", linewidth=1.5, alpha=0.7)
        ax.text(today, len(df)+0.5, " 今天", color="red", fontsize=9, va="bottom")
    
    # 调整布局
    plt.tight_layout()
    
    # 保存
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=150, bbox_inches="tight")
    plt.close()
    
    console.print(f"[green]✅ 甘特图已生成: {output}[/green]")
    console.print(f"📊 包含 {len(tasks)} 个任务")

@app.command()
def budget_check(
    threshold: float = typer.Option(0.85, "--threshold", "-t", help="预警阈值 (0-1)")
):
    """
    检查预算使用情况
    
    输出：已超支任务、即将超支任务
    """
    global PROJECT_DATA
    if PROJECT_DATA is None:
        console.print("[yellow]⚠️ 请先使用 import-tasks 加载项目数据[/yellow]")
        raise typer.Exit(1)
    
    tasks = [t for t in PROJECT_DATA["tasks"] if t.get("budget", 0) > 0]
    if not tasks:
        console.print("[yellow]⚠️ 项目中没有预算数据[/yellow]")
        return
    
    # 假设有实际花费字段，如果没有则用估算 (此处需手动输入测试数据)
    total_budget = sum(t.get("budget", 0) for t in tasks)
    total_spent = sum(t.get("spent", 0) for t in tasks)
    
    console.print(f"[bold]预算概览[/bold]")
    console.print(f"总预算: ¥{total_budget:,.0f}")
    console.print(f"已花费: ¥{total_spent:,.0f}")
    console.print(f"使用率: {total_spent/total_budget*100:.1f}%" if total_budget > 0 else "使用率: N/A")
    
    if total_budget > 0 and total_spent / total_budget >= threshold:
        console.print(f"[red]⚠️ 警告：预算使用率超过 {threshold*100}%[/red]")
    
    # 单任务检查
    table = Table(title="任务预算详情")
    table.add_column("任务", style="cyan")
    table.add_column("预算", justify="right")
    table.add_column("花费", justify="right")
    table.add_column("使用率", justify="right")
    table.add_column("状态", justify="center")
    
    for task in tasks:
        name = task.get("name", "未命名")
        budget = task.get("budget", 0)
        spent = task.get("spent", 0)
        usage = spent / budget if budget > 0 else 0
        
        if usage >= threshold:
            status = "[red]超支风险[/red]"
        elif usage >= threshold * 0.7:
            status = "[yellow]正常[/yellow]"
        else:
            status = "[green]良好[/green]"
        
        table.add_row(
            name[:30],
            f"¥{budget:,.0f}",
            f"¥{spent:,.0f}",
            f"{usage*100:.1f}%",
            status
        )
    
    console.print(table)

@app.command()
def risk_assessment(
    output: Path = typer.Option("risk_report.json", "--output", "-o", help="输出文件"),
    days_ahead: int = typer.Option(7, "--days", "-d", help="检查未来N天内的任务风险")
):
    """
    自动识别项目风险
    
    检测项：
    - 任务延期（已过截止日期未完成）
    - 即将到期（未来N天内截止）
    - 资源冲突（同一人同时负责多个任务）
    - 预算超支
    """
    global PROJECT_DATA
    if PROJECT_DATA is None:
        console.print("[yellow]⚠️ 请先使用 import-tasks 加载项目数据[/yellow]")
        raise typer.Exit(1)
    
    tasks = PROJECT_DATA["tasks"]
    today = datetime.now().date()
    risks = []
    
    # 1. 检查延期
    for task in tasks:
        if task.get("status") == "completed":
            continue
        
        end_date = datetime.strptime(task["end"], "%Y-%m-%d").date()
        if end_date < today:
            risks.append({
                "type": "延期",
                "task": task["name"],
                "owner": task.get("owner", "未分配"),
                "severity": "high",
                "message": f"任务已延期 { (today - end_date).days } 天"
            })
    
    # 2. 检查即将到期
    deadline_cutoff = today + timedelta(days=days_ahead)
    for task in tasks:
        if task.get("status") in ["completed", "cancelled"]:
            continue
        
        end_date = datetime.strptime(task["end"], "%Y-%m-%d").date()
        if today <= end_date <= deadline_cutoff:
            days_left = (end_date - today).days
            risks.append({
                "type": "即将到期",
                "task": task["name"],
                "owner": task.get("owner", "未分配"),
                "severity": "medium" if days_left <= 3 else "low",
                "message": f"剩余 {days_left} 天截止"
            })
    
    # 3. 检查资源冲突
    owner_tasks = {}
    for task in tasks:
        if task.get("status") in ["completed", "cancelled"]:
            continue
        owner = task.get("owner", "未分配")
        if owner not in owner_tasks:
            owner_tasks[owner] = []
        owner_tasks[owner].append(task["name"])
    
    for owner, task_list in owner_tasks.items():
        if len(task_list) > 2:
            risks.append({
                "type": "资源冲突",
                "task": ", ".join(task_list[:3]),
                "owner": owner,
                "severity": "medium",
                "message": f"同一人负责 {len(task_list)} 个进行中任务"
            })
    
    # 4. 检查预算超支（简单判断）
    for task in tasks:
        budget = task.get("budget", 0)
        spent = task.get("spent", 0)
        if budget > 0 and spent / budget >= 0.9:
            risks.append({
                "type": "预算超支",
                "task": task["name"],
                "owner": task.get("owner", "未分配"),
                "severity": "high" if spent >= budget else "medium",
                "message": f"已花费 ¥{spent:,.0f} / 预算 ¥{budget:,.0f} ({spent/budget*100:.1f}%)"
            })
    
    # 输出结果
    result = {
        "project": PROJECT_DATA.get("project_name", "未命名项目"),
        "assessment_date": datetime.now().isoformat(),
        "risk_count": len(risks),
        "risks": risks,
        "summary": {
            "high": sum(1 for r in risks if r["severity"] == "high"),
            "medium": sum(1 for r in risks if r["severity"] == "medium"),
            "low": sum(1 for r in risks if r["severity"] == "low")
        }
    }
    
    with open(output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    # 控制台输出
    console.print(f"[bold]风险评估完成: {PROJECT_DATA.get('project_name', '项目')}[/bold]")
    console.print(f"发现风险数: {len(risks)}")
    console.print(f"高风险: {result['summary']['high']} | 中风险: {result['summary']['medium']} | 低风险: {result['summary']['low']}")
    
    if risks:
        table = Table(title="风险清单")
        table.add_column("类型", style="red")
        table.add_column("任务", style="cyan")
        table.add_column("负责人", style="yellow")
        table.add_column("严重度", justify="center")
        table.add_column("说明", style="magenta")
        
        for r in risks:
            severity_color = {"high": "red", "medium": "yellow", "low": "green"}.get(r["severity"], "white")
            table.add_row(
                r["type"],
                r["task"][:40],
                r["owner"],
                f"[{severity_color}]{r['severity']}[/{severity_color}]",
                r["message"]
            )
        console.print(table)
    
    console.print(f"[green]📝 详细报告已保存: {output}[/green]")

@app.command()
def list_templates():
    """列出可用模板（未来扩展）"""
    console.print("[bold]项目追踪器模板[/bold]")
    console.print("当前无自定义模板，功能直接通过CLI实现")

if __name__ == "__main__":
    app()
