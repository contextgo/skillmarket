# 项目追踪器 (project-tracker)

**广告AE的项目管理与风险控制工具**

> **v1.0.1** — 修复甘特图中文显示乱码问题，优化字体配置

---

## 📦 功能概览

| 命令 | 功能 | 描述 |
|------|------|------|
| `import-tasks` | 任务导入 | 支持 JSON/CSV/Excel 格式的项目数据加载 |
| `generate-gantt` | 甘特图生成 | 导出 PNG/PDF 格式的时间轴图表 |
| `budget-check` | 预算检查 | 计算使用率，超支预警 |
| `risk-assessment` | 风险评估 | 自动识别延期、资源冲突、预算风险 |
| `list-templates` | 模板列表 | 显示可用输出模板 |

---

## 🚀 快速开始

### 安装依赖

```bash
cd project-tracker
pip install -r requirements.txt
```

### 基本流程

```bash
# 1. 导入任务数据
project-tracker import-tasks --file my_project.json

# 2. 生成甘特图
project-tracker generate-gantt --output timeline.png --title "Q1品牌Campaign"

# 3. 检查预算
project-tracker budget-check --threshold 0.85

# 4. 风险评估
project-tracker risk-assessment --output risks.json
```

---

## 📊 数据格式

### JSON 示例

```json
{
  "project_name": "XX品牌春季推广",
  "start_date": "2025-03-01",
  "budget_total": 500000,
  "tasks": [
    {
      "id": 1,
      "name": "策略简报",
      "start": "2025-03-01",
      "end": "2025-03-05",
      "owner": "张三",
      "budget": 10000,
      "spent": 8500,
      "status": "completed",
      "dependencies": []
    },
    {
      "id": 2,
      "name": "创意设计",
      "start": "2025-03-06",
      "end": "2025-03-15",
      "owner": "李四",
      "budget": 15000,
      "spent": 12000,
      "status": "in_progress",
      "dependencies": [1]
    }
  ]
}
```

**字段说明：**
- `project_name` - 项目名称
- `start_date` - 项目开始日期（可选）
- `budget_total` - 项目总预算（可选）
- `tasks` - 任务列表
  - `id` - 任务ID
  - `name` - 任务名称
  - `start` / `end` - 开始/结束日期（YYYY-MM-DD）
  - `owner` - 负责人
  - `budget` - 任务预算（元）
  - `spent` - 已花费（元，可选，用于预算检查）
  - `status` - 任务状态：`pending`, `in_progress`, `completed`, `delayed`, `cancelled`
  - `dependencies` - 依赖的前置任务ID列表（可选）

### CSV 格式（简化）

```csv
id,name,start,end,owner,budget,spent,status
1,策略简报,2025-03-01,2025-03-05,张三,10000,8500,completed
2,创意设计,2025-03-06,2025-03-15,李四,15000,12000,in_progress
```

---

## 📈 命令详解

### import-tasks

加载项目数据，自动识别格式（JSON/CSV/Excel）。

```bash
project-tracker import-tasks --file project.json
project-tracker import-tasks --file tasks.csv --format csv
```

**输出：** 项目概览、任务数量、总预算、任务状态统计表。

---

### generate-gantt

生成甘特图，支持配置标题和依赖显示。

```bash
project-tracker generate-gantt --output gantt.png --title "春季Campaign"
```

**输出文件：** PNG（默认150 DPI，可改为PDF）

**特性：**
- 自动根据任务状态着色（完成=绿色、进行中=蓝色、延期=红色）
- 今日红色虚线标记
- 任务名称 + 负责人显示

---

### budget-check

检查预算使用情况，支持自定义预警阈值。

```bash
project-tracker budget-check --threshold 0.85
```

**输出：**
- 总预算 vs 已花费
- 使用率百分比
- 各任务预算详情表（超支任务高亮）

---

### risk-assessment

全面检查项目风险，输出JSON报告。

```bash
project-tracker risk-assessment --output risks.json --days 7
```

**检测维度：**
1. **延期风险**：已过截止日期未完成的任务
2. **即将到期**：未来N天内截止的任务（默认7天）
3. **资源冲突**：同一负责人同时负责超过2个进行中任务
4. **预算超支**：花费达到预算 90% 以上的任务

**JSON报告结构：**
```json
{
  "project": "项目名称",
  "assessment_date": "2025-03-14T22:30:00",
  "risk_count": 3,
  "summary": {"high": 1, "medium": 2, "low": 0},
  "risks": [...]
}
```

---

## 🎨 可视化样例

甘特图效果：
```
  March 2025             
Su Mo Tu We Th Fr Sa
     1  2  3  4  5  6  ██████████ 策略简报 (张三)
 7  8  9 10 11 12 13        ███████████████████ 创意设计 (李四)
...
```

预算检查表：
```
任务         | 预算    | 花费    | 使用率 | 状态
策略简报     | ¥10,000 | ¥8,500  | 85.0%  | [green]良好[/green]
创意设计     | ¥15,000 | ¥13,500 | 90.0%  | [red]超支风险[/red]
```

---

## 🛠️ 高级用法

### 批量处理多个项目

```bash
for f in projects/*.json; do
  project-tracker import-tasks --file "$f"
  project-tracker generate-gantt --output "output/$(basename $f .json).png"
done
```

### 集成到周报

```bash
# 生成风险报告并插入周报
project-tracker risk-assessment --output risks.json
# 用 jq 提取风险数插入周报模板
echo "本周识别风险: $(jq '.risk_count' risks.json) 个" >> weekly_report.md
```

---

## 📂 输出文件

| 文件 | 内容 | 生成命令 |
|------|------|----------|
| `gantt.png` | 甘特图图表 | `generate-gantt` |
| `risk_report.json` | 风险评估JSON | `risk-assessment` |
| 控制台表格 | 预算详情 | `budget-check` |

---

## 🔧 故障排除

**错误：未加载项目数据**
- 确保先运行 `import-tasks` 再使用其他命令

**错误：日期格式无效**
- 日期必须是 `YYYY-MM-DD` 格式，如 `2025-03-15`

**甘特图不显示任务名称**
- 检查任务名中是否包含特殊字符，可缩短名称

---

## 🧪 测试用例

```bash
# 使用示例数据
cat > test_project.json << 'EOF'
{
  "project_name": "Test Campaign",
  "tasks": [
    {"name": "Strategy", "start": "2025-03-01", "end": "2025-03-05", "owner": "Alice", "budget": 10000, "status": "completed"},
    {"name": "Creative", "start": "2025-03-06", "end": "2025-03-15", "owner": "Bob", "budget": 15000, "status": "in_progress"},
    {"name": "Media Buy", "start": "2025-03-10", "end": "2025-03-20", "owner": "Alice", "budget": 20000, "status": "pending"}
  ]
}
EOF

project-tracker import-tasks --file test_project.json
project-tracker generate-gantt --output test_gantt.png
project-tracker risk-assessment --output test_risks.json
```

---

## 📄 许可

MIT License - 可自由修改和商业使用

---

**版本:** 1.0.0  
**最后更新:** 2025-03-14
