---
name: project-manager
description: "项目管理工具，管理基于JSON的项目系统，支持Kanban看板、任务同步和Swarm指令处理。触发词：项目管理、project management、任务管理、kanban、swarm指令、token预算管理、进度追踪、任务拆分。"
version: "1.1.0"
last_updated: "2026-04-15"
changelog: "- 补充执行流程、异常处理和验收标准"
---
# Skill: Project Manager (Vivi OS) - Swarm Edition

## 目的
管理内部项目任务，保持看板、同步状态和协作指令一致。

## 适用场景
- 需要查看、添加、移动或同步任务
- 需要把模糊目标拆成可执行项目
- 需要处理 Swarm 指令和 token 预算约束

## 执行流程

### Phase 1: 任务确认
- 明确项目名、目标、截止时间、优先级
- 如果目标过大，先拆成子任务

### Phase 2: 看板操作
- 读取当前状态
- 将任务放入 todo / in_progress / review / done / blocked
- 保持 in_progress 数量可控，避免同时推进过多任务

### Phase 3: 同步与协作
- 对需要同步的任务更新外部状态
- 处理 Swarm 指令前先检查格式、参与者和 token 预算

### Phase 4: 异常处理
- 缺少项目 ID 时先补齐，再写入
- 预算超标、格式错误、状态冲突时先阻断，不要硬写

## 规则
1. 只在信息足够时写入变更
2. 先验证，再执行
3. 状态变更必须可追踪
4. Swarm 指令必须通过预算校验

## 验收标准
- 任务状态清楚可查
- 新任务有明确下一步
- 失败时能说清卡点，而不是假装完成
