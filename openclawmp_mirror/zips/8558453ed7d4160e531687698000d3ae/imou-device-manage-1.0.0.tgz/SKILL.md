---
name: imou-device-manage
displayName: 乐橙设备管理
version: 1.0.0
description: >
  乐橙（Imou）设备管理技能。支持查看账号下设备列表、查询设备详情（序列号/型号/在线状态/设备名称/通道信息）、按序列号查询设备、修改设备或通道名称。
  适用于中文/英文请求，如：我有哪些乐橙设备、乐橙设备列表、设备详情、修改设备名称、查询设备序列号等。
metadata:
  {
    "openclaw":
      {
        "emoji": "📋",
        "requires": { "env": ["IMOU_APP_ID", "IMOU_APP_SECRET"], "pip": ["requests"] },
        "primaryEnv": "IMOU_APP_ID",
        "install":
          [
            { "id": "python-requests", "kind": "pip", "package": "requests", "label": "安装 requests 依赖" }
          ]
      }
  }
---

# 📋 乐橙设备管理

管理乐橙云端设备：查看设备序列号、型号、在线状态、设备名称、通道信息（通道ID、通道名称）；按序列号查询设备详情；重命名设备或通道。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置环境变量（必填）

```bash
export IMOU_APP_ID="你的应用ID"
export IMOU_APP_SECRET="你的应用密钥"
export IMOU_BASE_URL="API基础地址"
```

**API 基础地址说明：**

| 区域 | 数据中心 | 基础地址 |
|------|---------|---------|
| 中国大陆 | — | `https://openapi.lechange.cn` |
| 海外 | 东亚 | `https://openapi-sg.easy4ip.com:443` |
| 海外 | 中欧 | `https://openapi-fk.easy4ip.com:443` |
| 海外 | 美西 | `https://openapi-or.easy4ip.com:443` |

**如何获取 App ID 和 App Secret：**
- 访问 [乐橙开放平台](https://open.imou.com) 注册开发者账号
- 进入「应用管理」-「应用信息」获取 `appId` 和 `appSecret`

### 3. 运行命令

```bash
# 列出所有设备（支持分页）
python3 {baseDir}/scripts/device_manage.py list

# 指定每页数量和页码
python3 {baseDir}/scripts/device_manage.py list --page-size 20 --page 1

# 按序列号查询设备详情（支持多个）
python3 {baseDir}/scripts/device_manage.py get 设备序列号1 [设备序列号2 ...]

# 重命名设备或通道
python3 {baseDir}/scripts/device_manage.py rename 设备序列号 "新名称" [--channel-id 通道ID]
```

## ✨ 功能特性

1. **设备列表查询**：分页查询账号下所有设备，返回序列号、型号、在线状态、设备名称、通道列表（含通道ID和通道名称）
2. **设备详情查询**：按设备序列号查询一个或多个设备的详细信息
3. **设备/通道重命名**：自定义设备名称，或指定通道ID修改通道名称

## 📡 请求标识

所有请求都会携带请求头 `Client-Type: OpenClaw`，用于平台识别。

## 📚 API 参考文档

| 接口 | 文档地址 |
|-----|---------|
| 开发规范 | https://open.imou.com/document/pages/c20750/ |
| 获取 accessToken | https://open.imou.com/document/pages/fef620/ |
| 分页查询设备列表 | https://open.imou.com/document/pages/683248/ |
| 根据设备ID查询设备 | https://open.imou.com/document/pages/320fb7/ |
| 修改设备/通道名称 | https://open.imou.com/document/pages/8ffaa3/ |

更多请求/响应格式详见 `references/imou-device-api.md`

## 💡 使用提示

- **Token 有效期**：每次运行自动获取，有效期3天。如需跨运行缓存，请自行实现过期处理逻辑
- **分页参数**：`list` 命令支持 `--page-size`（1-50）和 `--page`（从1开始）
- **重命名说明**：不指定 `--channel-id` 时修改设备名称；单通道IPC设备可能同时更新设备名和通道名

## 🔒 数据流向说明

| 数据 | 发送至 | 用途 |
|-----|-------|-----|
| appId, appSecret | 乐橙开放平台 | 获取 accessToken |
| accessToken, deviceId 等 | 乐橙开放平台 | 查询设备列表、获取详情、修改名称 |

所有请求仅发送至配置的 `IMOU_BASE_URL`（乐橙官方API），不涉及第三方。
