---
name: voice-setup
description: 从零配置语音消息能力：安装依赖、生成语音、发送到 Telegram/飞书等通道。基于 edge-tts + ffmpeg 实战验证的完整流程。
version: 1.0.0
tags: [voice, tts, telegram, feishu, edge-tts, audio]
author: X
---

# 语音消息配置与发送

从零开始让 OpenClaw Agent 具备语音消息能力。基于 edge-tts（微软免费 TTS）+ ffmpeg 的方案，实战验证可用。

## 前置条件检查

执行任何操作前，先检查依赖：

```bash
which edge-tts && which ffmpeg && which ffprobe && echo "✅ 依赖齐全" || echo "❌ 缺少依赖"
```

## 第一步：安装依赖

### edge-tts（文字转语音）

```bash
pip install edge-tts --break-system-packages
```

注意：如果系统有 PEP 668 限制（externally-managed-environment），必须加 `--break-system-packages`。

### ffmpeg（音频转换）

Ubuntu/Debian:
```bash
apt-get install -y ffmpeg
```

验证安装：
```bash
edge-tts --version
ffmpeg -version | head -1
```

## 第二步：生成语音文件

使用 `scripts/gen_voice.sh`：

```bash
# 中文（默认 XiaoxiaoNeural 女声）
bash scripts/gen_voice.sh "你好，这是一条语音消息" /tmp/voice.ogg

# 英文
bash scripts/gen_voice.sh "Hello world" /tmp/voice.ogg en-US-JennyNeural

# 中文男声
bash scripts/gen_voice.sh "你好" /tmp/voice.ogg zh-CN-YunjianNeural
```

输出：ogg/opus 格式，Telegram 直接支持。

## 第三步：发送语音

### Telegram

⚠️ 关键坑：`openclaw message send --media` 的文件路径必须在 OpenClaw 允许的目录下（workspace 等），`/tmp/` 会被 SSRF guard 拦截。

正确流程：
```bash
# 1. 生成到 workspace
bash scripts/gen_voice.sh "内容" /root/.openclaw/workspace/voice_out.ogg

# 2. 发送（作为音频文件）
openclaw message send --channel telegram --account default --target "<chat_id>" --media /root/.openclaw/workspace/voice_out.ogg

# 3. 清理
rm -f /root/.openclaw/workspace/voice_out.ogg
```

注意：当前 `openclaw message send` 不支持 `--asVoice` 参数，发出去是音频文件而非语音气泡。如需语音气泡，需直接调用 Telegram Bot API 的 `sendVoice` 接口。

### 飞书

飞书不支持 message 工具的 asVoice，必须用专用脚本：

```bash
bash scripts/send_feishu_voice.sh /tmp/voice.ogg <receive_id> <tenant_access_token> [receive_id_type]
```

receive_id_type 可选：open_id（默认）、chat_id、user_id、union_id、email

## 常用声音

| 语言 | 声音 | 特点 |
|------|------|------|
| 中文 | zh-CN-XiaoxiaoNeural | 女声，温暖（默认） |
| 中文 | zh-CN-YunjianNeural | 男声，沉稳 |
| 英文 | en-US-JennyNeural | 女声，自然 |
| 英文 | en-US-GuyNeural | 男声 |
| 日语 | ja-JP-NanamiNeural | 女声 |
| 粤语 | zh-HK-HiuGaaiNeural | 女声 |

完整列表：`edge-tts --list-voices`

## 踩过的坑

1. `/tmp/` 路径被 LocalMediaAccessError 拦截 → 文件必须放在 workspace 或其他允许目录
2. `pip install` 在新系统需要 `--break-system-packages`
3. `--asVoice` / `--as-voice` 参数在 `openclaw message send` CLI 中不存在
4. edge-tts 生成的是 mp3，必须用 ffmpeg 转 ogg/opus 才能被 Telegram 正确识别
5. 飞书发语音必须用专用脚本，message 工具的 asVoice=true 在飞书上只会发文件附件
