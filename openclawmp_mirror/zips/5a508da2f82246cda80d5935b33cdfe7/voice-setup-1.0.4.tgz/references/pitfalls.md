# 踩坑记录

## 1. /tmp/ 路径被拦截
- 现象：`LocalMediaAccessError: Local media path is not under an allowed directory: /tmp/voice_demo.ogg`
- 原因：OpenClaw 的 SSRF guard 限制了 `openclaw message send --media` 的文件路径，只允许 workspace 等白名单目录
- 解决：生成文件到 workspace 下，如 `/root/.openclaw/workspace/voice_out.ogg`，发完删除

## 2. pip install 被 PEP 668 拒绝
- 现象：`error: externally-managed-environment`
- 原因：Ubuntu 24.04+ 默认启用 PEP 668，禁止系统级 pip install
- 解决：加 `--break-system-packages` 参数

## 3. --asVoice 参数不存在
- 现象：`error: unknown option '--asVoice'`
- 原因：`openclaw message send` CLI 没有 asVoice 参数，skill 文档里写的是 message 工具（agent 内部工具）的参数，不是 CLI 参数
- 解决：CLI 只能用 `--media` 发音频文件。如需语音气泡，需直接调 Telegram Bot API 的 sendVoice

## 4. edge-tts 输出是 mp3
- 现象：直接发 mp3 到 Telegram，不会显示为语音
- 原因：Telegram 语音消息要求 ogg/opus 格式
- 解决：用 ffmpeg 转换 `ffmpeg -y -i input.mp3 -c:a libopus -b:a 64k output.ogg`

## 5. 飞书语音必须用专用脚本
- 现象：飞书 message 工具的 asVoice=true 发出去是文件附件，不是语音气泡
- 原因：飞书 API 的语音消息需要特殊的上传流程（opus + duration 元数据）
- 解决：用 `scripts/send_feishu_voice.sh` 专用脚本
