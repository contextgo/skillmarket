# 常用声音参考

## 中文
| 声音 | 性别 | 特点 | 适用场景 |
|------|------|------|----------|
| zh-CN-XiaoxiaoNeural | 女 | 温暖自然 | 日常对话、汇报（默认） |
| zh-CN-YunjianNeural | 男 | 沉稳有力 | 正式汇报、新闻播报 |
| zh-CN-YunxiNeural | 男 | 年轻活泼 | 轻松场景 |
| zh-CN-XiaoyiNeural | 女 | 甜美 | 故事讲述 |
| zh-HK-HiuGaaiNeural | 女 | 粤语 | 粤语场景 |
| zh-TW-HsiaoChenNeural | 女 | 台湾腔 | 台湾用户 |

## 英文
| 声音 | 性别 | 特点 |
|------|------|------|
| en-US-JennyNeural | 女 | 自然流畅 |
| en-US-GuyNeural | 男 | 标准美音 |
| en-GB-SoniaNeural | 女 | 英式发音 |

## 其他语言
| 语言 | 声音 | 性别 |
|------|------|------|
| 日语 | ja-JP-NanamiNeural | 女 |
| 韩语 | ko-KR-SunHiNeural | 女 |
| 法语 | fr-FR-DeniseNeural | 女 |
| 德语 | de-DE-KatjaNeural | 女 |
| 西班牙语 | es-ES-ElviraNeural | 女 |
| 俄语 | ru-RU-SvetlanaNeural | 女 |
| 泰语 | th-TH-PremwadeeNeural | 女 |
| 越南语 | vi-VN-HoaiMyNeural | 女 |

查看全部声音：`edge-tts --list-voices`
