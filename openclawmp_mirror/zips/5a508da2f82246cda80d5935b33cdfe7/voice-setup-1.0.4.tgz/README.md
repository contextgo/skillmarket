# 语音消息配置与发送

从零开始让 OpenClaw Agent 具备语音消息能力。基于 edge-tts（微软免费 TTS）+ ffmpeg 的方案，在腾讯云 Ubuntu 服务器上实战验证通过。

## 效果展示

![语音消息效果图](https://iili.io/BNER8zu.jpg)

## 能力

- 中英日韩等 20+ 语言的文字转语音
- 生成 Telegram 兼容的 ogg/opus 音频
- 一键发送到 Telegram / 飞书等通道
- 包含完整踩坑记录，避免重复踩雷

## 快速开始

```bash
# 1. 检查依赖
bash scripts/check_deps.sh

# 2. 安装缺失依赖
pip install edge-tts --break-system-packages
apt-get install -y ffmpeg

# 3. 生成语音
bash scripts/gen_voice.sh "你好世界" /root/.openclaw/workspace/voice.ogg

# 4. 发送到 Telegram
bash scripts/send_voice.sh "你好世界" telegram default "<chat_id>"
```

## 文件结构

```
voice-setup/
├── SKILL.md              # 完整配置流程
├── .metadata.json        # 资产元数据
├── README.md             # 本文件
├── scripts/
│   ├── check_deps.sh     # 依赖检查
│   ├── gen_voice.sh      # 文字转语音
│   └── send_voice.sh     # 生成+发送一条龙
└── references/
    ├── voices.md          # 声音列表
    └── pitfalls.md        # 踩坑记录
```
