#!/bin/bash
# check_deps.sh - 检查语音消息依赖是否就绪
# 用法: check_deps.sh

echo "=== 语音消息依赖检查 ==="

OK=true

if command -v edge-tts &>/dev/null; then
  VER=$(edge-tts --version 2>&1 || echo "unknown")
  echo "✅ edge-tts: $VER"
else
  echo "❌ edge-tts: 未安装 → pip install edge-tts --break-system-packages"
  OK=false
fi

if command -v ffmpeg &>/dev/null; then
  VER=$(ffmpeg -version 2>&1 | head -1)
  echo "✅ ffmpeg: $VER"
else
  echo "❌ ffmpeg: 未安装 → apt-get install -y ffmpeg"
  OK=false
fi

if command -v ffprobe &>/dev/null; then
  echo "✅ ffprobe: 已安装"
else
  echo "❌ ffprobe: 未安装（随 ffmpeg 一起装）"
  OK=false
fi

if command -v openclaw &>/dev/null; then
  echo "✅ openclaw: 已安装"
else
  echo "❌ openclaw: 未安装"
  OK=false
fi

echo ""
if [ "$OK" = true ]; then
  echo "🎉 所有依赖就绪，可以发语音了！"
else
  echo "⚠️ 有缺失依赖，请先安装"
fi
