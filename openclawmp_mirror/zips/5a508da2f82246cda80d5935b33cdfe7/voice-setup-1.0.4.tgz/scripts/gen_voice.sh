#!/bin/bash
# gen_voice.sh - 文字转语音生成 ogg/opus 文件
# 用法: gen_voice.sh <text> <output.ogg> [voice]
# 默认声音: zh-CN-XiaoxiaoNeural

set -e

TEXT="$1"
OUTPUT="$2"
VOICE="${3:-zh-CN-XiaoxiaoNeural}"

if [ -z "$TEXT" ] || [ -z "$OUTPUT" ]; then
  echo "用法: gen_voice.sh <文本> <输出文件.ogg> [声音名称]"
  echo "示例: gen_voice.sh '你好世界' /tmp/voice.ogg"
  echo "示例: gen_voice.sh 'Hello' /tmp/voice.ogg en-US-JennyNeural"
  exit 1
fi

# 检查依赖
if ! command -v edge-tts &>/dev/null; then
  echo "❌ edge-tts 未安装，执行: pip install edge-tts --break-system-packages"
  exit 1
fi
if ! command -v ffmpeg &>/dev/null; then
  echo "❌ ffmpeg 未安装，执行: apt-get install -y ffmpeg"
  exit 1
fi

TMP_MP3=$(mktemp /tmp/voice_XXXXXX.mp3)
trap "rm -f $TMP_MP3" EXIT

echo "🎤 生成语音: voice=$VOICE, 文本长度=${#TEXT}字"
edge-tts --voice "$VOICE" --text "$TEXT" --write-media "$TMP_MP3" 2>&1

echo "🔄 转换为 ogg/opus..."
ffmpeg -y -i "$TMP_MP3" -c:a libopus -b:a 64k "$OUTPUT" 2>&1 | tail -1

SIZE=$(stat -c%s "$OUTPUT" 2>/dev/null || stat -f%z "$OUTPUT" 2>/dev/null)
echo "✅ 生成完成: $OUTPUT (${SIZE} bytes)"
