#!/bin/bash
# send_voice.sh - 生成语音并发送到指定通道
# 用法: send_voice.sh <text> <channel> <account> <target> [voice]
# 示例: send_voice.sh "你好" telegram default "-1003715249520"

set -e

TEXT="$1"
CHANNEL="$2"
ACCOUNT="$3"
TARGET="$4"
VOICE="${5:-zh-CN-XiaoxiaoNeural}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKSPACE="/root/.openclaw/workspace"
OUTPUT="$WORKSPACE/_voice_tmp.ogg"

if [ -z "$TEXT" ] || [ -z "$CHANNEL" ] || [ -z "$ACCOUNT" ] || [ -z "$TARGET" ]; then
  echo "用法: send_voice.sh <文本> <通道> <账号> <目标> [声音]"
  echo "示例: send_voice.sh '你好' telegram default '-1003715249520'"
  exit 1
fi

# 生成语音
bash "$SCRIPT_DIR/gen_voice.sh" "$TEXT" "$OUTPUT" "$VOICE"

# 发送（文件必须在 workspace 下，否则被 SSRF guard 拦截）
echo "📤 发送到 $CHANNEL/$ACCOUNT -> $TARGET"
openclaw message send --channel "$CHANNEL" --account "$ACCOUNT" --target "$TARGET" --media "$OUTPUT"

# 清理
rm -f "$OUTPUT"
echo "✅ 发送完成"
