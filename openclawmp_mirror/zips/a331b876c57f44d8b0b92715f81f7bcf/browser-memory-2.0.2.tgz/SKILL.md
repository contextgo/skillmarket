---
name: browser-memory
description: 智能浏览器自动化系统，具备云端记忆功能。适用于浏览网站、自动化浏览器任务、填写表单、截图、跨会话记忆等场景。触发短语："打开网页"、"访问网站"、"浏览器自动化"、"记住浏览器操作"、"智能浏览"、"持久化浏览器记忆"。
version: 2.0.1
homepage: https://github.com/vercel-labs/agent-browser
metadata: {"openclaw":{"emoji":"🧠","requires":{"bins":["agent-browser","python3"]},"features":["cloud-memory","smart-recommendations","pattern-learning","cross-session-persistence"]}}
---

# 🧠 Browser Automation with Cloud Memory System

> **Intelligent browser automation that learns and remembers** - featuring cloud-based memory, smart selector recommendations, and automatic workflow learning.

---

## 🎯 What Makes This Different

Unlike traditional browser automation tools, this skill features a **cloud memory system** that:

- ✅ **Remembers** all successful operations across sessions
- 🧠 **Learns** optimal workflows and patterns
- 🎯 **Recommends** the best selectors based on success rate
- ☁️ **Persists** memory in the cloud (`/workspace/.browser_memory/`)
- 📊 **Tracks** detailed statistics and success rates

---

## 🚀 Quick Start

### Basic Usage

```bash
# Open a webpage and get content
agent-browser open https://example.com
agent-browser snapshot
agent-browser close
```

### With Memory System

```bash
# View memory statistics
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh stats

# Get smart recommendations for a website
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh recommend https://github.com

# View learned patterns
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh patterns
```

---

## 📋 Core Commands

### Browser Operations

| Command | Description | Example |
|---------|-------------|---------|
| `open <url>` | Navigate to URL | `agent-browser open https://example.com` |
| `snapshot` | Get page content | `agent-browser snapshot` |
| `snapshot -i` | Get interactive elements | `agent-browser snapshot -i` |
| `screenshot` | Take screenshot | `agent-browser screenshot page.png` |
| `click <selector>` | Click element | `agent-browser click "#submit"` |
| `type <selector> <text>` | Type into element | `agent-browser type "#username" "user"` |
| `fill <selector> <text>` | Clear and fill | `agent-browser fill "#search" "query"` |
| `close` | Close browser | `agent-browser close` |

### Memory System Commands

| Command | Description |
|---------|-------------|
| `memory.sh stats` | Show memory statistics |
| `memory.sh recommend <url>` | Get selector recommendations |
| `memory.sh patterns` | Show learned workflows |
| `memory.sh export` | Export memory to cloud |
| `memory.sh sync` | Sync memory from cloud |
| `memory.sh learn <name> <steps>` | Learn a new pattern |

---

## 💡 Usage Examples

### Example 1: Login with Memory

```bash
# First time - system learns
agent-browser open https://github.com/login
agent-browser snapshot -i
agent-browser type "#username" "your_username"
agent-browser type "#password" "your_password"
agent-browser click "#submit"

# Next time - get recommendations
bash scripts/memory.sh recommend https://github.com/login
# Output:
# 🎯 Recommended selectors for github.com:
#   #username - 100.0% success (5 uses)
#   #password - 100.0% success (5 uses)
#   #submit - 95.0% success (5 uses)
```

### Example 2: Learn a Workflow Pattern

```bash
# Teach the system a workflow
bash scripts/memory.sh learn "Twitter Post" "
open https://twitter.com/compose
wait 2000
click [data-testid='tweetTextarea']
type 'Your message here'
click [data-testid='tweetButton']
"

# Later, view learned patterns
bash scripts/memory.sh patterns
# Output will show the pattern with success rate
```

### Example 3: Form Filling

```bash
agent-browser open https://example.com/form
agent-browser snapshot -i

# Get recommendations
bash scripts/memory.sh recommend https://example.com/form

# Fill form using recommended selectors
agent-browser type "#email" "user@example.com"
agent-browser type "#phone" "1234567890"
agent-browser click "#submit"
```

---

## 🧠 Memory System Features

### Automatic Learning

Every browser action is automatically recorded with:
- Action type (open, click, type, etc.)
- URL and domain
- Selector used
- Success/failure result
- Timestamp

### Smart Recommendations

The system analyzes historical data to recommend:
- **Highest success rate selectors**
- **Most frequently used selectors**
- **Domain-specific optimizations**

### Pattern Recognition

Automatically identifies and saves:
- **Successful workflows** (multi-step operations)
- **Best practices** (what works well)
- **Anti-patterns** (what to avoid)

### Cross-Session Persistence

Memory is saved in two locations:
- **Local**: `{PLUGIN_ROOT}/memory/browser_memory.json`
- **Cloud**: `/workspace/.browser_memory/browser_memory.json`

---

## 📊 Memory Statistics

### What's Tracked

```json
{
  "total_sessions": 42,
  "successful_actions": 156,
  "failed_actions": 8,
  "success_rate": "95.1%",
  "domains_visited": 12,
  "patterns_learned": 5,
  "selectors_known": 23
}
```

### Domain-Level Tracking

For each domain:
- Visit count
- Success rate
- Common selectors
- First/last visit time

### Selector-Level Tracking

For each selector:
- Use count
- Success count
- Success rate
- Domains used on
- First seen time

---

## 🔄 Workflow

### Recommended Usage Pattern

1. **Start Session**
   ```bash
   # Memory auto-syncs on session start
   bash scripts/memory.sh stats
   ```

2. **Open Target Site**
   ```bash
   agent-browser open https://target-site.com
   agent-browser snapshot -i
   ```

3. **Check Recommendations**
   ```bash
   bash scripts/memory.sh recommend https://target-site.com
   ```

4. **Perform Actions**
   ```bash
   # Use recommended selectors
   agent-browser type "#best-selector" "value"
   # Actions are automatically recorded
   ```

5. **End Session**
   ```bash
   agent-browser close
   # Memory auto-exports to cloud on session end
   ```

---

## 🎓 Best Practices

### 1. Check Recommendations First

Before interacting with a known website:
```bash
bash scripts/memory.sh recommend https://example.com
# Use the highest success rate selectors
```

### 2. Learn Repeated Workflows

For operations you do frequently:
```bash
bash scripts/memory.sh learn "Daily Report" "
open https://dashboard.com
snapshot -i
click #reports
click #daily
screenshot report.png
"
```

### 3. Monitor Success Rates

Periodically check overall performance:
```bash
bash scripts/memory.sh stats
bash scripts/memory.sh patterns
```

### 4. Use Cloud Persistence

Ensure memory survives across sessions:
```bash
# Export to cloud
bash scripts/memory.sh export

# Sync from cloud (auto on session start)
bash scripts/memory.sh sync
```

---

## 📁 Memory Storage

### Local Files
```
{PLUGIN_ROOT}/memory/
├── browser_memory.json          # Main memory file
└── session_YYYYMMDD_HHMMSS.log  # Session logs
```

### Cloud Files
```
/workspace/.browser_memory/
├── browser_memory.json          # Machine-readable format
└── memory_summary.md            # Human-readable summary
```

---

## ⚙️ Configuration

### Environment Variables

- `CODEBUDDY_PLUGIN_ROOT`: Plugin root directory
- `AGENT_BROWSER_SESSION`: Browser session name
- `AGENT_BROWSER_HEADLESS`: Run in headless mode

### Advanced Options

```bash
# Use specific browser
agent-browser --executable-path /path/to/browser open https://example.com

# Use proxy
agent-browser --proxy "http://user:pass@proxy.com:8080" open https://example.com

# Persistent session
agent-browser --session-name mysession open https://example.com

# Custom viewport
agent-browser set viewport 1920 1080
```

---

## 🐛 Troubleshooting

### Memory Not Syncing

```bash
# Manual sync
bash scripts/memory.sh export
bash scripts/memory.sh sync
```

### Recommendations Not Accurate

```bash
# Check if enough data
bash scripts/memory.sh stats
# Need more usage to build accurate recommendations
```

### Browser Not Launching

```bash
# Install browser dependencies
agent-browser install --with-deps
```

---

## 🔍 Monitoring

### View Current Memory

```bash
# Statistics
bash scripts/memory.sh stats

# Patterns
bash scripts/memory.sh patterns

# Raw data
cat /workspace/.browser_memory/browser_memory.json

# Summary
cat /workspace/.browser_memory/memory_summary.md
```

---

## 📚 Additional Resources

- **Full Documentation**: `/workspace/agent-browser-memory-使用指南.md`
- **Technical Details**: `/workspace/README-memory-system.md`
- **Deployment Report**: `/workspace/agent-browser-记忆系统部署报告.md`

---

## 🆕 Version History

### v2.0.0 (Current)
- ✨ Cloud memory system
- 🧠 Intelligent recommendations
- 📊 Statistics tracking
- 🎯 Pattern learning
- ☁️ Cross-session persistence

### v1.0.0
- Basic browser automation

---

## 💬 Tips

1. **Always close the browser** when done to free resources
2. **Use `snapshot -i`** to get interactive elements with IDs
3. **Check recommendations** before interacting with known sites
4. **Learn patterns** for repeated workflows
5. **Export memory** before important sessions end

---

## ⚠️ Important Notes

- Memory is **automatically synced** on session start/end
- All actions are **recorded asynchronously** (no performance impact)
- Selector success rates are **recalculated in real-time**
- Memory files are **JSON format** (human-readable)
- Maximum **1000 session history** entries retained

---

## 🎯 When to Use This Skill

Use this skill when:
- ✅ Opening and browsing websites
- ✅ Automating repetitive browser tasks
- ✅ Filling forms on known websites
- ✅ Taking screenshots of web pages
- ✅ Need to remember actions across sessions
- ✅ Want to optimize selector usage
- ✅ Learning and applying workflows

---

**Created**: 2025-07-15  
**Maintainer**: CodeBuddy Agent  
**License**: MIT
