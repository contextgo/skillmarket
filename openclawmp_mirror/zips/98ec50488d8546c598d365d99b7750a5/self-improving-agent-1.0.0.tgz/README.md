# Self-Improvement System

捕捉学习记录、错误和修正，实现AI Agent的持续自我改进。

## 核心功能

- **错误记录**：自动记录命令失败、API异常等问题
- **学习日志**：记录用户纠正、知识更新、最佳实践
- **功能请求**：追踪用户想要的新能力
- **定期复盘**：周期性回顾学习记录，提炼改进点
- **知识提升**：将重要学习记录提升到项目记忆文件

## 使用场景

1. 命令或操作意外失败时
2. 用户纠正你的错误时（"No, that's wrong..."）
3. 用户请求不存在的功能时
4. 外部API或工具失败时
5. 发现自己的知识过时或不正确时
6. 发现更好的方法处理重复任务时

## 日志文件

- `.learnings/LEARNINGS.md` - 学习记录（纠正、知识缺口、最佳实践）
- `.learnings/ERRORS.md` - 错误记录（命令失败、异常）
- `.learnings/FEATURE_REQUESTS.md` - 功能请求

## 集成方式

支持多种AI Agent平台：
- OpenClaw（推荐）：通过workspace注入
- Claude Code：通过hooks自动触发
- GitHub Copilot：通过copilot-instructions.md
- 通用：手动记录和定期复盘

## 价值

让AI Agent像人类一样从错误中学习，持续进化，避免重复犯错。
