---
name: kling-comic
description: 可灵AI漫画创作工具。基于暴雨漫画工作流，但图像生成使用可灵(Kling)AI，支持高质量文生视频和图生视频，让漫画画面动起来。适用于创作动态漫画、短视频内容、教育动画等。
metadata:
  openclaw:
    requires:
      env:
        - KLING_API_KEY
      bins:
        - python
    primaryEnv: KLING_API_KEY
---

# 可灵AI漫画 (Kling Comic)

基于暴雨漫画创作流程，使用可灵(Kling)AI进行图像/视频生成，创作动态漫画内容。

## 特点

| 特性 | 说明 |
|------|------|
 **文生视频** | 用文字描述直接生成视频片段 |
| **图生视频** | 静态漫画画面转为动态视频 |
| **视频续写** | 延长视频时长，保持连贯性 |
| **运动笔刷** | 精确控制画面中元素的运动 |

## 前置要求

需要可灵 API Key：
1. 访问 https://klingai.com/
2. 注册/登录账号
3. 在控制台获取 **Access Key** 和 **Secret Key**
4. 设置环境变量：
   ```bash
   export KLING_ACCESS_KEY="your-access-key"
   export KLING_SECRET_KEY="your-secret-key"
   ```

## 认证说明

可灵 API 使用 **Access Key + Secret Key** 的签名认证方式。

**注意**：当前脚本中的认证逻辑需要根据可灵官方 API 文档进行调整。如果遇到认证失败，请：
1. 检查 API Key 是否正确
2. 确认账户有可用额度
3. 参考可灵官方文档调整认证方式

## 使用方法

```bash
# 从文本文件创建漫画
/kling-comic story.md

# 指定画风和基调
/kling-comic story.md --art manga --tone warm

# 生成动态视频漫画
/kling-comic story.md --mode video
```

## 画风选项

| 风格 | 说明 |
|------|------|
| manga | 日漫风格 |
| realistic | 写实风格 |
| ink-brush | 水墨风格 |
| ligne-claire | 清线风格 |

## 基调选项

| 基调 | 说明 |
|------|------|
| warm | 温馨 |
| dramatic | 戏剧 |
| energetic | 活力 |
| neutral | 中性 |

## 输出模式

| 模式 | 说明 |
|------|------|
| static | 静态图片（默认）|
| video | 动态视频 |
| mixed | 静图+视频混合 |

## 文件结构

```
comic/{topic-slug}/
├── source.md              # 源内容
├── analysis.md            # 内容分析
├── storyboard.md          # 分镜脚本
├── characters/
│   ├── characters.md      # 角色设定
│   └── characters.jpg     # 角色参考图
├── prompts/               # 生成提示词
├── images/                # 静态图片
├── videos/                # 动态视频
└── {topic-slug}.pdf       # 最终PDF
```

## 工作流程

1. **内容分析** - 分析主题、受众、核心元素
2. **角色设计** - 创建角色设定和参考图
3. **分镜脚本** - 设计每页的画面和叙事
4. **提示词生成** - 为每页生成可灵优化的提示词
5. **图像/视频生成** - 调用可灵API生成内容
6. **合并输出** - 整合为PDF或视频合集

## 脚本

| 脚本 | 功能 |
|------|------|
| `scripts/generate_image.py` | 使用可灵生成静态图片 |
| `scripts/generate_video.py` | 使用可灵生成动态视频 |
| `scripts/merge_to_pdf.py` | 合并为PDF |

## 注意事项

- 可灵API有调用频率限制，请合理规划
- 视频生成耗时较长（30秒-2分钟/片段）
- 建议先生成静态图片确认效果，再生成视频
