#!/usr/bin/env python3
"""
测试可灵API - 获取模型列表
"""

import os
import sys
import json
import urllib.request
import time
import hmac
import hashlib
import base64

KLING_API_BASE = "https://api-beijing.klingai.com"


def encode_jwt_token(ak, sk):
    """生成JWT Token"""
    header = json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(',', ':'))
    header_b64 = base64.urlsafe_b64encode(header.encode()).decode().rstrip('=')
    
    payload = json.dumps({
        "iss": ak,
        "exp": int(time.time()) + 1800,
        "nbf": int(time.time()) - 5
    }, separators=(',', ':'))
    payload_b64 = base64.urlsafe_b64encode(payload.encode()).decode().rstrip('=')
    
    message = f"{header_b64}.{payload_b64}"
    signature = hmac.new(
        sk.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).digest()
    signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
    
    return f"{message}.{signature_b64}"


def test_api(access_key, secret_key):
    """测试API调用"""
    api_token = encode_jwt_token(access_key, secret_key)
    
    # 尝试图像生成接口
    path = "/v1/images/generations"
    url = f"{KLING_API_BASE}{path}"
    
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }
    
    # 简单的测试请求
    data = json.dumps({
        "prompt": "a cat",
        "n": 1,
        "model": "kling-v1"  # 尝试不同的模型名称
    })
    
    print(f"Testing API: {url}")
    print(f"Headers: {headers}")
    print(f"Body: {data}")
    
    try:
        req = urllib.request.Request(
            url,
            data=data.encode('utf-8'),
            headers=headers,
            method='POST'
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            print(f"Success!")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return True
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code}")
        error_body = e.read().decode('utf-8')
        print(f"Response: {error_body}")
        
        # 尝试解析错误
        try:
            error_json = json.loads(error_body)
            print(f"\nError Code: {error_json.get('code')}")
            print(f"Message: {error_json.get('message')}")
        except:
            pass
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False


if __name__ == "__main__":
    access_key = os.environ.get("KLING_ACCESS_KEY")
    secret_key = os.environ.get("KLING_SECRET_KEY")
    
    if not access_key or not secret_key:
        print("Error: 请设置 KLING_ACCESS_KEY 和 KLING_SECRET_KEY")
        sys.exit(1)
    
    print(f"Testing with Access Key: {access_key[:10]}...")
    test_api(access_key, secret_key)
