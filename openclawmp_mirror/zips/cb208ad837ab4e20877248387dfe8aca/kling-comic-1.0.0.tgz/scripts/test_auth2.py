#!/usr/bin/env python3
"""测试可灵API认证 - 尝试不同格式"""

import os
import sys
import json
import urllib.request
import urllib.error
import hashlib
import hmac
import base64
import time
from urllib.parse import urlencode

ACCESS_KEY = "AFhLmRnDfQKpB9PNGprFCARtRQPtPKNR"
SECRET_KEY = "99HRkbnPnCt9Agp9GyB4TNKTrG3EPLE9"

def test_bearer_with_signature():
    """测试 Bearer + Signature 格式"""
    print("=== Testing Bearer + Signature ===")
    
    method = "POST"
    path = "/v1/images/generations"
    url = f"https://api.klingai.com{path}"
    
    timestamp = str(int(time.time()))
    nonce = str(int(time.time() * 1000000))  # 微秒级
    
    body = json.dumps({"prompt": "test", "n": 1})
    
    # 构建签名字符串（根据可灵文档格式）
    string_to_sign = f"{method}\n{path}\n\n{body}\n{timestamp}\n{nonce}"
    
    # HMAC-SHA256签名
    signature = hmac.new(
        SECRET_KEY.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    # Bearer + AccessKey:Signature 格式
    auth = f"Bearer {ACCESS_KEY}:{signature}"
    
    print(f"Auth: {auth[:50]}...")
    
    headers = {
        "Authorization": auth,
        "X-Api-Timestamp": timestamp,
        "X-Api-Nonce": nonce,
        "Content-Type": "application/json"
    }
    
    try:
        req = urllib.request.Request(url, data=body.encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

def test_simple_bearer():
    """测试简单 Bearer (只用 AccessKey)"""
    print("\n=== Testing Simple Bearer (AccessKey only) ===")
    
    url = "https://api.klingai.com/v1/images/generations"
    
    headers = {
        "Authorization": f"Bearer {ACCESS_KEY}",
        "Content-Type": "application/json"
    }
    
    body = json.dumps({"prompt": "test", "n": 1}).encode('utf-8')
    
    try:
        req = urllib.request.Request(url, data=body, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

def test_api_key_header():
    """测试 X-Api-Key header"""
    print("\n=== Testing X-Api-Key Header ===")
    
    url = "https://api.klingai.com/v1/images/generations"
    
    headers = {
        "X-Api-Key": ACCESS_KEY,
        "X-Api-Secret": SECRET_KEY,
        "Content-Type": "application/json"
    }
    
    body = json.dumps({"prompt": "test", "n": 1}).encode('utf-8')
    
    try:
        req = urllib.request.Request(url, data=body, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

if __name__ == "__main__":
    test_bearer_with_signature()
    test_simple_bearer()
    test_api_key_header()
