#!/usr/bin/env python3
"""
使用可灵(Kling)AI生成图像

Usage:
    python generate_image.py --prompt "描述" --filename "output.jpg"

环境变量:
    KLING_ACCESS_KEY - 可灵 Access Key
    KLING_SECRET_KEY - 可灵 Secret Key
"""

import argparse
import os
import sys
import json
import urllib.request
import urllib.error
import time
from pathlib import Path

# 尝试导入jwt，如果没有则使用备用方案
try:
    import jwt
    HAS_JWT = True
except ImportError:
    HAS_JWT = False
    import hmac
    import hashlib
    import base64

KLING_API_BASE = "https://api-beijing.klingai.com"


def get_credentials():
    """从环境变量获取凭证"""
    access_key = os.environ.get("KLING_ACCESS_KEY")
    secret_key = os.environ.get("KLING_SECRET_KEY")
    
    if not access_key or not secret_key:
        print("Error: 请设置环境变量 KLING_ACCESS_KEY 和 KLING_SECRET_KEY")
        sys.exit(1)
    
    return access_key, secret_key


def encode_jwt_token(ak, sk):
    """生成JWT Token"""
    if HAS_JWT:
        # 使用PyJWT库
        headers = {
            "alg": "HS256",
            "typ": "JWT"
        }
        payload = {
            "iss": ak,
            "exp": int(time.time()) + 1800,  # 30分钟有效期
            "nbf": int(time.time()) - 5      # 提前5秒生效
        }
        token = jwt.encode(payload, sk, headers=headers, algorithm="HS256")
        return token
    else:
        # 手动实现JWT
        # Header
        header = json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(',', ':'))
        header_b64 = base64.urlsafe_b64encode(header.encode()).decode().rstrip('=')
        
        # Payload
        payload = json.dumps({
            "iss": ak,
            "exp": int(time.time()) + 1800,
            "nbf": int(time.time()) - 5
        }, separators=(',', ':'))
        payload_b64 = base64.urlsafe_b64encode(payload.encode()).decode().rstrip('=')
        
        # Signature
        message = f"{header_b64}.{payload_b64}"
        signature = hmac.new(
            sk.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
        
        return f"{message}.{signature_b64}"


def generate_image(prompt: str, filename: str, aspect_ratio: str = "3:4"):
    """使用可灵生成图像"""
    access_key, secret_key = get_credentials()
    
    # 生成JWT Token
    api_token = encode_jwt_token(access_key, secret_key)
    
    path = "/v1/images/generations"
    url = f"{KLING_API_BASE}{path}"
    
    # 请求数据
    data = {
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "n": 1,
        "model": "kling-v1"
    }
    body = json.dumps(data)
    
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }
    
    try:
        req = urllib.request.Request(
            url,
            data=body.encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        print(f"Sending request to {url}...")
        
        with urllib.request.urlopen(req, timeout=300) as response:
            result = json.loads(response.read().decode('utf-8'))
            print(f"Response: {json.dumps(result, indent=2, ensure_ascii=False)}")
            
            # 处理响应
            if result.get('code') == 0 and 'data' in result:
                task_id = result['data'].get('task_id')
                if task_id:
                    print(f"Task submitted: {task_id}")
                    return poll_image_result(task_id, filename, access_key, secret_key)
            
            print(f"Error: {result.get('message', 'Unknown error')}")
            return False
            
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} - {e.reason}")
        error_body = e.read().decode('utf-8')
        print(f"Response: {error_body}")
        return False
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def poll_image_result(task_id: str, filename: str, access_key: str, secret_key: str):
    """轮询获取图像结果"""
    path = f"/v1/images/generations/{task_id}"
    url = f"{KLING_API_BASE}{path}"
    
    print("Waiting for image generation...")
    
    for i in range(60):  # 最多等待5分钟
        time.sleep(5)
        
        # 重新生成JWT Token（防止过期）
        api_token = encode_jwt_token(access_key, secret_key)
        headers = {"Authorization": f"Bearer {api_token}"}
        
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if result.get('code') != 0:
                    print(f"Error: {result.get('message')}")
                    continue
                
                data = result.get('data', {})
                status = data.get('status')
                
                print(f"Status: {status} ({i*5}s)")
                
                if status == 'succeed':
                    # 获取图片URL
                    results = data.get('results', [])
                    if results and len(results) > 0:
                        image_url = results[0].get('url')
                        if image_url:
                            print(f"Downloading image from {image_url}...")
                            # 下载图片
                            img_req = urllib.request.Request(image_url)
                            with urllib.request.urlopen(img_req, timeout=60) as img_response:
                                Path(filename).write_bytes(img_response.read())
                            print(f"Image saved: {filename}")
                            return True
                elif status == 'failed':
                    print(f"Generation failed: {data.get('failed_reason', 'Unknown')}")
                    return False
                    
        except Exception as e:
            print(f"Polling error: {e}")
    
    print("Timeout waiting for image generation")
    return False


def main():
    parser = argparse.ArgumentParser(description="Generate images using Kling AI")
    parser.add_argument("--prompt", required=True, help="Image description prompt")
    parser.add_argument("--filename", required=True, help="Output filename (must end with .jpg)")
    parser.add_argument("--aspect-ratio", default="3:4",
                       choices=["1:1", "2:3", "3:2", "3:4", "4:3", "9:16", "16:9"],
                       help="Aspect ratio (default: 3:4)")
    
    args = parser.parse_args()
    
    # 确保文件名以.jpg结尾
    if not args.filename.endswith('.jpg'):
        args.filename += '.jpg'
    
    print(f"Generating image with Kling AI...")
    print(f"Prompt: {args.prompt}")
    print(f"Aspect ratio: {args.aspect_ratio}")
    
    if not HAS_JWT:
        print("Note: PyJWT not installed, using manual JWT implementation")
    
    success = generate_image(args.prompt, args.filename, args.aspect_ratio)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
