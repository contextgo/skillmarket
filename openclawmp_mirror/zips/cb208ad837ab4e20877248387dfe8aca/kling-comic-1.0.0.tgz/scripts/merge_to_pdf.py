#!/usr/bin/env python3
"""
合并漫画图片为PDF

Usage:
    python merge_to_pdf.py --input-dir "comic/my-comic/images" --output "my-comic.pdf"
"""

import argparse
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("Error: PIL not installed. Run: pip install pillow")
    sys.exit(1)


def merge_images_to_pdf(input_dir: str, output_file: str):
    """合并图片为PDF"""
    input_path = Path(input_dir)
    
    # 获取所有图片文件
    image_files = sorted([
        f for f in input_path.glob("*.jpg")
        if f.name != "characters.jpg"
    ])
    
    if not image_files:
        print(f"No images found in {input_dir}")
        return False
    
    print(f"Found {len(image_files)} images")
    
    # 打开所有图片
    images = []
    for img_file in image_files:
        print(f"Loading: {img_file.name}")
        img = Image.open(img_file)
        # 转换为RGB（PDF不支持RGBA）
        if img.mode != 'RGB':
            img = img.convert('RGB')
        images.append(img)
    
    # 保存为PDF
    if images:
        first_image = images[0]
        other_images = images[1:] if len(images) > 1 else []
        
        first_image.save(
            output_file,
            "PDF",
            resolution=100.0,
            save_all=True,
            append_images=other_images
        )
        print(f"PDF saved: {output_file}")
        return True
    
    return False


def main():
    parser = argparse.ArgumentParser(description="Merge comic images to PDF")
    parser.add_argument("--input-dir", required=True, help="Directory containing images")
    parser.add_argument("--output", required=True, help="Output PDF filename")
    
    args = parser.parse_args()
    
    # 确保输出文件名以.pdf结尾
    if not args.output.endswith('.pdf'):
        args.output += '.pdf'
    
    success = merge_images_to_pdf(args.input_dir, args.output)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
