#!/usr/bin/env python3
"""
使用可灵(Kling)AI生成视频
支持文生视频和图生视频

Usage:
    # 文生视频
    python generate_video.py --prompt "描述" --filename "output.mp4"
    
    # 图生视频
    python generate_video.py --prompt "描述" --input-image "input.jpg" --filename "output.mp4"
"""

import argparse
import os
import sys
import json
import urllib.request
import urllib.error
import time
from pathlib import Path

KLING_API_BASE = "https://api.klingai.com"


def get_api_key():
    """从环境变量获取API Key"""
    api_key = os.environ.get("KLING_API_KEY")
    if not api_key:
        print("Error: KLING_API_KEY environment variable not set")
        print("Please set it: export KLING_API_KEY='your-key'")
        sys.exit(1)
    return api_key


def submit_video_job(prompt: str, input_image: str = None, duration: int = 5):
    """提交视频生成任务"""
    api_key = get_api_key()
    
    url = f"{KLING_API_BASE}/v1/videos/generations"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "prompt": prompt,
        "duration": duration,
        "model": "kling-video-v1"
    }
    
    if input_image:
        # 读取图片并转为base64
        image_data = Path(input_image).read_bytes()
        import base64
        data["image"] = base64.b64encode(image_data).decode('utf-8')
    
    try:
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=60) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result.get('data', {}).get('task_id')
            
    except Exception as e:
        print(f"Error submitting job: {e}")
        return None


def check_job_status(task_id: str):
    """检查任务状态"""
    api_key = get_api_key()
    url = f"{KLING_API_BASE}/v1/videos/generations/{task_id}"
    
    headers = {
        "Authorization": f"Bearer {api_key}"
    }
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result.get('data', {})
    except Exception as e:
        print(f"Error checking status: {e}")
        return None


def download_video(url: str, filename: str):
    """下载视频"""
    api_key = get_api_key()
    try:
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {api_key}"})
        with urllib.request.urlopen(req) as response:
            Path(filename).write_bytes(response.read())
        return True
    except Exception as e:
        print(f"Error downloading video: {e}")
        return False


def generate_video(prompt: str, filename: str, input_image: str = None, duration: int = 5):
    """生成视频"""
    print(f"Submitting video generation job...")
    print(f"Prompt: {prompt}")
    if input_image:
        print(f"Input image: {input_image}")
    print(f"Duration: {duration}s")
    
    # 提交任务
    task_id = submit_video_job(prompt, input_image, duration)
    if not task_id:
        print("Failed to submit job")
        return False
    
    print(f"Task ID: {task_id}")
    print("Waiting for generation (this may take 30s-2min)...")
    
    # 轮询检查状态
    max_retries = 60
    for i in range(max_retries):
        time.sleep(5)
        status_data = check_job_status(task_id)
        
        if not status_data:
            continue
        
        status = status_data.get('status')
        print(f"Status: {status} ({i*5}s)")
        
        if status == 'completed':
            video_url = status_data.get('video_url')
            if video_url and download_video(video_url, filename):
                print(f"Video saved: {filename}")
                return True
        elif status == 'failed':
            print(f"Generation failed: {status_data.get('error', 'Unknown error')}")
            return False
    
    print("Timeout waiting for video generation")
    return False


def main():
    parser = argparse.ArgumentParser(description="Generate videos using Kling AI")
    parser.add_argument("--prompt", required=True, help="Video description prompt")
    parser.add_argument("--filename", required=True, help="Output filename (must end with .mp4)")
    parser.add_argument("--input-image", help="Input image for image-to-video (optional)")
    parser.add_argument("--duration", type=int, default=5, choices=[5, 10],
                       help="Video duration in seconds (default: 5)")
    
    args = parser.parse_args()
    
    # 确保文件名以.mp4结尾
    if not args.filename.endswith('.mp4'):
        args.filename += '.mp4'
    
    success = generate_video(args.prompt, args.filename, args.input_image, args.duration)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
