#!/usr/bin/env python3
"""测试可灵API认证"""

import os
import sys
import json
import urllib.request
import urllib.error
import hashlib
import hmac
import base64
import time
from urllib.parse import urlencode

ACCESS_KEY = "AkrBMdkMBbnErJyn48QEeprMBkTaJAGf"
SECRET_KEY = "gbPFhmnyF4tgRnhCpLeaAKGMf4rMQ9bN"

def test_bearer():
    """测试Bearer Token"""
    print("=== Testing Bearer Token ===")
    url = "https://api.klingai.com/v1/images/generations"
    
    headers = {
        "Authorization": f"Bearer {ACCESS_KEY}",
        "Content-Type": "application/json"
    }
    
    data = json.dumps({"prompt": "test", "n": 1}).encode('utf-8')
    
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

def test_aksk():
    """测试AK/SK签名"""
    print("\n=== Testing AK/SK Signature ===")
    
    method = "POST"
    path = "/v1/images/generations"
    url = f"https://api.klingai.com{path}"
    
    timestamp = str(int(time.time()))
    nonce = str(int(time.time() * 1000))
    
    body = json.dumps({"prompt": "test", "n": 1})
    
    # 构建签名字符串
    string_to_sign = f"{method}\n{path}\n\n{body}\n{timestamp}\n{nonce}"
    
    print(f"String to sign: {string_to_sign}")
    
    # HMAC-SHA256签名
    signature = hmac.new(
        SECRET_KEY.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    print(f"Signature: {signature}")
    
    headers = {
        "Authorization": f"{ACCESS_KEY}:{signature}",
        "X-Api-Timestamp": timestamp,
        "X-Api-Nonce": nonce,
        "Content-Type": "application/json"
    }
    
    print(f"Headers: {headers}")
    
    try:
        req = urllib.request.Request(url, data=body.encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

def test_basic_auth():
    """测试Basic Auth"""
    print("\n=== Testing Basic Auth ===")
    
    url = "https://api.klingai.com/v1/images/generations"
    
    # Base64编码
    credentials = base64.b64encode(f"{ACCESS_KEY}:{SECRET_KEY}".encode()).decode()
    
    headers = {
        "Authorization": f"Basic {credentials}",
        "Content-Type": "application/json"
    }
    
    data = json.dumps({"prompt": "test", "n": 1}).encode('utf-8')
    
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f"Success: {response.read().decode('utf-8')}")
    except urllib.error.HTTPError as e:
        print(f"Failed: {e.code} - {e.read().decode('utf-8')}")

if __name__ == "__main__":
    test_bearer()
    test_aksk()
    test_basic_auth()
