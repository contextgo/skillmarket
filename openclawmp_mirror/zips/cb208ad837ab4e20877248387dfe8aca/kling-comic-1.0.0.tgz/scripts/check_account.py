#!/usr/bin/env python3
"""
检查可灵账户信息
"""

import os
import sys
import json
import urllib.request
import time
import hmac
import hashlib
import base64

KLING_API_BASE = "https://api-beijing.klingai.com"


def encode_jwt_token(ak, sk):
    """生成JWT Token"""
    # Header
    header = json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(',', ':'))
    header_b64 = base64.urlsafe_b64encode(header.encode()).decode().rstrip('=')
    
    # Payload
    payload = json.dumps({
        "iss": ak,
        "exp": int(time.time()) + 1800,
        "nbf": int(time.time()) - 5
    }, separators=(',', ':'))
    payload_b64 = base64.urlsafe_b64encode(payload.encode()).decode().rstrip('=')
    
    # Signature
    message = f"{header_b64}.{payload_b64}"
    signature = hmac.new(
        sk.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).digest()
    signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
    
    return f"{message}.{signature_b64}"


def check_account(access_key, secret_key):
    """查询账户信息"""
    api_token = encode_jwt_token(access_key, secret_key)
    
    path = "/v1/account/info"
    url = f"{KLING_API_BASE}{path}"
    
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            print(f"Account Info Response:")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return result
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} - {e.reason}")
        print(f"Response: {e.read().decode('utf-8')}")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None


if __name__ == "__main__":
    access_key = os.environ.get("KLING_ACCESS_KEY")
    secret_key = os.environ.get("KLING_SECRET_KEY")
    
    if not access_key or not secret_key:
        print("Error: 请设置 KLING_ACCESS_KEY 和 KLING_SECRET_KEY")
        sys.exit(1)
    
    print(f"Checking account with Access Key: {access_key[:10]}...")
    check_account(access_key, secret_key)
