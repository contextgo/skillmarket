# AI 日报 Skill 使用文档

## 安装

```bash
cd ~/.openclaw/workspace/skills/ai-daily-news
npm install
```

## 使用方法

### 完整流程（抓取 + 生成 + 保存）

```bash
node ai-daily-news.js
```

### 仅抓取新闻

```bash
node ai-daily-news.js fetch
```

### 仅生成简报

```bash
node ai-daily-news.js format
```

### 仅发送简报

```bash
node ai-daily-news.js send
```

## 配置文件

编辑 `config.json` 添加更多数据源：

```json
{
  "sources": [
    {
      "type": "rss",
      "name": "TechCrunch AI",
      "url": "https://techcrunch.com/category/artificial-intelligence/feed/"
    },
    {
      "type": "rss",
      "name": "MIT Technology Review",
      "url": "https://www.technologyreview.com/topic/artificial-intelligence/feed/"
    }
  ]
}
```

## 定时任务

已配置每天9点自动运行：

```bash
# 查看定时任务
openclaw cron list

# 手动触发
openclaw cron run ai-daily-news
```

## 翻译功能

自动将英文新闻标题翻译为中文（使用 MyMemory 免费 API）：
- ✅ 完全免费，每天 5000 字符额度
- ✅ 无需 API Key
- ✅ 国内可访问
- ✅ 自动跳过已中文内容

翻译在抓取后自动进行，简报中所有标题均为中文。

## 输出文件

- `data/items.json` - 抓取的新闻原始数据
- `data/items_translated.json` - 翻译后的新闻数据
- `data/briefing.txt` - 生成的简报

## 简报格式

- 📰 标题 + 日期
- 🔥 今日头条（3条）
- 📊 关键数据（自动提取数字）
- 🎯 热门话题（按领域分类）
