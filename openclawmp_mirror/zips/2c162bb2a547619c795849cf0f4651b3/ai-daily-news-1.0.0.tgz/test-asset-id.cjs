// test-asset-id.js - 测试官方 asset_id 算法
const crypto = require('crypto');

// 官方算法（来自文档）
function computeAssetIdOfficial(asset) {
  const clean = { ...asset };
  delete clean.asset_id;
  const sorted = JSON.stringify(clean, Object.keys(clean).sort());
  return "sha256:" + crypto.createHash("sha256").update(sorted).digest("hex");
}

// 我的算法
function computeAssetIdMine(asset) {
  const clean = JSON.parse(JSON.stringify(asset));
  delete clean.asset_id;
  
  const sortedObj = {};
  Object.keys(clean).sort().forEach(key => {
    sortedObj[key] = clean[key];
  });
  
  const sorted = JSON.stringify(sortedObj);
  return "sha256:" + crypto.createHash("sha256").update(sorted).digest("hex");
}

// 测试数据
const capsule = {
  type: "Capsule",
  gene: "sha256:68f039297a3b92fe1ee664b7ff471bdc2c07654b88bbde1ca7b17255b542f83f",
  summary: "AI 新闻日报多源抓取与自动翻译实现 - RSS聚合+MyMemory翻译+智能分类+飞书推送",
  confidence: 0.95,
  trigger: ["cron_daily", "ai_news", "rss_fetch", "translation"],
  blast_radius: { files: 8, lines: 1166 },
  outcome: { status: "success", score: 0.95 },
  env_fingerprint: { runtime: "node18+", platform: "linux", arch: "x64", dependencies: ["fast-xml-parser"], apis: ["MyMemory Translate API (free)"] }
};

console.log('Official algorithm:');
const officialId = computeAssetIdOfficial(capsule);
console.log('  Asset ID:', officialId);

console.log('\nMy algorithm:');
const myId = computeAssetIdMine(capsule);
console.log('  Asset ID:', myId);

console.log('\nMatch:', officialId === myId ? 'YES' : 'NO');

// 打印官方的 sorted JSON
const clean = { ...capsule };
delete clean.asset_id;
console.log('\nOfficial sorted JSON:', JSON.stringify(clean, Object.keys(clean).sort()));
