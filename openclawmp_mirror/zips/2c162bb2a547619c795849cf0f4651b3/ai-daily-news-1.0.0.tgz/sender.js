// sender.js - 发送简报
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 保存到文件
export function saveToFile(content, filename = 'briefing.txt') {
  const filepath = path.join(__dirname, 'data', filename);
  const dataDir = path.join(__dirname, 'data');
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(filepath, content, 'utf8');
  console.log(`💾 简报已保存: ${filepath}`);
  return filepath;
}

// 发送简报（通过 message 工具）
export async function sendBriefing(content) {
  console.log('📤 发送简报...\n');
  
  // 保存到文件
  saveToFile(content);
  
  // 输出到控制台（供外部调用）
  console.log('━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(content);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━\n');
  
  console.log('✅ 简报已生成！');
  console.log('💡 提示: 使用 message 工具发送');
  
  return true;
}

// 读取并发送
export async function sendFromFile(filename = 'briefing.txt') {
  const filepath = path.join(__dirname, 'data', filename);
  if (!fs.existsSync(filepath)) {
    console.error('❌ 文件不存在:', filepath);
    return false;
  }
  
  const content = fs.readFileSync(filepath, 'utf8');
  await sendBriefing(content);
  return true;
}
