---
name: ai-daily-news
description: "AI 日报 - 自动抓取 AI 新闻并生成简报，支持定时推送"
version: 1.0.0
type: skill
---

# AI 日报

自动抓取 AI 新闻，生成简报并推送。

## 功能

- 📰 自动抓取多个 AI 新闻源
- 📝 智能生成简报（今日头条 + 关键数据 + 热门话题）
- ⏰ 支持定时推送（默认每天9点）
- 🚀 手动触发即时获取

## 使用方法

### 手动生成今日简报

```bash
cd ~/.openclaw/workspace/skills/ai-daily-news
node ai-daily-news.js
```

### 仅抓取新闻

```bash
node ai-daily-news.js fetch
```

### 仅发送简报

```bash
node ai-daily-news.js send
```

## 配置

编辑 `config.json`：

```json
{
  "sources": [
    {
      "type": "rss",
      "name": "TechCrunch AI",
      "url": "https://techcrunch.com/category/artificial-intelligence/feed/"
    }
  ],
  "schedule": {
    "daily": "0 9 * * *"
  }
}
```

## 定时任务

已配置每天9点自动推送：
- 抓取最新 AI 新闻
- 生成简报
- 发送飞书消息

## 数据源

- TechCrunch AI
- MIT Technology Review
- （可配置更多）
