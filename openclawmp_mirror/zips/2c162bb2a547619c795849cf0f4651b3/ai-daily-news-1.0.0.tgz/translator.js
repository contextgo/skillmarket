// translator.js - MyMemory 免费翻译 API
// 每天 5000 字符免费额度，无需 API Key

import https from 'https';
import querystring from 'querystring';

const MYMEMORY_API_URL = 'api.mymemory.translated.net';

/**
 * 翻译单个文本
 * @param {string} text - 要翻译的文本
 * @param {string} sourceLang - 源语言（默认 auto 自动检测）
 * @param {string} targetLang - 目标语言（默认 zh-CN 中文）
 * @returns {Promise<string>} 翻译后的文本
 */
export async function translateText(text, sourceLang = 'en', targetLang = 'zh-CN') {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // 如果已经是中文，直接返回
  const chineseRatio = (text.match(/[\u4e00-\u9fa5]/g) || []).length / text.length;
  if (chineseRatio > 0.5) {
    return text;
  }
  
  return new Promise((resolve, reject) => {
    const params = querystring.stringify({
      q: text,
      langpair: `${sourceLang}|${targetLang}`,
      mt: '1' // 使用机器翻译
    });
    
    const options = {
      hostname: MYMEMORY_API_URL,
      path: `/get?${params}`,
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json'
      },
      timeout: 5000
    };
    
    const req = https.get(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.responseData && result.responseData.translatedText) {
            resolve(result.responseData.translatedText);
          } else {
            console.log('⚠️ MyMemory 翻译失败:', result.responseDetails || 'Unknown error');
            resolve(text); // 失败返回原文
          }
        } catch (error) {
          console.error('❌ MyMemory 解析失败:', error.message);
          resolve(text);
        }
      });
    });
    
    req.on('error', (error) => {
      console.error('❌ MyMemory 请求失败:', error.message);
      resolve(text);
    });
    
    req.on('timeout', () => {
      console.error('❌ MyMemory 超时');
      req.destroy();
      resolve(text);
    });
    
    req.end();
  });
}

/**
 * 批量翻译（带延迟避免 rate limit）
 * @param {string[]} texts - 要翻译的文本数组
 * @param {number} delay - 每条之间的延迟（毫秒，默认300）
 * @returns {Promise<string[]>} 翻译后的文本数组
 */
export async function translateBatch(texts, delay = 300) {
  const results = [];
  let translatedCount = 0;
  let skippedCount = 0;
  
  for (let i = 0; i < texts.length; i++) {
    const text = texts[i];
    const chineseRatio = (text.match(/[\u4e00-\u9fa5]/g) || []).length / text.length;
    
    // 如果已经是中文，跳过翻译
    if (chineseRatio > 0.5 || !text.trim()) {
      results.push(text);
      skippedCount++;
      continue;
    }
    
    try {
      const translated = await translateText(text);
      results.push(translated);
      translatedCount++;
      
      // 添加延迟避免 rate limit
      if (i < texts.length - 1 && delay > 0) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    } catch (error) {
      console.error(`❌ 翻译失败 [${i}]:`, error.message);
      results.push(text);
    }
  }
  
  console.log(`🌐 MyMemory 翻译: ${translatedCount} 成功, ${skippedCount} 跳过 (中文/空文本)`);
  return results;
}

/**
 * 翻译新闻项目
 * @param {Object[]} items - 新闻项目数组
 * @returns {Promise<Object[]>} 翻译后的新闻项目
 */
export async function translateNewsItems(items) {
  console.log('🌐 开始翻译新闻 (MyMemory 免费 API)...');
  console.log(`📄 共 ${items.length} 条新闻`);
  
  // 提取所有标题
  const titles = items.map(item => item.title || '');
  
  // 翻译标题
  console.log('📝 翻译标题...');
  const translatedTitles = await translateBatch(titles, 200);
  
  // 合并结果
  const translatedItems = items.map((item, index) => ({
    ...item,
    title: translatedTitles[index] || item.title,
    _translated: translatedTitles[index] !== item.title
  }));
  
  const translatedCount = translatedItems.filter(i => i._translated).length;
  console.log(`✅ 翻译完成: ${translatedCount}/${items.length} 条新闻`);
  
  return translatedItems;
}

export default { translateText, translateBatch, translateNewsItems };
