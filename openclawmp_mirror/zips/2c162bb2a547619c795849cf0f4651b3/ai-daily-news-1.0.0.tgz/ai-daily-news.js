#!/usr/bin/env node
/**
 * AI 日报 - 主入口
 * 自动抓取 AI 新闻，生成简报并推送
 * 集成 Auto Debug 自动错误修复
 */

import { fetchNews } from './fetcher.js';
import { formatBriefing } from './formatter.js';
import { sendBriefing } from './sender.js';
import { translateNewsItems } from './translator.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const command = process.argv[2] || 'all';
const noTranslate = process.argv.includes('--no-translate');

// 从 JSON 文件读取抓取结果
function loadFetchedItems() {
  const dataPath = path.join(__dirname, 'data', 'items.json');
  if (fs.existsSync(dataPath)) {
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  }
  return [];
}

async function main() {
  console.log('🚀 AI 日报启动...\n');
  
  try {
    let items = [];
    
    // 抓取新闻
    if (command === 'fetch' || command === 'all') {
      console.log('📡 抓取新闻...');
      items = await fetchNews();
      
      // 保存到文件
      const dataDir = path.join(__dirname, 'data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(
        path.join(dataDir, 'items.json'),
        JSON.stringify(items, null, 2)
      );
      console.log(`✅ 抓取完成: ${items.length} 条新闻\n`);
      
      // 翻译新闻（DeepL API）
      if (!noTranslate) {
        console.log('🌐 翻译新闻...');
        items = await translateNewsItems(items);
        
        // 保存翻译后的数据
        fs.writeFileSync(
          path.join(dataDir, 'items_translated.json'),
          JSON.stringify(items, null, 2)
        );
        console.log('✅ 翻译完成\n');
      } else {
        console.log('⏭️  跳过翻译（使用原文）\n');
      }
    } else {
      items = loadFetchedItems();
      console.log(`📂 加载已有数据: ${items.length} 条\n`);
    }
    
    // 生成简报
    if ((command === 'format' || command === 'all') && items.length > 0) {
      console.log('📝 生成简报...');
      const briefing = await formatBriefing(items);
      
      // 保存简报
      fs.writeFileSync(
        path.join(__dirname, 'data', 'briefing.txt'),
        briefing
      );
      console.log('✅ 简报生成完成\n');
      console.log('━━━━━━━━━━━━━━━━━━━━━━━');
      console.log(briefing);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━\n');
    }
    
    // 发送简报
    if (command === 'send' || command === 'all') {
      console.log('📤 准备发送...');
      const briefingPath = path.join(__dirname, 'data', 'briefing.txt');
      if (fs.existsSync(briefingPath)) {
        const briefing = fs.readFileSync(briefingPath, 'utf8');
        await sendBriefing(briefing);
      } else {
        console.error('❌ 简报不存在，先运行 format');
      }
    }
    
    console.log('\n✅ 完成！');
  } catch (e) {
    console.error('\n❌ 错误:', e.message);
    console.error(e.stack);
    process.exit(1);
  }
}

main();
