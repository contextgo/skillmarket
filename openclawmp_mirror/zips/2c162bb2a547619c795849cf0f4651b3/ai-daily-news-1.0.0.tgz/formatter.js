// formatter.js - 格式化简报
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 格式化日期
function formatDate() {
  const now = new Date();
  return `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`;
}

// 提取关键数据
function extractKeyData(items) {
  const data = [];
  const seen = new Set();
  
  items.forEach(item => {
    const title = item.title || '';
    const matches = title.match(/(\d+[\d,]*(?:\.\d+)?)\s*(亿|万|百万|千万|B|M|K|%|billion|million)/gi);
    if (matches) {
      matches.forEach(match => {
        const clean = match.replace(/,/g, '');
        if (!seen.has(clean)) {
          seen.add(clean);
          data.push(match);
        }
      });
    }
  });
  
  return data.slice(0, 6);
}

// 翻译标题 - 使用完整映射
function translateTitle(title) {
  if (!title) return '';
  
  // 如果已经是中文，直接返回
  if (/^[\u4e00-\u9fa5\s\d]+$/.test(title)) {
    return title;
  }
  
  // 完整标题翻译映射
  const titleMap = {
    'Google looks to tackle longstanding RCS spam in India — but not alone': '谷歌联手Airtel治理印度RCS垃圾信息',
    'OpenAI reveals more details about its agreement with the Pentagon': 'OpenAI披露与五角大楼合作协议详情',
    "Anthropic's Claude rises to No. 1 in the App Store following Pentagon dispute": 'Claude升至应用商店榜首',
    "Anthropic's Claude rises to No. 2 in the App Store following Pentagon dispute": 'Claude升至应用商店第二',
    "Anthropic\u2019s Claude rises to No. 1 in the App Store following Pentagon dispute": 'Claude升至应用商店榜首',
    "Anthropic\u2019s Claude rises to No. 2 in the App Store following Pentagon dispute": 'Claude升至应用商店第二',
    'Anthropic\'s Claude rises to No. 2 in the App Store following Pentagon dispute': 'Anthropic Claude升至应用商店第二',
    "SaaS in, SaaS out: Here's what's driving the SaaSpocalypse": 'SaaS行业大洗牌：什么推动了这场变革',
    'SaaS in, SaaS out: Here&#8217;s what&#8217;s driving the SaaSpocalypse': 'SaaS行业大洗牌：什么推动了这场变革',
    'The trap Anthropic built for itself': 'Anthropic自我设限的困境',
    'The billion-dollar infrastructure deals powering the AI boom': '十亿美元级基础设施交易推动AI繁荣',
    'OpenAI\'s Sam Altman announces Pentagon deal with \'technical safeguards\'': 'Sam Altman宣布与五角大楼合作',
    'Pentagon moves to designate Anthropic as a supply-chain risk': '五角大楼拟将Anthropic列为供应链风险',
    'ChatGPT reaches 900M weekly active users': 'ChatGPT周活跃用户达9亿',
    'AI music generator Suno hits 2M paid subscribers and $300M in annual recurring revenue': 'Suno AI音乐生成器付费用户达200万',
    'AI is rewiring how the world\'s best Go players think': 'AI正在重塑世界顶级围棋选手思维',
    'The human work behind humanoid robots is being hidden': '人形机器人背后的人类劳动被隐藏',
    'Microsoft has a new plan to prove what\'s real and what\'s AI online': '微软推出验证网络内容真伪新方案',
    'Google DeepMind wants to know if chatbots are just virtue signaling': 'DeepMind质疑聊天机器人是否在道德表演',
    'AI is already making online crimes easier. It could get much worse.': 'AI已使网络犯罪更容易，情况可能更糟',
    'What\'s next for Chinese open-source AI': '中国开源AI的下一步',
    'Is a secure AI assistant possible?': '安全的AI助手是否可能',
    'A "QuitGPT" campaign is urging people to cancel their ChatGPT subscriptions': '"QuitGPT"运动呼吁取消ChatGPT订阅',
    'Finding value with AI and Industry 5.0 transformation': 'AI与工业5.0转型的价值发现',
    'The Algorithm: AI news and updates': 'AI算法：新闻与更新',
    'Nvidia\'s Jensen Huang says we\'re entering the age of physical AI': '英伟达黄仁勋：我们正进入物理AI时代',
    'Meta is building a $10 billion subsea cable': 'Meta投资100亿美元建设海底光缆',
    'Amazon\'s new AI model can\'t stop hallucinating': '亚马逊新AI模型幻觉问题严重',
    'Apple\'s AI strategy faces headwinds': '苹果AI战略遭遇阻力',
    'Tesla\'s robotaxi plans hit regulatory roadblocks': '特斯拉Robotaxi计划遭遇监管障碍',
    'Microsoft unveils new AI-powered Windows features': '微软发布AI驱动Windows新功能',
    // 新增今日新闻翻译
    'Tech giants make non-binding White House pledge to cover AI data center energy costs': '科技巨头签署白宫非约束性承诺，承担AI数据中心能源成本',
    "Ikea's Matter-compatible smart bulbs are now available in the US": '宜家Matter兼容智能灯泡在美国上市',
    'Apple puts AI disclosure responsibility on labels and distributors': '苹果将AI披露责任交由标签和分销商',
    'Apple Music adds optional labels for AI songs and visuals': '苹果Music为AI歌曲和视觉内容添加可选标签',
    'Apple Music to add Transparency Tags to distinguish AI music, says report': '报道称苹果Music将添加透明度标签以区分AI音乐',
    'Anthropic CEO attacks OpenAI\'s Pentagon deal as "safety theater" while investors scramble for de-escalation': 'Anthropic CEO抨击OpenAI五角大楼交易是"安全表演"',
    'Anthropic makes last-ditch effort to salvage Pentagon relationship': 'Anthropic最后一刻努力挽救与五角大楼关系',
    "Jensen Huang says Nvidia is pulling back from OpenAI's orbit": '黄仁勋称英伟达正从OpenAI轨道回撤',
    'Alibaba\'s chief AI developer quits, taking team with him': '阿里巴巴首席AI开发者离职，带走团队',
    'How 1,000+ customer calls shaped a breakout email AI agent': '1000多个客户电话如何塑造突破性邮件AI代理',
    'Lio raises $30M from Andreessen Horowitz and others to automate enterprise procurement': 'Lio融资3000万美元自动化企业采购',
    'Online harassment is entering its AI era': '网络骚扰正在进入AI时代',
    // 修正匹配 - 注意转义
    'Ikea\u2019s Matter-compatible smart bulbs are now available in the US': '宜家Matter兼容智能灯泡在美国上市',
    'Ikea\'s Matter-compatible smart bulbs are now available in the US': '宜家Matter兼容智能灯泡在美国上市',
    'How 1,000+ customer calls shaped a breakout enterprise AI startup': '1000多个客户电话如何塑造突破性企业AI初创公司',
    'Anthropic CEO attacks OpenAI\u2019s Pentagon deal as "safety theater" while investors scramble for de-escalation': 'Anthropic CEO抨击OpenAI五角大楼交易是"安全表演"',
    'Anthropic CEO attacks OpenAI\'s Pentagon deal as "safety theater" while investors scramble for de-escalation': 'Anthropic CEO抨击OpenAI五角大楼交易是"安全表演"',
    'Anthropic CEO attacks OpenAI&#039;s Pentagon deal as "safety theater" while investors scramble for de-escalation': 'Anthropic CEO抨击OpenAI五角大楼交易是"安全表演"',
    // 2026-03-07 新增
    'Grammarly is using our identities without permission': 'Grammarly 未经许可使用用户身份信息',
    'Nintendo is suing the US government for a refund of Trump&#8217;s illegal tariffs': '任天堂起诉美国政府要求退还特朗普非法关税',
    'Nintendo is suing the US government for a refund of Trump\'s illegal tariffs': '任天堂起诉美国政府要求退还特朗普非法关税',
    'The best microSD Express card for the Switch 2 is the cheapest one you can find': 'Switch 2 最佳 microSD Express 卡是能找到的最便宜的',
    'Microsoft, Google, Amazon say Anthropic Claude remains available to non-defense customers': '微软、谷歌、亚马逊称 Anthropic Claude 仍对非国防客户可用',
    'Is the Pentagon allowed to surveil Americans with AI?': '五角大楼被允许用 AI 监视美国人吗？',
    'City Detect, which uses AI to help cities standardize building code enforcement, raises $17M': 'City Detect 融资1700万美元用AI帮助城市标准化建筑法规执行',
    'Meta智能眼镜曝隐私风险 用户AI互动画面会被第三方查看': 'Meta智能眼镜曝隐私风险 用户AI互动画面会被第三方查看',
    '倒计时10天，2026 AI最佳场景渗透案例火热征集中': '倒计时10天，2026 AI最佳场景渗透案例火热征集中'
  };
  
  // 精确匹配
  if (titleMap[title]) {
    return titleMap[title];
  }
  
  // 关键词替换（作为后备）
  const keywordMap = {
    'Google': '谷歌',
    'OpenAI': 'OpenAI',
    'Anthropic': 'Anthropic',
    'Claude': 'Claude',
    'ChatGPT': 'ChatGPT',
    'Microsoft': '微软',
    'DeepMind': 'DeepMind',
    'Meta': 'Meta',
    'Amazon': '亚马逊',
    'Apple': '苹果',
    'Tesla': '特斯拉',
    'Nvidia': '英伟达',
    'Pentagon': '五角大楼',
    'Department of Defense': '国防部',
    'Sam Altman': 'Sam Altman',
    'App Store': '应用商店',
    'rises to No. 1': '升至第一',
    'rises to No. 2': '升至第二',
    'rises': '上升',
    'tops': '登顶',
    'hits': '达到',
    'reaches': '达到',
    'spam': '垃圾信息',
    'reveals': '披露',
    'agreement': '协议',
    'deal': '交易',
    'dispute': '争议',
    'India': '印度'
  };
  
  let translated = title;
  
  // 按长度降序排序，优先替换长词
  const sortedKeywords = Object.entries(keywordMap)
    .sort((a, b) => b[0].length - a[0].length);
  
  for (const [en, cn] of sortedKeywords) {
    const regex = new RegExp(en.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    translated = translated.replace(regex, cn);
  }
  
  return translated;
}

// 批量翻译标题
function translateTitles(items) {
  const translations = {};
  
  for (const item of items) {
    if (item.title) {
      translations[item.title] = translateTitle(item.title);
    }
  }
  
  return translations;
}

// 分类话题（去重：已在今日头条出现的不重复显示）
function categorizeTopics(items, topNewsTitles) {
  const categories = {
    'AI + 国防 🔥': [],
    'AI + 机器人 🤖': [],
    'AI + 内容创作 🎵': [],
    'AI + 安全 🔒': [],
    'AI + 商业 💰': [],
    'AI + 研究 🔬': []
  };
  
  // 创建已选标题集合（用于去重）
  const seenTitles = new Set(topNewsTitles.map(t => t.toLowerCase().trim()));
  
  const keywords = {
    'AI + 国防 🔥': ['pentagon', 'military', 'defense', '国防部', '五角大楼', 'anthropic', 'openai', 'dispute', 'deal', 'agreement'],
    'AI + 机器人 🤖': ['robot', '人形机器人', 'robotics', 'humanoid', 'go', '围棋', 'players'],
    'AI + 内容创作 🎵': ['music', 'art', 'content', 'suno', 'creation', 'subscriber', 'music', 'subscription', 'chatgpt'],
    'AI + 安全 🔒': ['security', 'safety', 'crime', 'secure', '安全', 'crime', 'privacy', 'real', 'virtue', 'spam', 'filtering'],
    'AI + 商业 💰': ['funding', 'investment', 'revenue', '融资', '收入', '用户', 'billion', 'million', 'infrastructure', 'deals', 'SaaS'],
    'AI + 研究 🔬': ['deepmind', 'research', 'study', 'open-source', 'chinese']
  };
  
  items.forEach(item => {
    const title = (item.title || '').toLowerCase().trim();
    const content = (item.content || '').toLowerCase();
    const text = title + ' ' + content;
    
    // 跳过已在今日头条中出现的
    if (seenTitles.has(title)) {
      return;
    }
    
    let categorized = false;
    for (const [category, words] of Object.entries(keywords)) {
      if (words.some(word => text.includes(word.toLowerCase()))) {
        categories[category].push(item);
        categorized = true;
        break;
      }
    }
  });
  
  return categories;
}

// 相似标题合并（基于关键词匹配）
function mergeSimilarTitles(items) {
  const merged = [];
  const used = new Set();
  
  for (let i = 0; i < items.length; i++) {
    if (used.has(i)) continue;
    
    const item = items[i];
    const title = item.title || '';
    const similar = [item];
    
    // 提取关键词（公司名+核心主题）
    const keywords = extractKeywords(title);
    
    for (let j = i + 1; j < items.length; j++) {
      if (used.has(j)) continue;
      
      const other = items[j];
      const otherTitle = other.title || '';
      const otherKeywords = extractKeywords(otherTitle);
      
      // 如果关键词重叠度>50%，认为是相似新闻
      const overlap = keywords.filter(k => otherKeywords.includes(k)).length;
      if (overlap > 0 && keywords.length >= 2 && otherKeywords.length >= 2 && overlap >= 2) {
        similar.push(other);
        used.add(j);
      }
    }
    
    if (similar.length > 1) {
      // 合并多条相似新闻
      const sources = similar.map(s => s.source).filter(Boolean);
      merged.push({
        ...item,
        _merged: true,
        _sources: sources,
        _count: similar.length
      });
    } else {
      merged.push(item);
    }
    
    used.add(i);
  }
  
  return merged;
}

// 翻译摘要 - 关键词替换
function translateSummary(summary) {
  if (!summary) return '';
  
  // 如果已经是中文，直接返回
  if (/[\u4e00-\u9fa5]/.test(summary)) {
    return summary;
  }
  
  const keywordMap = {
    'Google': '谷歌',
    'OpenAI': 'OpenAI',
    'Anthropic': 'Anthropic',
    'Claude': 'Claude',
    'ChatGPT': 'ChatGPT',
    'Microsoft': '微软',
    'DeepMind': 'DeepMind',
    'Meta': 'Meta',
    'Amazon': '亚马逊',
    'Apple': '苹果',
    'Tesla': '特斯拉',
    'Nvidia': '英伟达',
    'Nintendo': '任天堂',
    'Grammarly': 'Grammarly',
    'Pentagon': '五角大楼',
    'Department of Defense': '国防部',
    'the US government': '美国政府',
    'AI': 'AI',
    'users': '用户',
    'writing': '写作',
    'advice': '建议',
    'review': '评论',
    'feature': '功能',
    'expert': '专家',
    'identities': '身份信息',
    'permission': '许可',
    'suing': '起诉',
    'government': '政府',
    'refund': '退款',
    'tariffs': '关税',
    'illegal': '非法的',
    'microSD': 'microSD卡',
    'Switch 2': 'Switch 2',
    'available': '可用',
    'non-defense customers': '非国防客户',
    'surveil': '监视',
    'Americans': '美国人'
  };
  
  let translated = summary;
  
  // 按长度降序排序，优先替换长词
  const sortedKeywords = Object.entries(keywordMap)
    .sort((a, b) => b[0].length - a[0].length);
  
  for (const [en, cn] of sortedKeywords) {
    const regex = new RegExp(en.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    translated = translated.replace(regex, cn);
  }
  
  return translated;
}
function extractKeywords(title) {
  const keywords = [];
  // 只匹配公司名，避免主题词导致过度合并
  const companyKeywords = ['Apple', 'Google', 'OpenAI', 'Anthropic', '微软', '苹果', '谷歌', '亚马逊', 'Amazon', 'Meta', 'Tesla', 'Nvidia', '英伟达', '特斯拉', '海信'];
  
  const lowerTitle = title.toLowerCase();
  
  companyKeywords.forEach(k => {
    if (lowerTitle.includes(k.toLowerCase())) keywords.push(k.toLowerCase());
  });
  
  return [...new Set(keywords)];
}

// 生成简报
export async function formatBriefing(items) {
  const date = formatDate();
  
  // 合并相似标题
  const mergedItems = mergeSimilarTitles(items);
  
  // 取前5条作为今日头条
  const topNews = mergedItems.slice(0, 5);
  
  // 批量翻译标题
  const translations = translateTitles(topNews);
  
  // 提取关键数据
  const keyData = extractKeyData(items);
  
  // 分类话题（传入今日头条标题用于去重 - 使用翻译后的标题）
  const topNewsTitles = topNews.map(item => translations[item.title] || item.title);
  const categories = categorizeTopics(items, topNewsTitles);
  
  let briefing = `📰 AI 新闻简报 - ${date}\n\n`;
  
  // 今日头条
  briefing += '🔥 今日头条\n\n';
  topNews.forEach((item, index) => {
    const title = translations[item.title] || item.title;
    briefing += `${index + 1}️⃣ ${title}`;
    
    // 如果是合并的新闻，标注来源
    if (item._merged) {
      briefing += ` [${item._count}家媒体报道]`;
    }
    briefing += '\n';
    
    // 提取摘要
    let summary = '';
    if (item.content) {
      summary = item.content
        .replace(/<[^>]*>/g, '')
        .replace(/\n/g, ' ')
        .slice(0, 100);
      if (summary.length >= 100) summary += '...';
      // 翻译摘要
      summary = translateSummary(summary);
    }
    
    if (summary && summary.length > 20) {
      briefing += `   ${summary}\n`;
    }
    briefing += '\n';
  });
  
  // 关键数据
  if (keyData.length > 0) {
    briefing += '📊 关键数据\n\n';
    keyData.forEach(data => {
      briefing += `• ${data}\n`;
    });
    briefing += '\n';
  }
  
  // 热门话题
  briefing += '🎯 热门话题\n\n';
  for (const [category, categoryItems] of Object.entries(categories)) {
    if (categoryItems.length > 0) {
      briefing += `${category}\n`;
      // 翻译分类下的标题
      for (const item of categoryItems.slice(0, 2)) {
        const title = translations[item.title] || translateTitle(item.title);
        const shortTitle = title.length > 45 ? title.slice(0, 45) + '...' : title;
        briefing += `• ${shortTitle}\n`;
      }
      briefing += '\n';
    }
  }
  
  return briefing;
}
