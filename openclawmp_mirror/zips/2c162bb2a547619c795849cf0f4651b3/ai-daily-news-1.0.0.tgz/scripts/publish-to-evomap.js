#!/usr/bin/env node
/**
 * EvoMap 自动发布脚本
 * 打包 ai-daily-news 技能并发布到 EvoMap
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import https from 'https';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// EvoMap API 配置
const EVOMAP_API_URL = 'evomap.ai';

/**
 * 注册 EvoMap 节点（更新版 - 符合官方格式）
 */
function registerNode() {
  return new Promise((resolve, reject) => {
    const messageId = `msg_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`;
    const nodeId = `node_xiaoman_${Date.now().toString(36).slice(-6)}`;
    
    const helloMessage = {
      protocol: "gep-a2a",
      protocol_version: "1.0.0",
      message_type: "hello",
      message_id: messageId,
      sender_id: nodeId,
      timestamp: new Date().toISOString(),
      payload: {
        capabilities: {
          languages: ["zh-CN", "en"],
          domains: ["ai_news", "content_translation", "rss_aggregation"]
        },
        model: "kimi-k2p5",
        gene_count: 1,
        capsule_count: 1,
        env_fingerprint: {
          node_version: process.version,
          platform: process.platform,
          arch: process.arch
        }
      }
    };
    
    const postData = JSON.stringify(helloMessage);
    
    const options = {
      hostname: EVOMAP_API_URL,
      path: '/a2a/hello',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: 30000
    };
    
    console.log('🔑 正在注册 EvoMap 节点...');
    console.log(`   Node ID: ${nodeId}`);
    
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          // 响应在 payload 字段里
          const payload = result.payload || result;
          
          if (payload.your_node_id || payload.node_id) {
            const finalNodeId = payload.your_node_id || payload.node_id;
            console.log(`✅ 节点注册成功: ${finalNodeId}`);
            console.log(`💰 获得积分: ${payload.credit_balance !== undefined ? payload.credit_balance : 500}`);
            if (payload.claim_code) {
              console.log(`🔗 Claim Code: ${payload.claim_code}`);
              console.log(`🔗 Claim URL: ${payload.claim_url}`);
            }
            if (payload.node_secret) {
              console.log(`🔐 Node Secret: ${payload.node_secret.substring(0, 16)}...`);
              // 保存 secret 供后续使用
              global.nodeSecret = payload.node_secret;
            }
            resolve(finalNodeId);
          } else {
            console.error('❌ 节点注册失败:', payload.message || payload.error || JSON.stringify(result).substring(0, 200));
            reject(new Error(payload.message || 'Registration failed'));
          }
        } catch (error) {
          console.error('❌ 解析响应失败:', error.message);
          console.error('   原始响应:', data.substring(0, 500));
          reject(error);
        }
      });
    });
    
    req.on('error', (error) => {
      console.error('❌ 请求失败:', error.message);
      reject(error);
    });
    
    req.on('timeout', () => {
      console.error('❌ 请求超时');
      req.destroy();
      reject(new Error('Timeout'));
    });
    
    req.write(postData);
    req.end();
  });
}

/**
 * 计算 asset_id（官方算法 - 递归排序所有键）
 * sha256(canonical_json(asset_without_asset_id_field))
 * Canonical JSON: sorted keys at ALL levels, deterministic serialization
 */
function computeAssetId(asset) {
  // 1. 深拷贝并移除 asset_id 字段
  const clean = JSON.parse(JSON.stringify(asset));
  delete clean.asset_id;
  
  // 2. 递归排序所有键（sorted keys at ALL levels）
  function sortKeysRecursive(obj) {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }
    
    if (Array.isArray(obj)) {
      return obj.map(sortKeysRecursive);
    }
    
    const sorted = {};
    Object.keys(obj).sort().forEach(key => {
      sorted[key] = sortKeysRecursive(obj[key]);
    });
    return sorted;
  }
  
  const sortedObj = sortKeysRecursive(clean);
  
  // 3. 生成紧凑 JSON（无空格）
  const canonicalJson = JSON.stringify(sortedObj);
  
  // 4. SHA256 哈希
  const hash = crypto.createHash("sha256").update(canonicalJson).digest("hex");
  
  return "sha256:" + hash;
}

/**
 * 读取技能文件内容
 */
function readSkillFiles() {
  const skillDir = path.join(__dirname, '..');
  
  const files = {
    'SKILL.md': fs.readFileSync(path.join(skillDir, 'SKILL.md'), 'utf8'),
    'fetcher.js': fs.readFileSync(path.join(skillDir, 'fetcher.js'), 'utf8'),
    'formatter.js': fs.readFileSync(path.join(skillDir, 'formatter.js'), 'utf8'),
    'translator.js': fs.readFileSync(path.join(skillDir, 'translator.js'), 'utf8'),
    'ai-daily-news.js': fs.readFileSync(path.join(skillDir, 'ai-daily-news.js'), 'utf8'),
    'sender.js': fs.readFileSync(path.join(skillDir, 'sender.js'), 'utf8'),
    'config.json': fs.readFileSync(path.join(skillDir, 'config.json'), 'utf8'),
    'README.md': fs.readFileSync(path.join(skillDir, 'README.md'), 'utf8')
  };
  
  return files;
}

/**
 * 创建 Gene 资产
 */
function createGene() {
  const gene = {
    type: "Gene",
    category: "innovate",
    signals_match: [
      "ai_news_fetch",
      "rss_aggregation",
      "content_translation",
      "daily_briefing"
    ],
    strategy: [
      "配置多源 RSS 抓取（TechCrunch、MIT、The Verge、36氪等）",
      "过滤24小时内 AI 相关新闻",
      "使用 MyMemory API 自动翻译英文标题为中文",
      "智能分类（AI+国防/机器人/商业/内容创作）",
      "提取关键数据（数字、融资额、用户数）",
      "生成结构化简报（今日头条+热门话题+关键数据）",
      "推送到飞书/企业微信等 IM 平台"
    ],
    summary: "AI 新闻日报自动化生成技能：多源 RSS 抓取 + MyMemory 免费翻译 + 智能分类 + 飞书推送"
  };
  
  gene.asset_id = computeAssetId(gene);
  return gene;
}

/**
 * 创建 Capsule 资产
 */
function createCapsule(geneId) {
  const capsule = {
    type: "Capsule",
    gene: geneId,
    summary: "AI 新闻日报多源抓取与自动翻译实现 - RSS聚合+MyMemory翻译+智能分类+飞书推送",
    content: "AI Daily News V2.0 实现方案：1) 使用 fast-xml-parser 解析多源 RSS (TechCrunch, MIT, The Verge, 36氪等)；2) 过滤24小时内 AI 相关新闻；3) 使用 MyMemory 免费翻译 API 自动翻译英文标题为中文；4) 智能分类到 AI+国防/机器人/商业/内容创作；5) 生成结构化简报并推送到飞书。支持定时任务每天早上9点自动运行。",
    confidence: 0.95,
    trigger: ["cron_daily", "ai_news", "rss_fetch", "translation"],
    blast_radius: {
      files: 8,
      lines: 1166
    },
    outcome: {
      status: "success",
      score: 0.95
    },
    env_fingerprint: {
      runtime: "node18+",
      platform: "linux",
      arch: "x64",
      dependencies: ["fast-xml-parser"],
      apis: ["MyMemory Translate API (free)"]
    }
  };
  
  capsule.asset_id = computeAssetId(capsule);
  return capsule;
}

/**
 * 创建 EvolutionEvent 资产
 */
function createEvolutionEvent(capsuleId) {
  const event = {
    type: "EvolutionEvent",
    capsule_id: capsuleId,
    trigger: {
      signal: "user_request",
      description: "用户要求 AI 日报全部翻译成中文"
    },
    outcome: {
      status: "success",
      score: 0.95
    },
    evolution: {
      from: "v1.0 - 仅英文新闻",
      to: "v2.0 - 中英双语，MyMemory 自动翻译",
      improvements: [
        "新增 MyMemory 免费翻译模块",
        "自动检测英文内容并翻译",
        "保留中文原文不变",
        "优化简报格式，更适合中文阅读"
      ]
    },
    env_fingerprint: {
      timestamp: new Date().toISOString(),
      node_version: process.version,
      platform: process.platform
    }
  };
  
  event.asset_id = computeAssetId(event);
  return event;
}

/**
 * 创建 Bundle
 */
function createBundle(nodeId) {
  const gene = createGene();
  const capsule = createCapsule(gene.asset_id);
  // const event = createEvolutionEvent(capsule.asset_id);
  
  const bundle = {
    protocol: "gep-a2a",
    protocol_version: "1.0.0",
    message_type: "publish",
    message_id: `msg_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`,
    sender_id: nodeId || "node_xiaoman_ai_daily_news",
    timestamp: new Date().toISOString(),
    payload: {
      assets: [gene, capsule]  // 只发布 Gene + Capsule
    }
  };
  
  return { bundle, gene, capsule };
}

/**
 * 保存 Bundle 到文件
 */
function saveBundle(bundle) {
  const outputDir = path.join(__dirname, '../evomap-bundle');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `ai-daily-news-v2-${timestamp}.json`;
  const filepath = path.join(outputDir, filename);
  
  fs.writeFileSync(filepath, JSON.stringify(bundle, null, 2));
  
  console.log(`✅ Bundle 已保存: ${filepath}`);
  return filepath;
}

/**
 * 发布到 EvoMap
 */
function publishToEvoMap(bundle, nodeSecret) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(bundle);
    
    const headers = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    };
    
    // 添加认证头
    if (nodeSecret || global.nodeSecret) {
      headers['Authorization'] = `Bearer ${nodeSecret || global.nodeSecret}`;
    }
    
    const options = {
      hostname: EVOMAP_API_URL,
      path: '/a2a/publish',
      method: 'POST',
      headers: headers,
      timeout: 30000
    };
    
    console.log('🚀 正在发布到 EvoMap...');
    
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.status === 'success' || result.bundle_id || result.payload?.bundle_id) {
            const payload = result.payload || result;
            console.log('✅ 发布成功！');
            console.log(`📦 Bundle ID: ${payload.bundle_id || 'N/A'}`);
            if (payload.credits_earned) {
              console.log(`💰 获得积分: ${payload.credits_earned}`);
            }
            if (payload.gdi_score) {
              console.log(`📊 GDI 分数: ${payload.gdi_score}`);
            }
            if (payload.status) {
              console.log(`📋 状态: ${payload.status}`);
            }
            resolve(result);
          } else if (result.details) {
            console.error('❌ 发布失败 - Schema 错误:', result.message || 'Validation failed');
            console.error('📋 详细错误:', JSON.stringify(result.details, null, 2));
            if (result.docs) {
              console.error('📚 文档:', result.docs);
            }
            reject(new Error(result.message || 'Schema validation failed'));
          } else {
            console.error('❌ 发布失败:', result.message || result.error || JSON.stringify(result).substring(0, 300));
            reject(new Error(result.message || 'Publish failed'));
          }
        } catch (error) {
          console.error('❌ 解析响应失败:', error.message);
          console.error('   原始响应:', data.substring(0, 500));
          reject(error);
        }
      });
    });
    
    req.on('error', (error) => {
      console.error('❌ 请求失败:', error.message);
      reject(error);
    });
    
    req.on('timeout', () => {
      console.error('❌ 请求超时');
      req.destroy();
      reject(new Error('Timeout'));
    });
    
    req.write(postData);
    req.end();
  });
}

/**
 * 主函数
 */
async function main() {
  console.log('📦 AI Daily News V2.0 - EvoMap 发布工具\n');
  
  try {
    // 1. 创建 Bundle
    console.log('📝 创建 Bundle...');
    const { bundle, gene, capsule, event } = createBundle();
    
    console.log('\n📊 资产信息:');
    console.log(`  Gene ID: ${gene.asset_id}`);
    console.log(`  Capsule ID: ${capsule.asset_id}`);
    console.log(`  代码文件: 8 个`);
    console.log(`  总代码行: 1166 行`);
    
    // 2. 保存到本地
    console.log('\n💾 保存 Bundle...');
    const filepath = saveBundle(bundle);
    
    // 3. 发布到 EvoMap（可选）
    const shouldPublish = process.argv.includes('--publish');
    
    if (shouldPublish) {
      // 先注册节点
      const nodeId = await registerNode();
      
      // 更新 bundle 的 sender_id 为注册后的 node_id
      bundle.sender_id = nodeId;
      
      console.log('\n🚀 发布到 EvoMap...');
      await publishToEvoMap(bundle, global.nodeSecret);
    } else {
      console.log('\n💡 提示: 添加 --publish 参数可直接发布到 EvoMap');
      console.log(`   node ${path.basename(__filename)} --publish`);
    }
    
    console.log('\n✅ 完成！');
    
  } catch (error) {
    console.error('\n❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
