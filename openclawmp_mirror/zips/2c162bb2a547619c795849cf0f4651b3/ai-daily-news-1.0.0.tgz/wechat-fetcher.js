// wechat-fetcher.js - 浏览器抓取微信公众号
import puppeteer from 'puppeteer';

const WECHAT_ACCOUNTS = [
  {
    name: '硬AI',
    id: 'yingai',
    url: 'https://mp.weixin.qq.com/s?__biz=MzI5NjQ3MDk2MQ==',
    type: 'AI深度分析'
  },
  {
    name: 'AI科技评论',
    id: 'aitechtalk', 
    url: 'https://mp.weixin.qq.com/s?__biz=MzA5NjEyMDUyMA==',
    type: 'AI产品动态'
  },
  {
    name: '赛博禅心',
    id: 'saibochanxin',
    url: 'https://mp.weixin.qq.com/s?__biz=MzU5NjQxNzQ3Mw==',
    type: 'AI哲学思考'
  },
  {
    name: 'FounderPark',
    id: 'founderpark',
    url: 'https://mp.weixin.qq.com/s?__biz=MzAxMzgyMjU1MA==',
    type: '创业者视角'
  }
];

export async function fetchWechatArticles() {
  const articles = [];
  
  console.log('🌐 启动浏览器抓取微信公众号...');
  
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    for (const account of WECHAT_ACCOUNTS) {
      console.log(`  📱 ${account.name}...`);
      
      const page = await browser.newPage();
      
      // 设置User-Agent
      await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15');
      
      try {
        // 访问公众号历史文章页面
        await page.goto(account.url, { 
          waitUntil: 'networkidle2',
          timeout: 30000 
        });
        
        // 等待文章列表加载
        await page.waitForSelector('.rich_media_content, .weui_media_box', { timeout: 10000 });
        
        // 提取文章
        const accountArticles = await page.evaluate(() => {
          const items = [];
          const articles = document.querySelectorAll('.weui_media_box, .rich_media_content');
          
          articles.forEach((article, index) => {
            if (index >= 5) return; // 只取前5篇
            
            const titleEl = article.querySelector('.weui_media_title, h2');
            const linkEl = article.querySelector('a');
            const timeEl = article.querySelector('.weui_media_desc_extra');
            
            if (titleEl) {
              items.push({
                title: titleEl.textContent.trim(),
                link: linkEl ? linkEl.href : window.location.href,
                pubDate: timeEl ? timeEl.textContent.trim() : new Date().toISOString(),
                source: '微信公众号'
              });
            }
          });
          
          return items;
        });
        
        articles.push(...accountArticles.map(a => ({
          ...a,
          account: account.name,
          accountType: account.type
        })));
        
        console.log(`     ✅ ${accountArticles.length} 篇文章`);
        
      } catch (err) {
        console.log(`     ❌ ${err.message}`);
      } finally {
        await page.close();
      }
      
      // 延迟避免被封
      await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 1000));
    }
    
  } finally {
    await browser.close();
  }
  
  console.log(`✅ 微信公众号抓取完成: ${articles.length} 篇文章\n`);
  return articles;
}

// 备用方案：使用Sogou微信搜索
export async function fetchWechatViaSogou(keyword = 'AI') {
  const articles = [];
  
  console.log('🔍 通过Sogou搜索微信公众号...');
  
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    
    // Sogou微信搜索
    const searchUrl = `https://weixin.sogou.com/weixin?type=2&query=${encodeURIComponent(keyword)}&tsn=1`;
    
    await page.goto(searchUrl, { waitUntil: 'networkidle2', timeout: 30000 });
    
    // 等待结果加载
    await page.waitForSelector('.news-list li', { timeout: 10000 });
    
    const results = await page.evaluate(() => {
      const items = [];
      const list = document.querySelectorAll('.news-list li');
      
      list.forEach((item, index) => {
        if (index >= 10) return;
        
        const titleEl = item.querySelector('h3 a');
        const summaryEl = item.querySelector('.txt-box p');
        const accountEl = item.querySelector('.account');
        const timeEl = item.querySelector('.s2');
        
        if (titleEl) {
          items.push({
            title: titleEl.textContent.trim(),
            link: titleEl.href,
            content: summaryEl ? summaryEl.textContent.trim() : '',
            source: accountEl ? accountEl.textContent.trim() : '微信公众号',
            pubDate: timeEl ? timeEl.textContent.trim() : new Date().toISOString()
          });
        }
      });
      
      return items;
    });
    
    articles.push(...results);
    console.log(`✅ Sogou搜索完成: ${results.length} 篇文章\n`);
    
  } catch (err) {
    console.log(`❌ Sogou搜索失败: ${err.message}\n`);
  } finally {
    await browser.close();
  }
  
  return articles;
}
