// fetcher.js - 抓取新闻
import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import { XMLParser } from 'fast-xml-parser';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 加载配置
function loadConfig() {
  const configPath = path.join(__dirname, 'config.json');
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

// 随机 User-Agent 列表
const userAgents = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15'
];

// HTTP 请求（支持重定向和反爬）
function fetchURL(url, options = {}, maxRedirects = 3) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) {
      reject(new Error('Too many redirects'));
      return;
    }
    
    const client = url.startsWith('https:') ? https : http;
    const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];
    
    const req = client.get(url, {
      timeout: 30000,
      headers: {
        'User-Agent': randomUA,
        'Accept': 'application/rss+xml,application/xml,text/xml,*/*',
        'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8',
        // 不请求压缩内容，避免需要解压
        // 'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        ...options.headers
      }
    }, (res) => {
      // 处理重定向
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        const redirectUrl = new URL(res.headers.location, url).toString();
        console.log(`     ↪️  Redirect to: ${redirectUrl}`);
        fetchURL(redirectUrl, options, maxRedirects - 1)
          .then(resolve)
          .catch(reject);
        return;
      }
      
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ statusCode: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout'));
    });
  });
}

// 获取文本内容（处理CDATA和对象）
function getText(val) {
  if (typeof val === 'string') return val;
  if (val && typeof val === 'object') {
    return val['#text'] || val.__cdata || JSON.stringify(val);
  }
  return '';
}

// 解析 RSS
function parseRSS(xml) {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    parseTagValue: false,
    trimValues: true,
    cdataPropName: '__cdata'
  });
  return parser.parse(xml);
}

// 抓取 RSS 源
async function fetchRSS(source, options = {}) {
  const { timeout = 15000, maxRetries = 2, retryDelay = 1000 } = options;
  
  console.log(`  🔍 ${source.name}...`);
  
  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // 添加延迟避免请求过快
      if (attempt > 0) {
        console.log(`     🔄 重试第 ${attempt + 1} 次...`);
        await new Promise(resolve => setTimeout(resolve, retryDelay));
      } else {
        await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 500));
      }
      
      const { statusCode, body } = await fetchURL(source.url, { 
        headers: source.headers || {},
        timeout 
      });
      
      if (statusCode !== 200) {
        console.log(`     ❌ HTTP ${statusCode}`);
        continue;
      }
      
      // 检查返回内容
      if (!body || body.trim().length === 0) {
        console.log(`     ⚠️  返回内容为空`);
        continue;
      }
      
      // 检查是否是HTML错误页面
      if (body.includes('<!DOCTYPE html>') || body.includes('<html')) {
        console.log(`     ⚠️  返回HTML而非XML (可能是反爬拦截)`);
        continue;
      }
      
      let feed;
      try {
        feed = parseRSS(body);
      } catch (parseErr) {
        console.log(`     ⚠️  XML解析失败: ${parseErr.message}`);
        continue;
      }
      
      // 处理不同 RSS 格式
      let items = [];
      if (feed.rss?.channel?.item) {
        items = feed.rss.channel.item;
      } else if (feed.feed?.entry) {
        // Atom 格式
        items = feed.feed.entry.map(entry => ({
          title: getText(entry.title),
          link: entry.link?.['@_href'] || getText(entry.link),
          pubDate: entry.updated || entry.published,
          description: getText(entry.summary) || getText(entry.content)
        }));
      }
      
      const itemArray = Array.isArray(items) ? items : (items ? [items] : []);
      
      // 只保留最近24小时的新闻
      const now = new Date();
      const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      
      // AI关键词过滤
      const aiKeywords = ['AI', '人工智能', '大模型', 'ChatGPT', 'OpenAI', 'Claude', '机器人', 'Robot', '大语言模型', 'LLM', '生成式AI', 'AIGC', '智能驾驶', '自动驾驶', '算法', '深度学习', '机器学习', '神经网络', 'GPT', '算力', '芯片', '半导体', '英伟达', 'Nvidia', 'artificial intelligence', 'machine learning', 'deep learning', 'neural network', 'generative AI', 'foundation model'];
      
      // 排除关键词
      const excludeKeywords = ['恒生科技指数', 'A股三大指数', '沪指', '深成指', '创业板指', '盘初跌', '开盘跌', '涨超', '跌超', '成交额突破', '两市成交'];
      const medicalKeywords = ['创新药', '医疗IPO', '新药BD', '阿斯利康', '生物制药', '医疗健康赛道', '药企'];
      
      const recentItems = itemArray.filter(item => {
        const pubDate = new Date(getText(item.pubDate) || Date.now());
        const isRecent = pubDate >= oneDayAgo;
        
        const title = getText(item.title).toLowerCase();
        const content = getText(item.description).toLowerCase();
        const text = title + ' ' + content;
        
        const hasAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
        const hasExclude = excludeKeywords.some(kw => text.includes(kw.toLowerCase()));
        const isMedical = source.name === '36氪' && medicalKeywords.some(kw => text.includes(kw.toLowerCase()));
        
        return isRecent && hasAI && !hasExclude && !isMedical;
      });
      
      console.log(`     ✅ ${recentItems.length} 条 (24小时内，AI相关)`);
      
      return recentItems.slice(0, 10).map(item => ({
        title: getText(item.title).substring(0, 200),
        url: getText(item.link) || (typeof item.link === 'object' ? item.link?.['@_href'] : item.link) || '',
        author: getText(item.author) || getText(item['dc:creator']) || '',
        content: getText(item.description).substring(0, 500),
        published: getText(item.pubDate) || new Date().toISOString(),
        source: source.name
      }));
      
    } catch (e) {
      lastError = e;
      if (attempt < maxRetries - 1) {
        console.log(`     ⚠️  ${e.message}，准备重试...`);
      }
    }
  }
  
  console.log(`     ❌ ${lastError?.message || '抓取失败'}`);
  return [];
}

// 主抓取函数
export async function fetchNews() {
  console.log('📡 抓取新闻...\n');
  
  const config = loadConfig();
  const allItems = [];
  
  // 抓取所有RSS源（国内源优先，国外源失败快速跳过）
  console.log(`  共 ${config.sources.length} 个新闻源\n`);
  
  for (const source of config.sources) {
    if (source.type === 'rss') {
      const items = await fetchRSS(source, config.fetchOptions);
      allItems.push(...items);
    }
  }
  
  // 按时间排序
  allItems.sort((a, b) => new Date(b.published) - new Date(a.published));
  
  console.log(`\n📊 总计: ${allItems.length} 条新闻`);
  return allItems;
}