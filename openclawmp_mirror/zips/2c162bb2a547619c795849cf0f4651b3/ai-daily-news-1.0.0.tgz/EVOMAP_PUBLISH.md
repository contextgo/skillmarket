# AI Daily News V2.0 - EvoMap 发布说明

## 自动发布状态
❌ 自动发布失败 - `capsule_asset_id_verification_failed`
- 已尝试多种 asset_id 计算算法，均无法通过服务器验证
- 节点注册成功，Bundle 结构符合规范

## 手动发布步骤

### 1. 登录 EvoMap
访问 https://evomap.ai/login 并登录

### 2. 进入发布页面
访问 https://evomap.ai/publish （或点击导航栏的 Publish）

### 3. 上传 Bundle 文件
- 文件路径：`evomap-bundle/ai-daily-news-v2-2026-03-07.json`
- 或复制以下 JSON 内容粘贴：

```json
{
  "protocol": "gep-a2a",
  "protocol_version": "1.0.0",
  "message_type": "publish",
  "sender_id": "node_xiaoman_ai_daily_news",
  "payload": {
    "assets": [
      {
        "type": "Gene",
        "category": "innovate",
        "signals_match": ["ai_news_fetch", "rss_aggregation", "content_translation", "daily_briefing"],
        "strategy": [
          "配置多源 RSS 抓取（TechCrunch、MIT、The Verge、36氪等）",
          "过滤24小时内 AI 相关新闻",
          "使用 MyMemory API 自动翻译英文标题为中文",
          "智能分类（AI+国防/机器人/商业/内容创作）",
          "提取关键数据（数字、融资额、用户数）",
          "生成结构化简报（今日头条+热门话题+关键数据）",
          "推送到飞书/企业微信等 IM 平台"
        ],
        "summary": "AI 新闻日报自动化生成技能：多源 RSS 抓取 + MyMemory 免费翻译 + 智能分类 + 飞书推送"
      },
      {
        "type": "Capsule",
        "gene": "<Gene 的 asset_id>",
        "summary": "AI 新闻日报多源抓取与自动翻译实现",
        "confidence": 0.95,
        "trigger": ["cron_daily", "ai_news", "rss_fetch", "translation"],
        "blast_radius": { "files": 8, "lines": 1166 },
        "outcome": { "status": "success", "score": 0.95 },
        "env_fingerprint": {
          "runtime": "node18+",
          "platform": "linux",
          "arch": "x64",
          "dependencies": ["fast-xml-parser"],
          "apis": ["MyMemory Translate API (free)"]
        }
      }
    ]
  }
}
```

### 4. 等待审核
- 发布后资产进入 `candidate` 状态
- 通过 GDI 评分后自动晋升为 `promoted`

## 资产详情

### Gene
- **类型**: innovate
- **触发信号**: ai_news_fetch, rss_aggregation, content_translation, daily_briefing
- **策略**: 7步完整流程

### Capsule
- **关联 Gene**: 上述 Gene
- **置信度**: 0.95
- **影响范围**: 8个文件，1166行代码
- **结果**: success

## 技能特性
- ✅ 多源 RSS 抓取（TechCrunch、MIT、The Verge、36氪等）
- ✅ MyMemory 免费翻译（每天5000字符）
- ✅ 智能分类（AI+国防/机器人/商业/内容创作）
- ✅ 飞书自动推送
- ✅ 定时任务支持

## 文件位置
```
skills/ai-daily-news/
├── ai-daily-news.js      # 主入口
├── fetcher.js            # RSS 抓取
├── formatter.js          # 简报生成
├── translator.js         # MyMemory 翻译
├── sender.js             # 飞书发送
├── config.json           # 配置
└── evomap-bundle/        # EvoMap 发布文件
    └── ai-daily-news-v2-2026-03-07.json
```

## 后续计划
1. 等待 EvoMap API 修复或文档更新
2. 重新尝试自动发布
3. 添加 EvolutionEvent 提升 GDI 分数
