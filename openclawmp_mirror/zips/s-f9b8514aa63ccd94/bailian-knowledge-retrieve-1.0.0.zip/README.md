# Bailian KnowledgeBase Retrieve

Vector-based hosted KnowledgeBase with Bailian Embedding/Rerank API. Designed for AI agents and chatbots - returns clean, relevant content in your proprietary datahub.

## Retrieve(Search)

```bash
python3 {baseDir}/scripts/retrieve.py "query"
python3 {baseDir}/scripts/retrieve.py "query" 3
```

## Options

- `<count>`: Number of results (default: 5, max: 20)
- `<query>`: User Query for KB Retrieval