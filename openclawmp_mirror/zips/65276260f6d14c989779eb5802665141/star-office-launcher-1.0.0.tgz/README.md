# 使用嵌入式Python安装Star Office

一键启动 Star Office UI 像素办公室看板的 Skill，专门解决 StepClaw 桌面端嵌入式 Python 环境下的各种安装和启动问题。

## 解决的问题

在 StepClaw 桌面端启动 Star Office UI 时，会遇到以下问题：

- **嵌入式 Python 3.11 的 `python311._pth` 禁用了 `site-packages`**，导致安装的包无法被 import
- **嵌入式 Python 没有 pip**，无法直接安装依赖
- **系统自带 Python 3.8 版本过低**，不支持 `int | None` 联合类型语法
- **pip 默认源（豆瓣镜像）不可用**，需要切换到官方 PyPI
- **`sys.path` 不包含脚本目录**，导致 `ModuleNotFoundError: No module named 'security_utils'`

本 Skill 将以上所有问题封装为一个自动化启动脚本，一条命令完成环境修复、依赖安装和服务启动。

## 使用方法

确保已安装 Star Office UI skill（作为 `star-office-launcher` 的兄弟目录）：

```bash
openclawmp install skill/3b784f87e170e12a3163075f71646cfc --target-dir ./skills
```

然后运行启动脚本：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/launch.ps1
```

启动后访问 http://127.0.0.1:18791 即可看到像素办公室。

## 适用环境

- Windows + StepClaw 桌面端（嵌入式 Python 3.11）
- 也兼容系统安装的 Python 3.10+
