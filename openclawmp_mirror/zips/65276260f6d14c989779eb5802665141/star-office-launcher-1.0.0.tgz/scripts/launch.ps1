#!/usr/bin/env pwsh
<#
.SYNOPSIS
  Launch Star Office UI backend (Flask on port 18791).
.DESCRIPTION
  1. Locates the star-office-ui skill directory (sibling or configurable).
  2. Ensures Python 3.10+ is available (prefers StepFun embedded Python 3.11).
  3. Installs Flask + Pillow if missing.
  4. Patches app.py sys.path if needed (embedded Python ._pth issue).
  5. Copies state.sample.json → state.json on first run.
  6. Starts the Flask server in the foreground.
#>
param(
    [string]$OfficeDir,
    [int]$Port = 18791
)

$ErrorActionPreference = 'Stop'

# ---------- locate star-office-ui ----------
if (-not $OfficeDir) {
    # default: sibling skill directory
    $OfficeDir = Join-Path (Split-Path $PSScriptRoot -Parent | Split-Path -Parent) 'star-office-ui'
}
if (-not (Test-Path "$OfficeDir\backend\app.py")) {
    Write-Error "star-office-ui not found at $OfficeDir. Pass -OfficeDir <path>."
    exit 1
}
Write-Host "[star-office-launcher] Office dir: $OfficeDir"

# ---------- find Python 3.10+ ----------
$stepfunPy = "$env:LOCALAPPDATA\StepFun\StepFun\resources\app.asar.unpacked\tools\win\python-3.11.9\python.exe"
$candidates = @()
if (Test-Path $stepfunPy) { $candidates += $stepfunPy }
# also check system pythons
foreach ($cmd in @('python3', 'python')) {
    $found = Get-Command $cmd -ErrorAction SilentlyContinue
    if ($found) { $candidates += $found.Source }
}

$pyExe = $null
foreach ($c in $candidates) {
    $ver = & $c -c "import sys; print(sys.version_info[:2])" 2>$null
    if ($ver -match '\(3,\s*(\d+)\)') {
        $minor = [int]$Matches[1]
        if ($minor -ge 10) { $pyExe = $c; break }
    }
}
if (-not $pyExe) {
    Write-Error "No Python >= 3.10 found. Install Python 3.10+ first."
    exit 1
}
Write-Host "[star-office-launcher] Using Python: $pyExe"

# ---------- fix embedded Python ._pth if needed ----------
$pthFile = Join-Path (Split-Path $pyExe) 'python311._pth'
if (Test-Path $pthFile) {
    $content = Get-Content $pthFile -Raw
    if ($content -match '#import site') {
        Write-Host "[star-office-launcher] Enabling site-packages in python311._pth ..."
        $content = $content -replace '#import site', 'import site'
        Set-Content $pthFile $content -NoNewline
    }
}

# ---------- ensure pip ----------
$hasPip = & $pyExe -c "import pip" 2>$null; $pipOk = ($LASTEXITCODE -eq 0)
if (-not $pipOk) {
    Write-Host "[star-office-launcher] Installing pip via get-pip.py ..."
    $getPip = Join-Path $env:TEMP 'get-pip.py'
    Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile $getPip
    & $pyExe $getPip -i 'https://pypi.org/simple/'
    if ($LASTEXITCODE -ne 0) { Write-Error "Failed to install pip."; exit 1 }
}

# ---------- install dependencies ----------
$hasFlask = & $pyExe -c "import flask" 2>$null; $flaskOk = ($LASTEXITCODE -eq 0)
$hasPillow = & $pyExe -c "import PIL" 2>$null; $pillowOk = ($LASTEXITCODE -eq 0)
if (-not $flaskOk -or -not $pillowOk) {
    Write-Host "[star-office-launcher] Installing Flask + Pillow ..."
    & $pyExe -m pip install flask==3.0.2 pillow==10.4.0 -i 'https://pypi.org/simple/' -q
    if ($LASTEXITCODE -ne 0) { Write-Error "Failed to install dependencies."; exit 1 }
}

# ---------- patch app.py sys.path if needed ----------
$appPy = Join-Path $OfficeDir 'backend\app.py'
$appContent = Get-Content $appPy -Raw -Encoding UTF8
$patchLine = "import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))"
if ($appContent -notmatch 'sys\.path\.insert.*dirname.*abspath.*__file__') {
    Write-Host "[star-office-launcher] Patching app.py with sys.path fix ..."
    $appContent = $appContent -replace '(#!/usr/bin/env python3\r?\n"""Star Office UI.*?""")', "`$1`n$patchLine"
    Set-Content $appPy $appContent -Encoding UTF8 -NoNewline
}

# ---------- ensure state.json ----------
$stateJson = Join-Path $OfficeDir 'state.json'
$stateSample = Join-Path $OfficeDir 'state.sample.json'
if (-not (Test-Path $stateJson) -and (Test-Path $stateSample)) {
    Write-Host "[star-office-launcher] Creating state.json from sample ..."
    Copy-Item $stateSample $stateJson
}

# ---------- launch ----------
Write-Host "[star-office-launcher] Starting Star Office UI on port $Port ..."
$env:FLASK_RUN_PORT = $Port
Set-Location (Join-Path $OfficeDir 'backend')
& $pyExe app.py
