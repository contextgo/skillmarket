---
name: star-office-launcher
description: "Install, configure, and launch the Star Office UI pixel-art dashboard for OpenClaw. Use when the user wants to start/run/launch Star Office UI, troubleshoot its Flask backend failing to start, fix Python dependency or import errors related to Star Office UI, or set up the pixel office for the first time. Also triggers on mentions of port 18791, pixel office, or star office."
---

# Star Office Launcher

One-command launcher for [Star Office UI](https://openclawmp.stepfun.com/asset/3b784f87e170e12a3163075f71646cfc) — a pixel-art office dashboard where AI agents move between workstations based on their status.

## Prerequisites

- **Python ≥ 3.10** (the app uses `int | None` union syntax)
- **Star Office UI skill installed** as a sibling directory (`../star-office-ui/`)

If Star Office UI is not installed yet:

```bash
openclawmp install skill/3b784f87e170e12a3163075f71646cfc --target-dir ./skills
```

## Quick Start

Run the launcher script — it handles everything automatically:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/launch.ps1
```

With a custom Star Office UI path:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/launch.ps1 -OfficeDir "C:\path\to\star-office-ui"
```

The script will:
1. Find Python 3.10+ (prefers StepFun embedded Python 3.11)
2. Fix the embedded Python `._pth` file to enable `site-packages` if needed
3. Install `pip` via `get-pip.py` if missing
4. Install `flask` and `pillow` if missing
5. Patch `app.py` with `sys.path` fix for embedded Python's import issue
6. Create `state.json` from the sample on first run
7. Start the Flask server on `http://127.0.0.1:18791`

## Common Issues

### `ModuleNotFoundError: No module named 'security_utils'`

The embedded Python's `python311._pth` file blocks normal module discovery. The launcher fixes this automatically. If running manually, either:
- Uncomment `import site` in `python311._pth`
- Add `sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))` to the top of `app.py`

### `TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`

Python version too old. The app requires Python ≥ 3.10 for union type syntax (`int | None`). Do not use Python 3.8/3.9.

### pip source connection failures (douban mirror)

The embedded Python may have a pip config pointing to an unreachable mirror. The launcher forces `https://pypi.org/simple/` as the index URL.

### `No module named pip` on embedded Python

The `._pth` file disables `site-packages` loading. The launcher fixes this before installing pip.

## Changing Status

After launching, update the agent status from the project root:

```bash
python set_state.py STATUS "MESSAGE"
```

Statuses: `writing`, `syncing`, `error`, `idle`

## Security

Default sidebar passcode is `1234`. Change it via environment variable before launch:

```powershell
$env:ASSET_DRAWER_PASS = "your-strong-pass"
```
